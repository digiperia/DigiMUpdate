/**
 * Hospitable quote hydration: progressive card pricing.
 * - Fires immediately for all visible cards (no IntersectionObserver delay).
 * - 3 concurrent AJAX requests for instant feel.
 * - Renders full price: original w/ strikethrough, total, "for X nights", discount lines.
 * - After all quotes load: applies Breezy Choice badges to top 3 cheapest.
 * - Updates data-price on card for client-side price filter compatibility.
 * - Retries failed requests once before giving up.
 * - Handles bfcache (back/forward navigation) to re-hydrate stale cards.
 */
(function () {
  if (typeof window === 'undefined' || typeof document === 'undefined') return;
  var config = window.digimQuoteConfig;
  if (!config || !config.ajax_url) return;

  var AJAX_URL = config.ajax_url;
  var ACTION = config.action || 'get_property_quote';
  var NONCE = config.nonce || '';
  var MAX_CONCURRENT = 3;
  var MAX_RETRIES = 1;

  var quoteCache = Object.create(null);
  var inFlight = Object.create(null);
  var jobQueue = [];
  var activeCount = 0;
  var processing = false;
  var totalJobs = 0;
  var completedJobs = 0;
  var cardQuotes = [];
  var initRunning = false;

  function buildCacheKey(uuid, checkin, checkout, guests, pets) {
    pets = pets || 0;
    return 'hosp_quote_' + uuid + '_' + checkin + '_' + checkout + '_' + guests + '_' + pets;
  }

  function formatPrice(amount, symbol) {
    symbol = symbol || '$';
    var rounded = Math.round(amount);
    return symbol + rounded.toLocaleString('en-US');
  }

  function processQueue() {
    if (processing) return;
    processing = true;
    drainQueue();
  }

  function drainQueue() {
    while (activeCount < MAX_CONCURRENT && jobQueue.length > 0) {
      var job = jobQueue.shift();
      if (!job) continue;
      var cacheKey = job.cacheKey;
      if (inFlight[cacheKey]) continue;
      if (quoteCache[cacheKey]) {
        applyQuoteToCard(job.cardEl, quoteCache[cacheKey], job);
        onJobDone();
        continue;
      }

      activeCount += 1;
      inFlight[cacheKey] = true;
      fetchQuote(job);
    }
    if (jobQueue.length === 0 && activeCount === 0) {
      processing = false;
    }
  }

  function onJobDone() {
    completedJobs++;
    if (completedJobs >= totalJobs) {
      applyBestValue();
    }
  }

  function fetchQuote(job) {
    var cacheKey = job.cacheKey;
    var retries = job._retries || 0;
    var formData = new FormData();
    formData.append('action', ACTION);
    formData.append('uuid', job.uuid);
    formData.append('checkin', job.checkin);
    formData.append('checkout', job.checkout);
    formData.append('guests', String(job.guests));
    formData.append('pets', String(job.pets != null ? job.pets : 0));
    if (NONCE) formData.append('nonce', NONCE);

    fetch(AJAX_URL, { method: 'POST', credentials: 'same-origin', body: formData })
      .then(function (response) {
        if (!response.ok) throw new Error('Network ' + response.status);
        return response.json();
      })
      .then(function (json) {
        if (!json || !json.success || !json.data) throw new Error('Invalid response');
        var data = json.data;
        quoteCache[cacheKey] = data;
        applyQuoteToCard(job.cardEl, data, job);
      })
      .catch(function () {
        if (retries < MAX_RETRIES) {
          job._retries = retries + 1;
          jobQueue.push(job);
        } else {
          setCardLoading(job.cardEl, false);
        }
      })
      .finally(function () {
        activeCount -= 1;
        delete inFlight[cacheKey];
        onJobDone();
        if (jobQueue.length > 0 && activeCount < MAX_CONCURRENT) {
          drainQueue();
        } else if (jobQueue.length === 0 && activeCount === 0) {
          processing = false;
        }
      });
  }

  function applyQuoteToCard(cardEl, data, job) {
    if (!cardEl) return;

    setCardLoading(cardEl, false);

    // final_price includes subtotal, cleaning fee, service fee, pet fee (when present), minus discounts
    var finalPrice = Number(data.final_price || 0);
    if (finalPrice <= 0) return;

    var totalWithoutTaxes = Number(data.total_without_taxes || 0);
    var hasDiscount = !!data.has_discount;
    var symbol = data.symbol || '$';
    var nights = Number(data.nights || 0);
    var discounts = data.discounts || [];
    var checkinFmt = data.checkin_fmt || '';
    var checkoutFmt = data.checkout_fmt || '';

    if (nights <= 0 && job) {
      var d1 = new Date(job.checkin + 'T00:00:00');
      var d2 = new Date(job.checkout + 'T00:00:00');
      nights = Math.max(1, Math.round((d2 - d1) / 86400000));
    }

    var originalEl = cardEl.querySelector('.js-price-original');
    var totalEl = cardEl.querySelector('.js-price-total');
    var forNightsEl = cardEl.querySelector('.digim-price-for-nights');
    var pricingSection = cardEl.querySelector('.digim-pricing-section');
    if (!pricingSection) return;

    if (hasDiscount && totalWithoutTaxes > 0) {
      if (originalEl) {
        originalEl.textContent = formatPrice(totalWithoutTaxes, symbol);
        originalEl.style.display = '';
      }
    } else {
      if (originalEl) { originalEl.style.display = 'none'; }
    }
    if (totalEl) {
      totalEl.textContent = formatPrice(finalPrice, symbol);
    }
    if (forNightsEl) {
      forNightsEl.style.display = '';
    }

    var oldLines = pricingSection.querySelectorAll('.digim-price-discount-line');
    for (var x = 0; x < oldLines.length; x++) { oldLines[x].parentNode.removeChild(oldLines[x]); }
    if (discounts && discounts.length > 0) {
      for (var i = 0; i < discounts.length; i++) {
        var d = discounts[i];
        if (d.name && d.amount > 0) {
          var line = document.createElement('p');
          line.className = 'digim-price-discount-line';
          line.textContent = d.name + ' -' + symbol + Number(d.amount).toFixed(2);
          pricingSection.appendChild(line);
        }
      }
    }

    cardEl.setAttribute('data-price', String(finalPrice));

    // Progressive price filter — hide this card if outside the active price range
    filterCardByPrice(cardEl, finalPrice);

    var uuid = job ? job.uuid : (cardEl.getAttribute('data-uuid') || '');
    if (uuid && finalPrice > 0) {
      cardQuotes.push({ uuid: uuid, price: finalPrice, cardEl: cardEl });
    }
  }

  function getActivePriceRange() {
    var minEl = document.getElementById('digim-filter-price-min');
    var maxEl = document.getElementById('digim-filter-price-max');
    if (!minEl && !maxEl) {
      var url = new URL(window.location.href);
      var pMin = url.searchParams.get('filter_price_min');
      var pMax = url.searchParams.get('filter_price_max');
      return {
        min: pMin ? parseFloat(pMin) : null,
        max: pMax ? parseFloat(pMax) : null
      };
    }
    return {
      min: minEl ? parseFloat(minEl.value) || null : null,
      max: maxEl ? parseFloat(maxEl.value) || null : null
    };
  }

  function filterCardByPrice(cardEl, price) {
    var range = getActivePriceRange();
    if (range.min == null && range.max == null) return;
    if ((range.min === 0 || range.min == null) && (range.max == null || range.max >= 10000)) return;
    var inRange = (range.min == null || price >= range.min) && (range.max == null || price <= range.max);
    cardEl.style.display = inRange ? '' : 'none';
  }

  function setCardLoading(cardEl, isLoading) {
    if (!cardEl) return;
    var spinnerEl = cardEl.querySelector('.js-price-spinner');
    if (!spinnerEl) return;
    spinnerEl.style.display = isLoading ? 'inline-block' : 'none';
  }

  function applyBestValue() {
    // Final price filter pass — all quotes are loaded, do full grid filter
    if (typeof window.digimApplyPriceFilter === 'function') {
      window.digimApplyPriceFilter();
    }

    if (cardQuotes.length < 1) return;

    // Remove all previous tier badges
    var oldSels = '.digim-best-value-badge, .digim-great-value-badge, .digim-trending-badge';
    var oldBadges = document.querySelectorAll(oldSels);
    for (var i = 0; i < oldBadges.length; i++) {
      oldBadges[i].parentNode.removeChild(oldBadges[i]);
    }

    // --- Score every card ---
    var LOG101 = Math.log10(101);
    var items = [];
    var sumPrice = 0; var sumRating = 0; var sumReviews = 0; var cntRating = 0;

    for (var s = 0; s < cardQuotes.length; s++) {
      var cq = cardQuotes[s];
      var card = cq.cardEl;
      if (!card) continue;

      var ratingEl = card.querySelector('.rating-value');
      var countEl = card.querySelector('.rating-count');
      var rawRating = ratingEl && ratingEl.textContent.trim().length > 0 ? parseFloat(ratingEl.textContent) : -1;
      var reviewCount = countEl && countEl.textContent.trim().length > 0
        ? (parseInt(countEl.textContent.replace(/[()]/g, ''), 10) || 0)
        : 0;

      var normRating = rawRating > 0 ? Math.min(rawRating / 5.0, 1.0) : 0.5;
      var normVolume = reviewCount > 0 ? Math.min(Math.log10(reviewCount + 1) / LOG101, 1.0) : 0.0;
      var score = 0.60 * normRating + 0.40 * normVolume;

      var entry = {
        uuid: cq.uuid, price: cq.price, cardEl: card, score: score,
        rating: rawRating, reviews: reviewCount, badge: ''
      };
      items.push(entry);
      sumPrice += cq.price;
      sumReviews += reviewCount;
      if (rawRating > 0) { sumRating += rawRating; cntRating++; }
    }

    if (items.length === 0) return;

    // --- Breezy Choice: top 20% by score (min 1) ---
    items.sort(function (a, b) { return b.score - a.score; });
    var topCount = Math.max(1, Math.ceil(items.length * 0.20));
    for (var t = 0; t < topCount; t++) {
      items[t].badge = 'breezy_choice';
    }

    // --- Averages for secondary badges ---
    var avgPrice = sumPrice / items.length;
    var avgRating = cntRating > 0 ? sumRating / cntRating : 0;
    var avgReviews = sumReviews / items.length;

    // --- Great Value: high quality + below-avg price (cap 15%) ---
    var gvMax = Math.max(1, Math.ceil(items.length * 0.15));
    var gvCount = 0;
    for (var g = 0; g < items.length && gvCount < gvMax; g++) {
      if (items[g].badge) continue;
      var ratingOk = items[g].rating <= 0 || items[g].rating >= avgRating;
      if (ratingOk && items[g].price <= avgPrice * 0.90) {
        items[g].badge = 'great_value';
        gvCount++;
      }
    }

    // --- Trending: review count well above average (cap 15%) ---
    var trMax = Math.max(1, Math.ceil(items.length * 0.15));
    var trCount = 0;
    var trendingThreshold = avgReviews * 1.5;
    for (var r = 0; r < items.length && trCount < trMax; r++) {
      if (items[r].badge) continue;
      if (items[r].reviews > trendingThreshold && items[r].reviews >= 3) {
        items[r].badge = 'trending';
        trCount++;
      }
    }

    // --- Render badges ---
    var badgeConfig = {
      breezy_choice: { cls: 'digim-best-value-badge',  dot: 'best-value-dot',  label: 'Breezy Choice' },
      great_value:   { cls: 'digim-great-value-badge', dot: 'great-value-dot', label: 'Great Value' },
      trending:      { cls: 'digim-trending-badge',    dot: 'trending-dot',    label: 'Trending' }
    };

    for (var j = 0; j < items.length; j++) {
      var it = items[j];
      if (!it.badge || !it.cardEl) continue;
      var mediaEl = it.cardEl.querySelector('.digim-card-media');
      if (!mediaEl) continue;

      var existingBadges = mediaEl.querySelectorAll('.digim-suggestion-badge, .digim-almost-booked-badge, .digim-almost-fully-booked-badge');
      var topPos = 12;
      for (var k = 0; k < existingBadges.length; k++) {
        topPos += 36;
      }

      var cfg = badgeConfig[it.badge];
      var badge = document.createElement('span');
      badge.className = cfg.cls;
      badge.style.top = topPos + 'px';
      badge.innerHTML = '<span class="' + cfg.dot + '" aria-hidden="true"></span>' + cfg.label;
      mediaEl.appendChild(badge);
    }
  }

  function initObserver() {
    if (initRunning) return;
    initRunning = true;

    var cards = document.querySelectorAll('.js-property-card');
    if (!cards || cards.length === 0) {
      initRunning = false;
      return;
    }

    // Full reset — clear all in-progress state so every card gets a fresh chance
    jobQueue = [];
    inFlight = Object.create(null);
    activeCount = 0;
    totalJobs = 0;
    completedJobs = 0;
    cardQuotes = [];
    processing = false;

    var toQueue = [];
    [].forEach.call(cards, function (cardEl) {
      if (cardEl.getAttribute('data-suggestion') === '1') return;

      var totalEl = cardEl.querySelector('.js-price-total');
      if (!totalEl) return;

      var existingPrice = (totalEl.textContent || '').trim();
      if (existingPrice.length > 0 && /[\d$€£]/.test(existingPrice)) return;

      var uuid = cardEl.getAttribute('data-uuid') || cardEl.getAttribute('data-property-uuid');
      var checkin = cardEl.getAttribute('data-checkin');
      var checkout = cardEl.getAttribute('data-checkout');
      var guestsAttr = cardEl.getAttribute('data-guests');
      var guests = guestsAttr ? parseInt(guestsAttr, 10) : 0;
      var petsAttr = cardEl.getAttribute('data-pets');
      var pets = petsAttr !== null && petsAttr !== '' ? parseInt(petsAttr, 10) : 0;
      if (isNaN(pets) || pets < 0) pets = 0;
      if (pets === 0) {
        var urlParams = typeof URL !== 'undefined' ? new URL(window.location.href).searchParams : null;
        if (urlParams && urlParams.get('pets')) pets = parseInt(urlParams.get('pets'), 10) || 0;
      }

      if (!uuid || !checkin || !checkout || guests <= 0) return;

      var cacheKey = buildCacheKey(uuid, checkin, checkout, guests, pets);

      toQueue.push({
        cardEl: cardEl,
        uuid: uuid,
        checkin: checkin,
        checkout: checkout,
        guests: guests,
        pets: pets,
        cacheKey: cacheKey,
        _retries: 0
      });
    });

    totalJobs = toQueue.length;
    initRunning = false;
    if (totalJobs === 0) return;

    for (var i = 0; i < toQueue.length; i++) {
      jobQueue.push(toQueue[i]);
    }
    processQueue();
  }

  window.digimInitQuoteHydration = initObserver;

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initObserver);
  } else {
    initObserver();
  }

  // Re-hydrate cards restored from bfcache (back/forward navigation)
  window.addEventListener('pageshow', function (e) {
    if (e.persisted) {
      quoteCache = Object.create(null);
      initObserver();
    }
  });
})();
