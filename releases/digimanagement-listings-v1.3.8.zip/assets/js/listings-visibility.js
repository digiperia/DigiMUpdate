/**
 * DigiM Listings admin: toggle "Hide on frontend" per property.
 */
(function ($) {
    'use strict';

    var L = window.digimListings || {};
    var $status = $('#digim-listings-status');
    var $totalEl = $('#digim-listings-count-total');
    var $visibleEl = $('#digim-listings-count-visible');
    var $hiddenEl = $('#digim-listings-count-hidden');

    function updateCounts(hiddenCount) {
        var total = typeof L.total === 'number' ? L.total : parseInt($totalEl.text(), 10) || 0;
        if (typeof hiddenCount !== 'number' || isNaN(hiddenCount)) {
            return;
        }
        var visible = Math.max(0, total - hiddenCount);
        $hiddenEl.text(hiddenCount);
        $visibleEl.text(visible);
    }

    function showNotice(message, type) {
        type = type || 'success';
        $status.removeClass('notice-success notice-error').addClass('notice-' + type).html(message).show();
        setTimeout(function () { $status.fadeOut(); }, 3000);
    }

    $('.digim-listing-toggle').on('change', function () {
        var $input = $(this);
        var uuid = $input.data('uuid');
        var hide = !$input.prop('checked'); // checkbox checked = show, so hide = !checked

        if (!uuid) return;

        var $row = $input.closest('tr');
        var $label = $row.find('.digim-toggle-label');
        $input.prop('disabled', true);

        $.post(L.ajax_url, {
            action: 'digim_toggle_listing_visibility',
            nonce: L.nonce,
            uuid: uuid,
            hide: hide ? '1' : '0'
        })
            .done(function (res) {
                if (res.success) {
                    var lbl = L.strings || {};
                    $label.text(hide ? (lbl.label_hidden_row || 'Hidden') : (lbl.label_shown_row || 'Shown'));
                    if (res.data && typeof res.data.hidden_count === 'number') {
                        updateCounts(res.data.hidden_count);
                    }
                    if (res.data && typeof res.data.total === 'number') {
                        L.total = res.data.total;
                        $totalEl.text(res.data.total);
                    }
                    showNotice(res.data && res.data.message ? res.data.message : (hide ? L.strings.saved : L.strings.shown), 'success');
                } else {
                    showNotice(L.strings.error || 'Error', 'error');
                    $input.prop('checked', !hide);
                }
            })
            .fail(function () {
                showNotice(L.strings.error || 'Error', 'error');
                $input.prop('checked', !hide);
            })
            .always(function () {
                $input.prop('disabled', false);
            });
    });
})(jQuery);
