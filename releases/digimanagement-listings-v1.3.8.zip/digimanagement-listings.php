<?php

/**
 * Plugin Name: DigiM
 * Plugin URI: https://digiperia.com
 * Description: A
 *  professional WordPress plugin that integrates with Hospitable API to display property listings with flexible shortcode parameters.
 * Version: 1.3.8
 * Author: Digiperia
 * Author URI: https://digiperia.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wml-hospitable
 * Domain Path: /languages
 * Requires at least: 5.0
 * Tested up to: 6.9.0
 * Requires PHP: 7.4
 * Network: false
 */

// === Plugin Path & URL Constants ===
define('DIGIMANAGEMENT_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('DIGIMANAGEMENT_PLUGIN_URL', plugin_dir_url(__FILE__));

/**
 * Prefer .min.css / .min.js when present (after npm run build:assets).
 * Returns ['path' => absolute path, 'url' => URL] for the asset.
 */
if (!function_exists('digim_asset')) {
  function digim_asset($rel) {
    $base_path = DIGIMANAGEMENT_PLUGIN_PATH;
    $base_url  = DIGIMANAGEMENT_PLUGIN_URL;
    $rel_min   = preg_replace('/\.(css|js)$/', '.min.$1', $rel);
    $path_min  = $base_path . $rel_min;
    $path_full = $base_path . $rel;
    if (file_exists($path_min)) {
      return ['path' => $path_min, 'url' => $base_url . $rel_min];
    }
    return ['path' => $path_full, 'url' => $base_url . $rel];
  }
}

require_once __DIR__ . '/plugin-update-checker/plugin-update-checker.php';

use YahnisElsts\PluginUpdateChecker\v5p6\PucFactory;

$myUpdateChecker = PucFactory::buildUpdateChecker(
  'https://raw.githubusercontent.com/digiperia/DigiMUpdate/main/digim-plugin-update.json',
  __FILE__,
  'digimanagement-listings'
);



// === Admin-only CSS (load everywhere in admin first; scope later once IDs known) ===
add_action('admin_enqueue_scripts', function () {
  $asset = digim_asset('assets/css/admin.css');
  if (!file_exists($asset['path'])) {
    error_log('DigiM admin.css not found at: ' . $asset['path']);
    return;
  }
  wp_enqueue_style('digim-admin', $asset['url'], [], filemtime($asset['path']));
});




// === Admin Pages ===
if (is_admin()) {
  require_once DIGIMANAGEMENT_PLUGIN_PATH . 'admin/menu.php';
  require_once DIGIMANAGEMENT_PLUGIN_PATH . 'admin/admin-settings.php';
}

// === Frontend Shortcode ===
require_once DIGIMANAGEMENT_PLUGIN_PATH . 'includes/shortcode.php';


// === Enqueue Plugin Styles & Scripts ===
add_action('wp_enqueue_scripts', function () {
  global $post;
  
  // Check if we should load the styles and scripts
  $should_load = false;
  
  // Check if shortcode exists in post content
  if (isset($post) && (has_shortcode($post->post_content, 'digimanagement_listings') || has_shortcode($post->post_content, 'digim_cards'))) {
    $should_load = true;
  }
  
  // Check if we're on a page that might contain listings (like /listings/)
  if (is_page() && (strpos($_SERVER['REQUEST_URI'], '/listings') !== false || 
                   strpos($_SERVER['REQUEST_URI'], 'listings') !== false)) {
    $should_load = true;
  }
  
  // Check if we're on a property single page
  if (get_query_var('dm_property_uuid')) {
    $should_load = true;
  }
  
  // Check if the current page template or content contains digim classes or shortcodes
  if (isset($post) && (strpos($post->post_content, 'digim-main') !== false || 
                      strpos($post->post_content, 'digimanagement') !== false ||
                      strpos($post->post_content, '[digim_cards') !== false ||
                      strpos($post->post_content, '[digimanagement_listings') !== false)) {
    $should_load = true;
  }
  
  // Fallback: Check if we're on any page that might need the plugin styles
  // This can be customized based on your specific needs
  $force_load_pages = ['listings', 'properties', 'search'];
  foreach ($force_load_pages as $page_slug) {
    if (is_page($page_slug) || strpos($_SERVER['REQUEST_URI'], $page_slug) !== false) {
      $should_load = true;
      break;
    }
  }
  
  if (!$should_load) return;

  // ✅ Leaflet CSS & JS
  wp_enqueue_style('leaflet', 'https://unpkg.com/leaflet/dist/leaflet.css');
  wp_enqueue_script('leaflet', 'https://unpkg.com/leaflet/dist/leaflet.js', [], null, true);

  // ✅ Leaflet Marker Cluster
  wp_enqueue_style('leaflet-cluster', 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css');
  wp_enqueue_script('leaflet-cluster', 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js', ['leaflet'], null, true);

  // ✅ Plugin Styles (ensure loaded after Leaflet to override; uses .min when built)
  $style_asset = digim_asset('assets/css/style.css');
  if (file_exists($style_asset['path'])) {
    wp_enqueue_style('digim-style', $style_asset['url'], [], filemtime($style_asset['path']));
  }

  // ✅ Plugin Frontend JS (map logic, interactivity; uses .min when built)
  $js_asset = digim_asset('assets/js/frontend.js');
  if (file_exists($js_asset['path'])) {
    wp_enqueue_script('digim-frontend', $js_asset['url'], ['jquery', 'leaflet', 'leaflet-cluster'], filemtime($js_asset['path']), true);
    wp_localize_script('digim-frontend', 'digimQuoteConfig', array(
      'ajax_url' => admin_url('admin-ajax.php'),
      'action' => 'get_property_quote',
      'nonce' => wp_create_nonce('digim_quote_nonce'),
    ));
  }

  // Quote hydration: progressive card pricing (max 2 concurrent, viewport-triggered)
  $quote_js = digim_asset('assets/js/quote-hydration.js');
  if (file_exists($quote_js['path'])) {
    wp_enqueue_script('digim-quote-hydration', $quote_js['url'], ['digim-frontend'], filemtime($quote_js['path']), true);
  }

  // Feather icons (for filter amenities; same as property-single)
  wp_enqueue_script('digim-feather-icons', 'https://cdn.jsdelivr.net/npm/feather-icons@4.29.2/dist/feather.min.js', [], '4.29.2', true);
});


// === Property Context (for SEO/meta) === //
$GLOBALS['digimanagement_current_property_context'] = null;

function digimanagement_set_current_property_context($property = null, $identifier = null)
{
  if (!$property || !is_array($property)) {
    $GLOBALS['digimanagement_current_property_context'] = null;
    return;
  }

  $GLOBALS['digimanagement_current_property_context'] = [
    'property'    => $property,
    'identifier'  => $identifier,
    'permalink'   => home_url('/property/' . rawurlencode($identifier ?? ($property['uuid'] ?? '')) . '/'),
  ];
}

function digimanagement_get_current_property_context()
{
  return $GLOBALS['digimanagement_current_property_context'] ?? null;
}

if (!function_exists('digim_get_nested_value')) {
  /**
   * Safely get a nested value from an array using an ordered list of keys.
   *
   * @param array<string,mixed> $source
   * @param array<int,string>   $path
   * @return mixed|null
   */
  function digim_get_nested_value($source, $path)
  {
    $value = $source;

    foreach ($path as $segment) {
      if (!is_array($value) || !array_key_exists($segment, $value)) {
        return null;
      }

      $value = $value[$segment];
    }

    return $value;
  }
}

if (!function_exists('digim_normalize_description_text')) {
  /**
   * Normalize description content into a clean, plain-text string.
   */
  function digim_normalize_description_text($text)
  {
    if (!is_string($text)) {
      return '';
    }

    $normalized = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $normalized = preg_replace('/<\s*br\s*\/?>/i', "\n", $normalized);
    $normalized = preg_replace('/<\/\s*p\s*>/i', "\n\n", $normalized);
    $normalized = preg_replace('/<\/\s*li\s*>/i', "\n", $normalized);
    $normalized = preg_replace('/<\s*\/?(ul|ol)\s*>/i', "\n", $normalized);
    $normalized = wp_strip_all_tags($normalized);
    $normalized = preg_replace("/\r\n?/", "\n", $normalized);
    $normalized = preg_replace("/\n{3,}/", "\n\n", $normalized);

    return trim($normalized);
  }
}

if (!function_exists('digim_get_property_description')) {
  /**
   * Extract the best available description text from a property payload.
   *
   * Handles multiple potential field shapes returned by the Hospitable API.
   *
   * @param array<string,mixed>|null $property
   */
  function digim_get_property_description($property)
  {
    if (!is_array($property)) {
      return '';
    }

    $candidates = [];

    $addCandidate = function ($value) use (&$candidates, &$addCandidate) {
      if (is_string($value)) {
        $normalized = digim_normalize_description_text($value);
        if ($normalized !== '' && !in_array($normalized, $candidates, true)) {
          $candidates[] = $normalized;
        }
        return;
      }

      if (!is_array($value)) {
        return;
      }

      $priorityKeys = [
        'plain_text',
        'text',
        'description',
        'summary',
        'content',
        'value',
        'html',
        'markdown',
        'default',
      ];

      foreach ($priorityKeys as $key) {
        if (isset($value[$key])) {
          $addCandidate($value[$key]);
          if (!empty($candidates)) {
            return;
          }
        }
      }

      if (isset($value['translations']) && is_array($value['translations'])) {
        foreach (['en-US', 'en_us', 'en-US', 'en', 'default'] as $localeKey) {
          if (isset($value['translations'][$localeKey])) {
            $addCandidate($value['translations'][$localeKey]);
            if (!empty($candidates)) {
              return;
            }
          }
        }
      }

      foreach ($value as $item) {
        $addCandidate($item);
        if (!empty($candidates)) {
          return;
        }
      }
    };

    $paths = [
      ['description'],
      ['summary'],
      ['public_description'],
      ['description_plain_text'],
      ['description_text'],
      ['description_html'],
      ['summary_html'],
      ['public_summary'],
      ['details', 'description'],
      ['details', 'summary'],
      ['content', 'description'],
      ['content', 'summary'],
      ['content', 'space'],
      ['content', 'the_space'],
      ['body', 'description'],
    ];

    foreach ($paths as $path) {
      $value = digim_get_nested_value($property, $path);
      if ($value !== null) {
        $addCandidate($value);
      }
      if (!empty($candidates)) {
        break;
      }
    }

    if (empty($candidates)) {
      foreach ($property as $key => $value) {
        if (is_string($key) && stripos($key, 'description') !== false) {
          $addCandidate($value);
        }
        if (!empty($candidates)) {
          break;
        }
      }
    }

    return $candidates[0] ?? '';
  }
}

if (!function_exists('digim_get_property_summary')) {
  /**
   * Extract Hospitable "Summary" only (for display after description in #tab-about).
   *
   * @param array<string,mixed>|null $property
   * @return string
   */
  function digim_get_property_summary($property)
  {
    if (!is_array($property)) {
      return '';
    }
    $addCandidate = function ($value) {
      if (is_string($value)) {
        return digim_normalize_description_text($value);
      }
      if (is_array($value)) {
        foreach (['plain_text', 'text', 'summary', 'content', 'value'] as $key) {
          if (isset($value[$key]) && is_string($value[$key])) {
            return digim_normalize_description_text($value[$key]);
          }
        }
      }
      return '';
    };
    $paths = [
      ['summary'],
      ['content', 'summary'],
      ['listing_summary'],
      ['property_summary'],
      ['details', 'summary'],
    ];
    foreach ($paths as $path) {
      $value = digim_get_nested_value($property, $path);
      if ($value !== null) {
        $out = $addCandidate($value);
        if ($out !== '') {
          return $out;
        }
      }
    }
    return '';
  }
}

if (!function_exists('digim_get_property_other_notes')) {
  /**
   * Extract "Other details to note" style content from a property payload.
   *
   * Hospitable / channel APIs may expose this under various keys and nesting
   * (e.g. direct_bookings_other_details, content.other_things_to_note, content.other_details_to_note, etc.).
   * This helper mirrors the robustness of digim_get_property_description.
   *
   * @param array<string,mixed>|null $property
   * @return string
   */
  function digim_get_property_other_notes($property)
  {
    if (!is_array($property)) {
      return '';
    }

    $candidates = [];

    $addCandidate = function ($value) use (&$candidates, &$addCandidate) {
      if (is_string($value)) {
        $normalized = digim_normalize_description_text($value);
        if ($normalized !== '' && !in_array($normalized, $candidates, true)) {
          $candidates[] = $normalized;
        }
        return;
      }

      if (!is_array($value)) {
        return;
      }

      // Common inner keys used for text-ish payloads
      $priorityKeys = [
        'plain_text',
        'text',
        'description',
        'summary',
        'content',
        'value',
        'html',
        'markdown',
        'default',
      ];

      foreach ($priorityKeys as $key) {
        if (isset($value[$key])) {
          $addCandidate($value[$key]);
          if (!empty($candidates)) {
            return;
          }
        }
      }

      // Fallback: scan translations-like structures
      if (isset($value['translations']) && is_array($value['translations'])) {
        foreach (['en-US', 'en_us', 'en', 'default'] as $localeKey) {
          if (isset($value['translations'][$localeKey])) {
            $addCandidate($value['translations'][$localeKey]);
            if (!empty($candidates)) {
              return;
            }
          }
        }
      }

      // Final fallback: walk items
      foreach ($value as $item) {
        $addCandidate($item);
        if (!empty($candidates)) {
          return;
        }
      }
    };

    // Likely locations for "Other things/details to note" in Hospitable / Airbnb-style payloads.
    $paths = [
      ['airbnb_other_details'],
      ['content', 'airbnb_other_details'],
      ['content', 'direct_bookings_other_details'],
      ['direct_bookings_other_details'],
      ['directBookingsOtherDetails'],
      ['content', 'directBookingsOtherDetails'],
      ['direct_booking_other_details'],
      ['content', 'direct_booking_other_details'],
      ['content', 'other_things_to_note'],
      ['content', 'other_details_to_note'],
      ['content', 'other_notes'],
      ['details', 'other_things_to_note'],
      ['details', 'other_details_to_note'],
      ['details', 'other_notes'],
      ['other_things_to_note'],
      ['other_details_to_note'],
      ['other_notes'],
    ];

    foreach ($paths as $path) {
      $value = digim_get_nested_value($property, $path);
      if ($value !== null) {
        $addCandidate($value);
      }
      if (!empty($candidates)) {
        break;
      }
    }

    // Absolute fallback: look for any key that looks like "other ... note" or "direct ... booking" or "airbnb ... other"
    if (empty($candidates)) {
      $iterator = function ($source) use (&$iterator, &$addCandidate) {
        if (!is_array($source)) {
          return;
        }

        foreach ($source as $key => $value) {
          if (is_string($key)) {
            $lower = strtolower($key);
            if (
              ((strpos($lower, 'other') !== false || strpos($lower, 'note') !== false) &&
              (strpos($lower, 'note') !== false || strpos($lower, 'notes') !== false)) ||
              (strpos($lower, 'direct') !== false && strpos($lower, 'booking') !== false && strpos($lower, 'detail') !== false) ||
              (strpos($lower, 'airbnb') !== false && strpos($lower, 'other') !== false && strpos($lower, 'detail') !== false)
            ) {
              $addCandidate($value);
              if (!empty($candidates)) {
                return;
              }
            }
          }

          if (is_array($value)) {
            $iterator($value);
            if (!empty($candidates)) {
              return;
            }
          }
        }
      };

      $iterator($property);
    }

    // Debug logging to help identify the field structure
    if (empty($candidates) && defined('WP_DEBUG') && WP_DEBUG) {
      error_log('DigiM Debug - Property keys for other_notes extraction: ' . print_r(array_keys($property), true));
      if (isset($property['content'])) {
        error_log('DigiM Debug - Property content keys: ' . print_r(array_keys($property['content']), true));
      }
    }

    return $candidates[0] ?? '';
  }
}

function digimanagement_build_property_seo_title($property)
{
  $name = trim($property['name'] ?? '');
  if (!$name) {
    return null;
  }

  $city    = trim($property['address']['city'] ?? '');
  $state   = trim($property['address']['state'] ?? '');
  $country = trim($property['address']['country'] ?? '');

  $location_parts = array_filter([$city, $state ?: $country]);
  if (!empty($location_parts)) {
    return sprintf('%s | %s', $name, implode(', ', $location_parts));
  }

  return $name;
}

function digimanagement_build_property_seo_description($property)
{
  $description = digim_get_property_description($property);
  $description = preg_replace('/\s+/', ' ', (string) $description);
  $description = trim($description);

  if (!$description) {
    $beds     = $property['bedrooms'] ?? null;
    $baths    = $property['bathrooms'] ?? null;
    $guests   = $property['occupancy'] ?? $property['max_guests'] ?? null;
    $location = trim(($property['address']['city'] ?? '') . ', ' . ($property['address']['state'] ?? ''));

    $parts = [];
    if ($beds) {
      $parts[] = sprintf('%s bedroom%s', $beds, intval($beds) === 1 ? '' : 's');
    }
    if ($baths) {
      $parts[] = sprintf('%s bath%s', $baths, intval($baths) === 1 ? '' : 's');
    }
    if ($guests) {
      $parts[] = sprintf('Sleeps %s', $guests);
    }
    if ($location) {
      $parts[] = $location;
    }

    $description = implode(' • ', array_filter($parts));
  }

  if (!$description) {
    return null;
  }

  return wp_trim_words($description, 35, '…');
}

add_filter('pre_get_document_title', function ($title) {
  $context = digimanagement_get_current_property_context();
  if (!$context) {
    return $title;
  }

  $seo_title = digimanagement_build_property_seo_title($context['property']);
  return $seo_title ?: $title;
}, 20);

add_filter('document_title_parts', function ($parts) {
  $context = digimanagement_get_current_property_context();
  if (!$context) {
    return $parts;
  }

  $seo_title = digimanagement_build_property_seo_title($context['property']);
  if ($seo_title) {
    $parts['title'] = $seo_title;
  }

  return $parts;
}, 20);

add_filter('wpseo_title', function ($title) {
  $context = digimanagement_get_current_property_context();
  if (!$context) {
    return $title;
  }

  $seo_title = digimanagement_build_property_seo_title($context['property']);
  return $seo_title ?: $title;
}, 20, 1);

add_filter('rank_math/frontend/title', function ($title) {
  $context = digimanagement_get_current_property_context();
  if (!$context) {
    return $title;
  }

  $seo_title = digimanagement_build_property_seo_title($context['property']);
  return $seo_title ?: $title;
}, 20, 1);

add_filter('wpseo_metadesc', function ($description) {
  $context = digimanagement_get_current_property_context();
  if (!$context) {
    return $description;
  }

  $seo_description = digimanagement_build_property_seo_description($context['property']);
  return $seo_description ?: $description;
}, 20, 1);

add_filter('rank_math/frontend/description', function ($description) {
  $context = digimanagement_get_current_property_context();
  if (!$context) {
    return $description;
  }

  $seo_description = digimanagement_build_property_seo_description($context['property']);
  return $seo_description ?: $description;
}, 20, 1);

add_filter('wpseo_canonical', function ($canonical) {
  $context = digimanagement_get_current_property_context();
  if (!$context) {
    return $canonical;
  }

  return $context['permalink'] ?? $canonical;
}, 20, 1);

add_filter('rank_math/frontend/canonical', function ($canonical) {
  $context = digimanagement_get_current_property_context();
  if (!$context) {
    return $canonical;
  }

  return $context['permalink'] ?? $canonical;
}, 20, 1);

add_action('wp_head', function () {
  $context = digimanagement_get_current_property_context();
  if (!$context) {
    return;
  }

  global $wp;

  $property = $context['property'];
  $seo_title = digimanagement_build_property_seo_title($property);
  $seo_description = digimanagement_build_property_seo_description($property);
  $permalink = $context['permalink'] ?? home_url(isset($wp) && isset($wp->request) ? $wp->request : '');
  $image = '';

  if (!empty($property['images']) && is_array($property['images'])) {
    $first_image = $property['images'][0];
    if (is_array($first_image)) {
      $image = $first_image['url'] ?? $first_image['original_url'] ?? '';
      if (!$image && isset($first_image[0]) && is_string($first_image[0])) {
        $image = $first_image[0];
      }
    } elseif (is_string($first_image)) {
      $image = $first_image;
    }
  } elseif (!empty($property['image'])) {
    $image = $property['image'];
  }

  if ($seo_description) {
    echo '<meta name="description" content="' . esc_attr($seo_description) . '">' . PHP_EOL;
  }

  if ($seo_title) {
    echo '<meta property="og:title" content="' . esc_attr($seo_title) . '">' . PHP_EOL;
    echo '<meta name="twitter:title" content="' . esc_attr($seo_title) . '">' . PHP_EOL;
  }

  if ($seo_description) {
    echo '<meta property="og:description" content="' . esc_attr($seo_description) . '">' . PHP_EOL;
    echo '<meta name="twitter:description" content="' . esc_attr($seo_description) . '">' . PHP_EOL;
  }

  echo '<meta property="og:type" content="article">' . PHP_EOL;
  echo '<meta property="og:url" content="' . esc_url($permalink) . '">' . PHP_EOL;
  if (!defined('WPSEO_VERSION') && !defined('RANK_MATH_VERSION')) {
    echo '<link rel="canonical" href="' . esc_url($permalink) . '">' . PHP_EOL;
  }

  if ($image) {
    echo '<meta property="og:image" content="' . esc_url($image) . '">' . PHP_EOL;
    echo '<meta name="twitter:card" content="summary_large_image">' . PHP_EOL;
    echo '<meta name="twitter:image" content="' . esc_url($image) . '">' . PHP_EOL;
  }
}, 5);

function digimanagement_get_api_url()
{
  return trim(get_option('digimanagement_api_url', 'https://public.api.hospitable.com/v2'));
}

function digimanagement_get_api_token()
{
  $token = trim(get_option('digimanagement_api_key', ''));
  
  // Require token to be set in admin settings - no fallback
  if (empty($token)) {
    return '';
  }
  
  return 'Bearer ' . $token;
}

/**
 * Get list of property UUIDs that are hidden on the frontend (still live on Hospitable).
 *
 * @return string[]
 */
function digim_get_hidden_listing_uuids()
{
  $hidden = get_option('digim_hidden_listings', []);
  if (!is_array($hidden)) {
    return [];
  }
  return array_values(array_filter(array_map('strval', $hidden)));
}

/**
 * Check if a listing is hidden on the frontend.
 *
 * @param string $uuid Property UUID.
 * @return bool
 */
function digim_is_listing_hidden($uuid)
{
  if ($uuid === null || $uuid === '') {
    return false;
  }
  return in_array(trim((string) $uuid), digim_get_hidden_listing_uuids(), true);
}

// Debug function to test API response for a specific property
function digimanagement_debug_property_api($property_uuid) {
    error_log("=== DEBUGGING PROPERTY API FOR UUID: $property_uuid ===");
    
    // Test 1: Get property details
    $property_url = digimanagement_get_api_url() . "/properties/$property_uuid";
    $property_response = wp_remote_get($property_url, [
        'headers' => [
            'Authorization' => digimanagement_get_api_token(),
            'Accept' => 'application/json',
        ],
        'timeout' => 15,
    ]);
    
    if (is_wp_error($property_response)) {
        error_log("Property API Error: " . $property_response->get_error_message());
        return;
    }
    
    $property_data = json_decode(wp_remote_retrieve_body($property_response), true);
    error_log("Property API Response Code: " . wp_remote_retrieve_response_code($property_response));
    error_log("Property API Response: " . wp_remote_retrieve_body($property_response));
    
    if ($property_data && isset($property_data['data'])) {
        $property = $property_data['data'];
        error_log("Property Name: " . ($property['name'] ?? 'N/A'));
        error_log("Property Fields: " . implode(', ', array_keys($property)));
        
        // Check for pricing fields
        if (isset($property['pricing'])) {
            error_log("Pricing Fields: " . implode(', ', array_keys($property['pricing'])));
            error_log("Pricing Data: " . print_r($property['pricing'], true));
        }
    }
    
    // Test 2: Get rates
    $rates_url = digimanagement_get_api_url() . "/properties/$property_uuid/rates";
    $rates_response = wp_remote_get($rates_url, [
        'headers' => [
            'Authorization' => digimanagement_get_api_token(),
            'Accept' => 'application/json',
        ],
        'timeout' => 15,
    ]);
    
    if (!is_wp_error($rates_response)) {
        error_log("Rates API Response Code: " . wp_remote_retrieve_response_code($rates_response));
        error_log("Rates API Response: " . wp_remote_retrieve_body($rates_response));
    }
    
    error_log("=== END DEBUGGING FOR UUID: $property_uuid ===");
}

// Test function to debug API responses
function digimanagement_test_api_ajax() {
    // Skip nonce verification for local testing
    error_log("Test API function called - skipping nonce verification for local testing");
    
    $property_uuid = sanitize_text_field($_POST['property_uuid'] ?? '');
    if (empty($property_uuid)) {
        wp_send_json_error('Property UUID required');
        return;
    }
    
    // Test property API - first test the working listings endpoint
    $listings_url = digimanagement_get_api_url() . "/properties?page=1";
    $listings_response = wp_remote_get($listings_url, [
        'headers' => [
            'Authorization' => digimanagement_get_api_token(),
            'Accept' => 'application/json',
            'Cache-Control' => 'no-cache',
            'Pragma' => 'no-cache',
        ],
        'timeout' => 15,
    ]);
    
    // Test specific property API
    $property_url = digimanagement_get_api_url() . "/properties/$property_uuid";
    $property_response = wp_remote_get($property_url, [
        'headers' => [
            'Authorization' => digimanagement_get_api_token(),
            'Accept' => 'application/json',
        ],
        'timeout' => 15,
    ]);
    
    $property_data = null;
    $property_response_body = '';
    if (!is_wp_error($property_response)) {
        $property_response_body = wp_remote_retrieve_body($property_response);
        $property_data = json_decode($property_response_body, true);
    } else {
        error_log("Property API Error: " . $property_response->get_error_message());
    }
    
    // Test rates API
    $rates_url = digimanagement_get_api_url() . "/properties/$property_uuid/rates";
    $rates_response = wp_remote_get($rates_url, [
        'headers' => [
            'Authorization' => digimanagement_get_api_token(),
            'Accept' => 'application/json',
        ],
        'timeout' => 15,
    ]);
    
    $rates_data = null;
    $rates_response_body = '';
    if (!is_wp_error($rates_response)) {
        $rates_response_body = wp_remote_retrieve_body($rates_response);
        $rates_data = json_decode($rates_response_body, true);
    } else {
        error_log("Rates API Error: " . $rates_response->get_error_message());
    }
    
    // Test quote API
    $quote_url = digimanagement_get_api_url() . "/properties/$property_uuid/quote";
    $quote_data = array(
        'checkin' => '2025-11-09',
        'checkout' => '2025-11-12',
        'adults' => 2,
        'children' => 0,
        'infants' => 0
    );
    
    $quote_response = wp_remote_post($quote_url, array(
        'headers' => array(
            'Authorization' => digimanagement_get_api_token(),
            'Accept' => 'application/json',
            'Content-Type' => 'application/json'
        ),
        'body' => json_encode($quote_data),
        'timeout' => 30
    ));
    
    $quote_data = null;
    $quote_response_body = '';
    if (!is_wp_error($quote_response)) {
        $quote_response_body = wp_remote_retrieve_body($quote_response);
        $quote_data = json_decode($quote_response_body, true);
    } else {
        error_log("Quote API Error: " . $quote_response->get_error_message());
    }
    
    $listings_data = null;
    $listings_response_body = '';
    if (!is_wp_error($listings_response)) {
        $listings_response_body = wp_remote_retrieve_body($listings_response);
        $listings_data = json_decode($listings_response_body, true);
    }
    
    wp_send_json_success([
        'listings_test' => [
            'url' => $listings_url,
            'response_code' => wp_remote_retrieve_response_code($listings_response),
            'raw_response' => substr($listings_response_body, 0, 500),
            'is_error' => is_wp_error($listings_response),
            'data_count' => isset($listings_data['data']) ? count($listings_data['data']) : 0
        ],
        'property' => [
            'url' => $property_url,
            'response_code' => wp_remote_retrieve_response_code($property_response),
            'raw_response' => substr($property_response_body, 0, 500), // First 500 chars
            'data' => $property_data
        ],
        'rates' => [
            'url' => $rates_url,
            'response_code' => wp_remote_retrieve_response_code($rates_response),
            'raw_response' => substr($rates_response_body, 0, 500), // First 500 chars
            'data' => $rates_data
        ],
        'quote' => [
            'url' => $quote_url,
            'response_code' => wp_remote_retrieve_response_code($quote_response),
            'raw_response' => substr($quote_response_body, 0, 500), // First 500 chars
            'data' => $quote_data
        ],
        'api_token' => digimanagement_get_api_token(),
        'api_url' => digimanagement_get_api_url(),
        'stored_token_option' => get_option('digimanagement_api_key', 'NOT_SET')
    ]);
}

// Simple test function
function digimanagement_simple_test_ajax() {
    wp_send_json_success([
        'message' => 'Simple test works!',
        'timestamp' => current_time('mysql'),
        'api_token' => digimanagement_get_api_token(),
        'api_url' => digimanagement_get_api_url()
    ]);
}


// === Amenity normalization (shared by shortcode, template, property-single) === //
if (!function_exists('digim_normalize_amenity')) {
    function digim_normalize_amenity($amenity) {
        if (is_array($amenity)) {
            $amenity = $amenity['name'] ?? $amenity['slug'] ?? $amenity['id'] ?? '';
        }
        $amenity = (string) $amenity;
        return trim(preg_replace('/[^a-z0-9]+/', '_', strtolower($amenity)), '_');
    }
}

// === Amenity icons (same as property-single; used by filter dropdown and single template) === //
if (!function_exists('digim_get_amenity_icons')) {
    function digim_get_amenity_icons() {
        return [
            'ac' => 'wind',
            'alfresco_dining' => 'coffee',
            'alfresco_shower' => 'cloud-rain',
            'arcade_machine' => 'cpu',
            'baking_sheet' => 'grid',
            'barbeque_utensils' => 'tool',
            'bathtub' => 'droplet',
            'bbq_area' => 'sun',
            'beach_essentials' => 'umbrella',
            'bed_linens' => 'layers',
            'blender' => 'aperture',
            'board_games' => 'grid',
            'ceiling_fan' => 'rotate-cw',
            'coffee' => 'coffee',
            'conditioner' => 'droplet',
            'crib' => 'box',
            'dining_table' => 'grid',
            'dishes_and_silverware' => 'tool',
            'dishwasher' => 'droplet',
            'dryer' => 'wind',
            'ev_charger' => 'battery-charging',
            'fire_extinguisher' => 'shield',
            'first_aid_kit' => 'plus-square',
            'free_parking' => 'truck',
            'freezer' => 'thermometer',
            'game_console' => 'cpu',
            'hair_dryer' => 'wind',
            'hangers' => 'feather',
            'high_chair' => 'square',
            'hot_water' => 'thermometer',
            'iron' => 'slash',
            'keurig_coffee_machine' => 'coffee',
            'kitchen' => 'home',
            'laptop_friendly_workspace' => 'monitor',
            'laundromat_nearby' => 'refresh-ccw',
            'microwave' => 'cpu',
            'portable_fans' => 'wind',
            'refrigerator' => 'thermometer',
            'room_darkening_shades' => 'moon',
            'shampoo' => 'droplet',
            'sun_loungers' => 'sun',
            'toaster' => 'grid',
            'tv' => 'tv',
            'washer' => 'refresh-cw',
            'wine_glasses' => 'heart',
            'wifi' => 'wifi',
            'wireless_internet' => 'wifi',
        ];
    }
}
if (!function_exists('digim_get_amenity_default_icon')) {
    function digim_get_amenity_default_icon() {
        return 'check-square';
    }
}

// === Slug Functions === //
/**
 * Check if a property allows pets (pet-friendly, pets allowed, etc.).
 * Uses amenities, tags, and direct property keys. Matches property-single logic.
 * Returns false if the property explicitly disallows pets (e.g. "Not including service animals").
 *
 * @param array $property Property data from API.
 * @return bool True if property allows pets.
 */
function digim_property_allows_pets($property) {
  if (!is_array($property)) {
    return false;
  }
  $normalize = function ($a) {
    if (is_array($a)) {
      $a = $a['id'] ?? $a['name'] ?? $a['slug'] ?? '';
    }
    return trim(preg_replace('/[^a-z0-9]+/', '_', strtolower((string) $a)), '_');
  };
  $normalize_raw = function ($a) {
    if (is_array($a)) {
      $a = $a['name'] ?? $a['slug'] ?? $a['id'] ?? '';
    }
    return strtolower((string) $a);
  };
  // Negative indicators: property does NOT allow pets (e.g. "Not including service animals")
  $no_pet_keys = ['no_pets', 'pets_not_allowed', 'not_including_service_animals', 'service_animals_not_included', 'no_dogs', 'no_animals'];
  $amenities = $property['amenities'] ?? [];
  $norm_amenities = array_map($normalize, is_array($amenities) ? $amenities : []);
  foreach ($no_pet_keys as $key) {
    if (in_array($key, $norm_amenities, true)) {
      return false;
    }
  }
  foreach (is_array($amenities) ? $amenities : [] as $a) {
    $raw = $normalize_raw($a);
    if (strpos($raw, 'not including service animal') !== false || strpos($raw, 'no pet') !== false || strpos($raw, 'pets not allowed') !== false) {
      return false;
    }
  }
  $tags = $property['tags'] ?? [];
  $norm_tags = array_map($normalize, is_array($tags) ? $tags : []);
  foreach ($no_pet_keys as $key) {
    if (in_array($key, $norm_tags, true)) {
      return false;
    }
  }
  foreach (is_array($tags) ? $tags : [] as $t) {
    $raw = $normalize_raw($t);
    if (strpos($raw, 'not including service animal') !== false || strpos($raw, 'no pet') !== false || strpos($raw, 'pets not allowed') !== false) {
      return false;
    }
  }
  if (!empty($property['pets_not_allowed']) || !empty($property['no_pets'])) {
    return false;
  }
  // Positive indicators: property allows pets
  $pet_keys = ['pets_allowed', 'pet_friendly', 'pet_friendly_room'];
  foreach ($pet_keys as $key) {
    if (!empty($property[$key])) {
      return true;
    }
  }
  foreach ($pet_keys as $key) {
    if (in_array($key, $norm_amenities, true)) {
      return true;
    }
  }
  foreach ($pet_keys as $key) {
    if (in_array($key, $norm_tags, true)) {
      return true;
    }
  }
  return false;
}

function digimanagement_create_property_slug($property_name, $address = '') {
  // Create a slug from property name and address
  $slug = $property_name;
  if ($address) {
    $slug .= ' ' . $address;
  }
  
  // Convert to lowercase and replace spaces/special chars with hyphens
  $slug = strtolower($slug);
  $slug = preg_replace('/[^a-z0-9\s-]/', '', $slug);
  $slug = preg_replace('/[\s-]+/', '-', $slug);
  $slug = trim($slug, '-');
  
  // Limit length
  $slug = substr($slug, 0, 100);
  
  return $slug;
}

function digimanagement_get_property_by_slug($slug) {
  // Get all properties and find one with matching slug
  $all_properties = digim_get_all_properties();
  
  foreach ($all_properties as $property) {
    $property_slug = digimanagement_create_property_slug(
      $property['name'] ?? '', 
      $property['address']['city'] ?? ''
    );
    
    if ($property_slug === $slug) {
      return $property;
    }
  }
  
  return null;
}

function digimanagement_get_property_uuid_by_slug($slug) {
  $property = digimanagement_get_property_by_slug($slug);
  return $property ? ($property['uuid'] ?? $property['id'] ?? null) : null;
}

// Ajax UI BUILDER
add_action('wp_ajax_digim_preview_shortcode', function () {
  update_option('digim_layout_style', sanitize_text_field($_POST['layout']));
  update_option('digim_grid_columns', intval($_POST['columns']));

  echo do_shortcode('[digimanagement_listings]');
  wp_die();
});


// === Helper: Parallel Calendar Check === //
if (!function_exists('digim_calendar_day_is_available')) {
  function digim_calendar_day_is_available($day)
  {
    if (!is_array($day)) {
      return false;
    }

    $status = $day['status'] ?? [];

    if (array_key_exists('available', $status)) {
      $flag = $status['available'];
      if (is_bool($flag)) {
        return $flag;
      }
      if (is_string($flag)) {
        $normalized = strtolower($flag);
        if ($normalized === 'true' || $normalized === '1' || $normalized === 'yes') {
          return true;
        }
        if ($normalized === 'false' || $normalized === '0' || $normalized === 'no') {
          return false;
        }
      }
    }

    if (isset($status['state'])) {
      $state = strtolower((string)$status['state']);
      if (in_array($state, ['blocked', 'booked', 'unavailable', 'maintenance'], true)) {
        return false;
      }
    }

    if (isset($status['type'])) {
      $type = strtolower((string)$status['type']);
      if (in_array($type, ['blocked', 'booked', 'unavailable', 'maintenance'], true)) {
        return false;
      }
    }

    return true;
  }
}

/**
 * Check if a date range is available from calendar day data (for multi-range batch checks).
 * Uses same rules as single-range calendar check: check-in allowed, all nights available, min_nights, checkout not blocked.
 *
 * @param array  $calendar_days Array of day objects from API (data.days).
 * @param string $checkin        Y-m-d.
 * @param string $checkout       Y-m-d.
 * @return bool
 */
if (!function_exists('digim_calendar_range_available')) {
  function digim_calendar_range_available($calendar_days, $checkin, $checkout)
  {
    if (!is_array($calendar_days)) {
      return false;
    }
    $days_by_date = [];
    foreach ($calendar_days as $day) {
      if (!empty($day['date'])) {
        $d = $day['date'];
        $key = (strlen($d) >= 10 && (substr($d, 10, 1) === 'T' || substr($d, 10, 1) === ' ')) ? substr($d, 0, 10) : $d;
        $days_by_date[$key] = $day;
      }
    }
    $requested_nights = max(1, (int) floor((strtotime($checkout) - strtotime($checkin)) / DAY_IN_SECONDS));
    $current = strtotime($checkin);
    $end = strtotime($checkout);
    $checkin_date_str = date('Y-m-d', $current);

    while ($current < $end) {
      $date_str = date('Y-m-d', $current);
      $day_found = $days_by_date[$date_str] ?? null;
      $is_checkin_day = ($date_str === $checkin_date_str);

      if ($is_checkin_day && $day_found) {
        $day_allows_checkin = $day_found['allows_checkin'] ?? $day_found['checkin_allowed'] ?? true;
        if (isset($day_found['checkin_allowed']) && $day_found['checkin_allowed'] === false) {
          $day_allows_checkin = false;
        }
        $closed = $day_found['closed_for_checkin'] ?? $day_found['closed_for_check_in'] ?? false;
        if ($closed === true || $closed === 'true' || $closed === 1) {
          $day_allows_checkin = false;
        }
        $blocked = $day_found['checkin_blocked'] ?? $day_found['check_in_blocked'] ?? false;
        if ($blocked === true || $blocked === 'true' || $blocked === 1) {
          $day_allows_checkin = false;
        }
        $st = $day_found['status'] ?? [];
        if (is_array($st) && (isset($st['checkin_blocked']) && $st['checkin_blocked']) || (isset($st['allows_checkin']) && $st['allows_checkin'] === false) || (isset($st['checkin_allowed']) && $st['checkin_allowed'] === false)) {
          $day_allows_checkin = false;
        }
        if ($day_allows_checkin === false) {
          return false;
        }
      }

      if (!$day_found || !digim_calendar_day_is_available($day_found)) {
        return false;
      }

      // Minimum nights: only enforce on check-in day (stay must satisfy check-in day's min, not every night's).
      // Otherwise a 2-night Fri–Sun stay can be wrongly rejected if the second night has min_nights=3.
      if ($is_checkin_day) {
        $day_min = $day_found['min_nights'] ?? $day_found['minimum_nights'] ?? $day_found['min_stay'] ?? $day_found['minimum_stay'] ?? null;
        if ($day_min !== null && $requested_nights < (int) $day_min) {
          return false;
        }
      }

      $current = strtotime('+1 day', $current);
    }

    $checkout_day = $days_by_date[$checkout] ?? null;
    if ($checkout_day) {
      $closed = $checkout_day['closed_for_checkout'] ?? $checkout_day['closed_for_check_out'] ?? false;
      if ((is_bool($closed) && $closed) || (is_string($closed) && filter_var($closed, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE) === true) || (is_numeric($closed) && (int) $closed === 1)) {
        return false;
      }
    }
    return true;
  }
}

/**
 * Check multiple date ranges for multiple properties in one curl_multi (one round-trip).
 * Returns per-uuid list of available ranges: [ uuid => [ ['checkin'=>'Y-m-d','checkout'=>'Y-m-d'], ... ], ... ].
 * Used by flexible weekend/week/month search to avoid 4–7 sequential API rounds.
 *
 * @param array $uuids  List of property UUIDs.
 * @param array $ranges List of [ checkin, checkout ] pairs (e.g. weekend or week ranges).
 * @return array
 */
if (!function_exists('digimanagement_parallel_calendar_check_multi_ranges')) {
  /**
   * Check multiple date ranges for multiple properties.
   * Uses the pre-warmed year-range calendar cache (from cron) first — zero API calls when warm.
   * Falls back to curl_multi API calls only for properties without cached calendars.
   */
  function digimanagement_parallel_calendar_check_multi_ranges($uuids, $ranges)
  {
    if (empty($uuids) || empty($ranges)) {
      return [];
    }
    $uuids = array_values(array_filter(
      array_unique(array_map(function ($u) {
        $u = is_null($u) ? '' : trim((string) $u);
        return $u !== '' ? $u : null;
      }, $uuids)),
      function ($u) {
        return $u !== null && $u !== '';
      }
    ));

    $result = [];
    foreach ($uuids as $uuid) {
      $result[$uuid] = [];
    }

    try {
      $tz = function_exists('wp_timezone') ? wp_timezone() : new \DateTimeZone('UTC');
    } catch (\Exception $e) {
      $tz = new \DateTimeZone('UTC');
    }
    $today_obj = new \DateTimeImmutable('today', $tz);
    $year_start = $today_obj->format('Y-m-d');
    $year_end = $today_obj->modify('+1 year')->format('Y-m-d');

    $uuids_needing_api = [];
    foreach ($uuids as $uuid) {
      $cal_cache_key = 'digim_calendar_' . md5($uuid . '|' . $year_start . '|' . $year_end);
      $cached_cal = get_transient($cal_cache_key);
      if ($cached_cal !== false && is_array($cached_cal)) {
        $calendar_days = isset($cached_cal['data']['days']) && is_array($cached_cal['data']['days']) ? $cached_cal['data']['days'] : [];
        foreach ($ranges as $range) {
          list($cin, $cout) = $range;
          if (digim_calendar_range_available($calendar_days, $cin, $cout)) {
            $result[$uuid][] = ['checkin' => $cin, 'checkout' => $cout];
          }
        }
      } else {
        $uuids_needing_api[] = $uuid;
      }
    }

    if (empty($uuids_needing_api)) {
      return $result;
    }

    $calendar_timeout = (int) apply_filters('digim_calendar_request_timeout', 3);
    $calendar_connect = (int) apply_filters('digim_calendar_connect_timeout', 1);
    $calendar_cache_ttl = (int) apply_filters('digim_calendar_cache_ttl', 30 * MINUTE_IN_SECONDS);
    $calendar_cache_ttl = $calendar_cache_ttl > 0 ? $calendar_cache_ttl : 1800;
    $mh = curl_multi_init();
    $handles = [];

    foreach ($uuids_needing_api as $uuid) {
      $url = digimanagement_get_api_url() . '/properties/' . $uuid . '/calendar?' . http_build_query(['start_date' => $year_start, 'end_date' => $year_end]);
      $ch = curl_init();
      curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
          'Authorization: ' . digimanagement_get_api_token(),
          'Accept: application/json',
        ],
        CURLOPT_TIMEOUT => $calendar_timeout > 0 ? $calendar_timeout : 3,
        CURLOPT_CONNECTTIMEOUT => $calendar_connect > 0 ? $calendar_connect : 1,
      ]);
      curl_multi_add_handle($mh, $ch);
      $handles[$uuid] = $ch;
    }

    do {
      $status = curl_multi_exec($mh, $active);
      if ($active) {
        curl_multi_select($mh, 0.1);
      }
    } while ($active && $status === CURLM_OK);

    foreach ($handles as $uuid => $ch) {
      $body = curl_multi_getcontent($ch);
      $calendar = json_decode($body, true);
      if (is_array($calendar)) {
        $cal_cache_key = 'digim_calendar_' . md5($uuid . '|' . $year_start . '|' . $year_end);
        set_transient($cal_cache_key, $calendar, $calendar_cache_ttl);
        $calendar_days = isset($calendar['data']['days']) && is_array($calendar['data']['days']) ? $calendar['data']['days'] : [];
        foreach ($ranges as $range) {
          list($cin, $cout) = $range;
          if (digim_calendar_range_available($calendar_days, $cin, $cout)) {
            $result[$uuid][] = ['checkin' => $cin, 'checkout' => $cout];
          }
        }
      }
      curl_multi_remove_handle($mh, $ch);
      curl_close($ch);
    }
    curl_multi_close($mh);

    return $result;
  }
}

/**
 * Derive canonical Friday–Sunday weekend for "Weekend in [Month]" flexible search.
 * Used by both shortcode and get-listings AJAX so behaviour is the same everywhere.
 *
 * @param string $checkin    Current check-in (may be overwritten).
 * @param string $checkout   Current check-out (may be overwritten).
 * @param string $flex_mode  e.g. 'weekend'.
 * @param int    $flex_month 1–12.
 * @param int    $flex_year  Year.
 * @return array [ string $checkin, string $checkout, bool $was_derived ]
 */
function digim_derive_flexible_weekend_dates($checkin, $checkout, $flex_mode, $flex_month, $flex_year)
{
  $was_derived = false;
  if ($flex_mode !== 'weekend' || $flex_month < 1 || $flex_month > 12 || $flex_year < 1970) {
    return [ $checkin, $checkout, $was_derived ];
  }

  try {
    $tz = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC');
  } catch (Exception $e) {
    $tz = new DateTimeZone('UTC');
  }

  try {
    $first_of_month = new DateTimeImmutable(sprintf('%04d-%02d-01', $flex_year, $flex_month), $tz);
    $first_friday = $first_of_month->modify('first friday of this month');

    if ((int) $first_friday->format('n') === (int) $flex_month) {
      $today = new DateTimeImmutable('today', $tz);
      $candidate = $first_friday;

      while ($candidate < $today && (int) $candidate->format('n') === (int) $flex_month) {
        $candidate = $candidate->modify('+1 week');
      }

      if ((int) $candidate->format('n') === (int) $flex_month) {
        $checkin = $candidate->format('Y-m-d');
        $checkout = $candidate->modify('+2 days')->format('Y-m-d');
        $was_derived = true;
      }
    }
  } catch (Exception $e) {
    // Leave $checkin, $checkout unchanged
  }

  return [ $checkin, $checkout, $was_derived ];
}

/**
 * All Friday–Sunday (2-night) weekend ranges in a given month.
 * Used by "Weekend in [Month]" to check every weekend (e.g. May: 1–3, 8–10, 15–17, 22–24, 29–31).
 *
 * @param int $flex_year  Year (e.g. 2026).
 * @param int $flex_month Month 1–12.
 * @return array List of [ checkin => 'Y-m-d', checkout => 'Y-m-d' ].
 */
function digim_get_weekend_ranges_for_month($flex_year, $flex_month)
{
  $ranges = [];
  if ($flex_month < 1 || $flex_month > 12 || $flex_year < 1970) {
    return $ranges;
  }
  try {
    $tz = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC');
  } catch (Exception $e) {
    $tz = new DateTimeZone('UTC');
  }
  $first = new DateTimeImmutable(sprintf('%04d-%02d-01', $flex_year, $flex_month), $tz);
  $last  = $first->modify('last day of this month');
  $n     = (int) $flex_month;
  $current = $first;
  while ($current <= $last) {
    // 5 = Friday in 'N' format (1=Mon .. 7=Sun)
    if ((int) $current->format('N') === 5) {
      $checkin_w  = $current->format('Y-m-d');
      $checkout_w = $current->modify('+2 days')->format('Y-m-d');
      $ranges[] = [ $checkin_w, $checkout_w ];
    }
    $current = $current->modify('+1 day');
  }
  return $ranges;
}

/**
 * Derive a canonical 7-day (one week) range for "Week in [Month]" flexible search.
 * Used by both shortcode and get-listings AJAX so behaviour is the same everywhere.
 *
 * @param string $checkin    Current check-in (may be overwritten).
 * @param string $checkout   Current check-out (may be overwritten).
 * @param string $flex_mode  e.g. 'week'.
 * @param int    $flex_month 1–12.
 * @param int    $flex_year  Year.
 * @return array [ string $checkin, string $checkout, bool $was_derived ]
 */
function digim_derive_flexible_week_dates($checkin, $checkout, $flex_mode, $flex_month, $flex_year)
{
  $was_derived = false;
  if ($flex_mode !== 'week' || $flex_month < 1 || $flex_month > 12 || $flex_year < 1970) {
    return [ $checkin, $checkout, $was_derived ];
  }

  try {
    $tz = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC');
  } catch (Exception $e) {
    $tz = new DateTimeZone('UTC');
  }

  try {
    $first_of_month = new DateTimeImmutable(sprintf('%04d-%02d-01', $flex_year, $flex_month), $tz);
    $checkin = $first_of_month->format('Y-m-d');
    $checkout = $first_of_month->modify('+7 days')->format('Y-m-d');
    $was_derived = true;
  } catch (Exception $e) {
    // Leave $checkin, $checkout unchanged
  }

  return [ $checkin, $checkout, $was_derived ];
}

function digimanagement_parallel_calendar_check($uuids, $checkin, $checkout)
{
  if (empty($uuids)) {
    return [];
  }

  // Ensure UUIDs are unique, non-empty strings
  $uuids = array_values(array_filter(
    array_unique(array_map(function ($uuid) {
      $uuid = is_null($uuid) ? '' : trim((string) $uuid);
      return $uuid !== '' ? $uuid : null;
    }, $uuids)),
    function ($uuid) {
      return $uuid !== null && $uuid !== '';
    }
  ));

  if (empty($uuids)) {
    return [];
  }

  global $digim_next_available_suggestions;
  global $digim_min_nights_required;
  global $digim_checkin_blocked;
  global $digim_checkout_blocked_data;
  $digim_next_available_suggestions = [];
  $digim_min_nights_required = [];
  $digim_checkin_blocked = [];
  $digim_checkout_blocked_data = [];

  $requested_nights = max(1, (int) floor((strtotime($checkout) - strtotime($checkin)) / DAY_IN_SECONDS));
  $requested_nights = max(1, $requested_nights);

  // When user searched "Weekend in [Month]" or "Week in [Month]", suggest next available weekend (Fri–Sun) or 7-night stay.
  $flexible_weekend_next = ! empty($GLOBALS['digim_flexible_weekend_next_available']);
  $flexible_week_next = ! empty($GLOBALS['digim_flexible_week_next_available']);

  $search_window_days = max(30, (int) apply_filters('digim_next_available_search_window_days', 60, $checkin, $checkout));
  $search_end_timestamp = max(strtotime($checkout), strtotime('+' . $search_window_days . ' days', strtotime($checkin)));
  $search_end_date = date('Y-m-d', $search_end_timestamp);

  $cached_available = [];
  $pending_uuids = [];
  $cache_ttl = intval(apply_filters('digim_availability_cache_ttl', 20 * MINUTE_IN_SECONDS, $checkin, $checkout));
  $cache_ttl = $cache_ttl > 0 ? $cache_ttl : 1200;

  foreach ($uuids as $uuid) {
    $cache_key = 'digim_availability_v3_' . md5($uuid . '|' . $checkin . '|' . $checkout);
    $suggestion_cache_key = 'digim_next_available_v2_' . md5($uuid . '|' . $checkin . '|' . $checkout);
    $min_nights_cache_key = 'digim_min_nights_' . md5($uuid . '|' . $checkin . '|' . $checkout);
    $cached = get_transient($cache_key);
    $cached_suggestion = get_transient($suggestion_cache_key);
    $cached_min_nights = get_transient($min_nights_cache_key);

    if ($cached === 'available') {
      $cached_available[$uuid] = true;
      if ($cached_suggestion === 'none') {
        $digim_next_available_suggestions[$uuid] = null;
      } elseif ($cached_suggestion !== false) {
        $digim_next_available_suggestions[$uuid] = $cached_suggestion;
      }
    } elseif ($cached === 'unavailable') {
      // Check for cached minimum nights requirement
      if ($cached_min_nights !== false && is_numeric($cached_min_nights)) {
        $requested_nights = max(1, (int) floor((strtotime($checkout) - strtotime($checkin)) / DAY_IN_SECONDS));
        if ($requested_nights < (int)$cached_min_nights) {
          $digim_min_nights_required[$uuid] = (int)$cached_min_nights;
        }
      }
      
      if ($cached_suggestion !== false) {
        $digim_next_available_suggestions[$uuid] = $cached_suggestion === 'none' ? null : $cached_suggestion;
      } else {
        // Still need to check this property
        $pending_uuids[] = $uuid;
      }
    } else {
      $pending_uuids[] = $uuid;
    }
  }

  // If every UUID was cached as available and we have no pending calls, return early.
  // But we still need to return minimum nights data if any
  if (empty($pending_uuids)) {
    // Return available UUIDs - minimum nights data is already in global $digim_min_nights_required
    return array_keys($cached_available);
  }

  $query_end_date = $search_end_date;

  // Pre-warmed calendar: resolve pending UUIDs from year-range cache (zero API calls when warm).
  try {
    $tz_cal = function_exists('wp_timezone') ? wp_timezone() : new \DateTimeZone('UTC');
  } catch (\Exception $e) {
    $tz_cal = new \DateTimeZone('UTC');
  }
  $today_cal = new \DateTimeImmutable('today', $tz_cal);
  $year_start_cal = $today_cal->format('Y-m-d');
  $year_end_cal = $today_cal->modify('+1 year')->format('Y-m-d');
  $pre_resolved = [];
  $still_pending = [];
  foreach ($pending_uuids as $uuid) {
    $cal_key = 'digim_calendar_' . md5($uuid . '|' . $year_start_cal . '|' . $year_end_cal);
    $cached_cal = get_transient($cal_key);
    if ($cached_cal !== false && is_array($cached_cal)) {
      $pre_resolved[$uuid] = $cached_cal;
    } else {
      $still_pending[] = $uuid;
    }
  }
  $pending_uuids = $still_pending;

  $mh = curl_multi_init();
  $handles = [];
  $results = [];

  // Optional: fetch quotes in same round-trip for ~2s total (calendar + quote in one multi).
  $quote_guests = isset($GLOBALS['digim_parallel_quote_guests']) && is_array($GLOBALS['digim_parallel_quote_guests'])
    ? $GLOBALS['digim_parallel_quote_guests']
    : null;
  $quote_handles = [];
  $cached_quotes = [];
  $quote_result = [];
  if ($quote_guests !== null && function_exists('digimanagement_get_api_url')) {
    $adults_q = max(1, (int) ($quote_guests['adults'] ?? 1));
    $children_q = max(0, (int) ($quote_guests['children'] ?? 0));
    $infants_q = max(0, (int) ($quote_guests['infants'] ?? 0));
    $pets_q = max(0, (int) ($quote_guests['pets'] ?? 0));
    $cache_ttl_q = (int) apply_filters('digim_quote_cache_ttl', 15 * MINUTE_IN_SECONDS);
    $cache_ttl_q = $cache_ttl_q > 0 ? $cache_ttl_q : 300;
    $quote_key_prefix = 'digim_quote_v3_' . md5($checkin . '|' . $checkout . '|' . $adults_q . '|' . $children_q . '|' . $infants_q . '|' . $pets_q);
    $quote_payload = json_encode([
      'checkin_date' => $checkin,
      'checkout_date' => $checkout,
      'guests' => [
        'adults' => $adults_q,
        'children' => $children_q,
        'infants' => $infants_q,
        'pets' => $pets_q,
      ],
    ]);
    $api_base = digimanagement_get_api_url();
    $token = digimanagement_get_api_token();
    foreach ($uuids as $uuid) {
      $key = $quote_key_prefix . '_' . md5($uuid);
      $cached = get_transient($key);
      if ($cached !== false && is_array($cached)) {
        $cached_quotes[$uuid] = $cached;
      } else {
        $url = $api_base . '/properties/' . $uuid . '/quote';
        $ch = curl_init();
        curl_setopt_array($ch, [
          CURLOPT_URL => $url,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_POST => true,
          CURLOPT_POSTFIELDS => $quote_payload,
          CURLOPT_HTTPHEADER => [
            'Authorization: ' . $token,
            'Accept: application/json',
            'Content-Type: application/json',
          ],
          CURLOPT_TIMEOUT => (int) apply_filters('digim_quote_request_timeout', 6),
          CURLOPT_CONNECTTIMEOUT => 2,
        ]);
        curl_multi_add_handle($mh, $ch);
        $quote_handles[$uuid] = $ch;
      }
    }
  }

  $calendar_timeout = (int) apply_filters('digim_calendar_request_timeout', 3);
  $calendar_connect = (int) apply_filters('digim_calendar_connect_timeout', 1);
  foreach ($pending_uuids as $uuid) {
    $query_args = http_build_query([
      'start_date' => $checkin,
      'end_date'   => $query_end_date,
    ]);
    $url = digimanagement_get_api_url() . "/properties/$uuid/calendar?$query_args";
    $ch = curl_init();
    curl_setopt_array($ch, [
      CURLOPT_URL => $url,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_HTTPHEADER => [
        'Authorization: ' . digimanagement_get_api_token(),
        'Accept: application/json',
        'Cache-Control: no-cache',
        'Pragma: no-cache',
      ],
      CURLOPT_TIMEOUT => $calendar_timeout > 0 ? $calendar_timeout : 3,
      CURLOPT_CONNECTTIMEOUT => $calendar_connect > 0 ? $calendar_connect : 1,
    ]);
    curl_multi_add_handle($mh, $ch);
    $handles[$uuid] = $ch;
  }

  if (!empty($handles) || !empty($quote_handles)) {
    do {
      $status = curl_multi_exec($mh, $active);
      if ($active) {
        curl_multi_select($mh, 0.1);
      }
    } while ($active && $status === CURLM_OK);
  }

  $available_map = $cached_available;

  // Merge pre-resolved (from year-range cache) + API responses into one processing list
  $calendars_to_process = [];
  foreach ($pre_resolved as $uuid => $calendar) {
    $calendars_to_process[$uuid] = $calendar;
  }
  foreach ($handles as $uuid => $ch) {
    $body = curl_multi_getcontent($ch);
    $calendar = json_decode($body, true);
    $calendars_to_process[$uuid] = is_array($calendar) ? $calendar : [];
    curl_multi_remove_handle($mh, $ch);
    curl_close($ch);
  }

  foreach ($calendars_to_process as $uuid => $calendar) {
    $suggestion_cache_key = 'digim_next_available_v2_' . md5($uuid . '|' . $checkin . '|' . $checkout);
    $calendar_days = $calendar['data']['days'] ?? [];
    $range_available = true;

    $days_by_date = [];
    if (is_array($calendar_days)) {
      foreach ($calendar_days as $day) {
        if (!empty($day['date'])) {
          $d = $day['date'];
          $key = (strlen($d) >= 10 && (substr($d, 10, 1) === 'T' || substr($d, 10, 1) === ' ')) ? substr($d, 0, 10) : $d;
          $days_by_date[$key] = $day;
        }
      }
    }

    // Performance: extract checkout_blocked + unavailable from same response so template skips second API batch.
    $checkout_blocked_dates = [];
    $unavailable_dates = [];
    foreach ($calendar_days as $day) {
      if (empty($day['date'])) {
        continue;
      }
      $date = $day['date'];
      $closed_for_checkout = $day['closed_for_checkout'] ?? $day['closed_for_check_out'] ?? false;
      if ((is_bool($closed_for_checkout) && $closed_for_checkout) ||
          (is_string($closed_for_checkout) && in_array(strtolower($closed_for_checkout), ['true', '1'], true)) ||
          (is_numeric($closed_for_checkout) && (int) $closed_for_checkout === 1)) {
        $checkout_blocked_dates[] = $date;
      }
      $status = $day['status'] ?? [];
      $available = $status['available'] ?? true;
      if ((is_bool($available) && !$available) ||
          (isset($status['state']) && in_array(strtolower((string) $status['state']), ['blocked', 'booked', 'unavailable', 'maintenance'], true)) ||
          (isset($status['type']) && in_array(strtolower((string) $status['type']), ['blocked', 'booked', 'unavailable', 'maintenance'], true))) {
        $unavailable_dates[] = $date;
      }
    }
    $digim_checkout_blocked_data[$uuid] = [
      'checkout_blocked' => $checkout_blocked_dates,
      'unavailable'      => $unavailable_dates,
    ];

    $current = strtotime($checkin);
    $end = strtotime($checkout); // do NOT subtract 1 day

    // Check check-in day restriction (e.g., Saturday-only check-in)
    $checkin_day_of_week = (int) date('w', $current); // 0 = Sunday, 6 = Saturday
    $checkin_day_name = date('l', $current); // Full day name
    
    // Get check-in day from the calendar day data if available
    $checkin_date_str = date('Y-m-d', $current);
    $checkin_day_data = $days_by_date[$checkin_date_str] ?? null;
    $allowed_checkin_days = null;
    $min_nights_required = null;
    
    // Check if check-in day exists and if check-in is blocked (even if day data is null, check status)
    if ($checkin_day_data) {
      // Check for minimum nights requirement in the day data - try multiple possible field names
      $min_nights_required = $checkin_day_data['min_nights'] 
        ?? $checkin_day_data['minimum_nights'] 
        ?? $checkin_day_data['min_stay'] 
        ?? $checkin_day_data['minimum_stay']
        ?? (isset($checkin_day_data['pricing']) && isset($checkin_day_data['pricing']['min_nights']) ? $checkin_day_data['pricing']['min_nights'] : null)
        ?? null;
      
      // Store minimum nights requirement even if property is unavailable (for badge display)
      if ($min_nights_required !== null && $requested_nights < (int)$min_nights_required) {
        if (!isset($digim_min_nights_required[$uuid]) || (int)$min_nights_required > $digim_min_nights_required[$uuid]) {
          $digim_min_nights_required[$uuid] = (int)$min_nights_required;
          // Cache this for future requests
          $min_nights_cache_key = 'digim_min_nights_' . md5($uuid . '|' . $checkin . '|' . $checkout);
          set_transient($min_nights_cache_key, (int)$min_nights_required, $cache_ttl);
        }
      }
      
      // Check for check-in day restrictions
      $allowed_checkin_days = $checkin_day_data['checkin_days'] ?? $checkin_day_data['allowed_checkin_days'] ?? null;
      
      // Check multiple indicators for check-in blocked status
      $allows_checkin = $checkin_day_data['allows_checkin'] ?? $checkin_day_data['checkin_allowed'] ?? true;
      if (isset($checkin_day_data['checkin_allowed']) && $checkin_day_data['checkin_allowed'] === false) {
        $allows_checkin = false;
      }
      
      // Check for closed_for_checkin
      $closed_for_checkin = $checkin_day_data['closed_for_checkin'] ?? $checkin_day_data['closed_for_check_in'] ?? false;
      if ($closed_for_checkin === true || $closed_for_checkin === 'true' || $closed_for_checkin === 1) {
        $allows_checkin = false;
      }
      
      // Check for explicit checkin_blocked field
      $checkin_blocked = $checkin_day_data['checkin_blocked'] ?? $checkin_day_data['check_in_blocked'] ?? $checkin_day_data['check-in_blocked'] ?? false;
      if ($checkin_blocked === true || $checkin_blocked === 'true' || $checkin_blocked === 1) {
        $allows_checkin = false;
      }
      
      // Check status object for check-in blocked indicators
      $checkin_day_status = $checkin_day_data['status'] ?? [];
      if (is_array($checkin_day_status)) {
        if (isset($checkin_day_status['checkin_blocked']) && $checkin_day_status['checkin_blocked']) {
          $allows_checkin = false;
        }
        if (isset($checkin_day_status['allows_checkin']) && $checkin_day_status['allows_checkin'] === false) {
          $allows_checkin = false;
        }
        if (isset($checkin_day_status['checkin_allowed']) && $checkin_day_status['checkin_allowed'] === false) {
          $allows_checkin = false;
        }
        if (isset($checkin_day_status['closed_for_checkin']) && $checkin_day_status['closed_for_checkin'] === true) {
          $allows_checkin = false;
        }
      }
      
      // If check-in is explicitly not allowed on this day, mark as unavailable and track as check-in blocked
      if ($allows_checkin === false) {
        $range_available = false;
        $digim_checkin_blocked[$uuid] = true;
      }
    } else {
      // Check-in day data not found - check if it's in the unavailable dates or has special status
      // If the check-in date is completely missing from calendar, it might be blocked
      // But we'll let the availability check handle this - only mark as check-in blocked if we have explicit evidence
    }
    
    // Check minimum nights requirement
    if ($range_available && $min_nights_required !== null && $requested_nights < (int)$min_nights_required) {
      $range_available = false;
    }
    
    // Check check-in day restrictions (e.g., Saturday-only)
    if ($range_available && $allowed_checkin_days !== null) {
      if (is_array($allowed_checkin_days)) {
        // Array of allowed days (e.g., [6] for Saturday, [0,6] for Sunday and Saturday)
        $day_allowed = in_array($checkin_day_of_week, $allowed_checkin_days);
      } elseif (is_string($allowed_checkin_days)) {
        // String format (e.g., "Saturday", "6", "saturday")
        $day_allowed = (stripos($allowed_checkin_days, strtolower($checkin_day_name)) !== false) ||
                       (stripos($allowed_checkin_days, (string)$checkin_day_of_week) !== false);
      } else {
        $day_allowed = true; // If format is unknown, allow it
      }
      
      if (!$day_allowed) {
        $range_available = false;
        $digim_checkin_blocked[$uuid] = true; // Track as check-in blocked due to day restriction
      }
    }

    // First, specifically check the check-in day for check-in blocked status (even if unavailable)
    $checkin_day_found = $days_by_date[$checkin_date_str] ?? null;
    if ($checkin_day_found) {
      $checkin_allows_checkin = $checkin_day_found['allows_checkin'] ?? $checkin_day_found['checkin_allowed'] ?? true;
      if (isset($checkin_day_found['checkin_allowed']) && $checkin_day_found['checkin_allowed'] === false) {
        $checkin_allows_checkin = false;
      }
      
      $checkin_closed = $checkin_day_found['closed_for_checkin'] ?? $checkin_day_found['closed_for_check_in'] ?? false;
      if ($checkin_closed === true || $checkin_closed === 'true' || $checkin_closed === 1) {
        $checkin_allows_checkin = false;
      }
      
      $checkin_blocked_flag = $checkin_day_found['checkin_blocked'] ?? $checkin_day_found['check_in_blocked'] ?? $checkin_day_found['check-in_blocked'] ?? false;
      if ($checkin_blocked_flag === true || $checkin_blocked_flag === 'true' || $checkin_blocked_flag === 1) {
        $checkin_allows_checkin = false;
      }
      
      $checkin_day_status = $checkin_day_found['status'] ?? [];
      if (is_array($checkin_day_status)) {
        if (isset($checkin_day_status['checkin_blocked']) && $checkin_day_status['checkin_blocked']) {
          $checkin_allows_checkin = false;
        }
        if (isset($checkin_day_status['allows_checkin']) && $checkin_day_status['allows_checkin'] === false) {
          $checkin_allows_checkin = false;
        }
        if (isset($checkin_day_status['checkin_allowed']) && $checkin_day_status['checkin_allowed'] === false) {
          $checkin_allows_checkin = false;
        }
        if (isset($checkin_day_status['closed_for_checkin']) && $checkin_day_status['closed_for_checkin'] === true) {
          $checkin_allows_checkin = false;
        }
      }
      
      if ($checkin_allows_checkin === false) {
        $range_available = false;
        $digim_checkin_blocked[$uuid] = true;
      }
    }

    // Loop through each night from checkin to (checkout - 1)
    while ($current < $end && $range_available) {
      $date_str = date('Y-m-d', $current);
      $day_found = $days_by_date[$date_str] ?? null;
      $is_checkin_day = ($date_str === $checkin_date_str);

      // Check if this is the check-in day and if check-in is blocked (check this BEFORE availability check)
      if ($is_checkin_day && $day_found) {
        $day_allows_checkin = $day_found['allows_checkin'] ?? $day_found['checkin_allowed'] ?? true;
        if (isset($day_found['checkin_allowed']) && $day_found['checkin_allowed'] === false) {
          $day_allows_checkin = false;
        }
        
        // Check closed_for_checkin
        $day_closed_for_checkin = $day_found['closed_for_checkin'] ?? $day_found['closed_for_check_in'] ?? false;
        if ($day_closed_for_checkin === true || $day_closed_for_checkin === 'true' || $day_closed_for_checkin === 1) {
          $day_allows_checkin = false;
        }
        
        // Check checkin_blocked field
        $day_checkin_blocked = $day_found['checkin_blocked'] ?? $day_found['check_in_blocked'] ?? $day_found['check-in_blocked'] ?? false;
        if ($day_checkin_blocked === true || $day_checkin_blocked === 'true' || $day_checkin_blocked === 1) {
          $day_allows_checkin = false;
        }
        
        // Check status object for check-in blocked indicators
        $day_status = $day_found['status'] ?? [];
        if (is_array($day_status)) {
          if (isset($day_status['checkin_blocked']) && $day_status['checkin_blocked']) {
            $day_allows_checkin = false;
          }
          if (isset($day_status['allows_checkin']) && $day_status['allows_checkin'] === false) {
            $day_allows_checkin = false;
          }
          if (isset($day_status['checkin_allowed']) && $day_status['checkin_allowed'] === false) {
            $day_allows_checkin = false;
          }
        }
        
        if ($day_allows_checkin === false) {
          $range_available = false;
          $digim_checkin_blocked[$uuid] = true;
          break;
        }
      }

      // Now check if day is available (after check-in blocked check)
      if (!$day_found || !digim_calendar_day_is_available($day_found)) {
        $range_available = false;
        // If this is the check-in day and it's unavailable, also check if it's check-in blocked
        if ($is_checkin_day && $day_found) {
          // Re-check for check-in blocked even if day is unavailable
          $day_allows_checkin = $day_found['allows_checkin'] ?? $day_found['checkin_allowed'] ?? true;
          $day_closed_for_checkin = $day_found['closed_for_checkin'] ?? $day_found['closed_for_check_in'] ?? false;
          $day_checkin_blocked = $day_found['checkin_blocked'] ?? $day_found['check_in_blocked'] ?? $day_found['check-in_blocked'] ?? false;
          $day_status = $day_found['status'] ?? [];
          
          if (isset($day_found['checkin_allowed']) && $day_found['checkin_allowed'] === false) {
            $day_allows_checkin = false;
          }
          if ($day_closed_for_checkin === true || $day_closed_for_checkin === 'true' || $day_closed_for_checkin === 1) {
            $day_allows_checkin = false;
          }
          if ($day_checkin_blocked === true || $day_checkin_blocked === 'true' || $day_checkin_blocked === 1) {
            $day_allows_checkin = false;
          }
          if (is_array($day_status)) {
            if (isset($day_status['checkin_blocked']) && $day_status['checkin_blocked']) {
              $day_allows_checkin = false;
            }
            if (isset($day_status['allows_checkin']) && $day_status['allows_checkin'] === false) {
              $day_allows_checkin = false;
            }
            if (isset($day_status['closed_for_checkin']) && $day_status['closed_for_checkin'] === true) {
              $day_allows_checkin = false;
            }
          }
          
          if ($day_allows_checkin === false) {
            $digim_checkin_blocked[$uuid] = true;
          }
        }
        break;
      }
      
      // Minimum nights: only enforce on check-in day (stay must satisfy check-in day's min, not every night's).
      // Otherwise 2-night weekend stays are wrongly rejected when a later night has min_nights=3.
      if ($is_checkin_day) {
        $day_min_nights = $day_found['min_nights']
          ?? $day_found['minimum_nights']
          ?? $day_found['min_stay']
          ?? $day_found['minimum_stay']
          ?? (isset($day_found['pricing']) && isset($day_found['pricing']['min_nights']) ? $day_found['pricing']['min_nights'] : null)
          ?? null;
        if ($day_min_nights !== null && $requested_nights < (int)$day_min_nights) {
          $range_available = false;
          if (!isset($digim_min_nights_required[$uuid]) || (int)$day_min_nights > $digim_min_nights_required[$uuid]) {
            $digim_min_nights_required[$uuid] = (int)$day_min_nights;
            $min_nights_cache_key = 'digim_min_nights_' . md5($uuid . '|' . $checkin . '|' . $checkout);
            set_transient($min_nights_cache_key, (int)$day_min_nights, $cache_ttl);
          }
          break;
        }
      }

      $current = strtotime('+1 day', $current);
    }

    if ($range_available) {
      // Checkout date is the day the guest LEAVES (morning departure) - they do NOT stay that night.
      // So we must NOT require the checkout day to be "available" for stay - only that checkout
      // (departure) is allowed. A day can be "unavailable" for new stays (e.g. next guest checks in
      // that afternoon) but the current guest can still checkout that morning.
      $checkout_day = $days_by_date[$checkout] ?? null;
      if ($checkout_day) {
        // Only check if checkout is explicitly blocked on this date (closed_for_checkout = true)
        $closed_for_checkout = $checkout_day['closed_for_checkout'] ?? $checkout_day['closed_for_check_out'] ?? false;
        $is_checkout_blocked = false;
        if (is_bool($closed_for_checkout) && $closed_for_checkout === true) {
          $is_checkout_blocked = true;
        } elseif (is_string($closed_for_checkout)) {
          $checkout_bool = filter_var($closed_for_checkout, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
          if ($checkout_bool === true) {
            $is_checkout_blocked = true;
          }
        } elseif (is_numeric($closed_for_checkout) && (int)$closed_for_checkout === 1) {
          $is_checkout_blocked = true;
        }
        
        if ($is_checkout_blocked) {
          $range_available = false;
        }
      }
      // If checkout day is missing from calendar, allow it (API may not include all days; don't block availability)
    }

    if ($range_available) {
      $results[] = $uuid;
      $available_map[$uuid] = true;
      set_transient('digim_availability_v3_' . md5($uuid . '|' . $checkin . '|' . $checkout), 'available', $cache_ttl);
      $digim_next_available_suggestions[$uuid] = null;
      set_transient($suggestion_cache_key, 'none', $cache_ttl);
    } else {
      // Only cache "unavailable" when we had real calendar data; empty/failed API response should not stick
      if (!empty($days_by_date)) {
        set_transient('digim_availability_v3_' . md5($uuid . '|' . $checkin . '|' . $checkout), 'unavailable', $cache_ttl);

      // If we haven't stored minimum nights yet, check all days in the range to find the maximum requirement
      if (!isset($digim_min_nights_required[$uuid])) {
        $max_min_nights = null;
        $check_current = strtotime($checkin);
        $check_end = strtotime($checkout);
        
        while ($check_current < $check_end) {
          $check_date_str = date('Y-m-d', $check_current);
          $check_day = $days_by_date[$check_date_str] ?? null;
          
          if ($check_day) {
            // Try multiple possible field names for minimum nights
            $day_min = $check_day['min_nights'] 
              ?? $check_day['minimum_nights'] 
              ?? $check_day['min_stay'] 
              ?? $check_day['minimum_stay']
              ?? (isset($check_day['pricing']) && isset($check_day['pricing']['min_nights']) ? $check_day['pricing']['min_nights'] : null)
              ?? null;
            if ($day_min !== null) {
              $day_min_int = (int)$day_min;
              if ($max_min_nights === null || $day_min_int > $max_min_nights) {
                $max_min_nights = $day_min_int;
              }
            }
          }
          
          $check_current = strtotime('+1 day', $check_current);
        }
        
        // If we found a minimum nights requirement and requested nights is less, store it
        if ($max_min_nights !== null && $requested_nights < $max_min_nights) {
          $digim_min_nights_required[$uuid] = $max_min_nights;
          // Also cache this for future requests
          $min_nights_cache_key = 'digim_min_nights_' . md5($uuid . '|' . $checkin . '|' . $checkout);
          set_transient($min_nights_cache_key, $max_min_nights, $cache_ttl);
        }
      }

      // Attempt to find the next available window that respects minimum nights and check-in restrictions
      if ($flexible_weekend_next) {
        // Start from the day after the searched weekend; then move to next Friday.
        $search_cursor = strtotime($checkout . ' +1 day');
        while ((int) date('w', $search_cursor) !== 5) {
          $search_cursor = strtotime('+1 day', $search_cursor);
        }
      } elseif ($flexible_week_next) {
        $search_cursor = strtotime($checkin);
      } else {
        $search_cursor = strtotime($checkin);
      }
      $search_end_ts = strtotime($query_end_date);
      $next_available = null;
      
      // Get minimum nights and check-in restrictions from the original check-in day if available
      $original_checkin_day = $days_by_date[date('Y-m-d', strtotime($checkin))] ?? null;
      $property_min_nights = null;
      $property_allowed_checkin_days = null;
      
      if ($original_checkin_day) {
        $property_min_nights = $original_checkin_day['min_nights'] ?? $original_checkin_day['minimum_nights'] ?? null;
        $property_allowed_checkin_days = $original_checkin_day['checkin_days'] ?? $original_checkin_day['allowed_checkin_days'] ?? null;
      }

      while ($search_cursor <= $search_end_ts) {
        $candidate_start = $search_cursor;
        $candidate_start_date_str = date('Y-m-d', $candidate_start);
        $candidate_start_day = $days_by_date[$candidate_start_date_str] ?? null;
        
        // Check if this day allows check-in
        if ($candidate_start_day) {
          $allows_checkin = $candidate_start_day['allows_checkin'] ?? $candidate_start_day['checkin_allowed'] ?? true;
          if (isset($candidate_start_day['checkin_allowed']) && $candidate_start_day['checkin_allowed'] === false) {
            $allows_checkin = false;
          }
          
          if ($allows_checkin === false) {
            $search_cursor = $flexible_weekend_next ? strtotime('+7 days', $search_cursor) : strtotime('+1 day', $search_cursor);
            continue;
          }
          
          // Check check-in day restrictions
          $candidate_allowed_checkin_days = $candidate_start_day['checkin_days'] ?? $candidate_start_day['allowed_checkin_days'] ?? $property_allowed_checkin_days;
          if ($candidate_allowed_checkin_days !== null) {
            $candidate_day_of_week = (int) date('w', $candidate_start);
            $candidate_day_name = date('l', $candidate_start);
            
            if (is_array($candidate_allowed_checkin_days)) {
              $day_allowed = in_array($candidate_day_of_week, $candidate_allowed_checkin_days);
            } elseif (is_string($candidate_allowed_checkin_days)) {
              $day_allowed = (stripos($candidate_allowed_checkin_days, strtolower($candidate_day_name)) !== false) ||
                             (stripos($candidate_allowed_checkin_days, (string)$candidate_day_of_week) !== false);
            } else {
              $day_allowed = true;
            }
            
            if (!$day_allowed) {
              $search_cursor = $flexible_weekend_next ? strtotime('+7 days', $search_cursor) : strtotime('+1 day', $search_cursor);
              continue;
            }
          }
          
          // Get minimum nights for this candidate start date
          $candidate_min_nights = $candidate_start_day['min_nights'] ?? $candidate_start_day['minimum_nights'] ?? $property_min_nights;
          if ($flexible_weekend_next) {
            $required_nights = 2; // Weekend = Fri–Sun only
          } elseif ($flexible_week_next) {
            $required_nights = 7; // Week = 7 nights
          } else {
            $required_nights = $candidate_min_nights !== null ? max($requested_nights, (int)$candidate_min_nights) : $requested_nights;
          }
        } else {
          $required_nights = $flexible_weekend_next ? 2 : ($flexible_week_next ? 7 : $requested_nights);
        }
        
        $candidate_end = $candidate_start;
        $fits = true;

        // Check availability for the required number of nights
        for ($i = 0; $i < $required_nights; $i++) {
          $candidate_date_str = date('Y-m-d', $candidate_end);
          $candidate_day = $days_by_date[$candidate_date_str] ?? null;
          if (!$candidate_day || !digim_calendar_day_is_available($candidate_day)) {
            $fits = false;
            break;
          }
          $candidate_end = strtotime('+1 day', $candidate_end);
        }

        if ($fits) {
          // Checkout day: guest leaves that morning, doesn't stay. Only require checkout not blocked.
          $candidate_checkout_date_str = date('Y-m-d', $candidate_end);
          $candidate_checkout_day = $days_by_date[$candidate_checkout_date_str] ?? null;
          if ($candidate_checkout_day) {
            $closed_for_checkout = $candidate_checkout_day['closed_for_checkout'] ?? $candidate_checkout_day['closed_for_check_out'] ?? false;
            $blocked = (is_bool($closed_for_checkout) && $closed_for_checkout) ||
              (is_string($closed_for_checkout) && filter_var($closed_for_checkout, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE) === true) ||
              (is_numeric($closed_for_checkout) && (int)$closed_for_checkout === 1);
            if ($blocked) {
              $fits = false;
            }
          }
        }

        if ($fits) {
          $next_available = date('Y-m-d', $candidate_start);
          // Update suggested nights to match minimum requirement if needed (not in flexible weekend mode)
          if (! $flexible_weekend_next && isset($required_nights) && $required_nights > $requested_nights) {
            $requested_nights = $required_nights;
          }
          break;
        }

        $search_cursor = $flexible_weekend_next ? strtotime('+7 days', $search_cursor) : strtotime('+1 day', $search_cursor);
      }

      if ($next_available) {
        $suggest_nights = $flexible_weekend_next ? 2 : ($flexible_week_next ? 7 : $requested_nights);
        $suggested_checkout = date('Y-m-d', strtotime("+{$suggest_nights} days", strtotime($next_available)));
        $suggestion_payload = [
          'start'    => $next_available,
          'checkout' => $suggested_checkout,
          'nights'   => $suggest_nights,
        ];
        $digim_next_available_suggestions[$uuid] = $suggestion_payload;
        set_transient($suggestion_cache_key, $suggestion_payload, $cache_ttl);
      } else {
        $digim_next_available_suggestions[$uuid] = null;
        set_transient($suggestion_cache_key, 'none', $cache_ttl);
      }
      }
    }
  }

  // Process quote responses from same multi (calendar + quote in one round-trip for ~2s).
  if (!empty($quote_handles) && isset($quote_key_prefix, $cache_ttl_q)) {
    foreach ($quote_handles as $uuid => $ch) {
      $body = curl_multi_getcontent($ch);
      curl_multi_remove_handle($mh, $ch);
      curl_close($ch);
      $data = json_decode($body, true);
      $quote = isset($data['data']) ? $data['data'] : $data;
      if (isset($quote['error']) || !is_array($quote)) {
        $quote_result[$uuid] = null;
        continue;
      }
      $checkin_obj = \DateTime::createFromFormat('Y-m-d', $checkin);
      $checkout_obj = \DateTime::createFromFormat('Y-m-d', $checkout);
      $nights = ($checkin_obj && $checkout_obj) ? max(1, (int) $checkin_obj->diff($checkout_obj)->days) : 1;
      $currency = $quote['currency'] ?? 'USD';
      $subtotal = 0;
      $total = 0;
      if (isset($quote['financials']['totals']) && is_array($quote['financials']['totals'])) {
        $t = $quote['financials']['totals'];
        $sc = $t['sub_total']['amount'] ?? $t['sub_total'][0]['amount'] ?? null;
        $tc = $t['total']['amount'] ?? $t['total'][0]['amount'] ?? null;
        if ($sc !== null) $subtotal = (float) $sc / 100.0;
        if ($tc !== null) $total = (float) $tc / 100.0;
      }
      $symbol = (stripos($currency, 'EUR') !== false) ? '€' : ((stripos($currency, 'GBP') !== false) ? '£' : '$');
      $discounts = [];
      $discount_sum = 0.0;
      if (isset($quote['financials']['discounts']) && is_array($quote['financials']['discounts'])) {
        foreach ($quote['financials']['discounts'] as $d) {
          $label = $d['name'] ?? $d['type'] ?? $d['label'] ?? '';
          if ((string) $label !== '') {
            $amt = round((float) ((int) ($d['amount'] ?? $d['value'] ?? 0)) / 100.0, 2);
            $discounts[] = ['name' => (string) $label, 'amount' => $amt];
            $discount_sum += $amt;
          }
        }
      }
      $cleaning_fee = 0.0;
      $service_fee = 0.0;
      if (isset($quote['financials']['fees']) && is_array($quote['financials']['fees'])) {
        foreach ($quote['financials']['fees'] as $f) {
          $n = strtolower((string) ($f['name'] ?? $f['type'] ?? $f['label'] ?? ''));
          $amt = round((float) ((int) ($f['amount'] ?? $f['value'] ?? 0)) / 100.0, 2);
          if (stripos($n, 'cleaning') !== false) $cleaning_fee += $amt;
          else $service_fee += $amt;
        }
      }
      $total_before_tax = round(max(0.0, $subtotal - $discount_sum + $cleaning_fee + $service_fee), 2);
      $pricing = [
        'checkin' => $checkin,
        'checkout' => $checkout,
        'subtotal' => $subtotal,
        'total' => $total,
        'total_before_tax' => $total_before_tax,
        'cleaning_fee' => $cleaning_fee,
        'service_fee' => $service_fee,
        'nights' => $nights,
        'currency' => $currency,
        'symbol' => $symbol,
        'discounts' => $discounts,
        'quote_id' => $quote['quote_id'] ?? null,
        'booking_url' => $quote['booking_url'] ?? null,
      ];
      $quote_result[$uuid] = $pricing;
      set_transient($quote_key_prefix . '_' . md5($uuid), $pricing, $cache_ttl_q);
    }
  }
  if ($quote_guests !== null) {
    $GLOBALS['digim_quote_map'] = array_merge($cached_quotes, $quote_result);
  }

  curl_multi_close($mh);
  return array_keys($available_map);
}

/**
 * Fetch images for multiple properties in parallel using curl_multi
 * Returns an array mapping UUID => array of image URLs
 */
function digimanagement_parallel_fetch_images($uuids)
{
  if (empty($uuids)) {
    return [];
  }

  // Ensure UUIDs are unique, non-empty strings
  $uuids = array_values(array_filter(
    array_unique(array_map(function ($uuid) {
      $uuid = is_null($uuid) ? '' : trim((string) $uuid);
      return $uuid !== '' ? $uuid : null;
    }, $uuids)),
    function ($uuid) {
      return $uuid !== null && $uuid !== '';
    }
  ));

  if (empty($uuids)) {
    return [];
  }

  $cache_ttl = intval(apply_filters('digim_images_cache_ttl', 60 * 30)); // 30 minutes default
  $cache_ttl = $cache_ttl > 0 ? $cache_ttl : 1800;

  $cached_images = [];
  $pending_uuids = [];

  // Check cache first
  foreach ($uuids as $uuid) {
    $cache_key = 'digim_images_v2_' . md5($uuid);
    $cached = get_transient($cache_key);
    if ($cached !== false && is_array($cached)) {
      $cached_images[$uuid] = $cached;
    } else {
      $pending_uuids[] = $uuid;
    }
  }

  // If everything was cached, return early
  if (empty($pending_uuids)) {
    return $cached_images;
  }

  // Fetch images in parallel
  $mh = curl_multi_init();
  $handles = [];

  foreach ($pending_uuids as $uuid) {
    $url = digimanagement_get_api_url() . "/properties/$uuid/images";
    $ch = curl_init();
    curl_setopt_array($ch, [
      CURLOPT_URL => $url,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_HTTPHEADER => [
        'Authorization: ' . digimanagement_get_api_token(),
        'Accept: application/json',
      ],
      CURLOPT_TIMEOUT => 8, // Shorter timeout for images
    ]);
    curl_multi_add_handle($mh, $ch);
    $handles[$uuid] = $ch;
  }

  if (!empty($handles)) {
    do {
      $status = curl_multi_exec($mh, $active);
      if ($active) {
        curl_multi_select($mh, 0.5); // Shorter select timeout
      }
    } while ($active && $status === CURLM_OK);
  }

  // Process results
  foreach ($handles as $uuid => $ch) {
    $body = curl_multi_getcontent($ch);
    $images_data = json_decode($body, true);
    $image_urls = [];

    if (is_array($images_data) && isset($images_data['data']) && is_array($images_data['data'])) {
      foreach ($images_data['data'] as $img) {
        // Prefer url (medium-res) for crisp card gallery; thumbnail is too small for 260–300px display
        $url = $img['url'] ?? $img['original_url'] ?? $img['thumbnail_url'] ?? null;
        if ($url) {
          $image_urls[] = $url;
        }
      }
    }

    // Cache the results (even if empty, to avoid repeated failed requests)
    $cache_key = 'digim_images_v2_' . md5($uuid);
    set_transient($cache_key, $image_urls, $cache_ttl);

    $cached_images[$uuid] = $image_urls;

    curl_multi_remove_handle($mh, $ch);
    curl_close($ch);
  }

  curl_multi_close($mh);
  return $cached_images;
}

/**
 * Fetch checkout_blocked_dates for multiple properties in parallel
 * @param array $uuids Array of property UUIDs
 * @param string $checkin Check-in date (Y-m-d format)
 * @param string $checkout Checkout date (Y-m-d format)
 * @return array Associative array of uuid => checkout_blocked_dates array
 */
function digimanagement_parallel_fetch_checkout_blocked_dates($uuids, $checkin, $checkout)
{
  if (empty($uuids) || empty($checkin) || empty($checkout)) {
    return [];
  }

  // Validate dates - check if they are valid date strings
  $checkin = trim((string) $checkin);
  $checkout = trim((string) $checkout);
  
  // Check if dates are valid by trying to parse them
  $checkin_test = DateTimeImmutable::createFromFormat('Y-m-d', $checkin, wp_timezone());
  $checkout_test = DateTimeImmutable::createFromFormat('Y-m-d', $checkout, wp_timezone());
  
  // Also check for common invalid date strings
  $invalid_date_strings = ['Invalid date', 'invalid date', 'Invalid Date', 'NaN', 'null', 'undefined'];
  if (!$checkin_test || !$checkout_test || in_array($checkin, $invalid_date_strings, true) || in_array($checkout, $invalid_date_strings, true)) {
    return [];
  }

  // Ensure UUIDs are unique, non-empty strings
  $uuids = array_values(array_filter(
    array_unique(array_map(function ($uuid) {
      $uuid = is_null($uuid) ? '' : trim((string) $uuid);
      return $uuid !== '' ? $uuid : null;
    }, $uuids)),
    function ($uuid) {
      return $uuid !== null && $uuid !== '';
    }
  ));

  if (empty($uuids)) {
    return [];
  }

  // Calculate date range: from checkin to checkout + 30 days to find next available
  $start_date = $checkin;
  $end_date_obj = new DateTimeImmutable($checkout, wp_timezone());
  $end_date = $end_date_obj->modify('+30 days')->format('Y-m-d');

  $cache_ttl = intval(apply_filters('digim_checkout_blocked_cache_ttl', 30 * MINUTE_IN_SECONDS));
  $cache_ttl = $cache_ttl > 0 ? $cache_ttl : 1800;

  $cached_data = [];
  $pending_uuids = [];

  // Check cache first
  foreach ($uuids as $uuid) {
    $cache_key = 'digim_checkout_blocked_' . md5($uuid . '|' . $start_date . '|' . $end_date);
    $cached = get_transient($cache_key);
    if ($cached !== false && is_array($cached)) {
      // Handle both old format (array of dates) and new format (array with 'checkout_blocked' and 'unavailable')
      if (isset($cached['checkout_blocked']) && isset($cached['unavailable'])) {
        $cached_data[$uuid] = $cached;
      } else {
        // Old format - convert to new format
        $cached_data[$uuid] = [
          'checkout_blocked' => $cached,
          'unavailable' => [],
        ];
      }
    } else {
      $pending_uuids[] = $uuid;
    }
  }

  // If everything was cached, return early
  if (empty($pending_uuids)) {
    return $cached_data;
  }

  // Fetch checkout_blocked_dates in parallel
  $mh = curl_multi_init();
  $handles = [];

  foreach ($pending_uuids as $uuid) {
    $query_args = http_build_query([
      'start_date' => $start_date,
      'end_date'   => $end_date,
    ]);
    $url = digimanagement_get_api_url() . "/properties/$uuid/calendar?$query_args";
    $ch = curl_init();
    // Performance: short timeouts so checkout-blocked batch (current page only) stays fast.
    curl_setopt_array($ch, [
      CURLOPT_URL => $url,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_HTTPHEADER => [
        'Authorization: ' . digimanagement_get_api_token(),
        'Accept: application/json',
        'Cache-Control: no-cache',
        'Pragma: no-cache',
      ],
      CURLOPT_TIMEOUT => 5,
      CURLOPT_CONNECTTIMEOUT => 3,
    ]);
    curl_multi_add_handle($mh, $ch);
    $handles[$uuid] = $ch;
  }

  if (!empty($handles)) {
    do {
      $status = curl_multi_exec($mh, $active);
      if ($active) {
        curl_multi_select($mh, 0.3);
      }
    } while ($active && $status === CURLM_OK);
  }

  // Process results
  foreach ($handles as $uuid => $ch) {
    $body = curl_multi_getcontent($ch);
    $calendar = json_decode($body, true);
    $checkout_blocked_dates = [];
    $unavailable_dates = [];

    if (is_array($calendar) && isset($calendar['data']['days']) && is_array($calendar['data']['days'])) {
      foreach ($calendar['data']['days'] as $day) {
        if (!empty($day['date'])) {
          $date = $day['date'];
          
          // Check for checkout-blocked dates
          $closed_for_checkout = $day['closed_for_checkout'] ?? $day['closed_for_check_out'] ?? false;
          if (is_bool($closed_for_checkout) && $closed_for_checkout) {
            $checkout_blocked_dates[] = $date;
          } elseif (is_string($closed_for_checkout) && in_array(strtolower($closed_for_checkout), ['true', '1'], true)) {
            $checkout_blocked_dates[] = $date;
          } elseif (is_numeric($closed_for_checkout) && $closed_for_checkout == 1) {
            $checkout_blocked_dates[] = $date;
          }
          
          // Check for unavailable dates (booked/blocked)
          $status = $day['status'] ?? [];
          $available = $status['available'] ?? true;
          if (is_bool($available) && !$available) {
            $unavailable_dates[] = $date;
          } elseif (isset($status['state'])) {
            $state = strtolower((string)$status['state']);
            if (in_array($state, ['blocked', 'booked', 'unavailable', 'maintenance'], true)) {
              $unavailable_dates[] = $date;
            }
          } elseif (isset($status['type'])) {
            $type = strtolower((string)$status['type']);
            if (in_array($type, ['blocked', 'booked', 'unavailable', 'maintenance'], true)) {
              $unavailable_dates[] = $date;
            }
          }
        }
      }
    }

    // Cache the results (store both checkout-blocked and unavailable dates)
    $cache_key = 'digim_checkout_blocked_' . md5($uuid . '|' . $start_date . '|' . $end_date);
    $cache_data = [
      'checkout_blocked' => $checkout_blocked_dates,
      'unavailable' => $unavailable_dates,
    ];
    set_transient($cache_key, $cache_data, $cache_ttl);

    $cached_data[$uuid] = $cache_data;

    curl_multi_remove_handle($mh, $ch);
    curl_close($ch);
  }

  curl_multi_close($mh);
  return $cached_data;
}

// === Shortcode === //
require_once plugin_dir_path(__FILE__) . 'includes/shortcode.php';

// === SINGLE PAGE === //
add_action('init', function () {
  // Support both UUID and slug-based URLs
  add_rewrite_rule('^property/([^/]+)/?', 'index.php?dm_property_identifier=$matches[1]', 'top');
  add_rewrite_tag('%dm_property_identifier%', '([^&]+)');
});
add_filter('template_include', function ($template) {
  if (get_query_var('dm_property_identifier')) {
    return plugin_dir_path(__FILE__) . 'templates/property-single.php';
  }
  return $template;
});

// === Daily auto-clear properties cache so Hospitable changes appear within 24h ===
add_action('digim_daily_properties_cache_clear', function () {
  if (function_exists('digim_clear_properties_cache')) {
    digim_clear_properties_cache(true);
  } else {
    delete_transient('digim_all_properties');
    delete_option('digim_properties_stored');
  }
});

add_action('init', function () {
  if (!wp_next_scheduled('digim_daily_properties_cache_clear')) {
    wp_schedule_event(time(), 'daily', 'digim_daily_properties_cache_clear');
  }
}, 20);

// === Background pre-warm: calendars + images for ALL properties (instant search) ===
// Runs every 15 min. Fetches today→today+1 year calendar for every property and caches images.
// When cache is warm, date searches return in ~1s (zero API calls on the request path).
// Disable with: add_filter('digim_enable_calendar_prewarm', '__return_false');
add_action('digim_prewarm_calendar_cache', function () {
  if (!apply_filters('digim_enable_calendar_prewarm', true)) {
    return;
  }
  if (!function_exists('digim_get_all_properties') || !function_exists('digimanagement_get_api_url')) {
    return;
  }
  $all = digim_get_all_properties();
  if (empty($all)) {
    return;
  }
  $uuids = array_values(array_filter(array_unique(array_map(function ($p) {
    $u = $p['uuid'] ?? $p['id'] ?? null;
    return $u ? trim((string) $u) : null;
  }, $all)), function ($u) { return $u !== null && $u !== ''; }));
  if (empty($uuids)) {
    return;
  }

  $tz = function_exists('wp_timezone') ? wp_timezone() : new \DateTimeZone('UTC');
  $today_obj = new \DateTimeImmutable('today', $tz);
  $year_start = $today_obj->format('Y-m-d');
  $year_end = $today_obj->modify('+1 year')->format('Y-m-d');
  $calendar_cache_ttl = (int) apply_filters('digim_calendar_cache_ttl', 30 * MINUTE_IN_SECONDS);
  $calendar_cache_ttl = $calendar_cache_ttl > 0 ? $calendar_cache_ttl : 1800;
  $image_cache_ttl = (int) apply_filters('digim_images_cache_ttl', 30 * MINUTE_IN_SECONDS);
  $image_cache_ttl = $image_cache_ttl > 0 ? $image_cache_ttl : 1800;

  $api_base = digimanagement_get_api_url();
  $token = digimanagement_get_api_token();
  $batch_size = (int) apply_filters('digim_prewarm_batch_size', 10);
  $batch_size = max(4, min(20, $batch_size));

  // Process in batches to avoid overwhelming the API
  $chunks = array_chunk($uuids, $batch_size);
  foreach ($chunks as $chunk) {
    $mh = curl_multi_init();
    $cal_handles = [];
    $img_handles = [];

    foreach ($chunk as $uuid) {
      // Calendar: skip if already cached
      $cal_cache_key = 'digim_calendar_' . md5($uuid . '|' . $year_start . '|' . $year_end);
      if (get_transient($cal_cache_key) === false) {
        $url = $api_base . '/properties/' . $uuid . '/calendar?' . http_build_query(['start_date' => $year_start, 'end_date' => $year_end]);
        $ch = curl_init();
        curl_setopt_array($ch, [
          CURLOPT_URL => $url,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_HTTPHEADER => ['Authorization: ' . $token, 'Accept: application/json'],
          CURLOPT_TIMEOUT => 10,
          CURLOPT_CONNECTTIMEOUT => 3,
        ]);
        curl_multi_add_handle($mh, $ch);
        $cal_handles[$uuid] = $ch;
      }

      // Images: skip if already cached
      $img_cache_key = 'digim_images_v2_' . md5($uuid);
      if (get_transient($img_cache_key) === false) {
        $url = $api_base . '/properties/' . $uuid . '/images';
        $ch = curl_init();
        curl_setopt_array($ch, [
          CURLOPT_URL => $url,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_HTTPHEADER => ['Authorization: ' . $token, 'Accept: application/json'],
          CURLOPT_TIMEOUT => 8,
          CURLOPT_CONNECTTIMEOUT => 3,
        ]);
        curl_multi_add_handle($mh, $ch);
        $img_handles[$uuid] = $ch;
      }
    }

    if (!empty($cal_handles) || !empty($img_handles)) {
      do {
        $status = curl_multi_exec($mh, $active);
        if ($active) { curl_multi_select($mh, 0.2); }
      } while ($active && $status === CURLM_OK);
    }

    // Store calendar results
    foreach ($cal_handles as $uuid => $ch) {
      $body = curl_multi_getcontent($ch);
      $calendar = json_decode($body, true);
      if (is_array($calendar)) {
        set_transient('digim_calendar_' . md5($uuid . '|' . $year_start . '|' . $year_end), $calendar, $calendar_cache_ttl);
      }
      curl_multi_remove_handle($mh, $ch);
      curl_close($ch);
    }

    // Store image results
    foreach ($img_handles as $uuid => $ch) {
      $body = curl_multi_getcontent($ch);
      $images_data = json_decode($body, true);
      $image_urls = [];
      if (is_array($images_data) && isset($images_data['data']) && is_array($images_data['data'])) {
        foreach ($images_data['data'] as $img) {
          $url = $img['url'] ?? $img['original_url'] ?? $img['thumbnail_url'] ?? null;
          if ($url) { $image_urls[] = $url; }
        }
      }
      set_transient('digim_images_v2_' . md5($uuid), $image_urls, $image_cache_ttl);
      curl_multi_remove_handle($mh, $ch);
      curl_close($ch);
    }

    curl_multi_close($mh);
  }
});

add_action('init', function () {
  if (apply_filters('digim_enable_calendar_prewarm', true) && !wp_next_scheduled('digim_prewarm_calendar_cache')) {
    wp_schedule_event(time(), 'digim_15min', 'digim_prewarm_calendar_cache');
  }
  if (get_option('digim_cards_per_page_migrated_v2') !== '1') {
    update_option('digim_cards_per_page', 9);
    update_option('digim_cards_per_page_migrated_v2', '1');
  }
}, 21);

add_filter('cron_schedules', function ($schedules) {
  if (!isset($schedules['digim_15min'])) {
    $schedules['digim_15min'] = ['interval' => 15 * 60, 'display' => __('Every 15 Minutes', 'DigiM')];
  }
  return $schedules;
});

// === Flush === //
register_activation_hook(__FILE__, function () {
  flush_rewrite_rules();
  update_option('digim_cards_per_page', 9);
  if (!wp_next_scheduled('digim_daily_properties_cache_clear')) {
    wp_schedule_event(time(), 'daily', 'digim_daily_properties_cache_clear');
  }
  if (!wp_next_scheduled('digim_prewarm_calendar_cache')) {
    wp_schedule_event(time(), 'digim_15min', 'digim_prewarm_calendar_cache');
  }
});
register_deactivation_hook(__FILE__, function () {
  flush_rewrite_rules();
  wp_clear_scheduled_hook('digim_daily_properties_cache_clear');
  wp_clear_scheduled_hook('digim_prewarm_calendar_cache');
});

// === AJAX HANDLER === //
add_action('wp_ajax_digimanagement_get_listings', 'digimanagement_get_listings_ajax');
add_action('wp_ajax_nopriv_digimanagement_get_listings', 'digimanagement_get_listings_ajax');

// Filter listings AJAX handler
add_action('wp_ajax_digim_filter_listings', 'digimanagement_filter_listings_ajax');
add_action('wp_ajax_nopriv_digim_filter_listings', 'digimanagement_filter_listings_ajax');

// Booking submission AJAX handler
add_action('wp_ajax_digim_submit_booking', 'digimanagement_submit_booking_ajax');
add_action('wp_ajax_nopriv_digim_submit_booking', 'digimanagement_submit_booking_ajax');
// Create reservation and return hosted checkout URL
add_action('wp_ajax_digim_create_reservation', 'digimanagement_create_reservation_ajax');
add_action('wp_ajax_nopriv_digim_create_reservation', 'digimanagement_create_reservation_ajax');

// Pricing and availability AJAX handlers
add_action('wp_ajax_digim_get_pricing', 'digimanagement_get_pricing_ajax');
add_action('wp_ajax_nopriv_digim_get_pricing', 'digimanagement_get_pricing_ajax');

add_action('wp_ajax_digim_check_availability', 'digimanagement_check_availability_ajax');
add_action('wp_ajax_nopriv_digim_check_availability', 'digimanagement_check_availability_ajax');

add_action('wp_ajax_digim_get_unavailable_dates', 'digimanagement_get_unavailable_dates_ajax');
add_action('wp_ajax_nopriv_digim_get_unavailable_dates', 'digimanagement_get_unavailable_dates_ajax');

// Quote hydration: single-property quote for progressive card pricing (cached 10 min)
add_action('wp_ajax_get_property_quote', 'digim_get_property_quote_ajax');
add_action('wp_ajax_nopriv_get_property_quote', 'digim_get_property_quote_ajax');

/**
 * AJAX handler: get_property_quote
 * Returns cached or fresh Hospitable quote for one property. Used by frontend to progressively
 * hydrate card prices without blocking page render. Cache: 10 minutes.
 */
function digim_get_property_quote_ajax() {
  $uuid = isset($_POST['uuid']) ? sanitize_text_field(wp_unslash($_POST['uuid'])) : '';
  $checkin = isset($_POST['checkin']) ? sanitize_text_field(wp_unslash($_POST['checkin'])) : '';
  $checkout = isset($_POST['checkout']) ? sanitize_text_field(wp_unslash($_POST['checkout'])) : '';
  $guests = isset($_POST['guests']) ? max(1, (int) $_POST['guests']) : 1;
  $pets = isset($_POST['pets']) ? max(0, (int) $_POST['pets']) : 0;

  if ($uuid === '' || $checkin === '' || $checkout === '') {
    wp_send_json_error(array('message' => 'Missing or invalid parameters.'), 400);
  }

  $cache_key = 'hosp_quote_' . md5($uuid) . '_' . $checkin . '_' . $checkout . '_' . $guests . '_' . $pets;
  $cached = get_transient($cache_key);
  if ($cached !== false && is_array($cached)) {
    wp_send_json_success($cached);
  }

  $api_base = digimanagement_get_api_url();
  $api_token = digimanagement_get_api_token();
  if ($api_token === '') {
    wp_send_json_error(array('message' => 'API not configured.'), 500);
  }

  $endpoint = $api_base . '/properties/' . rawurlencode($uuid) . '/quote';
  $body = wp_json_encode(array(
    'checkin_date' => $checkin,
    'checkout_date' => $checkout,
    'guests' => array(
      'adults' => $guests,
      'children' => 0,
      'infants' => 0,
      'pets' => $pets,
    ),
  ));

  $response = wp_remote_post($endpoint, array(
    'headers' => array(
      'Authorization' => $api_token,
      'Content-Type' => 'application/json',
      'Accept' => 'application/json',
    ),
    'body' => $body,
    'timeout' => 20,
    'data_format' => 'body',
  ));

  if (is_wp_error($response)) {
    wp_send_json_error(array('message' => 'Failed to fetch quote.', 'error' => $response->get_error_message()), 500);
  }

  $code = wp_remote_retrieve_response_code($response);
  $raw = wp_remote_retrieve_body($response);
  $decoded = json_decode($raw, true);

  if ($code < 200 || $code >= 300 || !is_array($decoded)) {
    wp_send_json_error(array('message' => 'Quote request failed.', 'status' => $code), 500);
  }

  $quote = isset($decoded['data']) ? $decoded['data'] : $decoded;
  if (!is_array($quote) || isset($quote['error'])) {
    wp_send_json_error(array('message' => 'Invalid quote response.'), 500);
  }

  $subtotal = 0.0;
  $total = 0.0;
  if (isset($quote['financials']['totals']) && is_array($quote['financials']['totals'])) {
    $t = $quote['financials']['totals'];
    $sc = isset($t['sub_total']['amount']) ? $t['sub_total']['amount'] : (isset($t['sub_total'][0]['amount']) ? $t['sub_total'][0]['amount'] : null);
    $tc = isset($t['total']['amount']) ? $t['total']['amount'] : (isset($t['total'][0]['amount']) ? $t['total'][0]['amount'] : null);
    if ($sc !== null) {
      $subtotal = (float) $sc / 100.0;
    }
    if ($tc !== null) {
      $total = (float) $tc / 100.0;
    }
  }

  $discount_sum = 0.0;
  $discounts_list = [];
  if (isset($quote['financials']['discounts']) && is_array($quote['financials']['discounts'])) {
    foreach ($quote['financials']['discounts'] as $d) {
      $amt_cents = (int) (isset($d['amount']) ? $d['amount'] : (isset($d['value']) ? $d['value'] : 0));
      $amt = (float) $amt_cents / 100.0;
      $discount_sum += $amt;
      $d_name = isset($d['name']) ? (string) $d['name'] : (isset($d['label']) ? (string) $d['label'] : (isset($d['type']) ? (string) $d['type'] : ''));
      if ($d_name !== '' && $amt > 0) {
        $discounts_list[] = array('name' => $d_name, 'amount' => round($amt, 2));
      }
    }
  }

  $cleaning_fee = 0.0;
  $service_fee = 0.0;
  $pet_fee = 0.0;
  if (isset($quote['financials']['fees']) && is_array($quote['financials']['fees'])) {
    foreach ($quote['financials']['fees'] as $f) {
      $n = strtolower((string) (isset($f['name']) ? $f['name'] : (isset($f['type']) ? $f['type'] : (isset($f['label']) ? $f['label'] : ''))));
      $amt_cents = (int) (isset($f['amount']) ? $f['amount'] : (isset($f['value']) ? $f['value'] : 0));
      $amt = (float) $amt_cents / 100.0;
      if (strpos($n, 'cleaning') !== false) {
        $cleaning_fee += $amt;
      } elseif (strpos($n, 'pet') !== false) {
        $pet_fee += $amt;
      } else {
        $service_fee += $amt;
      }
    }
  }

  $nights = 0;
  $ci_obj = \DateTimeImmutable::createFromFormat('Y-m-d', $checkin);
  $co_obj = \DateTimeImmutable::createFromFormat('Y-m-d', $checkout);
  if ($ci_obj && $co_obj) {
    $nights = max(1, (int) $ci_obj->diff($co_obj)->days);
  }

  $total_without_taxes = $subtotal + $cleaning_fee + $service_fee + $pet_fee;
  $final_price = round(max(0.0, $total_without_taxes - $discount_sum), 2);
  $discount_amount = round($discount_sum, 2);
  $has_discount = $discount_amount > 0 && $final_price > 0;

  $checkin_fmt = '';
  $checkout_fmt = '';
  if ($ci_obj && $co_obj) {
    $checkin_fmt = $ci_obj->format('M j');
    $checkout_fmt = $co_obj->format('M j');
  }

  $response_data = array(
    'uuid' => $uuid,
    'total_without_taxes' => round($total_without_taxes, 2),
    'final_price' => $final_price,
    'pet_fee' => round($pet_fee, 2),
    'discount_amount' => $discount_amount,
    'has_discount' => $has_discount,
    'discounts' => $discounts_list,
    'nights' => $nights,
    'checkin_fmt' => $checkin_fmt,
    'checkout_fmt' => $checkout_fmt,
    'symbol' => (stripos($quote['currency'] ?? 'USD', 'EUR') !== false) ? '€' : ((stripos($quote['currency'] ?? '', 'GBP') !== false) ? '£' : '$'),
  );

  set_transient($cache_key, $response_data, 10 * MINUTE_IN_SECONDS);
  wp_send_json_success($response_data);
}

/**
 * AJAX handler for filtering listings
 * Returns filtered properties HTML
 */
function digimanagement_filter_listings_ajax() {
    // Get all filter parameters
    $search = isset($_POST['property_search']) ? $_POST['property_search'] : '';
    if (is_array($search)) {
        $search = array_map('sanitize_text_field', array_filter($search));
    } else {
        $search = $search ? [sanitize_text_field($search)] : [];
    }
    
    $checkin = sanitize_text_field($_POST['checkin'] ?? '');
    $checkout = sanitize_text_field($_POST['checkout'] ?? '');
    $adults = intval($_POST['adults'] ?? 0);
    $children = intval($_POST['children'] ?? 0);
    $infants = intval($_POST['infants'] ?? 0);
    $current_page = max(1, intval($_POST['property_page'] ?? 1));
    $show_available_only = isset($_POST['show_available_only']) && $_POST['show_available_only'] === '1';
    $filter_bedrooms = isset($_POST['filter_bedrooms']) ? sanitize_text_field($_POST['filter_bedrooms']) : '';
    $filter_beds = isset($_POST['filter_beds']) ? sanitize_text_field($_POST['filter_beds']) : '';
    $filter_price_min = isset($_POST['filter_price_min']) ? sanitize_text_field($_POST['filter_price_min']) : '';
    $filter_price_max = isset($_POST['filter_price_max']) ? sanitize_text_field($_POST['filter_price_max']) : '';
    $filter_amenities_raw = isset($_POST['filter_amenities']) ? $_POST['filter_amenities'] : '';
    $pets = intval($_POST['pets'] ?? 0);
    // Flexible search parameters (passed through to shortcode)
    $flex_mode  = isset($_POST['flex_mode']) ? sanitize_text_field($_POST['flex_mode']) : '';
    $flex_month = isset($_POST['flex_month']) ? (int) $_POST['flex_month'] : 0;
    $flex_year  = isset($_POST['flex_year']) ? (int) $_POST['flex_year'] : 0;
    
    // Backup original GET parameters
    $original_get = $_GET;
    
    // Set GET parameters for shortcode function (it reads from $_GET)
    $_GET['property_search'] = $search;
    $_GET['checkin'] = $checkin;
    $_GET['checkout'] = $checkout;
    $_GET['adults'] = $adults;
    $_GET['children'] = $children;
    $_GET['infants'] = $infants;
    $_GET['pets'] = $pets;
    if ($flex_mode !== '') {
        $_GET['flex_mode'] = $flex_mode;
    } else {
        unset($_GET['flex_mode']);
    }
    if ($flex_month > 0) {
        $_GET['flex_month'] = $flex_month;
    } else {
        unset($_GET['flex_month']);
    }
    if ($flex_year > 0) {
        $_GET['flex_year'] = $flex_year;
    } else {
        unset($_GET['flex_year']);
    }
    $_GET['property_page'] = $current_page;
    if (!empty($_POST['digim_ok'])) {
        $_GET['digim_ok'] = sanitize_text_field(wp_unslash((string) $_POST['digim_ok']));
    } else {
        unset($_GET['digim_ok']);
    }
    if ($show_available_only) {
        $_GET['show_available_only'] = '1';
    } else {
        unset($_GET['show_available_only']);
    }
    if ($filter_bedrooms) {
        $_GET['filter_bedrooms'] = $filter_bedrooms;
    } else {
        unset($_GET['filter_bedrooms']);
    }
    if ($filter_beds) {
        $_GET['filter_beds'] = $filter_beds;
    } else {
        unset($_GET['filter_beds']);
    }
    if ($filter_price_min !== '') {
        $_GET['filter_price_min'] = $filter_price_min;
    } else {
        unset($_GET['filter_price_min']);
    }
    if ($filter_price_max !== '') {
        $_GET['filter_price_max'] = $filter_price_max;
    } else {
        unset($_GET['filter_price_max']);
    }
    if (is_array($filter_amenities_raw) && !empty($filter_amenities_raw)) {
        $_GET['filter_amenities'] = array_map('sanitize_text_field', array_filter($filter_amenities_raw));
    } elseif (is_string($filter_amenities_raw) && $filter_amenities_raw !== '') {
        $_GET['filter_amenities'] = array_map('trim', array_filter(explode(',', sanitize_text_field($filter_amenities_raw))));
    } else {
        unset($_GET['filter_amenities']);
    }
    
    // Call the shortcode function to get filtered HTML
    ob_start();
    echo digimanagement_hospitable_listings_shortcode([]);
    $html = ob_get_clean();
    
    // Restore original GET parameters
    $_GET = $original_get;
    
    // Include filtered markers so the map updates to match the list
    $markers = isset($GLOBALS['digim_marker_data_for_response']) ? $GLOBALS['digim_marker_data_for_response'] : [];
    
    // Return the HTML and markers
    wp_send_json_success([
        'html' => $html,
        'page' => $current_page,
        'markers' => $markers
    ]);
}

// Test endpoint to debug API responses
add_action('wp_ajax_digim_test_api', 'digimanagement_test_api_ajax');
add_action('wp_ajax_nopriv_digim_test_api', 'digimanagement_test_api_ajax');

// Simple test endpoint
add_action('wp_ajax_digim_simple_test', 'digimanagement_simple_test_ajax');
add_action('wp_ajax_nopriv_digim_simple_test', 'digimanagement_simple_test_ajax');


function digimanagement_get_listings_ajax()
{
  $search = isset($_GET['property_search']) ? $_GET['property_search'] : '';
  // Handle both array (multiple) and string (single) formats
  if (is_array($search)) {
    $search = array_map('sanitize_text_field', array_filter($search));
  } else {
    $search = $search ? [sanitize_text_field($search)] : [];
  }
  $checkin = sanitize_text_field($_GET['checkin'] ?? '');
  $checkout = sanitize_text_field($_GET['checkout'] ?? '');
  $flex_mode  = isset($_GET['flex_mode']) ? sanitize_text_field($_GET['flex_mode']) : '';
  $flex_month = isset($_GET['flex_month']) ? (int) $_GET['flex_month'] : 0;
  $flex_year  = isset($_GET['flex_year']) ? (int) $_GET['flex_year'] : 0;

  // When "Weekend in <Month>" is selected, do NOT derive a single weekend — we check all
  // weekend dates in that month. Leave checkin/checkout empty so flexible-weekend branch runs.
  $is_flexible_weekend_in_month = (
    $flex_mode === 'weekend'
    && $flex_month >= 1 && $flex_month <= 12
    && $flex_year >= 1970
  );
  if (!$is_flexible_weekend_in_month && function_exists('digim_derive_flexible_weekend_dates')) {
    list($checkin, $checkout, $flex_weekend_derived) = digim_derive_flexible_weekend_dates($checkin, $checkout, $flex_mode, $flex_month, $flex_year);
    if ($flex_weekend_derived) {
      $GLOBALS['digim_flexible_weekend_next_available'] = true;
    }
  }
  if ($is_flexible_weekend_in_month) {
    $checkin  = '';
    $checkout = '';
  }
  // When "Week in [Month]" is selected, do NOT derive a single 7-day range — we check all
  // 7-day windows starting in that month (e.g. March 1–8, 2–9, 7–14, etc.).
  $is_flexible_week_in_month = (
    $flex_mode === 'week'
    && $flex_month >= 1 && $flex_month <= 12
    && $flex_year >= 1970
  );
  if ($is_flexible_week_in_month) {
    $checkin  = '';
    $checkout = '';
  }
  $is_flexible_month_in_month = (
    $flex_mode === 'month'
    && $flex_month >= 1 && $flex_month <= 12
    && $flex_year >= 1970
  );
  if ($is_flexible_month_in_month) {
    $checkin  = '';
    $checkout = '';
  }
  if (!$is_flexible_week_in_month && !$is_flexible_month_in_month && function_exists('digim_derive_flexible_week_dates')) {
    list($checkin, $checkout, $flex_week_derived) = digim_derive_flexible_week_dates($checkin, $checkout, $flex_mode, $flex_month, $flex_year);
    if ($flex_week_derived) {
      $GLOBALS['digim_flexible_week_next_available'] = true;
    }
  }

  // Load properties using the same cached helper as the shortcode.
  // This avoids re-paginating /properties with fresh API calls on every AJAX search.
  $all_properties = [];
  if (function_exists('digim_get_all_properties')) {
    $all_properties = digim_get_all_properties();
    // Exclude listings hidden on frontend (DigiM → Listings)
    if (function_exists('digim_get_hidden_listing_uuids')) {
      $hidden_uuids = digim_get_hidden_listing_uuids();
      if (!empty($hidden_uuids)) {
        $all_properties = array_values(array_filter($all_properties, function ($p) use ($hidden_uuids) {
          $uuid = $p['uuid'] ?? $p['id'] ?? null;
          $uuid = $uuid !== null ? trim((string) $uuid) : '';
          return $uuid === '' || !in_array($uuid, $hidden_uuids, true);
        }));
      }
    }
  } else {
    // Fallback: direct API pagination if helper is not available (same per_page as shortcode for speed).
    $page = 1;
    $per_page = (int) apply_filters('digim_properties_per_page', 100);
    $per_page = $per_page > 0 ? min($per_page, 100) : 100;
    do {
      $url = digimanagement_get_api_url() . '/properties?' . http_build_query(['page' => $page, 'per_page' => $per_page]);
      $response = wp_remote_get($url, [
        'headers' => [
          'Authorization' => digimanagement_get_api_token(),
          'Accept' => 'application/json',
          'Cache-Control' => 'no-cache',
          'Pragma' => 'no-cache',
        ],
        'timeout' => 10,
      ]);
      if (is_wp_error($response)) {
        wp_send_json_error($response->get_error_message());
      }
      $data = json_decode(wp_remote_retrieve_body($response), true);
      if (!isset($data['data'])) {
        break;
      }
      $all_properties = array_merge($all_properties, $data['data']);
      $page++;
    } while (isset($data['links']['next']) && $data['links']['next']);
    // Exclude listings hidden on frontend (same as when using helper)
    if (function_exists('digim_get_hidden_listing_uuids')) {
      $hidden_uuids = digim_get_hidden_listing_uuids();
      if (!empty($hidden_uuids)) {
        $all_properties = array_values(array_filter($all_properties, function ($p) use ($hidden_uuids) {
          $uuid = $p['uuid'] ?? $p['id'] ?? null;
          $uuid = $uuid !== null ? trim((string) $uuid) : '';
          return $uuid === '' || !in_array($uuid, $hidden_uuids, true);
        }));
      }
    }
  }

  if (!empty($search)) {
    $all_properties = array_filter($all_properties, function ($p) use ($search) {
      $property_name = strtolower($p['public_name'] ?? $p['name'] ?? '');
      $property_city = strtolower($p['address']['city'] ?? '');
      foreach ($search as $search_term) {
        $search_lower = strtolower($search_term);
        if (stripos($property_name, $search_lower) !== false || stripos($property_city, $search_lower) !== false) {
          return true;
        }
      }
      return false;
    });
  }

  // Flexible "Week in [Month]": 7 nights, sampled every N days for speed (~6 ranges vs 31).
  if ($flex_mode === 'week' && $flex_month >= 1 && $flex_month <= 12 && $flex_year >= 1970 && count($all_properties) > 0) {
    $uuids = array_values(array_filter(
      array_unique(array_map(function ($p) {
        $uuid = $p['uuid'] ?? $p['id'] ?? null;
        return is_null($uuid) ? null : trim((string) $uuid);
      }, $all_properties)),
      function ($uuid) {
        return $uuid !== null && $uuid !== '';
      }
    ));

    $flex_nights = (int) apply_filters('digim_flexible_week_nights', 7);
    $flex_nights = max(3, min(14, $flex_nights));
    $range_step = (int) apply_filters('digim_flexible_week_range_step', 1);
    $range_step = max(1, min(7, $range_step));
    $week_ranges = [];
    try {
      $tz = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC');
      $first_of_month = new DateTimeImmutable(sprintf('%04d-%02d-01', $flex_year, $flex_month), $tz);
      $last_of_month = $first_of_month->modify('last day of this month');
      $current = $first_of_month;
      while ($current <= $last_of_month) {
        $range_checkin = $current->format('Y-m-d');
        $range_checkout = $current->modify('+' . $flex_nights . ' days')->format('Y-m-d');
        $week_ranges[] = [ $range_checkin, $range_checkout ];
        $current = $current->modify('+' . $range_step . ' days');
      }
    } catch (Exception $e) {
      $week_ranges = [];
    }

    $week_available_map = [];
    if (function_exists('digimanagement_parallel_calendar_check_multi_ranges')) {
      $multi_result = digimanagement_parallel_calendar_check_multi_ranges($uuids, $week_ranges);
      foreach ($multi_result as $uuid => $available_ranges) {
        if (!empty($available_ranges)) {
          $week_available_map[$uuid] = $available_ranges[0];
        }
      }
    } else {
      foreach ($week_ranges as $range) {
        list($range_checkin, $range_checkout) = $range;
        $available_for_week = digimanagement_parallel_calendar_check($uuids, $range_checkin, $range_checkout);
        if (!is_array($available_for_week)) {
          continue;
        }
        foreach ($available_for_week as $uuid) {
          $uuid = trim((string) $uuid);
          if ($uuid === '') {
            continue;
          }
          if (isset($week_available_map[$uuid])) {
            continue;
          }
          $week_available_map[$uuid] = [
            'checkin'  => $range_checkin,
            'checkout' => $range_checkout,
          ];
        }
      }
    }

    $filtered = [];
    foreach ($all_properties as $property) {
      $uuid = $property['uuid'] ?? $property['id'] ?? null;
      $uuid = is_null($uuid) ? '' : trim((string) $uuid);
      if ($uuid === '') {
        continue;
      }
      if (!isset($week_available_map[$uuid])) {
        continue;
      }
      $first_week = $week_available_map[$uuid];
      $property['_digim_is_suggestion'] = false;
      $property['_digim_flexible_week_dates'] = [ $first_week ];
      $filtered[] = $property;
    }
    $all_properties = $filtered;
  } elseif ($flex_mode === 'month' && $flex_month >= 1 && $flex_month <= 12 && $flex_year >= 1970 && count($all_properties) > 0) {
    // Flexible "Month in [Month]": 1-month stays (day X to same date next month, e.g. Feb 2 – Mar 2)
    $uuids = array_values(array_filter(
      array_unique(array_map(function ($p) {
        $uuid = $p['uuid'] ?? $p['id'] ?? null;
        return is_null($uuid) ? null : trim((string) $uuid);
      }, $all_properties)),
      function ($uuid) { return $uuid !== null && $uuid !== ''; }
    ));

    $range_step = (int) apply_filters('digim_flexible_month_range_step', 1);
    $range_step = max(1, min(15, $range_step));
    $month_ranges = [];
    try {
      $tz = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC');
      $first_of_month = new DateTimeImmutable(sprintf('%04d-%02d-01', $flex_year, $flex_month), $tz);
      $last_of_month = $first_of_month->modify('last day of this month');
      $current = $first_of_month;
      while ($current <= $last_of_month) {
        $range_checkin = $current->format('Y-m-d');
        $range_checkout = $current->modify('+1 month')->format('Y-m-d');
        $month_ranges[] = [ $range_checkin, $range_checkout ];
        $current = $current->modify('+' . $range_step . ' days');
      }
    } catch (Exception $e) {
      $month_ranges = [];
    }

    $month_available_map = [];
    if (function_exists('digimanagement_parallel_calendar_check_multi_ranges')) {
      $multi_result = digimanagement_parallel_calendar_check_multi_ranges($uuids, $month_ranges);
      foreach ($multi_result as $uuid => $available_ranges) {
        if (!empty($available_ranges)) {
          $month_available_map[$uuid] = $available_ranges[0];
        }
      }
    } else {
      foreach ($month_ranges as $range) {
        list($range_checkin, $range_checkout) = $range;
        $available = digimanagement_parallel_calendar_check($uuids, $range_checkin, $range_checkout);
        if (!is_array($available)) continue;
        foreach ($available as $uuid) {
          $uuid = trim((string) $uuid);
          if ($uuid !== '' && !isset($month_available_map[$uuid])) {
            $month_available_map[$uuid] = [ 'checkin' => $range_checkin, 'checkout' => $range_checkout ];
          }
        }
      }
    }

    $filtered = [];
    foreach ($all_properties as $property) {
      $uuid = $property['uuid'] ?? $property['id'] ?? null;
      $uuid = is_null($uuid) ? '' : trim((string) $uuid);
      if ($uuid !== '' && isset($month_available_map[$uuid])) {
        $property['_digim_is_suggestion'] = false;
        $property['_digim_flexible_month_dates'] = [ $month_available_map[$uuid] ];
        $filtered[] = $property;
      }
    }
    $all_properties = $filtered;
  } elseif ($is_flexible_weekend_in_month && count($all_properties) > 0) {
    // Flexible "Weekend in [Month]": show properties available for at least one weekend in the month.
    $uuids = array_values(array_filter(
      array_unique(array_map(function ($p) {
        $uuid = $p['uuid'] ?? $p['id'] ?? null;
        return is_null($uuid) ? null : trim((string) $uuid);
      }, $all_properties)),
      function ($uuid) {
        return $uuid !== null && $uuid !== '';
      }
    ));

    // All Fridays in month → 2-night weekend ranges (e.g. May: 1–3, 8–10, 15–17, 22–24, 29–31).
    $weekend_ranges = function_exists('digim_get_weekend_ranges_for_month')
      ? digim_get_weekend_ranges_for_month($flex_year, $flex_month)
      : [];

    // Check EVERY weekend in the month; property is included if available for any of them.
    // Keep the first available weekend per property for consistent display.
    $weekend_available_map = [];
    foreach ($weekend_ranges as $range) {
      list($weekend_checkin, $weekend_checkout) = $range;
      $available_for_weekend = digimanagement_parallel_calendar_check($uuids, $weekend_checkin, $weekend_checkout);
      if (!is_array($available_for_weekend)) {
        continue;
      }
      foreach ($available_for_weekend as $uuid) {
        $uuid = trim((string) $uuid);
        if ($uuid === '' || isset($weekend_available_map[$uuid])) {
          continue;
        }
        $weekend_available_map[$uuid] = [[
          'checkin'  => $weekend_checkin,
          'checkout' => $weekend_checkout,
        ]];
      }
    }

    $filtered = [];
    foreach ($all_properties as $property) {
      $uuid = $property['uuid'] ?? $property['id'] ?? null;
      $uuid = is_null($uuid) ? '' : trim((string) $uuid);
      if ($uuid !== '' && !empty($weekend_available_map[$uuid])) {
        $first_weekend = $weekend_available_map[$uuid][0];
        $property['_digim_is_suggestion'] = false;
        $property['_digim_suggested_start'] = null;
        $property['_digim_suggested_checkout'] = null;
        $property['_digim_suggested_nights'] = null;
        $property['_digim_min_nights_required'] = null;
        $property['_digim_flexible_weekend_dates'] = [ $first_weekend ];
        $filtered[] = $property;
      }
    }
    $all_properties = $filtered;
  } elseif ($checkin && $checkout && count($all_properties) > 0) {
    $uuids = array_map(function ($p) {
      return $p['uuid'] ?? $p['id'] ?? null;
    }, $all_properties);

    $uuids = array_values(array_filter(
      array_unique(array_map(function ($uuid) {
        $uuid = is_null($uuid) ? '' : trim((string) $uuid);
        return $uuid !== '' ? $uuid : null;
      }, $uuids)),
      function ($uuid) {
        return $uuid !== null && $uuid !== '';
      }
    ));

    if (!empty($uuids)) {
      $available_uuids = digimanagement_parallel_calendar_check($uuids, $checkin, $checkout);
      $available_uuid_map = [];
      if (is_array($available_uuids)) {
        foreach ($available_uuids as $uuid) {
          $uuid = trim((string) $uuid);
          if ($uuid !== '') {
            $available_uuid_map[$uuid] = true;
          }
        }
      }

      global $digim_next_available_suggestions;
      $suggestion_map = is_array($digim_next_available_suggestions) ? $digim_next_available_suggestions : [];

      $available_properties = [];
      $suggested_properties = [];

      foreach ($all_properties as $property) {
        $uuid = $property['uuid'] ?? $property['id'] ?? null;
        $uuid = is_null($uuid) ? '' : trim((string) $uuid);
        if ($uuid === '') {
          continue;
        }

        if (isset($available_uuid_map[$uuid])) {
          $property['_digim_is_suggestion'] = false;
          $available_properties[] = $property;
        } elseif (!empty($suggestion_map[$uuid]) && is_array($suggestion_map[$uuid])) {
          $suggestion = $suggestion_map[$uuid];
          $property['_digim_is_suggestion'] = true;
          $property['_digim_suggested_start'] = $suggestion['start'] ?? null;
          $property['_digim_suggested_checkout'] = $suggestion['checkout'] ?? null;
          $property['_digim_suggested_nights'] = $suggestion['nights'] ?? null;
          $suggested_properties[] = $property;
        }
      }

      $all_properties = array_merge($available_properties, $suggested_properties);
    } else {
      $all_properties = [];
    }
  }

  wp_send_json_success(array_values($all_properties));
}

// Booking submission function
function digimanagement_submit_booking_ajax()
{
  // Verify nonce
  if (!wp_verify_nonce($_POST['nonce'], 'digim_booking_nonce')) {
    wp_send_json_error(['message' => 'Invalid nonce']);
    return;
  }

  // Get and sanitize booking data
  $property_uuid = sanitize_text_field($_POST['property_uuid'] ?? '');
  $checkin_date = sanitize_text_field($_POST['checkin_date'] ?? '');
  $checkout_date = sanitize_text_field($_POST['checkout_date'] ?? '');
  $adults = intval($_POST['adults'] ?? 0);
  $children = intval($_POST['children'] ?? 0);
  $infants = intval($_POST['infants'] ?? 0);
  $total_guests = intval($_POST['total_guests'] ?? 0);

  // Validate required fields
  if (empty($property_uuid) || empty($checkin_date) || empty($checkout_date) || $total_guests <= 0) {
    wp_send_json_error(['message' => 'Missing required booking information']);
    return;
  }

  // Validate dates
  $checkin = DateTime::createFromFormat('Y-m-d', $checkin_date);
  $checkout = DateTime::createFromFormat('Y-m-d', $checkout_date);
  
  if (!$checkin || !$checkout || $checkin >= $checkout) {
    wp_send_json_error(['message' => 'Invalid dates']);
    return;
  }

  // Check if check-in is in the future
  if ($checkin < new DateTime('today')) {
    wp_send_json_error(['message' => 'Check-in date must be in the future']);
    return;
  }

  try {
    // Prepare booking data for Hospitable API
    $booking_data = [
      'property_uuid' => $property_uuid,
      'checkin_date' => $checkin_date,
      'checkout_date' => $checkout_date,
      'adults' => $adults,
      'children' => $children,
      'infants' => $infants,
      'total_guests' => $total_guests,
      'status' => 'pending',
      'created_at' => current_time('mysql')
    ];

    // Submit to Hospitable API - using the booking endpoint
    $response = wp_remote_post(digimanagement_get_api_url() . '/bookings', [
      'headers' => [
        'Authorization' => digimanagement_get_api_token(),
        'Accept' => 'application/json',
        'Content-Type' => 'application/json',
      ],
      'body' => json_encode([
        'property_uuid' => $property_uuid,
        'checkin_date' => $checkin_date,
        'checkout_date' => $checkout_date,
        'adults' => $adults,
        'children' => $children,
        'infants' => $infants,
        'total_guests' => $total_guests,
        'status' => 'pending'
      ]),
      'timeout' => 30,
    ]);

    if (is_wp_error($response)) {
      wp_send_json_error(['message' => 'Failed to submit booking: ' . $response->get_error_message()]);
      return;
    }

    $response_code = wp_remote_retrieve_response_code($response);
    $response_body = json_decode(wp_remote_retrieve_body($response), true);

    if ($response_code >= 200 && $response_code < 300) {
      // Store booking locally for tracking
      $booking_id = wp_insert_post([
        'post_type' => 'digim_booking',
        'post_title' => 'Booking for Property ' . $property_uuid,
        'post_status' => 'publish',
        'meta_input' => $booking_data
      ]);

      wp_send_json_success([
        'message' => 'Booking submitted successfully',
        'booking_id' => $booking_id,
        'hospitable_response' => $response_body
      ]);
    } else {
      $error_message = $response_body['message'] ?? 'Unknown error occurred';
      wp_send_json_error(['message' => 'Booking failed: ' . $error_message]);
    }

  } catch (Exception $e) {
    wp_send_json_error(['message' => 'Booking error: ' . $e->getMessage()]);
  }
}

// Create reservation through Hospitable and return a hosted checkout URL
function digimanagement_create_reservation_ajax()
{
  // Verify nonce
  if (!wp_verify_nonce($_POST['nonce'], 'digim_booking_nonce')) {
    wp_send_json_error(['message' => 'Invalid nonce']);
    return;
  }

  $property_uuid = sanitize_text_field($_POST['property_uuid'] ?? '');
  $checkin_date = sanitize_text_field($_POST['checkin_date'] ?? '');
  $checkout_date = sanitize_text_field($_POST['checkout_date'] ?? '');
  $adults = intval($_POST['adults'] ?? 1);
  $children = intval($_POST['children'] ?? 0);
  $infants = intval($_POST['infants'] ?? 0);

  if (empty($property_uuid) || empty($checkin_date) || empty($checkout_date)) {
    wp_send_json_error(['message' => 'Missing required reservation parameters']);
    return;
  }

  try {
    $payload = [
      'property_uuid' => $property_uuid,
      'checkin_date' => $checkin_date,
      'checkout_date' => $checkout_date,
      'guests' => [
        'adults' => $adults,
        'children' => $children,
        'infants' => $infants,
      ],
      'source' => 'website',
      'status' => 'pending',
    ];

    $response = wp_remote_post(digimanagement_get_api_url() . '/reservations', [
      'headers' => [
        'Authorization' => digimanagement_get_api_token(),
        'Accept' => 'application/json',
        'Content-Type' => 'application/json',
      ],
      'body' => json_encode($payload),
      'timeout' => 30,
    ]);

    if (is_wp_error($response)) {
      wp_send_json_error(['message' => 'Reservation request failed: ' . $response->get_error_message()]);
      return;
    }

    $code = wp_remote_retrieve_response_code($response);
    $body_raw = wp_remote_retrieve_body($response);
    $body = json_decode($body_raw, true);

    if ($code >= 200 && $code < 300) {
      // Try common fields where checkout URL might be provided
      $checkout_url = $body['data']['checkout_url']
        ?? $body['data']['public_checkout_url']
        ?? $body['checkout_url']
        ?? $body['public_checkout_url']
        ?? null;
      $reservation_uuid = $body['data']['id'] ?? $body['data']['uuid'] ?? $body['id'] ?? $body['uuid'] ?? null;

      wp_send_json_success([
        'message' => 'Reservation created',
        'reservation_uuid' => $reservation_uuid,
        'checkout_url' => $checkout_url,
        'raw' => $body,
      ]);
    } else {
      $err = $body['message'] ?? $body_raw ?? 'Unknown error';
      wp_send_json_error(['message' => 'Reservation create failed: ' . $err, 'raw' => $body]);
    }
  } catch (Exception $e) {
    wp_send_json_error(['message' => 'Reservation error: ' . $e->getMessage()]);
  }
}

// Function to get quote from Hospitable API
function digimanagement_get_quote($property_uuid, $checkin_date, $checkout_date, $adults = 1, $children = 0, $infants = 0, $pets = 0) {
    $api_url = digimanagement_get_api_url() . "/properties/$property_uuid/quote";
    $api_token = digimanagement_get_api_token();
    
    // Minimal payload for pricing only - no guest details needed
    $request_body = json_encode([
        'checkin_date' => $checkin_date,
        'checkout_date' => $checkout_date,
        'guests' => [
            'adults' => $adults,
            'children' => $children,
            'infants' => $infants,
            'pets' => $pets
        ]
    ]);
    
    error_log("Quote API URL: " . $api_url);
    error_log("Quote API Token: " . substr($api_token, 0, 20) . "...");
    error_log("Quote API Request Body: " . $request_body);
    error_log("Quote API Request Headers: " . json_encode([
        'Authorization' => substr($api_token, 0, 20) . '...',
        'Accept' => 'application/json',
        'Content-Type' => 'application/json'
    ]));
    error_log("Property UUID for quote: " . $property_uuid);
    error_log("Property UUID length: " . strlen($property_uuid));
    
    $response = wp_remote_post($api_url, [
        'headers' => [
            'Authorization' => $api_token,
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
        ],
        'body' => $request_body,
        'timeout' => 30,
    ]);
    
    if (is_wp_error($response)) {
        error_log("Quote API error: " . $response->get_error_message());
        return [ 'error' => $response->get_error_message() ];
    }
    
    $response_code = wp_remote_retrieve_response_code($response);
    $response_body = json_decode(wp_remote_retrieve_body($response), true);
    
    error_log("Quote API response code: " . $response_code);
    error_log("Quote API response body: " . wp_remote_retrieve_body($response));
    error_log("Quote API response parsed: " . print_r($response_body, true));
    
    if ($response_code >= 200 && $response_code < 300) {
        // Some responses wrap data under 'data'
        return isset($response_body['data']) ? $response_body['data'] : $response_body;
    }
    // Return error details for debugging upstream
    return [
        'error' => 'non_2xx',
        'status' => $response_code,
        'body' => $response_body
    ];
}

/**
 * Fetch quotes from Hospitable API for multiple properties in parallel.
 * Used for listing cards when check-in/check-out dates are present (calendar-driven pricing).
 *
 * @param array  $uuids     Property UUIDs.
 * @param string $checkin   Check-in date (Y-m-d).
 * @param string $checkout  Check-out date (Y-m-d).
 * @param int    $adults    Adult guests.
 * @param int    $children  Child guests.
 * @param int    $infants   Infant guests.
 * @param int    $pets      Pet guests.
 * @return array Map of uuid => pricing_data (or uuid => null on error). pricing_data: checkin, checkout, subtotal, total, total_before_tax, cleaning_fee, service_fee, nights, currency, symbol, discounts (array of {name, amount} from Hospitable).
 */
function digimanagement_parallel_quote_fetch($uuids, $checkin, $checkout, $adults = 1, $children = 0, $infants = 0, $pets = 0) {
    $result = [];
    $uuids = array_values(array_filter(array_map(function ($u) {
        $u = is_null($u) ? '' : trim((string) $u);
        return $u !== '' ? $u : null;
    }, $uuids)));
    if (empty($uuids) || empty($checkin) || empty($checkout)) {
        return $result;
    }

    $cache_ttl = (int) apply_filters('digim_quote_cache_ttl', 15 * MINUTE_IN_SECONDS);
    $cache_ttl = $cache_ttl > 0 ? $cache_ttl : 300;
    $cache_key_prefix = 'digim_quote_v3_' . md5($checkin . '|' . $checkout . '|' . $adults . '|' . $children . '|' . $infants . '|' . $pets);

    $pending = [];
    foreach ($uuids as $uuid) {
        $key = $cache_key_prefix . '_' . md5($uuid);
        $cached = get_transient($key);
        if ($cached !== false && is_array($cached)) {
            $result[$uuid] = $cached;
        } else {
            $pending[] = $uuid;
        }
    }

    if (empty($pending)) {
        return $result;
    }

    $api_base = digimanagement_get_api_url();
    $token = digimanagement_get_api_token();
    $payload = json_encode([
        'checkin_date' => $checkin,
        'checkout_date' => $checkout,
        'guests' => [
            'adults' => max(0, (int) $adults),
            'children' => max(0, (int) $children),
            'infants' => max(0, (int) $infants),
            'pets' => max(0, (int) $pets),
        ],
    ]);

    $mh = curl_multi_init();
    $handles = [];
    foreach ($pending as $uuid) {
        $url = $api_base . '/properties/' . $uuid . '/quote';
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_HTTPHEADER => [
                'Authorization: ' . $token,
                'Accept: application/json',
                'Content-Type: application/json',
            ],
            CURLOPT_TIMEOUT => (int) apply_filters('digim_quote_request_timeout', 6),
            CURLOPT_CONNECTTIMEOUT => 2,
        ]);
        curl_multi_add_handle($mh, $ch);
        $handles[$uuid] = $ch;
    }

    do {
        $status = curl_multi_exec($mh, $active);
        if ($active) {
            curl_multi_select($mh, 0.1);
        }
    } while ($active && $status === CURLM_OK);

    foreach ($handles as $uuid => $ch) {
        $body = curl_multi_getcontent($ch);
        curl_multi_remove_handle($mh, $ch);
        curl_close($ch);

        $data = json_decode($body, true);
        $quote = isset($data['data']) ? $data['data'] : $data;
        if (isset($quote['error']) || !is_array($quote)) {
            $result[$uuid] = null;
            continue;
        }

        $checkin_obj = DateTime::createFromFormat('Y-m-d', $checkin);
        $checkout_obj = DateTime::createFromFormat('Y-m-d', $checkout);
        $nights = ($checkin_obj && $checkout_obj) ? max(1, (int) $checkin_obj->diff($checkout_obj)->days) : 1;

        $currency = $quote['currency'] ?? 'USD';
        $subtotal = 0;
        $total = 0;
        if (isset($quote['financials']['totals']) && is_array($quote['financials']['totals'])) {
            $t = $quote['financials']['totals'];
            $sc = $t['sub_total']['amount'] ?? $t['sub_total'][0]['amount'] ?? null;
            $tc = $t['total']['amount'] ?? $t['total'][0]['amount'] ?? null;
            if ($sc !== null) {
                $subtotal = (float) $sc / 100.0;
            }
            if ($tc !== null) {
                $total = (float) $tc / 100.0;
            }
        }
        $symbol = '$';
        if (stripos($currency, 'EUR') !== false) {
            $symbol = '€';
        } elseif (stripos($currency, 'GBP') !== false) {
            $symbol = '£';
        }

        $discounts = [];
        $discount_sum = 0.0;
        if (isset($quote['financials']['discounts']) && is_array($quote['financials']['discounts'])) {
            foreach ($quote['financials']['discounts'] as $d) {
                $label = $d['name'] ?? $d['type'] ?? $d['label'] ?? '';
                if ((string) $label === '') {
                    continue;
                }
                $amt_cents = (int) ($d['amount'] ?? $d['value'] ?? 0);
                $amt = round((float) $amt_cents / 100.0, 2);
                $discounts[] = [
                    'name' => (string) $label,
                    'amount' => $amt,
                ];
                $discount_sum += $amt;
            }
        }

        $cleaning_fee = 0.0;
        $service_fee = 0.0;
        if (isset($quote['financials']['fees']) && is_array($quote['financials']['fees'])) {
            foreach ($quote['financials']['fees'] as $f) {
                $n = strtolower((string) ($f['name'] ?? $f['type'] ?? $f['label'] ?? ''));
                $amt_cents = (int) ($f['amount'] ?? $f['value'] ?? 0);
                $amt = round((float) $amt_cents / 100.0, 2);
                if (stripos($n, 'cleaning') !== false) {
                    $cleaning_fee += $amt;
                } else {
                    $service_fee += $amt;
                }
            }
        }

        $total_before_tax = $subtotal - $discount_sum + $cleaning_fee + $service_fee;
        $total_before_tax = round(max(0.0, $total_before_tax), 2);

        $pricing = [
            'checkin' => $checkin,
            'checkout' => $checkout,
            'subtotal' => $subtotal,
            'total' => $total,
            'total_before_tax' => $total_before_tax,
            'cleaning_fee' => $cleaning_fee,
            'service_fee' => $service_fee,
            'nights' => $nights,
            'currency' => $currency,
            'symbol' => $symbol,
            'discounts' => $discounts,
            'quote_id' => $quote['quote_id'] ?? null,
            'booking_url' => $quote['booking_url'] ?? null,
        ];
        $result[$uuid] = $pricing;
        set_transient($cache_key_prefix . '_' . md5($uuid), $pricing, $cache_ttl);
    }

    curl_multi_close($mh);
    return $result;
}

// Get pricing data from Hospitable API
function digimanagement_get_pricing_ajax()
{
  // Verify nonce
  if (!wp_verify_nonce($_POST['nonce'], 'digim_booking_nonce')) {
    wp_send_json_error(['message' => 'Invalid nonce']);
    return;
  }

  $property_uuid = sanitize_text_field($_POST['property_uuid'] ?? '');
  $checkin_date = sanitize_text_field($_POST['checkin_date'] ?? '');
  $checkout_date = sanitize_text_field($_POST['checkout_date'] ?? '');
  $adults = intval($_POST['adults'] ?? 1);
  $children = intval($_POST['children'] ?? 0);
  $infants = intval($_POST['infants'] ?? 0);
  $pets = intval($_POST['pets'] ?? 0);

  if (empty($property_uuid) || empty($checkin_date) || empty($checkout_date)) {
    wp_send_json_error(['message' => 'Missing required parameters']);
    return;
  }
  
  // Validate UUID format
  if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $property_uuid)) {
    wp_send_json_error(['message' => 'Invalid property UUID format: ' . $property_uuid]);
    return;
  }

  try {
    // Calculate nights
    $checkin = DateTime::createFromFormat('Y-m-d', $checkin_date);
    $checkout = DateTime::createFromFormat('Y-m-d', $checkout_date);
    $nights = $checkin->diff($checkout)->days;
    
    // Debug logging
    error_log("Pricing request - Property: $property_uuid, Checkin: $checkin_date, Checkout: $checkout_date, Nights: $nights");
    error_log("Property UUID type: " . gettype($property_uuid) . ", Length: " . strlen($property_uuid));
    error_log("Property UUID value: " . $property_uuid);

    // Always use Quote API per new logic
    $base_price = 0;
    $cleaning_fee = 0;
    $service_fee = 0;
    $security_deposit = 0;
    $subtotal = 0;
    $total = 0;
    $quote_data = digimanagement_get_quote($property_uuid, $checkin_date, $checkout_date, $adults, $children, $infants, $pets);

    // Handle error returned by helper
    if (isset($quote_data['error'])) {
      $err_message = 'Failed to generate quote';
      if (!empty($quote_data['status'])) {
        $err_message .= ' (HTTP ' . intval($quote_data['status']) . ')';
      }
      if (!empty($quote_data['body']['message'])) {
        $err_message .= ': ' . $quote_data['body']['message'];
      }
      if (!empty($quote_data['body']['errors'])) {
        $err_message .= ' - Errors: ' . json_encode($quote_data['body']['errors']);
      }
      $stored_token = get_option('digimanagement_api_key', '');
      $using_fallback_token = empty(trim($stored_token));
      wp_send_json_error([
        'message' => $err_message,
        'raw' => $quote_data,
        'token_source' => $using_fallback_token ? 'fallback' : 'stored'
      ]);
      return;
    }

    // Parse totals from quote financials (amounts are in cents)
    $currency = $quote_data['currency'] ?? 'USD';
    if (isset($quote_data['financials']['totals'])) {
      $totals = $quote_data['financials']['totals'];
      $sub_cents = null;
      $total_cents = null;
      if (isset($totals['sub_total']['amount'])) { $sub_cents = $totals['sub_total']['amount']; }
      if (isset($totals['sub_total'][0]['amount'])) { $sub_cents = $totals['sub_total'][0]['amount']; }
      if (isset($totals['total']['amount'])) { $total_cents = $totals['total']['amount']; }
      if (isset($totals['total'][0]['amount'])) { $total_cents = $totals['total'][0]['amount']; }

      if ($sub_cents !== null) { $subtotal = floatval($sub_cents) / 100.0; }
      if ($total_cents !== null) { $total = floatval($total_cents) / 100.0; }
    }

    // Derive per-night base price from subtotal
    if ($nights > 0 && $subtotal > 0) {
      $base_price = round($subtotal / $nights, 2);
    }

    $cleaning_fee = 0.0;
    $service_fee = 0.0;
    if (isset($quote_data['financials']['fees']) && is_array($quote_data['financials']['fees'])) {
      foreach ($quote_data['financials']['fees'] as $f) {
        $n = strtolower((string) ($f['name'] ?? $f['type'] ?? $f['label'] ?? ''));
        $amt_cents = (int) ($f['amount'] ?? $f['value'] ?? 0);
        $amt = round((float) $amt_cents / 100.0, 2);
        if (stripos($n, 'cleaning') !== false) {
          $cleaning_fee += $amt;
        } else {
          $service_fee += $amt;
        }
      }
    }

    $taxes_cents = 0;
    if (isset($quote_data['financials']['taxes']) && is_array($quote_data['financials']['taxes'])) {
      foreach ($quote_data['financials']['taxes'] as $t) {
        if (isset($t['amount'])) { $taxes_cents += intval($t['amount']); }
      }
    }
    $taxes_total = round($taxes_cents / 100.0, 2);

    $long_stay_discount = 0.0;
    $long_stay_discount_label = '';
    $discount_sum = 0.0;
    if (isset($quote_data['financials']['discounts']) && is_array($quote_data['financials']['discounts'])) {
      foreach ($quote_data['financials']['discounts'] as $discount) {
        $amt_cents = (int) ($discount['amount'] ?? $discount['value'] ?? 0);
        $amt = round((float) $amt_cents / 100.0, 2);
        $discount_sum += $amt;
        $discount_name = strtolower($discount['name'] ?? $discount['type'] ?? $discount['label'] ?? '');
        $discount_label = $discount['name'] ?? $discount['type'] ?? $discount['label'] ?? 'Discount';
        $normalized = preg_replace('/[^a-z0-9]/', '', $discount_name);
        if (stripos($normalized, 'longstay') !== false ||
            (stripos($discount_name, 'long') !== false && stripos($discount_name, 'stay') !== false)) {
          $long_stay_discount = $amt;
          $long_stay_discount_label = $discount_label;
        }
      }
    }

    $total_before_tax = round($subtotal - $discount_sum + $cleaning_fee + $service_fee, 2);
    $total_before_tax = max(0.0, $total_before_tax);

    $pricing_data = [
      'base_price' => $base_price,
      'cleaning_fee' => $cleaning_fee,
      'service_fee' => $service_fee,
      'taxes' => $taxes_total,
      'security_deposit' => $security_deposit,
      'nights' => $nights,
      'subtotal' => $subtotal,
      'long_stay_discount' => $long_stay_discount,
      'long_stay_discount_label' => $long_stay_discount_label,
      'total' => $total,
      'total_before_tax' => $total_before_tax,
      'currency' => $currency,
      'quote_id' => $quote_data['quote_id'] ?? null,
      'booking_url' => $quote_data['booking_url'] ?? null,
    ];

    wp_send_json_success($pricing_data);

  } catch (Exception $e) {
    wp_send_json_error(['message' => 'Pricing error: ' . $e->getMessage()]);
  }
}

// Check availability from Hospitable API
/**
 * Fetch calendar for a property in a date range with server-side cache.
 * Ensures ONLY ONE availability API call per (property, start, end); never call inside a loop.
 * Cache key: listing ID(s) + check-in + check-out; TTL 15–30 min.
 *
 * @param string $property_uuid Property UUID
 * @param string $start_date Y-m-d
 * @param string $end_date Y-m-d
 * @return array|null Calendar data array or null on failure
 */
function digim_fetch_calendar_cached($property_uuid, $start_date, $end_date)
{
  $cache_key = 'digim_calendar_' . md5($property_uuid . '|' . $start_date . '|' . $end_date);
  $cached = get_transient($cache_key);
  if ($cached !== false && is_array($cached)) {
    return $cached;
  }

  $url = digimanagement_get_api_url() . '/properties/' . $property_uuid . '/calendar?' . http_build_query([
    'start_date' => $start_date,
    'end_date'   => $end_date,
  ]);
  $response = wp_remote_get($url, [
    'headers' => [
      'Authorization' => digimanagement_get_api_token(),
      'Accept'       => 'application/json',
    ],
    'timeout'         => (int) apply_filters('digim_calendar_request_timeout', 5),
    'connect_timeout' => (int) apply_filters('digim_calendar_connect_timeout', 2),
  ]);

  if (is_wp_error($response)) {
    return null;
  }
  $calendar = json_decode(wp_remote_retrieve_body($response), true);
  if (!is_array($calendar)) {
    return null;
  }
  // Longer TTL = fewer API calls. Default 30 min (was 20).
  $ttl = (int) apply_filters('digim_calendar_cache_ttl', 30 * MINUTE_IN_SECONDS);
  set_transient($cache_key, $calendar, $ttl > 0 ? $ttl : 1800);
  return $calendar;
}

function digimanagement_check_availability_ajax()
{
  if (!wp_verify_nonce($_POST['nonce'] ?? '', 'digim_booking_nonce')) {
    wp_send_json_error(['message' => 'Invalid nonce']);
    return;
  }

  $property_uuid = sanitize_text_field($_POST['property_uuid'] ?? '');
  $checkin_date = sanitize_text_field($_POST['checkin_date'] ?? '');
  $checkout_date = sanitize_text_field($_POST['checkout_date'] ?? '');

  if (empty($property_uuid) || empty($checkin_date) || empty($checkout_date)) {
    wp_send_json_error(['message' => 'Missing required parameters']);
    return;
  }

  // Performance: one API call per search via shared cached calendar; date-range fetch, not per-day.
  $calendar_data = digim_fetch_calendar_cached($property_uuid, $checkin_date, $checkout_date);
  if (!$calendar_data || !isset($calendar_data['data']['days'])) {
    wp_send_json_error(['message' => 'Failed to check availability']);
    return;
  }

  $days = $calendar_data['data']['days'];
  $days_by_date = [];
  foreach ($days as $day) {
    $date = $day['date'] ?? null;
    if ($date) {
      $days_by_date[$date] = $day;
    }
  }

  $current = strtotime($checkin_date);
  $end = strtotime($checkout_date);
  $requested_nights = max(1, (int) floor(($end - $current) / DAY_IN_SECONDS));
  $is_available = true;
  $checkin_date_str = date('Y-m-d', $current);

  $checkin_day_data = $days_by_date[$checkin_date_str] ?? null;
  $min_nights_required = null;
  $allows_checkin = true;

  if ($checkin_day_data) {
    $min_nights_required = $checkin_day_data['min_nights'] ?? $checkin_day_data['minimum_nights'] ?? $checkin_day_data['min_stay'] ?? $checkin_day_data['minimum_stay'] ?? null;
    $allows_checkin = $checkin_day_data['allows_checkin'] ?? $checkin_day_data['checkin_allowed'] ?? true;
    if (isset($checkin_day_data['checkin_allowed']) && $checkin_day_data['checkin_allowed'] === false) {
      $allows_checkin = false;
    }
    $closed_for_checkin = $checkin_day_data['closed_for_checkin'] ?? $checkin_day_data['closed_for_check_in'] ?? false;
    if ($closed_for_checkin === true || $closed_for_checkin === 'true' || (int) $closed_for_checkin === 1) {
      $allows_checkin = false;
    }
    $checkin_blocked = $checkin_day_data['checkin_blocked'] ?? $checkin_day_data['check_in_blocked'] ?? false;
    if ($checkin_blocked === true || $checkin_blocked === 'true' || (int) $checkin_blocked === 1) {
      $allows_checkin = false;
    }
  }

  if (!$allows_checkin) {
    wp_send_json_success([
      'available' => false,
      'unavailable_dates' => [],
      'checkin_date' => $checkin_date,
      'checkout_date' => $checkout_date,
    ]);
    return;
  }

  if ($min_nights_required !== null && $requested_nights < (int) $min_nights_required) {
    wp_send_json_success([
      'available' => false,
      'unavailable_dates' => [],
      'checkin_date' => $checkin_date,
      'checkout_date' => $checkout_date,
    ]);
    return;
  }

  while ($current < $end) {
    $date_str = date('Y-m-d', $current);
    $day_found = $days_by_date[$date_str] ?? null;
    if (!$day_found) {
      $is_available = false;
      break;
    }
    $status = $day_found['status'] ?? [];
    $available_flag = $status['available'] ?? null;
    $night_available = true;
    if (is_bool($available_flag)) {
      $night_available = $available_flag;
    } elseif (isset($status['state'])) {
      $state = strtolower((string) $status['state']);
      $night_available = !in_array($state, ['blocked', 'booked', 'unavailable', 'maintenance'], true);
    } elseif (isset($status['type'])) {
      $type = strtolower((string) $status['type']);
      $night_available = !in_array($type, ['blocked', 'booked', 'unavailable', 'maintenance'], true);
    }
    if (!$night_available) {
      $is_available = false;
      break;
    }
    $current = strtotime('+1 day', $current);
  }

  wp_send_json_success([
    'available' => $is_available,
    'unavailable_dates' => [],
    'checkin_date' => $checkin_date,
    'checkout_date' => $checkout_date,
  ]);
}

function digimanagement_get_unavailable_dates_ajax()
{
  $property_uuid = sanitize_text_field($_REQUEST['property_uuid'] ?? '');
  $start_date = sanitize_text_field($_REQUEST['start_date'] ?? '');
  $end_date = sanitize_text_field($_REQUEST['end_date'] ?? '');

  if ($property_uuid === '') {
    wp_send_json_error(['message' => 'Missing property UUID']);
    return;
  }

  if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $property_uuid)) {
    wp_send_json_error(['message' => 'Invalid property UUID format']);
    return;
  }

  $today = new DateTimeImmutable('today', wp_timezone());
  if ($start_date === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $start_date)) {
    $start_date = $today->format('Y-m-d');
  }

  $start_obj = DateTimeImmutable::createFromFormat('Y-m-d', $start_date);
  if (!$start_obj) {
    $start_obj = $today;
    $start_date = $start_obj->format('Y-m-d');
  }

  if ($end_date === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $end_date)) {
    $end_obj = $start_obj->modify('+12 months');
    $end_date = $end_obj->format('Y-m-d');
  } else {
    $end_obj = DateTimeImmutable::createFromFormat('Y-m-d', $end_date);
    if (!$end_obj) {
      $end_obj = $start_obj->modify('+12 months');
      $end_date = $end_obj->format('Y-m-d');
    }
  }

  if ($end_obj <= $start_obj) {
    $end_obj = $start_obj->modify('+1 month');
    $end_date = $end_obj->format('Y-m-d');
  }

  $max_range = $start_obj->modify('+18 months');
  if ($end_obj > $max_range) {
    $end_obj = $max_range;
    $end_date = $end_obj->format('Y-m-d');
  }

  $cache_key = 'digim_unavailable_' . md5($property_uuid . '|' . $start_date . '|' . $end_date);
  $cached = get_transient($cache_key);
  $is_debug_request = isset($_REQUEST['debug']) && $_REQUEST['debug'] === '1';

  // Performance: return cached availability to avoid repeated API calls (one API call per search).
  // Cache key includes listing ID + check-in + check-out; TTL 15–30 min.
  if ($cached !== false && is_array($cached) && !$is_debug_request) {
    $response_payload = $cached;
    // Frontend expects debug_info for checkout_only; build minimal from checkout_only_dates so we don't cache verbose debug.
    $response_payload['debug_info'] = [];
    foreach ($response_payload['checkout_only_dates'] ?? [] as $d) {
      $response_payload['debug_info'][$d] = ['_final_is_checkout_only' => true];
    }
    wp_send_json_success($response_payload);
    return;
  }

  $query_args = [
    'start_date' => $start_date,
    'end_date'   => $end_date,
  ];
  // Performance: one API call per search via shared cached calendar (digim_fetch_calendar_cached); month-based range, never per-day.
  $calendar = digim_fetch_calendar_cached($property_uuid, $start_date, $end_date);
  if (!$calendar || !is_array($calendar)) {
    wp_send_json_error(['message' => 'Failed to fetch calendar']);
    return;
  }

  $days = $calendar['data']['days'] ?? [];
  $unavailable = [];
  $min_nights_by_date = []; // Store minimum nights for each date
  $checkin_blocked_dates = []; // Dates where check-in is not allowed
  $checkout_only_dates = []; // Dates that are closed_for_checkout (can be used as checkout but not check-in)
  $checkout_blocked_dates = []; // Dates where checkout is blocked (closed_for_checkout = true)
  $debug_info = []; // Debug information for specific dates

  // Check if API returns check-in blocked dates in a separate array
  $api_checkin_blocked = $calendar['data']['checkin_blocked_dates'] ?? 
                        $calendar['data']['checkin_blocked'] ?? 
                        $calendar['data']['check_in_blocked_dates'] ?? 
                        $calendar['checkin_blocked_dates'] ?? [];
  if (is_array($api_checkin_blocked) && !empty($api_checkin_blocked)) {
    $checkin_blocked_dates = array_merge($checkin_blocked_dates, $api_checkin_blocked);
  }

  // Property-level check-in rules (fallback if individual day data is missing)
  $property_allowed_checkin_days = $calendar['data']['checkin_days'] ?? $calendar['data']['allowed_checkin_days'] ?? null;
  $property_allows_checkin = $calendar['data']['allows_checkin'] ?? $calendar['data']['checkin_allowed'] ?? true;
  
  // Debug: Log calendar structure
  $debug_info['_calendar_structure'] = [
    'data_keys' => isset($calendar['data']) && is_array($calendar['data']) ? array_keys($calendar['data']) : [],
    'api_checkin_blocked_found' => !empty($api_checkin_blocked),
    'api_checkin_blocked_count' => is_array($api_checkin_blocked) ? count($api_checkin_blocked) : 0,
    'requested_start_date' => $start_date,
    'requested_end_date' => $end_date,
    'api_url' => digimanagement_get_api_url() . "/properties/{$property_uuid}/calendar?" . http_build_query($query_args),
  ];

  // Dates to debug (June 8-9, 15-19, 2026) - including 18-19 which might be in unavailable instead, and June 8 which should be checkout-only, June 9 which should NOT be checkout-only
  $debug_dates = ['2026-06-08', '2026-06-09', '2026-06-15', '2026-06-16', '2026-06-17', '2026-06-18', '2026-06-19'];
  
  // Debug: Check if debug dates are in the response
  $all_dates_in_response = [];
  if (is_array($days)) {
    foreach ($days as $day) {
      $date = $day['date'] ?? null;
      if ($date) {
        $all_dates_in_response[] = $date;
      }
    }
  }
  $debug_info['_meta'] = [
    'total_days_in_response' => count($days),
    'debug_dates_found' => array_intersect($debug_dates, $all_dates_in_response),
    'debug_dates_missing' => array_diff($debug_dates, $all_dates_in_response),
    'date_range_in_response' => !empty($all_dates_in_response) ? [
      'first' => min($all_dates_in_response),
      'last' => max($all_dates_in_response)
    ] : null,
  ];

  // Build a map of dates to day objects for quick lookup
  $days_by_date = [];
  if (is_array($days)) {
    foreach ($days as $day) {
      $date = $day['date'] ?? null;
      if ($date) {
        $days_by_date[$date] = $day;
      }
    }
  }

  if (is_array($days)) {
    foreach ($days as $day) {
      $date = $day['date'] ?? null;
      if (!$date) {
        continue;
      }

      // Debug logging for specific dates - capture EVERYTHING from API
      if (in_array($date, $debug_dates, true)) {
        // Capture the ENTIRE day object and status object to see all available fields
        $debug_info[$date] = [
          'full_day_object' => $day, // Complete day object from API
          'all_keys' => array_keys($day), // Show all available keys in day object
          'status' => $day['status'] ?? null, // Complete status object
          'status_keys' => isset($day['status']) && is_array($day['status']) ? array_keys($day['status']) : [],
          'closed_for_checkin' => $day['closed_for_checkin'] ?? 'not_set',
          'closed_for_checkout' => $day['closed_for_checkout'] ?? 'not_set',
          'allows_checkin' => $day['allows_checkin'] ?? 'not_set',
          'checkin_allowed' => $day['checkin_allowed'] ?? 'not_set',
          'checkin_blocked' => $day['checkin_blocked'] ?? 'not_set',
          'checkin_days' => $day['checkin_days'] ?? 'not_set',
          'allowed_checkin_days' => $day['allowed_checkin_days'] ?? 'not_set',
          'property_allows_checkin' => $property_allows_checkin,
          'property_allowed_checkin_days' => $property_allowed_checkin_days,
          // Check for any field containing 'checkin', 'check-out', 'reservation', 'booking'
          'all_checkin_fields' => array_filter(array_keys($day), function($key) {
            return stripos($key, 'checkin') !== false || stripos($key, 'check-in') !== false;
          }),
          'all_reservation_fields' => array_filter(array_keys($day), function($key) {
            return stripos($key, 'reservation') !== false || stripos($key, 'booking') !== false;
          }),
          // Also check status object for reservation/booking fields
          'status_reservation_fields' => isset($day['status']) && is_array($day['status']) 
            ? array_filter(array_keys($day['status']), function($key) {
                return stripos($key, 'reservation') !== false || stripos($key, 'booking') !== false || stripos($key, 'id') !== false;
              })
            : [],
        ];
      }

      // Extract minimum nights requirement (Hospitable API uses 'min_stay')
      $min_nights = $day['min_stay'] ?? $day['min_nights'] ?? $day['minimum_nights'] ?? null;
      if ($min_nights !== null) {
        $min_nights_by_date[$date] = (int)$min_nights;
      }

      // Determine check-in allowance for this specific date
      // Get status first (we'll use it multiple times)
      $status = $day['status'] ?? [];
      
      // Check ALL possible fields that might indicate check-in is blocked
      $is_checkin_blocked = false;
      $is_checkout_only = false; // Track if date is checkout-only (closed_for_checkout but not closed_for_checkin)
      
      // Check closed_for_checkout field first (Hospitable API uses this)
      // If closed_for_checkout = true but closed_for_checkin != true, it's checkout-only
      $closed_for_checkout = $day['closed_for_checkout'] ?? false;
      $closed_for_checkout_bool = false;
      if (is_bool($closed_for_checkout) && $closed_for_checkout === true) {
        $closed_for_checkout_bool = true;
      } elseif (is_string($closed_for_checkout)) {
        $closed_checkout_bool = filter_var($closed_for_checkout, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
        if ($closed_checkout_bool === true) {
          $closed_for_checkout_bool = true;
        }
      } elseif (is_numeric($closed_for_checkout)) {
        // Handle numeric values (0/1)
        $closed_for_checkout_bool = ((int)$closed_for_checkout === 1);
      }
      
      // 0. Check closed_for_checkin field (Hospitable API uses this)
      $closed_for_checkin = $day['closed_for_checkin'] ?? false;
      $closed_for_checkin_bool = false;
      if (is_bool($closed_for_checkin) && $closed_for_checkin === true) {
        $closed_for_checkin_bool = true;
        $is_checkin_blocked = true;
        // Debug: Log when we detect closed_for_checkin
        if (in_array($date, $debug_dates, true)) {
          $debug_info[$date]['_detected_closed_for_checkin'] = true;
        }
      } elseif (is_string($closed_for_checkin)) {
        $closed_bool = filter_var($closed_for_checkin, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
        if ($closed_bool === true) {
          $closed_for_checkin_bool = true;
          $is_checkin_blocked = true;
          if (in_array($date, $debug_dates, true)) {
            $debug_info[$date]['_detected_closed_for_checkin'] = true;
          }
        }
      } elseif (is_numeric($closed_for_checkin)) {
        // Handle numeric values (0/1)
        if ((int)$closed_for_checkin === 1) {
          $closed_for_checkin_bool = true;
          $is_checkin_blocked = true;
          if (in_array($date, $debug_dates, true)) {
            $debug_info[$date]['_detected_closed_for_checkin'] = true;
          }
        }
      }
      
      // Determine if date is checkout-only
      // A date is checkout-only ONLY if checkout is ALLOWED but check-in is BLOCKED:
      // closed_for_checkout = false (checkout allowed) AND closed_for_checkin = true (check-in blocked)
      // 
      // IMPORTANT FIX: 
      // - If closed_for_checkout = true AND closed_for_checkin = false: This is checkout-BLOCKED only
      //   Check-in is still allowed on this date (you CAN check-in, you just can't check-out)
      //   This matches Hospitable's "No check-outs on this day" behavior
      // - Only closed_for_checkin = true should block check-in
      // - Simply being unavailable (booked/reserved) does NOT make a date checkout-only.
      // - Unavailable dates are fully blocked and cannot be used for checkout unless explicitly marked otherwise.
      
      // Checkout-only: checkout allowed, check-in blocked
      if (!$closed_for_checkout_bool && $closed_for_checkin_bool) {
        // closed_for_checkout = false (checkout allowed), closed_for_checkin = true (check-in blocked)
        // This is an explicit checkout-only date (can be used as checkout date, but not as check-in date)
        $is_checkout_only = true;
        $is_checkin_blocked = true;
        if (in_array($date, $debug_dates, true)) {
          $debug_info[$date]['_detected_checkout_only'] = true;
          $debug_info[$date]['_checkout_only_reason'] = 'explicit_closed_for_checkin';
        }
      }
      
      // Track checkout-blocked dates (closed_for_checkout = true)
      // These dates cannot be used as checkout dates
      if ($closed_for_checkout_bool) {
        if (!in_array($date, $checkout_blocked_dates, true)) {
          $checkout_blocked_dates[] = $date;
        }
        if (in_array($date, $debug_dates, true)) {
          $debug_info[$date]['_is_checkout_blocked'] = true;
        }
      }
      
      // IMPORTANT FIX: closed_for_checkout does NOT mean check-in is blocked
      // A date can be checkout-blocked (closed_for_checkout = true) but still allow check-in
      // Only block check-in if closed_for_checkin = true, not just because checkout is blocked
      // This matches Hospitable's behavior: "No check-outs on this day" doesn't mean "No check-ins"
      // Note: We will NOT automatically mark unavailable dates as checkout-only.
      // They must be explicitly marked by the API fields above.
      
      // 1. Check explicit checkin_blocked field (various formats)
      $checkin_blocked_field = $day['checkin_blocked'] ?? $day['check_in_blocked'] ?? $day['check-in_blocked'] ?? 
                               $day['checkinBlocked'] ?? $day['checkInBlocked'] ?? false;
      if (is_bool($checkin_blocked_field) && $checkin_blocked_field) {
        $is_checkin_blocked = true;
        if (in_array($date, $debug_dates, true)) {
          $debug_info[$date]['_checkin_blocked_from_field'] = true;
          $debug_info[$date]['_checkin_blocked_field_value'] = $checkin_blocked_field;
        }
      } elseif (is_string($checkin_blocked_field)) {
        $checkin_blocked_bool = filter_var($checkin_blocked_field, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
        if ($checkin_blocked_bool === true) {
          $is_checkin_blocked = true;
          if (in_array($date, $debug_dates, true)) {
            $debug_info[$date]['_checkin_blocked_from_field'] = true;
            $debug_info[$date]['_checkin_blocked_field_value'] = $checkin_blocked_field;
          }
        }
      }

      // 2. Check status object for check-in blocked indication
      if (!$is_checkin_blocked && !empty($status)) {
        $status_type = strtolower((string) ($status['type'] ?? ''));
        $status_state = strtolower((string) ($status['state'] ?? ''));
        $status_name = strtolower((string) ($status['name'] ?? ''));
        
        // Check if status indicates check-in blocked
        $blocked_indicators = ['checkin_blocked', 'checkin-blocked', 'no_checkin', 'no-checkin', 'check_in_blocked', 
                              'check-in_blocked', 'checkinblocked', 'check_in_disabled', 'check-in_disabled'];
        $status_indicates_blocked = in_array($status_type, $blocked_indicators, true) ||
            in_array($status_state, $blocked_indicators, true) ||
            in_array($status_name, $blocked_indicators, true);
        
        if ($status_indicates_blocked) {
          $is_checkin_blocked = true;
          if (in_array($date, $debug_dates, true)) {
            $debug_info[$date]['_checkin_blocked_from_status'] = true;
            $debug_info[$date]['_status_blocked_details'] = [
              'status_type' => $status_type,
              'status_state' => $status_state,
              'status_name' => $status_name,
              'matched_indicator' => $status_indicates_blocked,
            ];
          }
        }
        
        // Check status for explicit checkin_blocked field
        if (isset($status['checkin_blocked']) && $status['checkin_blocked']) {
          $is_checkin_blocked = true;
          if (in_array($date, $debug_dates, true)) {
            $debug_info[$date]['_checkin_blocked_from_status_field'] = true;
            $debug_info[$date]['_status_checkin_blocked'] = $status['checkin_blocked'];
          }
        }
        if (isset($status['check_in_blocked']) && $status['check_in_blocked']) {
          $is_checkin_blocked = true;
          if (in_array($date, $debug_dates, true)) {
            $debug_info[$date]['_checkin_blocked_from_status_field'] = true;
            $debug_info[$date]['_status_check_in_blocked'] = $status['check_in_blocked'];
          }
        }
        
        // Check for can_checkin, allows_checkin in status
        if (isset($status['can_checkin']) && $status['can_checkin'] === false) {
          $is_checkin_blocked = true;
          if (in_array($date, $debug_dates, true)) {
            $debug_info[$date]['_checkin_blocked_from_status_can_checkin'] = true;
          }
        }
        if (isset($status['allows_checkin']) && $status['allows_checkin'] === false) {
          $is_checkin_blocked = true;
          if (in_array($date, $debug_dates, true)) {
            $debug_info[$date]['_checkin_blocked_from_status_allows_checkin'] = true;
          }
        }
        if (isset($status['checkin_allowed']) && $status['checkin_allowed'] === false) {
          $is_checkin_blocked = true;
          if (in_array($date, $debug_dates, true)) {
            $debug_info[$date]['_checkin_blocked_from_status_checkin_allowed'] = true;
          }
        }
      }

      // 3. Check allows_checkin / checkin_allowed fields (if false, check-in is blocked)
      $allows_checkin = $day['allows_checkin'] ?? $day['checkin_allowed'] ?? $day['check_in_allowed'] ?? 
                       $day['checkInAllowed'] ?? $property_allows_checkin ?? true;
      if (isset($day['checkin_allowed']) && $day['checkin_allowed'] === false) {
        $allows_checkin = false;
      }
      if (isset($day['allows_checkin']) && $day['allows_checkin'] === false) {
        $allows_checkin = false;
      }
      
      $date_obj = DateTimeImmutable::createFromFormat('Y-m-d', $date, wp_timezone());
      if (!$date_obj) {
        $date_obj = new DateTimeImmutable($date);
      }
      $day_of_week = (int) $date_obj->format('w'); // 0 = Sunday, 6 = Saturday
      $day_name = $date_obj->format('l');

      // If we already determined check-in is blocked, add it
      // IMPORTANT: This includes dates where checkout is blocked (closed_for_checkout=true)
      // because checkout-blocked dates should also be check-in blocked (per Hospitable behavior)
      if ($is_checkin_blocked) {
        // Add to checkin_blocked_dates if not already there
        if (!in_array($date, $checkin_blocked_dates, true)) {
          $checkin_blocked_dates[] = $date;
        }
        // Debug: Log when we add a date to checkin_blocked_dates
        if (in_array($date, $debug_dates, true)) {
          $debug_info[$date]['_added_to_checkin_blocked'] = true;
          $debug_info[$date]['_is_checkin_blocked_flag'] = $is_checkin_blocked;
          $debug_info[$date]['_checkin_blocked_reasons'] = [
            'closed_for_checkin_bool' => $closed_for_checkin_bool,
            'closed_for_checkout_bool' => $closed_for_checkout_bool,
            'checkin_blocked_field' => $checkin_blocked_field ?? 'not_set',
            'status_type' => $status['type'] ?? 'not_set',
            'status_state' => $status['state'] ?? 'not_set',
            'status_name' => $status['name'] ?? 'not_set',
            'allows_checkin' => $allows_checkin,
            'checkin_allowed' => isset($day['checkin_allowed']) ? $day['checkin_allowed'] : 'not_set',
            'day_of_week' => $day_of_week,
            'day_name' => $day_name,
          ];
        }
        
        // If it's checkout-only (checkout allowed but check-in blocked), track it separately
        if ($is_checkout_only) {
          if (!in_array($date, $checkout_only_dates, true)) {
            $checkout_only_dates[] = $date;
          }
          if (in_array($date, $debug_dates, true)) {
            $debug_info[$date]['_added_to_checkout_only'] = true;
          }
        }
      } else {
        // Otherwise, check day-of-week restrictions
        // CRITICAL FIX: Check availability FIRST before applying any restrictions
        // If a date is available, NEVER apply property-level day-of-week restrictions
        // Property-level restrictions should only apply when day-level data is missing
        
        // First, determine if the date is available
        $availableFlag = $status['available'] ?? null;
        $is_date_available = true;
        if (is_bool($availableFlag)) {
          $is_date_available = $availableFlag;
        } elseif (is_string($availableFlag)) {
          $is_date_available = filter_var($availableFlag, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
          if ($is_date_available === null) {
            $is_date_available = strtolower($availableFlag) !== 'false';
          }
        } elseif (isset($status['state'])) {
          $state = strtolower((string) $status['state']);
          $is_date_available = !in_array($state, ['blocked', 'booked', 'unavailable', 'maintenance'], true);
        } elseif (isset($status['type'])) {
          $type = strtolower((string) $status['type']);
          $is_date_available = !in_array($type, ['blocked', 'booked', 'unavailable', 'maintenance'], true);
        }
        
        $checkin_allowed = $allows_checkin;
        
        // Check if day-level has explicit check-in days restriction
        $day_checkin_days = $day['checkin_days'] ?? $day['allowed_checkin_days'] ?? $day['check_in_days'] ?? null;
        
        // Determine which restriction to use (prefer day-level over property-level)
        $restriction_to_apply = null;
        $restriction_source = null;
        
        if ($day_checkin_days !== null) {
          // Day-level has explicit restriction - use it (even if date is available)
          $restriction_to_apply = $day_checkin_days;
          $restriction_source = 'day_level';
        } elseif ($property_allowed_checkin_days !== null && !$is_date_available) {
          // Property-level restriction exists
          // CRITICAL: Only apply property-level restrictions if date is NOT available
          // If date is available, property-level restrictions should NOT be applied
          // This prevents incorrectly blocking available dates
          $day_has_checkin_fields = (
            array_key_exists('allows_checkin', $day) ||
            array_key_exists('checkin_allowed', $day) ||
            array_key_exists('check_in_allowed', $day) ||
            array_key_exists('closed_for_checkin', $day) ||
            array_key_exists('checkin_blocked', $day) ||
            array_key_exists('check_in_blocked', $day)
          );
          
          // Only apply property-level restriction if:
          // 1. Date is NOT available (unavailable dates can have property-level restrictions)
          // 2. Day-level has NO check-in related fields (completely silent)
          // 3. Check-in is allowed
          if (!$day_has_checkin_fields && $checkin_allowed) {
            $restriction_to_apply = $property_allowed_checkin_days;
            $restriction_source = 'property_level';
          }
        }
        
        // Apply day-of-week restriction only if we have one to apply
        // BUT: Never apply property-level restrictions to available dates
        if ($restriction_to_apply !== null && $checkin_allowed) {
          // If it's a property-level restriction and date is available, skip it
          if ($restriction_source === 'property_level' && $is_date_available) {
            // Don't apply property-level restrictions to available dates
            $restriction_to_apply = null;
          } else {
            // Apply the restriction
            if (is_array($restriction_to_apply)) {
              // Empty array means no restrictions (all days allowed)
              if (!empty($restriction_to_apply)) {
                $checkin_allowed = in_array($day_of_week, $restriction_to_apply, true);
              }
            } elseif (is_string($restriction_to_apply)) {
              // Empty string means no restrictions
              if (trim($restriction_to_apply) !== '') {
                $checkin_allowed = (stripos($restriction_to_apply, strtolower($day_name)) !== false) ||
                  (stripos($restriction_to_apply, (string) $day_of_week) !== false);
              }
            }
          }
        }

        // Only block check-in if restriction says so AND date is available
        // Unavailable dates are already handled above
        if (!$checkin_allowed && $is_date_available) {
          $checkin_blocked_dates[] = $date;
          // Debug: Log when we add a date to checkin_blocked_dates due to day-of-week restrictions
          if (in_array($date, $debug_dates, true)) {
            $debug_info[$date]['_added_to_checkin_blocked'] = true;
            $debug_info[$date]['_checkin_blocked_reason'] = 'day_of_week_restriction';
            $debug_info[$date]['_checkin_blocked_details'] = [
              'day_of_week' => $day_of_week,
              'day_name' => $day_name,
              'restriction_applied' => $restriction_to_apply,
              'restriction_source' => $restriction_source,
              'allows_checkin' => $allows_checkin,
              'checkin_allowed' => $checkin_allowed,
              'is_date_available' => $is_date_available,
            ];
          }
          // If check-in is blocked due to day-of-week restrictions but checkout is allowed,
          // this is a checkout-only date
          if (!$closed_for_checkout_bool && !$is_checkout_only) {
            $is_checkout_only = true;
            if (in_array($date, $debug_dates, true)) {
              $debug_info[$date]['_detected_checkout_only'] = true;
              $debug_info[$date]['_checkout_only_reason'] = 'available_but_checkin_blocked_by_day_restriction';
            }
          }
        }
      }

      $status = $day['status'] ?? [];
      $availableFlag = $status['available'] ?? null;

      // IMPORTANT FIX: Based on Hospitable's booking interface behavior:
      // closed_for_checkout=true does NOT mean check-in is blocked
      // A date can be checkout-blocked but still allow check-in (you can check-in, just not check-out)
      // Only closed_for_checkin=true should block check-in
      
      $is_available = true;
      if (is_bool($availableFlag)) {
        $is_available = $availableFlag;
      } elseif (is_string($availableFlag)) {
        $is_available = filter_var($availableFlag, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
        if ($is_available === null) {
          $is_available = strtolower($availableFlag) !== 'false';
        }
      } elseif (isset($status['state'])) {
        $state = strtolower((string) $status['state']);
        $is_available = !in_array($state, ['blocked', 'booked', 'unavailable', 'maintenance'], true);
      } elseif (isset($status['type'])) {
        $type = strtolower((string) $status['type']);
        $is_available = !in_array($type, ['blocked', 'booked', 'unavailable', 'maintenance'], true);
      }

      // IMPORTANT: Check-in blocked dates should NOT be marked as unavailable if they're otherwise available
      // Check-in blocked dates can be used within a date range (as checkout dates or middle dates)
      // They should only block the START date, not dates within the range
      // Only mark as unavailable if the date is actually unavailable (booked/reserved), not just check-in blocked
      // Note: checkout-blocked dates (closed_for_checkout=true) are NOT check-in blocked
      // Only dates with closed_for_checkin=true or explicitly blocked are check-in blocked
      
      // Store the original availability status before any check-in blocking logic
      $was_originally_available = $is_available;
      
      // Do NOT force check-in blocked dates to be unavailable
      // Check-in blocked dates that are otherwise available should remain available
      // They will be blocked only when used as a START date, not when used within a range
      if ($is_checkin_blocked && in_array($date, $debug_dates, true)) {
        $debug_info[$date]['_is_checkin_blocked_but_available'] = $was_originally_available;
      }

      // Only add to unavailable array if the date is actually unavailable (booked/reserved)
      // NOT if it's only check-in blocked but otherwise available
      if (!$is_available) {
        // Add to unavailable array (only for dates that are actually unavailable, not just check-in blocked)
        if (!in_array($date, $unavailable, true)) {
          $unavailable[] = $date;
        }
        // Update debug info to show this date is unavailable
        if (in_array($date, $debug_dates, true)) {
          $debug_info[$date]['_is_unavailable'] = true;
          $debug_info[$date]['_unavailable_reason'] = [
            'status_available' => $availableFlag,
            'status_state' => $status['state'] ?? null,
            'status_type' => $status['type'] ?? null,
            'closed_for_checkout' => $closed_for_checkout_bool,
            'closed_for_checkin' => $closed_for_checkin_bool,
            'is_checkin_blocked' => $is_checkin_blocked,
          ];
        }
        
        // IMPORTANT: Unavailable dates are check-in blocked by default (you can't check-in on a reserved date)
        // Make sure unavailable dates are added to checkin_blocked_dates if not already there
        if (!in_array($date, $checkin_blocked_dates, true)) {
          $checkin_blocked_dates[] = $date;
        }
        
        // IMPORTANT: For unavailable dates, we need to determine if it's checkout-only
        // A date is checkout-only if it's the LAST day of a reservation (checkout date)
        // NOT if it's the FIRST day or MIDDLE of a reservation
        //
        // Logic: Check if the NEXT day is also unavailable (same reservation block)
        // - If next day is unavailable: current date is NOT checkout-only (it's start/middle of reservation)
        // - If next day is available or different: current date IS checkout-only (it's last day of reservation)
        //
        // This matches Hospitable's behavior:
        // - June 8 is checkout-only (next day June 9 is unavailable but different reservation)
        // - June 9 is NOT checkout-only (it's the start of a reservation)
        $next_date = date('Y-m-d', strtotime('+1 day', strtotime($date)));
        $next_day = $days_by_date[$next_date] ?? null;
        $next_day_unavailable = false;
        $next_day_status_reason = null;
        $next_day_status_source = null;
        
        if ($next_day) {
          $next_day_status = $next_day['status'] ?? [];
          $next_day_available = $next_day_status['available'] ?? true;
          if (is_bool($next_day_available)) {
            $next_day_unavailable = !$next_day_available;
          } elseif (isset($next_day_status['state'])) {
            $next_state = strtolower((string) $next_day_status['state']);
            $next_day_unavailable = in_array($next_state, ['blocked', 'booked', 'unavailable', 'maintenance'], true);
          } elseif (isset($next_day_status['type'])) {
            $next_type = strtolower((string) $next_day_status['type']);
            $next_day_unavailable = in_array($next_type, ['blocked', 'booked', 'unavailable', 'maintenance'], true);
          }
          $next_day_status_reason = $next_day_status['reason'] ?? null;
          $next_day_status_source = $next_day_status['source'] ?? null;
        }
        
        // Only mark as checkout-only if:
        // 1. Checkout is not explicitly blocked (closed_for_checkout = false)
        // 2. Current date is the LAST day of a reservation (not the first or middle)
        //
        // Logic to determine if it's the last day:
        // - Check the PREVIOUS day: if unavailable, current is part of a reservation block
        // - Check the NEXT day: if available or different reservation, current is the last day
        // - If previous is unavailable AND next is unavailable with same source → NOT last day
        // - If previous is unavailable AND next is available/different → IS last day (checkout-only)
        // - If previous is available AND next is unavailable → NOT last day (it's check-in day)
        $is_last_day_of_reservation = false;
        $current_status_source = $status['source'] ?? null;
        
        // Check previous day
        $prev_date = date('Y-m-d', strtotime('-1 day', strtotime($date)));
        $prev_day = $days_by_date[$prev_date] ?? null;
        $prev_day_unavailable = false;
        $prev_day_status_source = null;
        
        if ($prev_day) {
          $prev_day_status = $prev_day['status'] ?? [];
          $prev_day_available = $prev_day_status['available'] ?? true;
          if (is_bool($prev_day_available)) {
            $prev_day_unavailable = !$prev_day_available;
          } elseif (isset($prev_day_status['state'])) {
            $prev_state = strtolower((string) $prev_day_status['state']);
            $prev_day_unavailable = in_array($prev_state, ['blocked', 'booked', 'unavailable', 'maintenance'], true);
          } elseif (isset($prev_day_status['type'])) {
            $prev_type = strtolower((string) $prev_day_status['type']);
            $prev_day_unavailable = in_array($prev_type, ['blocked', 'booked', 'unavailable', 'maintenance'], true);
          }
          $prev_day_status_source = $prev_day_status['source'] ?? null;
        }
        
        // Determine if current date is the last day of a reservation
        // We can ONLY mark it as checkout-only if we can DEFINITIVELY determine it's the last day
        // Key principle: If we can't tell for sure, DON'T mark it as checkout-only
        
        if ($prev_day_unavailable) {
          // Previous day is unavailable - current date is part of a reservation block
          // Check if next day is available or from a different reservation
          if (!$next_day_unavailable) {
            // Next day is available - current date IS the last day (checkout-only)
            $is_last_day_of_reservation = true;
          } elseif ($next_day_unavailable) {
            // Next day is also unavailable - check if it's the same reservation
            if ($current_status_source !== null && $next_day_status_source === $current_status_source) {
              // Same reservation source - current date is NOT the last day
              $is_last_day_of_reservation = false;
            } elseif ($current_status_source !== null && $next_day_status_source !== null && $next_day_status_source !== $current_status_source) {
              // Different non-null sources - current date IS the last day
              $is_last_day_of_reservation = true;
            } elseif ($current_status_source === null && $next_day_status_source === null) {
              // Both have null source - we CANNOT definitively tell if they're the same or different reservation
              // 
              // KEY INSIGHT: We need to use the actual API fields to determine this, not assumptions
              // The API should have some way to identify if dates belong to the same reservation
              // 
              // Let's check if there's a reservation_id, booking_id, or similar field in the status object
              $current_reservation_id = $status['reservation_id'] ?? $status['booking_id'] ?? $status['id'] ?? null;
              $next_day_reservation_id = $next_day_status['reservation_id'] ?? $next_day_status['booking_id'] ?? $next_day_status['id'] ?? null;
              
              // Also check status.source_type - if it's "RESERVATION", we might be able to use it
              $current_source_type = $status['source_type'] ?? null;
              $next_day_source_type = $next_day_status['source_type'] ?? null;
              
              // If we have reservation IDs and they're different, they're different reservations
              if ($current_reservation_id !== null && $next_day_reservation_id !== null) {
                if ($current_reservation_id !== $next_day_reservation_id) {
                  // Different reservation IDs - current date IS the last day
                  $is_last_day_of_reservation = true;
                } else {
                  // Same reservation ID - current date is NOT the last day
                  $is_last_day_of_reservation = false;
                }
              } elseif ($current_source_type !== null && $next_day_source_type !== null && 
                        $current_source_type === 'RESERVATION' && $next_day_source_type === 'RESERVATION') {
                // Both are RESERVATION type - check if we can determine if they're the same
                // If previous day is unavailable (same reservation), and next is also RESERVATION,
                // we need to check if they're the same reservation
                // Since we don't have reservation IDs, we'll be conservative
                // 
                // Actually, if previous day is unavailable (part of current reservation) and
                // next day is also unavailable with RESERVATION type, they might be different reservations
                // But we can't tell for sure without reservation IDs
                // 
                // BE CONSERVATIVE: Only mark as checkout-only if we can definitively determine it
                // Since we can't tell if next day is same or different reservation, don't mark as checkout-only
                $is_last_day_of_reservation = false;
              } else {
                // No reservation IDs available, and source types don't help
                // 
                // KEY INSIGHT: If previous day is unavailable (same reservation as current) and
                // current and next both have null sources, we need to determine if they're the same reservation
                //
                // If previous day also has null source, then prev/current/next all have null sources
                // This likely means they're all part of the same reservation block
                // So current is NOT the last day (NOT checkout-only)
                //
                // If previous day has a non-null source but current and next have null sources,
                // then current and next might be a different reservation block
                // But we can't tell for sure, so be conservative
                //
                // For June 9: prev (June 8) is unavailable with null source, current (June 9) has null source,
                // next (June 10) probably also has null source
                // If they all have null sources, they're likely the same reservation
                // So June 9 is NOT the last day (NOT checkout-only)
                //
                // BE CONSERVATIVE: Only mark as checkout-only if we can definitively determine it
                // Since we can't tell if current and next are the same reservation, don't mark as checkout-only
                $is_last_day_of_reservation = false;
              }
              
              // Log for debugging - capture ALL available fields from status objects and day objects
              if (in_array($date, $debug_dates, true)) {
                $debug_info[$date]['_reservation_analysis'] = [
                  'current_reservation_id' => $current_reservation_id,
                  'next_reservation_id' => $next_day_reservation_id,
                  'current_source_type' => $current_source_type,
                  'next_source_type' => $next_day_source_type,
                  'current_status_full' => $status, // Log entire status object
                  'next_status_full' => $next_day_status, // Log entire next day status object
                  'current_status_keys' => array_keys($status),
                  'next_status_keys' => array_keys($next_day_status),
                  'prev_day_full' => $prev_day ? $prev_day : null, // Log entire previous day object
                  'next_day_full' => $next_day ? $next_day : null, // Log entire next day object
                ];
              }
            } else {
              // One has source, one doesn't - likely different reservations
              // Current date IS the last day
              $is_last_day_of_reservation = true;
            }
          }
        } else {
          // Previous day is available - this could mean:
          // 1. Current date is the START of a reservation (check-in day) - NOT checkout-only
          // 2. OR current date is the END of a previous reservation (checkout day) - IS checkout-only
          //
          // To determine which, check the NEXT day:
          // - If next day is available: current date IS the last day (checkout-only)
          // - If next day is unavailable: current date is likely the START of a reservation (NOT checkout-only)
          //   BUT it could also be the end of one reservation and start of another
          //
          // Key insight from user's debug: June 8 has prev=available, current=RESERVED, next=RESERVED
          // And June 8 SHOULD be checkout-only according to Hospitable
          // This means: if prev is available AND current is RESERVED AND next is RESERVED,
          // we need to check if they're the same reservation or different
          //
          // If current and next both have null sources, we can't tell for sure
          // But if current has null source and next has null source, and prev is available,
          // it's likely that current is the end of a reservation and next is the start of a new one
          // (because if they were the same reservation, the reservation would have started before current)
          //
          // Actually, let's think about this differently:
          // - If prev is available and current is RESERVED, the reservation must have started on or before current
          // - If next is also RESERVED with null source, they could be the same or different reservations
          // - But if they were the same reservation, the reservation would have started on current (check-in day)
          // - If they're different reservations, current is the end of one and next is the start of another
          //
          // Since we can't definitively tell, let's use a heuristic:
          // - If next day is available: current IS checkout-only (definitive)
          // - If next day is unavailable with null source: check if we can determine they're different reservations
          //   - If we can't tell, be conservative and assume current is check-in day (NOT checkout-only)
          //   - BUT: if the user says it should be checkout-only, maybe we should check other fields
          //
          // For now, let's check: if next day is unavailable, assume current is check-in day (NOT checkout-only)
          // UNLESS we can definitively determine otherwise
          if (!$next_day_unavailable) {
            // Next day is available - current date IS the last day (checkout-only)
            $is_last_day_of_reservation = true;
          } else {
            // Next day is also unavailable - current date is likely the START of a reservation
            // But it could also be the end of one and start of another
            // Check if we can determine if current and next are different reservations
            if ($current_status_source !== null && $next_day_status_source !== null && 
                $current_status_source !== $next_day_status_source) {
              // Different sources - current IS the last day
              $is_last_day_of_reservation = true;
            } elseif ($current_status_source === null && $next_day_status_source === null) {
              // Both have null sources - can't tell for sure
              // But if prev is available and current/next are both RESERVED with null sources,
              // it's likely that current is the end of a reservation and next is the start of a new one
              // (because the reservation that includes current would have started before current if they were the same)
              // 
              // Actually, let's be more specific: if prev is available, current is RESERVED, and next is RESERVED,
              // and all have null sources, we can't definitively tell
              // BUT: based on Hospitable's behavior (June 8 should be checkout-only),
              // if prev is available and current is RESERVED and next is RESERVED with null sources,
              // we should treat current as checkout-only (end of previous reservation)
              $is_last_day_of_reservation = true;
            } else {
              // One has source, one doesn't - likely different reservations
              // Current IS the last day
              $is_last_day_of_reservation = true;
            }
          }
        }
        
        if (!$closed_for_checkout_bool && !$is_checkout_only && $is_last_day_of_reservation) {
          // Date is unavailable, checkout not blocked, and it's the last day of reservation - checkout-only
          $is_checkout_only = true;
          if (in_array($date, $debug_dates, true)) {
            $debug_info[$date]['_detected_checkout_only'] = true;
            $debug_info[$date]['_checkout_only_reason'] = 'unavailable_last_day_of_reservation';
            $debug_info[$date]['_checkout_only_details'] = [
              'is_available' => $is_available,
              'is_checkin_blocked' => $is_checkin_blocked,
              'in_checkin_blocked_dates' => in_array($date, $checkin_blocked_dates, true),
              'closed_for_checkout' => $closed_for_checkout,
              'closed_for_checkout_bool' => $closed_for_checkout_bool,
              'closed_for_checkin' => $closed_for_checkin,
              'closed_for_checkin_bool' => $closed_for_checkin_bool,
              'status' => $status,
              'status_reason' => $status['reason'] ?? null,
              'status_source_type' => $status['source_type'] ?? null,
              'status_source' => $status['source'] ?? null,
              'prev_date' => $prev_date,
              'prev_day_unavailable' => $prev_day_unavailable,
              'prev_day_status_source' => $prev_day_status_source,
              'next_date' => $next_date,
              'next_day_unavailable' => $next_day_unavailable,
              'next_day_status_reason' => $next_day_status_reason,
              'next_day_status_source' => $next_day_status_source,
              'is_last_day_of_reservation' => $is_last_day_of_reservation,
            ];
          }
        } else if (!$is_last_day_of_reservation && in_array($date, $debug_dates, true)) {
          // Date is unavailable but NOT the last day of reservation - NOT checkout-only
          $debug_info[$date]['_not_checkout_only_reason'] = 'unavailable_but_not_last_day_of_reservation';
          $debug_info[$date]['_not_checkout_only_details'] = [
            'prev_date' => $prev_date,
            'prev_day_unavailable' => $prev_day_unavailable,
            'prev_day_status_source' => $prev_day_status_source,
            'next_date' => $next_date,
            'next_day_unavailable' => $next_day_unavailable,
            'next_day_status_reason' => $next_day_status_reason,
            'next_day_status_source' => $next_day_status_source,
            'current_status_source' => $status['source'] ?? null,
            'is_last_day_of_reservation' => $is_last_day_of_reservation,
          ];
        } else if ($closed_for_checkout_bool && in_array($date, $debug_dates, true)) {
          // Date is unavailable AND checkout is explicitly blocked - NOT checkout-only
          $debug_info[$date]['_not_checkout_only_reason'] = 'unavailable_and_checkout_explicitly_blocked';
          $debug_info[$date]['_not_checkout_only_details'] = [
            'closed_for_checkout_bool' => $closed_for_checkout_bool,
            'closed_for_checkin_bool' => $closed_for_checkin_bool,
          ];
        }
      } else {
        // Date is available - check if it should be checkout-only
        // If check-in is blocked (for any reason) but checkout is allowed, it's checkout-only
        // Check both $is_checkin_blocked flag and if date is in checkin_blocked_dates array
        $date_is_checkin_blocked = $is_checkin_blocked || in_array($date, $checkin_blocked_dates, true);
        if ($date_is_checkin_blocked && !$closed_for_checkout_bool && !$is_checkout_only) {
          $is_checkout_only = true;
          if (in_array($date, $debug_dates, true)) {
            $debug_info[$date]['_detected_checkout_only'] = true;
            $debug_info[$date]['_checkout_only_reason'] = 'available_but_checkin_blocked';
            $debug_info[$date]['_checkout_only_details'] = [
              'is_available' => $is_available,
              'is_checkin_blocked' => $is_checkin_blocked,
              'in_checkin_blocked_dates' => in_array($date, $checkin_blocked_dates, true),
              'closed_for_checkout' => $closed_for_checkout,
              'closed_for_checkout_bool' => $closed_for_checkout_bool,
              'closed_for_checkin' => $closed_for_checkin,
              'closed_for_checkin_bool' => $closed_for_checkin_bool,
            ];
          }
        }
        
        // Update debug info to show this date is available
        if (in_array($date, $debug_dates, true)) {
          $debug_info[$date]['_is_unavailable'] = false;
        }
      }
      
      // Final safeguard: If this date is checkout-only but wasn't added yet, add it now
      // This handles edge cases where the date might have gone through alternative logic paths
      if ($is_checkout_only && !in_array($date, $checkout_only_dates, true)) {
        $checkout_only_dates[] = $date;
        if (in_array($date, $debug_dates, true)) {
          $debug_info[$date]['_added_to_checkout_only_final'] = true;
        }
      }
      
      // Final safeguard: If this date is check-in blocked but wasn't added yet, add it now
      // This ensures all check-in blocked dates (regardless of detection method) are in the array
      if ($is_checkin_blocked && !in_array($date, $checkin_blocked_dates, true)) {
        $checkin_blocked_dates[] = $date;
        if (in_array($date, $debug_dates, true)) {
          $debug_info[$date]['_added_to_checkin_blocked_final_safeguard'] = true;
          $debug_info[$date]['_checkin_blocked_final_reason'] = 'final_safeguard_check';
        }
      }
      
      // Update debug info to show final check-in blocked status
      if (in_array($date, $debug_dates, true)) {
        $debug_info[$date]['_final_is_checkin_blocked'] = in_array($date, $checkin_blocked_dates, true);
        $debug_info[$date]['_final_is_checkin_blocked_flag'] = $is_checkin_blocked;
        $debug_info[$date]['_final_is_unavailable'] = in_array($date, $unavailable, true);
        $debug_info[$date]['_final_is_checkout_only'] = in_array($date, $checkout_only_dates, true);
        $debug_info[$date]['_final_is_checkout_only_flag'] = $is_checkout_only;
        $debug_info[$date]['_final_closed_for_checkout'] = $closed_for_checkout_bool;
        $debug_info[$date]['_final_closed_for_checkin'] = $closed_for_checkin_bool;
      }
    }
  }

  $final_checkin_blocked = array_values(array_unique($checkin_blocked_dates));
  $final_unavailable = array_values(array_unique($unavailable));
  $final_checkout_only = array_values(array_unique($checkout_only_dates));
  $final_checkout_blocked = array_values(array_unique($checkout_blocked_dates));
  
  // Add summary to debug info
  $debug_info['_summary'] = [
    'total_checkin_blocked_dates' => count($final_checkin_blocked),
    'checkin_blocked_dates' => $final_checkin_blocked,
    'total_checkout_only_dates' => count($final_checkout_only),
    'checkout_only_dates' => $final_checkout_only,
    'total_unavailable_dates' => count($final_unavailable),
    'unavailable_dates' => $final_unavailable,
    'debug_dates_in_blocked_list' => array_intersect($debug_dates, $final_checkin_blocked),
    'debug_dates_in_checkout_only_list' => array_intersect($debug_dates, $final_checkout_only),
    'debug_dates_in_unavailable_list' => array_intersect($debug_dates, $final_unavailable),
    'debug_dates_status' => array_map(function($date) use ($final_checkin_blocked, $final_unavailable, $final_checkout_only, $debug_info) {
      $status = [
        'date' => $date,
        'is_checkin_blocked' => in_array($date, $final_checkin_blocked, true),
        'is_checkout_only' => in_array($date, $final_checkout_only, true),
        'is_unavailable' => in_array($date, $final_unavailable, true),
      ];
      // Add checkout-blocked info if available
      if (isset($debug_info[$date]['_checkout_blocked'])) {
        $status['is_checkout_blocked'] = true;
        $status['checkout_blocked_note'] = $debug_info[$date]['_checkout_blocked_note'] ?? '';
      }
      return $status;
    }, $debug_dates),
  ];
  
  $payload = [
    'dates'                 => array_values(array_unique($unavailable)),
    'min_nights'            => $min_nights_by_date, // Minimum nights requirement for each date
    'checkin_blocked_dates' => $final_checkin_blocked, // Dates where check-in is disallowed
    'checkout_only_dates'   => $final_checkout_only, // Dates that are closed_for_checkout (can be checkout but not check-in)
    'checkout_blocked_dates' => $final_checkout_blocked, // Dates where checkout is blocked (closed_for_checkout = true)
    'range_start'           => $start_date,
    'range_end'             => $end_date,
    'debug_info'            => $debug_info, // Debug information for June 15-19, 2026
  ];

  // Don't cache debug info
  $cache_payload = $payload;
  unset($cache_payload['debug_info']);
  set_transient($cache_key, $cache_payload, apply_filters('digim_unavailable_dates_cache_ttl', 30 * MINUTE_IN_SECONDS, $property_uuid, $start_date, $end_date));

  wp_send_json_success($payload);
}