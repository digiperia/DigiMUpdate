<?php
add_action('admin_menu', function () {
    add_menu_page(
        __('DigiManagement', 'DigiM'),
        __('DigiManagement', 'DigiM'),
        'manage_options',
        'DigiM',
        'render_settings_page',
        'dashicons-building',
        58
    );

    add_submenu_page(
        'DigiM',
        __('DigiManagement Settings', 'DigiM'),
        __('Settings', 'DigiM'),
        'manage_options',
        'DigiM',
        'render_settings_page'
    );

    add_submenu_page(
        'DigiM',
        __('DigiManagement Documentation', 'DigiM'),
        __('Documentation', 'DigiM'),
        'manage_options',
        'DigiM-docs',
        'render_documentation_page'
    );
    add_submenu_page(
        'DigiM',
        __('DigiManagement Style', 'DigiM'),
        __('UI Builder', 'DigiM'),
        'manage_options',
        'DigiM-style',
        'digim_render_ui_builder_page'
    );
    add_submenu_page(
        'DigiM',
        __('DigiManagement Cards', 'DigiM'),
        __('Card Builder', 'DigiM'),
        'manage_options',
        'DigiM-cards',
        'digim_render_card_builder_page'
    );
    add_submenu_page(
        'DigiM',
        __('Amenities Ordering', 'DigiM'),
        __('Amenities Ordering', 'DigiM'),
        'manage_options',
        'DigiM-amenities',
        'digim_render_amenities_order_page'
    );
    add_submenu_page(
        'DigiM',
        __('Listings', 'DigiM'),
        __('Listings', 'DigiM'),
        'manage_options',
        'DigiM-listings',
        'digim_render_listings_page'
    );
    add_submenu_page(
        'DigiM',
        __('Debug Properties', 'DigiM'),
        __('Debug Properties', 'DigiM'),
        'manage_options',
        'DigiM-debug-properties',
        'digim_render_debug_properties_page'
    );
});

// Pages
require_once plugin_dir_path(__FILE__) . '/admin-settings.php';
require_once plugin_dir_path(__FILE__) . '/documentation.php';
require_once plugin_dir_path(__DIR__) . '/includes/shortcode.php';


// Callback functions
function render_settings_page()
{
    // Use the enhanced settings page function
    digimanagement_render_settings_page();
}

require_once __DIR__ . '/admin-ui-builder.php';
require_once __DIR__ . '/admin-card-builder.php';
require_once __DIR__ . '/admin-amenities-order.php';
require_once __DIR__ . '/admin-listings.php';
require_once __DIR__ . '/admin-debug-properties.php';
