<?php
add_action('admin_init', function () {
    register_setting('DigiM-style', 'digim_cards_per_page');
    register_setting('DigiM-style', 'digim_layout_style');
    register_setting('DigiM-style', 'digim_show_map');
    register_setting('DigiM-style', 'digim_show_capacity');
    register_setting('DigiM-style', 'digim_show_capacity_guests');
    register_setting('DigiM-style', 'digim_show_capacity_bedrooms');
    register_setting('DigiM-style', 'digim_show_capacity_beds');
    register_setting('DigiM-style', 'digim_show_capacity_bathrooms');
    register_setting('DigiM-style', 'digim_grid_columns');
    register_setting('DigiM-style', 'digim_card_style');
    register_setting('DigiM-style', 'digim_primary_color'); // <-- this is the key line

});

add_action('admin_enqueue_scripts', 'digim_enqueue_admin_ui_assets');
function digim_enqueue_admin_ui_assets($hook_suffix)
{
    if (isset($_GET['page']) && $_GET['page'] === 'DigiM-style') {
        $css_asset = digim_asset('assets/css/style.css');
        $js_asset  = digim_asset('assets/js/map-init.js');
        if (file_exists($css_asset['path'])) {
            wp_enqueue_style('digim-admin-ui-style', $css_asset['url'], [], filemtime($css_asset['path']));
        } else {
            wp_enqueue_style('digim-admin-ui-style', $css_asset['url']);
        }
        if (file_exists($js_asset['path'])) {
            wp_enqueue_script('digim-admin-map-init', $js_asset['url'], ['jquery'], filemtime($js_asset['path']), true);
        }
    }
}

// AJAX Handlers for UI Builder
add_action('wp_ajax_digim_update_preview', 'digim_ajax_update_preview');
add_action('wp_ajax_digim_save_ui_settings', 'digim_ajax_save_ui_settings');

function digim_ajax_update_preview() {
    // Verify nonce
    if (!wp_verify_nonce($_POST['nonce'], 'digim_ui_builder_nonce')) {
        wp_die('Security check failed');
    }

    // Update options temporarily for preview
    if (isset($_POST['digim_cards_per_page'])) {
        update_option('digim_cards_per_page', intval($_POST['digim_cards_per_page']));
    }
    if (isset($_POST['digim_layout_style'])) {
        update_option('digim_layout_style', sanitize_text_field($_POST['digim_layout_style']));
    }
    if (isset($_POST['digim_grid_columns'])) {
        update_option('digim_grid_columns', intval($_POST['digim_grid_columns']));
    }
    if (isset($_POST['digim_card_style'])) {
        update_option('digim_card_style', sanitize_text_field($_POST['digim_card_style']));
    }
    if (isset($_POST['digim_primary_color'])) {
        update_option('digim_primary_color', sanitize_hex_color($_POST['digim_primary_color']));
    }
    if (isset($_POST['digim_show_map'])) {
        update_option('digim_show_map', intval($_POST['digim_show_map']));
    }
    if (isset($_POST['digim_show_capacity'])) {
        update_option('digim_show_capacity', intval($_POST['digim_show_capacity']));
    }
    if (isset($_POST['digim_show_capacity_guests'])) {
        update_option('digim_show_capacity_guests', intval($_POST['digim_show_capacity_guests']));
    }
    if (isset($_POST['digim_show_capacity_bedrooms'])) {
        update_option('digim_show_capacity_bedrooms', intval($_POST['digim_show_capacity_bedrooms']));
    }
    if (isset($_POST['digim_show_capacity_beds'])) {
        update_option('digim_show_capacity_beds', intval($_POST['digim_show_capacity_beds']));
    }
    if (isset($_POST['digim_show_capacity_bathrooms'])) {
        update_option('digim_show_capacity_bathrooms', intval($_POST['digim_show_capacity_bathrooms']));
    }

    // Set flag to indicate this is from UI builder
    global $digim_from_ui_builder;
    $digim_from_ui_builder = true;

    // Generate preview HTML
    $preview_html = do_shortcode('[digimanagement_listings]');
    
    // Reset flag after use
    $digim_from_ui_builder = false;
    
    wp_send_json_success([
        'html' => $preview_html
    ]);
}

function digim_ajax_save_ui_settings() {
    // Verify nonce
    if (!wp_verify_nonce($_POST['nonce'], 'digim_ui_builder_nonce')) {
        wp_die('Security check failed');
    }

    // Save all settings
    $settings = [
        'digim_cards_per_page' => intval($_POST['digim_cards_per_page']),
        'digim_layout_style' => sanitize_text_field($_POST['digim_layout_style']),
        'digim_grid_columns' => intval($_POST['digim_grid_columns']),
        'digim_card_style' => sanitize_text_field($_POST['digim_card_style']),
        'digim_primary_color' => sanitize_hex_color($_POST['digim_primary_color']),
        'digim_show_map' => intval($_POST['digim_show_map']),
        'digim_show_capacity' => intval($_POST['digim_show_capacity']),
        'digim_show_capacity_guests' => intval($_POST['digim_show_capacity_guests']),
        'digim_show_capacity_bedrooms' => intval($_POST['digim_show_capacity_bedrooms']),
        'digim_show_capacity_beds' => intval($_POST['digim_show_capacity_beds']),
        'digim_show_capacity_bathrooms' => intval($_POST['digim_show_capacity_bathrooms'])
    ];

    foreach ($settings as $key => $value) {
        update_option($key, $value);
    }

    wp_send_json_success([
        'message' => 'Settings saved successfully'
    ]);
}

function digim_render_ui_builder_page()
{
    // Enqueue admin styles and scripts
    $admin_css = digim_asset('assets/css/admin.css');
    $ui_js     = digim_asset('assets/js/ui-builder.js');
    wp_enqueue_style('digim-admin-css', $admin_css['url'], [], file_exists($admin_css['path']) ? filemtime($admin_css['path']) : '1.0.0');
    wp_enqueue_script('digim-ui-builder-js', $ui_js['url'], ['jquery'], file_exists($ui_js['path']) ? filemtime($ui_js['path']) : '1.0.0', true);
    
    // Localize script for AJAX
    wp_localize_script('digim-ui-builder-js', 'digim_ui_ajax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('digim_ui_builder_nonce'),
        'strings' => [
            'updating' => __('Updating preview...', 'DigiM'),
            'saved' => __('Settings saved!', 'DigiM')
        ]
    ]);

    $per_page     = esc_attr(get_option('digim_cards_per_page', 9));
    $layout       = esc_attr(get_option('digim_layout_style', 'grid'));
    $grid_columns = esc_attr(get_option('digim_grid_columns', 3));
    $show_map     = get_option('digim_show_map', false);
    $show_capacity = get_option('digim_show_capacity', 1);
    $show_capacity_guests = get_option('digim_show_capacity_guests', 1);
    $show_capacity_bedrooms = get_option('digim_show_capacity_bedrooms', 1);
    $show_capacity_beds = get_option('digim_show_capacity_beds', 1);
    $show_capacity_bathrooms = get_option('digim_show_capacity_bathrooms', 1);
    $card_style   = esc_attr(get_option('digim_card_style', 'classic'));
    $primary_color = esc_attr(get_option('digim_primary_color', '#0073aa'));
?>
    <div class="digim-ui-builder">
        <!-- Header -->
        <div class="ui-builder-header">
            <div class="header-content">
                <h1><span class="dashicons dashicons-admin-customizer"></span> UI Builder – Listings Shortcode Settings</h1>
                <p>Design and customize your property listings with real-time preview</p>
            </div>
        </div>

        <!-- Main Builder Interface -->
        <div class="ui-builder-content">
            <!-- Left Sidebar - Controls -->
            <div class="ui-builder-sidebar">
                <form method="post" action="options.php" id="ui-builder-form" class="ui-builder-form">
                    <?php settings_fields('DigiM-style'); ?>
                    
                    <!-- Layout Settings -->
                    <div class="control-group">
                        <h3><span class="dashicons dashicons-layout"></span> Layout Settings</h3>
                        <div class="control-item">
                            <label for="digim_layout_style">Layout Style</label>
                            <div class="cb-columns-selector">
                                <input type="hidden" name="digim_layout_style" id="digim_layout_style" value="<?php echo esc_attr($layout); ?>" />
                                <div class="cb-columns-buttons">
                                    <button type="button" class="cb-column-btn cb-layout-btn <?php echo ($layout == 'grid') ? 'active' : ''; ?>" data-layout="grid" title="Grid Layout">
                                        <div class="cb-column-preview">
                                            <span class="cb-column-box"></span>
                                            <span class="cb-column-box"></span>
                                            <span class="cb-column-box"></span>
                                        </div>
                                        <span class="cb-column-label">Grid</span>
                                    </button>
                                    <button type="button" class="cb-column-btn cb-layout-btn <?php echo ($layout == 'list') ? 'active' : ''; ?>" data-layout="list" title="List Layout">
                                        <div class="cb-column-preview cb-list-preview">
                                            <span class="cb-list-line"></span>
                                            <span class="cb-list-line"></span>
                                            <span class="cb-list-line"></span>
                                        </div>
                                        <span class="cb-column-label">List</span>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div class="control-row">
                            <div class="control-item" id="grid-columns-control" style="<?php echo $layout === 'list' ? 'display: none;' : ''; ?>">
                                <label for="digim_grid_columns">Grid Columns</label>
                                <div class="cb-columns-selector">
                                    <input type="hidden" name="digim_grid_columns" id="digim_grid_columns" value="<?php echo esc_attr($grid_columns); ?>" />
                                    <div class="cb-columns-buttons">
                                        <button type="button" class="cb-column-btn <?php echo ($grid_columns == 2) ? 'active' : ''; ?>" data-columns="2" title="2 columns">
                                            <div class="cb-column-preview">
                                                <span class="cb-column-box"></span>
                                                <span class="cb-column-box"></span>
                                            </div>
                                            <span class="cb-column-label">2</span>
                                        </button>
                                        <button type="button" class="cb-column-btn <?php echo ($grid_columns == 3) ? 'active' : ''; ?>" data-columns="3" title="3 columns">
                                            <div class="cb-column-preview">
                                                <span class="cb-column-box"></span>
                                                <span class="cb-column-box"></span>
                                                <span class="cb-column-box"></span>
                                            </div>
                                            <span class="cb-column-label">3</span>
                                        </button>
                                        <button type="button" class="cb-column-btn <?php echo ($grid_columns == 4) ? 'active' : ''; ?>" data-columns="4" title="4 columns">
                                            <div class="cb-column-preview">
                                                <span class="cb-column-box"></span>
                                                <span class="cb-column-box"></span>
                                                <span class="cb-column-box"></span>
                                                <span class="cb-column-box"></span>
                                            </div>
                                            <span class="cb-column-label">4</span>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div class="control-item">
                                <label for="digim_cards_per_page">Cards per Page</label>
                                <div class="digim-number-input-wrapper">
                                    <button type="button" class="digim-number-btn digim-number-decrease" aria-label="Decrease">
                                        <span class="dashicons dashicons-minus"></span>
                                    </button>
                                    <input type="number" name="digim_cards_per_page" id="digim_cards_per_page" class="digim-input digim-number-input" value="<?php echo esc_attr($per_page); ?>" min="1" max="50" />
                                    <button type="button" class="digim-number-btn digim-number-increase" aria-label="Increase">
                                        <span class="dashicons dashicons-plus"></span>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div class="control-item">
                            <label for="digim_primary_color">Primary Color</label>
                            <div class="color-picker-wrapper">
                                <input type="color" name="digim_primary_color" id="digim_primary_color" value="<?php echo esc_attr($primary_color); ?>" />
                                <span class="color-value"><?php echo esc_attr($primary_color); ?></span>
                            </div>
                        </div>
                    </div>

                    <!-- Features -->
                    <div class="control-group">
                        <h3><span class="dashicons dashicons-admin-tools"></span> Features</h3>
                        <div class="control-item">
                            <label class="checkbox-control">
                                <input type="checkbox" name="digim_show_map" id="digim_show_map" value="1" <?php checked($show_map, 1); ?> />
                                <span class="label-text">Show Map below listings</span>
                                <div class="toggle-switch"></div>
                            </label>
                        </div>
                        <div class="control-item">
                            <label class="checkbox-control">
                                <input type="checkbox" name="digim_show_capacity" id="digim_show_capacity" value="1" <?php checked($show_capacity, 1); ?> />
                                <span class="label-text">Show capacity badges row</span>
                                <div class="toggle-switch"></div>
                            </label>
                        </div>
                        <div class="control-subgroup" id="capacity-options" style="<?php echo $show_capacity ? '' : 'display:none;'; ?>">
                            <!-- <div class="control-item">
                                <label class="checkbox-control">
                                    <input type="checkbox" name="digim_show_capacity_guests" id="digim_show_capacity_guests" value="1" <?php checked($show_capacity_guests, 1); ?> />
                                    <span class="label-text">Show guests</span>
                                    <div class="toggle-switch"></div>
                                </label>
                            </div> -->
                            <div class="control-item">
                                <label class="checkbox-control">
                                    <input type="checkbox" name="digim_show_capacity_bedrooms" id="digim_show_capacity_bedrooms" value="1" <?php checked($show_capacity_bedrooms, 1); ?> />
                                    <span class="label-text">Show bedrooms</span>
                                    <div class="toggle-switch"></div>
                                </label>
                            </div>
                            <div class="control-item">
                                <label class="checkbox-control">
                                    <input type="checkbox" name="digim_show_capacity_beds" id="digim_show_capacity_beds" value="1" <?php checked($show_capacity_beds, 1); ?> />
                                    <span class="label-text">Show beds</span>
                                    <div class="toggle-switch"></div>
                                </label>
                            </div>
                            <div class="control-item">
                                <label class="checkbox-control">
                                    <input type="checkbox" name="digim_show_capacity_bathrooms" id="digim_show_capacity_bathrooms" value="1" <?php checked($show_capacity_bathrooms, 1); ?> />
                                    <span class="label-text">Show baths</span>
                                    <div class="toggle-switch"></div>
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="control-group">
                        <div class="control-item">
                            <?php submit_button('Save UI Settings', 'primary', 'submit', false); ?>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Right Side - Live Preview -->
            <div class="ui-builder-preview">
                <div class="preview-header">
                    <h3><span class="dashicons dashicons-visibility"></span> Live Preview</h3>
                    <div class="preview-controls">
                        <button type="button" id="refresh-preview" class="button button-secondary">
                            <span class="dashicons dashicons-update"></span> Refresh
                        </button>
                    </div>
                </div>
                <div class="preview-container">
                    <div id="digim-preview" class="preview-content">
                        <?php echo do_shortcode('[digimanagement_listings]'); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
}
