<?php
/**
 * Debug page to diagnose property count issues.
 * Shows: cached count, API response, hidden listings, filters applied.
 */

add_action('admin_enqueue_scripts', function ($hook) {
    if (!isset($_GET['page']) || $_GET['page'] !== 'DigiM-debug-properties') {
        return;
    }
    $admin_css = digim_asset('assets/css/admin.css');
    wp_enqueue_style('digim-admin-css', $admin_css['url'], [], file_exists($admin_css['path']) ? filemtime($admin_css['path']) : '1.0.0');
});

function digim_render_debug_properties_page()
{
    if (!current_user_can('manage_options')) {
        wp_die('Insufficient permissions');
    }

    // Force clear cache if requested
    if (isset($_POST['clear_cache']) && wp_verify_nonce($_POST['_wpnonce'], 'digim_debug_clear')) {
        delete_transient('digim_all_properties');
        delete_option('digim_properties_stored');
        echo '<div class="notice notice-success"><p>Cache cleared. Refresh to fetch fresh data.</p></div>';
    }

    // Get cached data
    $transient_data = get_transient('digim_all_properties');
    $option_data = get_option('digim_properties_stored', null);
    $hidden_uuids = function_exists('digim_get_hidden_listing_uuids') ? digim_get_hidden_listing_uuids() : [];

    // Get fresh from function
    $all_properties = function_exists('digim_get_all_properties') ? digim_get_all_properties() : [];
    
    // After hidden filter
    $visible_properties = $all_properties;
    if (!empty($hidden_uuids)) {
        $visible_properties = array_filter($all_properties, function ($p) use ($hidden_uuids) {
            $uuid = $p['uuid'] ?? $p['id'] ?? null;
            $uuid = $uuid !== null ? trim((string) $uuid) : '';
            return $uuid === '' || !in_array($uuid, $hidden_uuids, true);
        });
    }

    // Get UI settings
    $cards_per_page = intval(get_option('digim_cards_per_page', 9));

    ?>
    <div class="wrap">
        <h1>DigiM Properties Debug</h1>
        
        <div style="background: #fff; padding: 20px; margin: 20px 0; border: 1px solid #ccc; border-radius: 4px;">
            <h2>Property Counts</h2>
            <table class="widefat" style="max-width: 600px;">
                <tr>
                    <th>From digim_get_all_properties()</th>
                    <td><strong><?php echo count($all_properties); ?></strong> properties</td>
                </tr>
                <tr>
                    <th>After removing hidden</th>
                    <td><strong><?php echo count($visible_properties); ?></strong> properties</td>
                </tr>
                <tr>
                    <th>Hidden in DigiM → Listings</th>
                    <td><strong><?php echo count($hidden_uuids); ?></strong> hidden</td>
                </tr>
                <tr>
                    <th>Cards per page (UI Builder)</th>
                    <td><strong><?php echo $cards_per_page; ?></strong></td>
                </tr>
            </table>
        </div>

        <div style="background: #fff; padding: 20px; margin: 20px 0; border: 1px solid #ccc; border-radius: 4px;">
            <h2>Cache Status</h2>
            <table class="widefat" style="max-width: 600px;">
                <tr>
                    <th>Transient (digim_all_properties)</th>
                    <td><?php echo is_array($transient_data) ? count($transient_data) . ' properties cached' : 'Empty or expired'; ?></td>
                </tr>
                <tr>
                    <th>Option (digim_properties_stored)</th>
                    <td><?php 
                        if (is_array($option_data) && isset($option_data['properties'])) {
                            $age = time() - ($option_data['updated'] ?? 0);
                            echo count($option_data['properties']) . ' properties (updated ' . human_time_diff($option_data['updated']) . ' ago)';
                        } else {
                            echo 'Empty';
                        }
                    ?></td>
                </tr>
            </table>
        </div>

        <?php if (!empty($hidden_uuids)): ?>
        <div style="background: #fff; padding: 20px; margin: 20px 0; border: 1px solid #ccc; border-radius: 4px;">
            <h2>Hidden Listings (<?php echo count($hidden_uuids); ?>)</h2>
            <div style="max-height: 300px; overflow-y: auto;">
                <ul style="margin: 0; padding-left: 20px;">
                    <?php foreach ($hidden_uuids as $uuid): ?>
                        <li><code><?php echo esc_html($uuid); ?></code></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
        <?php endif; ?>

        <div style="background: #fff; padding: 20px; margin: 20px 0; border: 1px solid #ccc; border-radius: 4px;">
            <h2>Sample Properties (first 5)</h2>
            <?php if (!empty($all_properties)): ?>
                <table class="widefat">
                    <thead>
                        <tr>
                            <th>UUID</th>
                            <th>Name</th>
                            <th>City</th>
                            <th>Hidden?</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach (array_slice($all_properties, 0, 5) as $p): 
                            $uuid = $p['uuid'] ?? $p['id'] ?? '';
                            $is_hidden = in_array($uuid, $hidden_uuids, true);
                        ?>
                            <tr>
                                <td><code><?php echo esc_html($uuid); ?></code></td>
                                <td><?php echo esc_html($p['public_name'] ?? $p['name'] ?? 'N/A'); ?></td>
                                <td><?php echo esc_html($p['address']['city'] ?? 'N/A'); ?></td>
                                <td><?php echo $is_hidden ? '<strong style="color: red;">YES</strong>' : 'No'; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No properties found.</p>
            <?php endif; ?>
        </div>

        <div style="background: #fff; padding: 20px; margin: 20px 0; border: 1px solid #ccc; border-radius: 4px;">
            <h2>Actions</h2>
            <form method="post">
                <?php wp_nonce_field('digim_debug_clear'); ?>
                <button type="submit" name="clear_cache" class="button button-primary">Clear Cache & Force Refresh</button>
                <p class="description">This will delete both transient and persistent cache. Next page load will fetch fresh from Hospitable API.</p>
            </form>
        </div>

        <div style="background: #fffbcc; padding: 20px; margin: 20px 0; border: 1px solid #e6db55; border-radius: 4px;">
            <h2>What to Check</h2>
            <ol>
                <li><strong>Expected:</strong> You should see 57 in "From digim_get_all_properties()"</li>
                <li><strong>If less than 57:</strong> API pagination stopped early. Click "Clear Cache & Force Refresh" above.</li>
                <li><strong>If "After removing hidden" is 23:</strong> You have 34 properties marked hidden in DigiM → Listings.</li>
                <li><strong>Cards per page:</strong> Should match your UI Builder setting (9 or 12).</li>
            </ol>
        </div>
    </div>
    <?php
}
