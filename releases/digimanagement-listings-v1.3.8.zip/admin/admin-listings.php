<?php
// Listings admin page: show all Hospitable listings and toggle "Hide on frontend" per property.

add_action('admin_enqueue_scripts', function ($hook) {
    if (!isset($_GET['page']) || $_GET['page'] !== 'DigiM-listings') {
        return;
    }

    $admin_css = digim_asset('assets/css/admin.css');
    wp_enqueue_style('digim-admin-css', $admin_css['url'], [], file_exists($admin_css['path']) ? filemtime($admin_css['path']) : '1.0.0');

    $js_asset = digim_asset('assets/js/listings-visibility.js');
    wp_enqueue_script(
        'digim-listings-visibility-js',
        $js_asset['url'],
        ['jquery'],
        file_exists($js_asset['path']) ? filemtime($js_asset['path']) : '1.0.0',
        true
    );

    $props_for_counts = function_exists('digim_get_all_properties') ? digim_get_all_properties() : [];
    $total_listings   = is_array($props_for_counts) ? count($props_for_counts) : 0;

    wp_localize_script('digim-listings-visibility-js', 'digimListings', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('digim_listings_visibility_nonce'),
        'total'    => $total_listings,
        'strings'  => [
            'loading' => __('Loading listings…', 'DigiM'),
            'saving'  => __('Saving…', 'DigiM'),
            'saved'   => __('Saved. Hidden on frontend.', 'DigiM'),
            'shown'   => __('Saved. Shown on frontend.', 'DigiM'),
            'error'   => __('Something went wrong.', 'DigiM'),
            'hide_on_frontend' => __('Hide on frontend', 'DigiM'),
            'show_on_frontend' => __('Show on frontend', 'DigiM'),
            'label_hidden_row' => __('Hidden', 'DigiM'),
            'label_shown_row'  => __('Shown', 'DigiM'),
        ],
    ]);
});

/**
 * How many listings in the current property list are hidden on the frontend.
 *
 * @param array $properties  From digim_get_all_properties().
 * @param array $hidden_uuids Stored UUIDs marked hidden.
 */
function digim_listings_count_hidden_among_properties(array $properties, array $hidden_uuids)
{
    if ($properties === [] || $hidden_uuids === []) {
        return 0;
    }
    $n = 0;
    foreach ($properties as $p) {
        $uuid = isset($p['uuid']) ? trim((string) $p['uuid']) : '';
        if ($uuid === '' && isset($p['id'])) {
            $uuid = trim((string) $p['id']);
        }
        if ($uuid !== '' && in_array($uuid, $hidden_uuids, true)) {
            $n++;
        }
    }
    return $n;
}

// AJAX: Toggle frontend visibility for one listing
add_action('wp_ajax_digim_toggle_listing_visibility', function () {
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'digim_listings_visibility_nonce')) {
        wp_send_json_error(['message' => 'Bad nonce']);
    }
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Insufficient permissions']);
    }

    $uuid = isset($_POST['uuid']) ? sanitize_text_field($_POST['uuid']) : '';
    if ($uuid === '') {
        wp_send_json_error(['message' => 'Missing UUID']);
    }

    $hidden = get_option('digim_hidden_listings', []);
    if (!is_array($hidden)) {
        $hidden = [];
    }

    $hide = isset($_POST['hide']) && $_POST['hide'] === '1';

    if ($hide) {
        if (!in_array($uuid, $hidden, true)) {
            $hidden[] = $uuid;
        }
    } else {
        $hidden = array_values(array_filter($hidden, function ($id) use ($uuid) {
            return $id !== $uuid;
        }));
    }

    update_option('digim_hidden_listings', $hidden);

    $properties        = function_exists('digim_get_all_properties') ? digim_get_all_properties() : [];
    $total_listings    = is_array($properties) ? count($properties) : 0;
    $hidden_list_count = digim_listings_count_hidden_among_properties($properties, $hidden);

    wp_send_json_success([
        'hidden'       => $hide,
        'message'      => $hide ? __('Hidden on frontend.', 'DigiM') : __('Shown on frontend.', 'DigiM'),
        'hidden_count' => $hidden_list_count,
        'total'        => $total_listings,
    ]);
});

/**
 * Render Listings admin page.
 */
function digim_render_listings_page()
{
    $hidden_uuids = digim_get_hidden_listing_uuids();
    $properties = [];
    if (function_exists('digim_get_all_properties')) {
        $properties = digim_get_all_properties();
    }
    $total_listings  = count($properties);
    $hidden_in_table = digim_listings_count_hidden_among_properties($properties, $hidden_uuids);
    $visible_count   = max(0, $total_listings - $hidden_in_table);
    ?>
    <div class="digim-ui-builder digim-listings-page">
        <div class="ui-builder-header">
            <div class="header-content">
                <h1><span class="dashicons dashicons-building"></span> <?php esc_html_e('Listings', 'DigiM'); ?></h1>
                <p><?php esc_html_e('All properties from the Hospitable API. Use "Hide on frontend" to hide a listing on your site only—it remains active on Hospitable.', 'DigiM'); ?></p>
            </div>
        </div>

        <div class="ui-builder-content">
            <div class="digim-listings-table-wrap">
                <div class="digim-listings-stats" id="digim-listings-stats" role="status" aria-live="polite">
                    <span class="digim-listings-stat">
                        <span class="digim-listings-stat-value" id="digim-listings-count-total"><?php echo esc_html((string) $total_listings); ?></span>
                        <span class="digim-listings-stat-label"><?php esc_html_e('listings total', 'DigiM'); ?></span>
                    </span>
                    <span class="digim-listings-stat">
                        <span class="digim-listings-stat-value" id="digim-listings-count-visible"><?php echo esc_html((string) $visible_count); ?></span>
                        <span class="digim-listings-stat-label"><?php esc_html_e('shown on site', 'DigiM'); ?></span>
                    </span>
                    <span class="digim-listings-stat digim-listings-stat-hidden">
                        <span class="digim-listings-stat-value" id="digim-listings-count-hidden"><?php echo esc_html((string) $hidden_in_table); ?></span>
                        <span class="digim-listings-stat-label"><?php esc_html_e('hidden on site', 'DigiM'); ?></span>
                    </span>
                </div>
                <div id="digim-listings-status" class="notice" style="display:none;"></div>
                <?php if (empty($properties)) : ?>
                    <p class="description"><?php esc_html_e('No listings found. Check your Hospitable API settings and sync under Settings.', 'DigiM'); ?></p>
                <?php else : ?>
                    <table class="wp-list-table widefat fixed striped digim-listings-table">
                        <thead>
                            <tr>
                                <th scope="col" class="column-name"><?php esc_html_e('Property', 'DigiM'); ?></th>
                                <th scope="col" class="column-location"><?php esc_html_e('Location', 'DigiM'); ?></th>
                                <th scope="col" class="column-visibility"><?php esc_html_e('Frontend', 'DigiM'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($properties as $p) :
                                $uuid = $p['uuid'] ?? $p['id'] ?? '';
                                $uuid = $uuid !== '' ? trim((string) $uuid) : '';
                                $name = $p['public_name'] ?? $p['name'] ?? $uuid;
                                $city = $p['address']['city'] ?? '';
                                $country = $p['address']['country'] ?? '';
                                $location = trim($city . ($country ? ', ' . $country : ''));
                                $is_hidden = in_array($uuid, $hidden_uuids, true);
                                ?>
                                <tr data-uuid="<?php echo esc_attr($uuid); ?>">
                                    <td class="column-name">
                                        <strong><?php echo esc_html($name); ?></strong>
                                        <?php if ($uuid) : ?>
                                            <br><code class="digim-uuid-small"><?php echo esc_html($uuid); ?></code>
                                        <?php endif; ?>
                                    </td>
                                    <td class="column-location"><?php echo esc_html($location); ?></td>
                                    <td class="column-visibility">
                                        <label class="digim-toggle-wrap" title="<?php echo $is_hidden ? esc_attr__('Currently hidden on frontend. Click to show.', 'DigiM') : esc_attr__('Currently shown on frontend. Click to hide.', 'DigiM'); ?>">
                                            <input type="checkbox" class="digim-listing-toggle" data-uuid="<?php echo esc_attr($uuid); ?>"
                                                <?php checked(!$is_hidden); ?>
                                                aria-label="<?php echo $is_hidden ? esc_attr__('Show on frontend', 'DigiM') : esc_attr__('Hide on frontend', 'DigiM'); ?>">
                                            <span class="digim-toggle-slider"></span>
                                            <span class="digim-toggle-label"><?php echo $is_hidden ? esc_html__('Hidden', 'DigiM') : esc_html__('Shown', 'DigiM'); ?></span>
                                        </label>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <style>
        /* Full-viewport UI builder layout breaks this screen (no sidebar); keep normal flow */
        .digim-listings-page.digim-ui-builder {
            margin: 0;
            min-height: 0;
            background: transparent;
        }
        .digim-listings-page .ui-builder-header {
            padding-top: 12px;
            align-items: flex-start;
        }
        .digim-listings-page .ui-builder-content {
            display: block;
            height: auto;
            min-height: 0;
            padding: 0 0 24px;
        }
        .digim-listings-stats {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 12px 24px;
            margin-bottom: 16px;
            padding: 12px 16px;
            background: #fff;
            border: 1px solid #c3c4c7;
            border-radius: 4px;
        }
        .digim-listings-stat {
            display: inline-flex;
            align-items: baseline;
            gap: 8px;
            font-size: 13px;
            color: #50575e;
        }
        .digim-listings-stat-value {
            font-size: 18px;
            font-weight: 600;
            color: #1d2327;
        }
        .digim-listings-stat-hidden .digim-listings-stat-value { color: #b32d2e; }
        .digim-listings-table-wrap { max-width: 960px; margin-top: 0; }
        .digim-listings-table { margin-top: 0; }
        .digim-listings-table .column-name { width: 35%; }
        .digim-listings-table .column-location { width: 35%; }
        .digim-listings-table .column-visibility { width: 30%; }
        .digim-uuid-small { font-size: 11px; color: #666; }
        .digim-toggle-wrap { display: inline-flex; align-items: center; gap: 8px; cursor: pointer; user-select: none; }
        .digim-toggle-wrap input { position: absolute; opacity: 0; width: 0; height: 0; }
        .digim-toggle-slider {
            position: relative;
            width: 44px;
            height: 24px;
            background: #c3c4c7;
            border-radius: 24px;
            transition: background 0.2s;
        }
        .digim-toggle-slider::before {
            content: '';
            position: absolute;
            height: 18px;
            width: 18px;
            left: 3px;
            bottom: 3px;
            background: #fff;
            border-radius: 50%;
            transition: transform 0.2s;
            box-shadow: 0 1px 3px rgba(0,0,0,0.2);
        }
        .digim-toggle-wrap input:checked + .digim-toggle-slider { background: #2271b1; }
        .digim-toggle-wrap input:checked + .digim-toggle-slider::before { transform: translateX(20px); }
        .digim-toggle-wrap input:focus + .digim-toggle-slider { box-shadow: 0 0 0 2px #2271b1; }
        .digim-toggle-label { font-size: 12px; color: #50575e; }
    </style>
    <?php
}
