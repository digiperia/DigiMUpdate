/**
 * Build assets: compile SCSS to minified CSS, minify JavaScript.
 * Run: npm run build:assets
 */
const fs = require('fs');
const path = require('path');

const rootDir = __dirname;
const cssDir = path.join(rootDir, 'assets', 'css');
const jsDir = path.join(rootDir, 'assets', 'js');

// SCSS entries: [source, minified output]
const scssEntries = [
  [path.join(cssDir, 'style.scss'), path.join(cssDir, 'style.min.css')],
  [path.join(cssDir, 'admin.scss'), path.join(cssDir, 'admin.min.css')]
];

// JS files to minify (output to same dir as .min.js)
const jsFiles = [
  'admin.js',
  'amenities-order.js',
  'card-builder.js',
  'frontend.js',
  'map-init.js',
  'quote-hydration.js',
  'ui-builder.js'
];

async function buildCss() {
  try {
    const sass = require('sass');
    console.log('📦 Compiling SCSS → minified CSS...');
    for (const [src, dest] of scssEntries) {
      if (!fs.existsSync(src)) {
        console.warn(`  ⚠️  Skip ${path.basename(src)} (not found)`);
        continue;
      }
      const result = sass.compile(src, {
        style: 'compressed',
        loadPaths: [path.dirname(src)]
      });
      fs.writeFileSync(dest, result.css);
      const size = (result.css.length / 1024).toFixed(1);
      console.log(`  ✅ ${path.basename(src)} → ${path.basename(dest)} (${size} KB)`);
    }
  } catch (err) {
    if (err.code === 'MODULE_NOT_FOUND') {
      console.error('  ❌ Run: npm install sass --save-dev');
      process.exit(1);
    }
    throw err;
  }
}

async function buildJs() {
  try {
    const terser = require('terser');
    console.log('\n📦 Minifying JavaScript...');
    for (const name of jsFiles) {
      const srcPath = path.join(jsDir, name);
      if (!fs.existsSync(srcPath)) {
        console.warn(`  ⚠️  Skip ${name} (not found)`);
        continue;
      }
      const code = fs.readFileSync(srcPath, 'utf8');
      const result = await terser.minify(code, {
        compress: { passes: 1 },
        mangle: false,
        format: { comments: false }
      });
      if (result.error) throw result.error;
      const destPath = path.join(jsDir, name.replace(/\.js$/, '.min.js'));
      fs.writeFileSync(destPath, result.code);
      const size = (result.code.length / 1024).toFixed(1);
      console.log(`  ✅ ${name} → ${path.basename(destPath)} (${size} KB)`);
    }
  } catch (err) {
    if (err.code === 'MODULE_NOT_FOUND') {
      console.error('  ❌ Run: npm install terser --save-dev');
      process.exit(1);
    }
    throw err;
  }
}

(async () => {
  console.log('🔨 DigiM assets build\n');
  try {
    await buildCss();
    await buildJs();
    console.log('\n✨ Done. Use .min.css and .min.js in production.\n');
  } catch (err) {
    console.error('\n❌ Build failed:', err.message);
    process.exit(1);
  }
})();
