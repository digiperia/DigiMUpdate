document.addEventListener("DOMContentLoaded", function () {
  flatpickr(".flatpickr-range", {
    mode: "range",
    minDate: "today",
    dateFormat: "Y-m-d",
    altInput: true,
    allowInput: false,

    onChange: function (selectedDates, dateStr, instance) {
      const [checkin, checkout] = selectedDates;

      const pad = (n) => String(n).padStart(2, "0");
      const formatDate = (d) =>
        `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

      const checkinStr = checkin ? formatDate(checkin) : "";
      const checkoutStr = checkout ? formatDate(checkout) : "";

      document.querySelector(".checkin-hidden").value = checkinStr;
      document.querySelector(".checkout-hidden").value = checkoutStr;

      if (checkinStr && checkoutStr) {
        document.querySelector(
          "input[name='date_range']"
        ).value = `${checkinStr} to ${checkoutStr}`;
      } else {
        document.querySelector("input[name='date_range']").value = "";
      }
    },
    onReady: function (selectedDates, dateStr, instance) {
      const checkinInput = document.querySelector(".checkin-hidden").value;
      const checkoutInput = document.querySelector(".checkout-hidden").value;

      if (checkinInput && checkoutInput) {
        const checkinDate = new Date(checkinInput + "T00:00:00");
        const checkoutDate = new Date(checkoutInput + "T00:00:00");

        instance.setDate([checkinDate, checkoutDate], true);

        document.querySelector(
          "input[name='date_range']"
        ).value = `${checkinInput} to ${checkoutInput}`;
      }
    },
  });
});

// Mobile: lock body scroll when datepicker is opened
document.addEventListener("DOMContentLoaded", function () {
  const isMobile = () => window.innerWidth <= 991;
  const addLock = () => { if (isMobile()) document.body.classList.add("digim-no-scroll"); };
  const removeLock = () => document.body.classList.remove("digim-no-scroll");

  // Try common selectors for the date input used by flatpickr
  const dateInputs = [
    document.querySelector("#date-range"),
    document.querySelector(".flatpickr-range"),
    document.querySelector(".airbnb-booking-form .date-input")
  ].filter(Boolean);

  dateInputs.forEach((el) => {
    el.addEventListener("focus", addLock);
    el.addEventListener("click", addLock);
    el.addEventListener("blur", removeLock);
  });

  // If flatpickr calendar closes (click outside), remove lock
  document.addEventListener("click", function (e) {
    const calendarOpen = document.querySelector(".flatpickr-calendar.open");
    const clickedInsideCalendar = e.target.closest && e.target.closest(".flatpickr-calendar");
    const clickedDateInput = e.target.closest && e.target.closest("#date-range, .flatpickr-range, .airbnb-booking-form .date-input");
    if (!calendarOpen || (!clickedInsideCalendar && !clickedDateInput)) {
      removeLock();
    }
  });

  // On resize to desktop, ensure unlock
  window.addEventListener("resize", function () {
    if (!isMobile()) removeLock();
  });
});

// Fix flatpickr calendar positioning to follow the input when scrolling
document.addEventListener("DOMContentLoaded", function () {
  let activeCalendar = null;
  let activeInput = null;

  // Monitor for flatpickr calendar opening
  const observer = new MutationObserver(function(mutations) {
    mutations.forEach(function(mutation) {
      if (mutation.type === 'childList') {
        const calendar = document.querySelector('.flatpickr-calendar.open');
        if (calendar && !activeCalendar) {
          activeCalendar = calendar;
          // Find the associated input
          activeInput = document.querySelector('.flatpickr-input:focus') || 
                       document.querySelector('.flatpickr-range:focus') ||
                       document.querySelector('#date-range:focus');
          
          if (activeInput) {
            // Start tracking scroll to reposition calendar
            window.addEventListener('scroll', repositionCalendar, { passive: true });
            window.addEventListener('resize', repositionCalendar, { passive: true });
          }
        } else if (!calendar && activeCalendar) {
          // Calendar closed, stop tracking
          activeCalendar = null;
          activeInput = null;
          window.removeEventListener('scroll', repositionCalendar);
          window.removeEventListener('resize', repositionCalendar);
        }
      }
    });
  });

  // Start observing
  observer.observe(document.body, { childList: true, subtree: true });

  function repositionCalendar() {
    if (activeCalendar && activeInput) {
      const inputRect = activeInput.getBoundingClientRect();
      const calendar = activeCalendar;
      
      // Position calendar relative to input
      calendar.style.position = 'fixed';
      calendar.style.top = (inputRect.bottom + window.scrollY + 5) + 'px';
      calendar.style.left = inputRect.left + 'px';
      calendar.style.zIndex = '1001';
    }
  }
});

document.addEventListener("DOMContentLoaded", function () {
  const trigger = document.querySelector(
    ".digimanagement-mobile-trigger .mobilesearchdestination"
  );
  const modal = document.querySelector(".digimanagement-mobile-modal");
  const closeBtn = document.querySelector(".digim-close-modal");

  if (trigger && modal && closeBtn) {
    trigger.addEventListener("click", () => {
      modal.classList.add("active");
    });

    closeBtn.addEventListener("click", () => {
      modal.classList.remove("active");
    });

    // Optional: close on outside click
    modal.addEventListener("click", (e) => {
      if (e.target === modal) {
        modal.classList.remove("active");
      }
    });
  }
});

// Mobile booking widget expand/collapse functionality
// Use event delegation so it works even if elements render later
document.addEventListener("click", function (e) {
  const btn = e.target.closest(".mobile-expand-btn");
  if (!btn) return;

  const widget = btn.closest(".booking-widget");
  if (!widget) return;

  const form = widget.querySelector(".booking-form");
  const header = widget.querySelector(".booking-header");
  const rightSidebar = widget.closest(".right-sidebar");
  if (!form || !header) return;

  e.preventDefault();
  const isActive = form.classList.toggle("active");
  header.classList.toggle("active", isActive);
  widget.classList.toggle("active", isActive);
  if (rightSidebar) rightSidebar.classList.toggle("active", isActive);
});

document.addEventListener("DOMContentLoaded", function () {
  const galleryWrappers = document.querySelectorAll("[data-digim-gallery]");
  if (!galleryWrappers.length) {
    return;
  }

  galleryWrappers.forEach((wrapper) => {
    const slides = Array.from(
      wrapper.querySelectorAll("[data-digim-gallery-slide]")
    );
    if (slides.length <= 1) {
      // Nothing to slide – ensure the single slide is visible
      const single = slides[0];
      if (single) {
        single.classList.add("is-active");
      }
      return;
    }

    const prevBtn = wrapper.querySelector("[data-digim-gallery-prev]");
    const nextBtn = wrapper.querySelector("[data-digim-gallery-next]");
    const dots = Array.from(
      wrapper.querySelectorAll("[data-digim-gallery-dot]")
    );
    const counter = wrapper.querySelector(
      ".digim-gallery-counter .current-index"
    );

    let activeIndex = 0;
    let autoplayTimer = null;
    const AUTOPLAY_DELAY = 5000;

    const applyState = (newIndex) => {
      const maxIndex = slides.length - 1;
      if (newIndex < 0) {
        newIndex = maxIndex;
      } else if (newIndex > maxIndex) {
        newIndex = 0;
      }

      slides.forEach((slide, idx) =>
        slide.classList.toggle("is-active", idx === newIndex)
      );
      dots.forEach((dot, idx) =>
        dot.classList.toggle("is-active", idx === newIndex)
      );
      if (counter) {
        counter.textContent = newIndex + 1;
      }
      activeIndex = newIndex;
    };

    const goNext = () => applyState(activeIndex + 1);
    const goPrev = () => applyState(activeIndex - 1);

    const restartAutoplay = () => {
      if (autoplayTimer) {
        clearInterval(autoplayTimer);
      }
      autoplayTimer = window.setInterval(goNext, AUTOPLAY_DELAY);
    };

    if (prevBtn) {
      prevBtn.addEventListener("click", (event) => {
        event.preventDefault();
        goPrev();
        restartAutoplay();
      });
    }

    if (nextBtn) {
      nextBtn.addEventListener("click", (event) => {
        event.preventDefault();
        goNext();
        restartAutoplay();
      });
    }

    dots.forEach((dot, idx) => {
      dot.addEventListener("click", (event) => {
        event.preventDefault();
        applyState(idx);
        restartAutoplay();
      });
    });

    // Enable keyboard navigation
    wrapper.setAttribute("tabindex", "0");
    wrapper.addEventListener("keydown", (event) => {
      if (event.key === "ArrowRight") {
        event.preventDefault();
        goNext();
        restartAutoplay();
      } else if (event.key === "ArrowLeft") {
        event.preventDefault();
        goPrev();
        restartAutoplay();
      }
    });

    // Basic touch support
    let touchStartX = null;
    const onTouchStart = (event) => {
      const touch = event.touches[0];
      touchStartX = touch ? touch.clientX : null;
    };
    const onTouchEnd = (event) => {
      if (touchStartX === null) {
        return;
      }
      const touch = event.changedTouches[0];
      if (!touch) {
        touchStartX = null;
        return;
      }
      const distance = touch.clientX - touchStartX;
      const threshold = 40;
      if (Math.abs(distance) > threshold) {
        if (distance < 0) {
          goNext();
        } else {
          goPrev();
        }
        restartAutoplay();
      }
      touchStartX = null;
    };

    wrapper.addEventListener("touchstart", onTouchStart, { passive: true });
    wrapper.addEventListener("touchend", onTouchEnd);

    applyState(0);
    restartAutoplay();

    wrapper.addEventListener("mouseover", () => {
      if (autoplayTimer) {
        clearInterval(autoplayTimer);
        autoplayTimer = null;
      }
    });

    wrapper.addEventListener("mouseleave", () => {
      restartAutoplay();
    });

    wrapper.addEventListener("focusin", () => {
      if (autoplayTimer) {
        clearInterval(autoplayTimer);
        autoplayTimer = null;
      }
    });

    wrapper.addEventListener("focusout", () => {
      restartAutoplay();
    });
  });
});
