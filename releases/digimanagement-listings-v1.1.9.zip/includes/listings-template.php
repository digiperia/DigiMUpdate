<?php
// Check if this is from UI builder
global $digim_from_ui_builder;
$container_class = 'digim-main';
if (!empty($digim_from_ui_builder)) {
    $container_class .= ' digim-shortcode';
}
?>
<div class="<?php echo esc_attr($container_class); ?>">
    <!-- Search Form -->
    <div class="bg-white">
        <form class="digimanagement-search" method="get">

            <div class="search-grid">
                <!-- WHERE -->
                <div class="search-group">
                    <label>Where</label>
                    <select name="property_search" class="city-select">
                        <option value="">Search destinations</option>
                        <?php foreach ($destination_names as $city): ?>
                            <option value="<?php echo esc_attr($city); ?>" <?php selected($search, $city); ?>>
                                <?php echo esc_html($city); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- CHECKIN / CHECKOUT -->
                <div class="search-group datecal">
                    <label>Check in / Check out</label>
                    <input type="text" name="date_range" class="flatpickr-range" placeholder="Add dates">
                    <input type="hidden" name="checkin" class="checkin-hidden" value="<?php echo esc_attr($checkin); ?>">
                    <input type="hidden" name="checkout" class="checkout-hidden" value="<?php echo esc_attr($checkout); ?>">
                </div>


                <!-- WHO -->
                <div class="search-group">
                    <label>Who</label>
                    <div class="guest-dropdown-wrapper">
                        <button type="button" class="guest-toggle">Add guests</button>
                        <div class="guest-dropdown">
                            <?php
                            $guest_types = [
                                'adults' => ['label' => 'Adults', 'desc' => 'Ages 13 or above'],
                                'children' => ['label' => 'Children', 'desc' => 'Ages 2–12'],
                                'infants' => ['label' => 'Infants', 'desc' => 'Under 2'],
                                'pets' => ['label' => 'Pets', 'desc' => '<a href="#">Bringing a service animal?</a>'],
                            ];
                            foreach ($guest_types as $type => $meta):
                                $val = intval($_GET[$type] ?? 0);
                            ?>
                                <div class="guest-row">
                                    <div class="guest-labels">
                                        <span><?= $meta['label'] ?></span>
                                        <span><?= $meta['desc'] ?></span>
                                    </div>
                                    <div class="guest-controls">
                                        <button type="button" class="minus">−</button>
                                        <span class="guest-count"><?= $val ?></span>
                                        <button type="button" class="plus">+</button>
                                        <input type="hidden" name="<?= $type ?>" value="<?= $val ?>" id="<?= $type ?>-input">
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <input type="hidden" name="guests" value="<?php echo esc_attr($guest_count); ?>" id="total-guests">
                    </div>
                </div>

                <!-- BUTTONS -->
                <div class="search-buttons">
                    <button type="button" class="reset-button" title="Reset"><i class="fas fa-undo"></i></button>
                    <button type="submit" class="search-button" title="Search"><i class="fas fa-search"></i></button>
                </div>
            </div>

        </form>

        <script>
            document.addEventListener("DOMContentLoaded", function() {
                const wrapper = document.querySelector(".guest-dropdown-wrapper");
                const toggleBtn = wrapper.querySelector(".guest-toggle");
                const guestRows = wrapper.querySelectorAll(".guest-row");
                const totalGuestsInput = wrapper.querySelector('input[name="guests"]');

                const updateGuestSummary = () => {
                    let guests = 0;
                    let infants = 0;
                    let pets = 0;

                    guestRows.forEach(row => {
                        const input = row.querySelector('input[type="hidden"]');
                        const count = parseInt(input.value) || 0;
                        const type = input.name;

                        if (type === "adults" || type === "children") guests += count;
                        else if (type === "infants") infants = count;
                        else if (type === "pets") pets = count;

                        row.querySelector(".guest-count").textContent = count;
                    });

                    let text = guests > 0 ? `${guests} guest${guests > 1 ? 's' : ''}` : "Add guests";
                    if (infants > 0) text += `, ${infants} infant${infants > 1 ? 's' : ''}`;
                    if (pets > 0) text += `, ${pets} pet${pets > 1 ? 's' : ''}`;

                    toggleBtn.textContent = text;
                    totalGuestsInput.value = guests;
                };

                // Apply increment/decrement events
                guestRows.forEach(row => {
                    const input = row.querySelector('input[type="hidden"]');
                    const minus = row.querySelector(".minus");
                    const plus = row.querySelector(".plus");

                    minus.addEventListener("click", () => {
                        let val = parseInt(input.value) || 0;
                        input.value = Math.max(0, val - 1);
                        updateGuestSummary();
                    });

                    plus.addEventListener("click", () => {
                        let val = parseInt(input.value) || 0;
                        input.value = val + 1;
                        updateGuestSummary();
                    });
                });

                // Toggle dropdown
                toggleBtn.addEventListener("click", () => {
                    wrapper.querySelector(".guest-dropdown").classList.toggle("active");
                });

                document.addEventListener("click", e => {
                    if (!wrapper.contains(e.target)) {
                        wrapper.querySelector(".guest-dropdown").classList.remove("active");
                    }
                });

                // Reset form
                document.querySelector('.reset-button').addEventListener("click", () => {
                    // Reset city select dropdown
                    const citySelect = document.querySelector('.city-select');
                    if (citySelect) {
                        if (window.jQuery && window.jQuery(citySelect).data('select2')) {
                            window.jQuery(citySelect).val(null).trigger('change');
                        } else {
                            citySelect.value = '';
                        }
                    }

                    // Reset date range (Flatpickr)
                    const dateRangeInput = document.querySelector('.flatpickr-range');
                    if (dateRangeInput && dateRangeInput._flatpickr) {
                        dateRangeInput._flatpickr.clear();
                    } else if (dateRangeInput) {
                        dateRangeInput.value = '';
                    }
                    
                    // Reset hidden date inputs
                    const checkinHidden = document.querySelector('.checkin-hidden');
                    const checkoutHidden = document.querySelector('.checkout-hidden');
                    if (checkinHidden) checkinHidden.value = '';
                    if (checkoutHidden) checkoutHidden.value = '';

                    // Reset guest inputs
                    guestRows.forEach(row => {
                        const input = row.querySelector('input[type="hidden"]');
                        if (input) {
                            input.value = '0';
                        }
                    });

                    // Update guest summary
                    updateGuestSummary();

                    // Clear URL parameters - reload only if URL has parameters
                    if (window.location.search) {
                        // URL has parameters, reload with clean URL
                        window.location.href = window.location.pathname;
                    }
                    // If no URL parameters, just reset inputs (already done above, no reload)
                });

                updateGuestSummary();
            });
        </script>

        <?php
        $grid_class = $layout_style === 'list' ? 'digimanagement-list' : "digimanagement-grid grid-cols-$grid_columns";
        $show_capacity_setting = [
            'row'       => intval(get_option('digim_show_capacity', 1)),
            'guests'    => intval(get_option('digim_show_capacity_guests', 1)),
            'bedrooms'  => intval(get_option('digim_show_capacity_bedrooms', 1)),
            'beds'      => intval(get_option('digim_show_capacity_beds', 1)),
            'bathrooms' => intval(get_option('digim_show_capacity_bathrooms', 1)),
        ];
        ?>
        <div class="dm-grid <?php echo $show_map ? 'map-listing' : ''; ?>">
            <div class="dm-property">
                <div class="<?php echo esc_attr($grid_class); ?>">

                    <?php if (empty($properties_to_show)): ?>
                        <p class="no-results" style="margin-top: 1rem;">No listings match your filters. Try changing date, location, or guest count.</p>
                    <?php else: ?>
                        <?php foreach ($properties_to_show as $property):
                            $is_suggestion = !empty($property['_digim_is_suggestion']);
                            $suggested_start = $property['_digim_suggested_start'] ?? '';
                            $suggested_checkout = $property['_digim_suggested_checkout'] ?? '';
                            $suggested_nights = intval($property['_digim_suggested_nights'] ?? 0);
                            $suggestion_label = '';

                            if ($is_suggestion && $suggested_start) {
                                $start_ts = strtotime($suggested_start);
                                $nights = $suggested_nights > 0 ? $suggested_nights : 1;
                                $end_ts = $start_ts + max(0, ($nights - 1)) * DAY_IN_SECONDS;
                                $start_label = $start_ts ? wp_date('M j', $start_ts) : '';
                                $end_label = ($nights > 1 && $end_ts) ? wp_date('M j', $end_ts) : '';
                                if ($start_label && $end_label && $start_label !== $end_label) {
                                    $suggestion_label = sprintf(__('Next available %1$s – %2$s', 'digim'), $start_label, $end_label);
                                } elseif ($start_label) {
                                    $suggestion_label = sprintf(__('Next available %s', 'digim'), $start_label);
                                }
                            }

                            $original_picture = $property['picture'] ?? '';
                            $high_res_picture = preg_replace('/\?.*/', '', $original_picture);
                            $uuid = $property['uuid'] ?? $property['id'] ?? '';
                            $property_slug = digimanagement_create_property_slug(
                                $property['name'] ?? '', 
                                $property['address']['city'] ?? ''
                            );
                            $query_params = $_GET;
                            $query_string = http_build_query($query_params);
                            $property_url = site_url('/property/' . esc_attr($property_slug) . '/') . ($query_string ? '?' . $query_string : '');
                            $show_capacity = apply_filters('digim_show_capacity_grid', $show_capacity_setting['row'], $property);
                            $show_capacity_guests = apply_filters('digim_show_capacity_guests', $show_capacity_setting['guests'], $property);
                            $show_capacity_bedrooms = apply_filters('digim_show_capacity_bedrooms', $show_capacity_setting['bedrooms'], $property);
                            $show_capacity_beds = apply_filters('digim_show_capacity_beds', $show_capacity_setting['beds'], $property);
                            $show_capacity_bathrooms = apply_filters('digim_show_capacity_bathrooms', $show_capacity_setting['bathrooms'], $property);

                            $gallery_images = [];
                            if (!empty($property['images']) && is_array($property['images'])) {
                                foreach ($property['images'] as $img) {
                                    $url = '';
                                    if (is_array($img)) {
                                        $url = $img['url'] ?? $img['original_url'] ?? '';
                                        if (!$url && isset($img[0]) && is_string($img[0])) {
                                            $url = $img[0];
                                        }
                                    } elseif (is_string($img)) {
                                        $url = $img;
                                    }
                                    if ($url) {
                                        $gallery_images[] = $url;
                                    }
                                    if (count($gallery_images) >= 4) {
                                        break;
                                    }
                                }
                            }
                            if (empty($gallery_images) && !empty($high_res_picture)) {
                                $gallery_images[] = $high_res_picture;
                            }
                            $gallery_count = count($gallery_images);

                            $rating_value = null;
                            $rating_source_keys = ['average_rating', 'rating', 'overall_rating', 'review_rating'];
                            foreach ($rating_source_keys as $rating_key) {
                                if (isset($property[$rating_key]) && is_numeric($property[$rating_key])) {
                                    $rating_value = round(floatval($property[$rating_key]), 2);
                                    break;
                                }
                                if (isset($property['reviews'][$rating_key]) && is_numeric($property['reviews'][$rating_key])) {
                                    $rating_value = round(floatval($property['reviews'][$rating_key]), 2);
                                    break;
                                }
                            }

                            $reviews_count = null;
                            $review_count_keys = ['reviews_count', 'review_count', 'total_reviews', 'count'];
                            foreach ($review_count_keys as $review_key) {
                                if (isset($property[$review_key]) && is_numeric($property[$review_key])) {
                                    $reviews_count = intval($property[$review_key]);
                                    break;
                                }
                                if (isset($property['reviews'][$review_key]) && is_numeric($property['reviews'][$review_key])) {
                                    $reviews_count = intval($property['reviews'][$review_key]);
                                    break;
                                }
                            }
                            ?>
                            <a href="<?php echo esc_url($property_url); ?>" class="digimanagement-card <?php echo esc_attr(trim($card_style . ' ' . ($is_suggestion ? 'digim-card-suggested' : ''))); ?>">
                                <?php if ($gallery_count > 0): ?>
                                    <div class="digim-card-media" data-digim-gallery>
                                        <?php if ($is_suggestion && $suggestion_label): ?>
                                            <span class="digim-suggestion-badge">
                                                <span class="suggestion-dot" aria-hidden="true"></span>
                                                <?php echo esc_html($suggestion_label); ?>
                                            </span>
                                        <?php endif; ?>
                                        <div class="digim-card-gallery" data-digim-gallery-track>
                                            <?php foreach ($gallery_images as $index => $image_url): ?>
                                                <div class="digim-card-slide <?php echo $index === 0 ? 'is-active' : ''; ?>" data-digim-gallery-slide="<?php echo esc_attr($index); ?>">
                                                    <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($property['name'] ?? 'Property image'); ?>" loading="lazy" decoding="async" />
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                        <?php if ($gallery_count > 1): ?>
                                            <button class="digim-gallery-nav previous" type="button" aria-label="<?php echo esc_attr__('View previous image', 'digim'); ?>" data-digim-gallery-prev>
                                                <span aria-hidden="true">&lsaquo;</span>
                                            </button>
                                            <button class="digim-gallery-nav next" type="button" aria-label="<?php echo esc_attr__('View next image', 'digim'); ?>" data-digim-gallery-next>
                                                <span aria-hidden="true">&rsaquo;</span>
                                            </button>
                                            <div class="digim-gallery-indicators" role="tablist">
                                                <?php foreach ($gallery_images as $index => $image_url): ?>
                                                    <button type="button" class="digim-gallery-dot <?php echo $index === 0 ? 'is-active' : ''; ?>" aria-label="<?php echo esc_attr(sprintf(__('Show image %d', 'digim'), $index + 1)); ?>" data-digim-gallery-dot="<?php echo esc_attr($index); ?>"></button>
                                                <?php endforeach; ?>
                                            </div>
                                            <span class="digim-gallery-counter" aria-live="polite">
                                                <span class="current-index">1</span>
                                                <span class="separator">/</span>
                                                <span class="total-count"><?php echo esc_html($gallery_count); ?></span>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                                <div class="digim-card-content">
                                    <div class="digim-card-header">
                                        <h3 class="digim-title"><?php echo esc_html($property['name'] ?? 'Untitled'); ?></h3>
                                        <?php if ($rating_value !== null): ?>
                                            <div class="digim-rating">
                                                <span class="rating-icon" aria-hidden="true">★</span>
                                                <span class="rating-value"><?php echo esc_html($rating_value); ?></span>
                                                <?php if ($reviews_count !== null): ?>
                                                    <span class="rating-count">(<?php echo esc_html($reviews_count); ?>)</span>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>

                                    <?php
                                    $city = trim((string) ($property['address']['city'] ?? ''));
                                    $state = trim((string) ($property['address']['state'] ?? $property['address']['state_name'] ?? ''));
                                    $country = trim((string) ($property['address']['country'] ?? ''));
                                    $country_code = trim((string) ($property['address']['country_code'] ?? ''));

                                    $short_address_parts = array_filter([
                                        $city,
                                        $state,
                                        $country ?: $country_code,
                                    ], static function ($part) {
                                        return $part !== '';
                                    });

                                    $short_address_parts = array_values(array_unique($short_address_parts));
                                    $short_address = implode(', ', $short_address_parts);

                                    if ($short_address === '' && !empty($property['address']['display'])) {
                                        $short_address = $property['address']['display'];
                                    }
                                    ?>
                                    <?php if ($short_address !== ''): ?>
                                        <p class="digim-address">
                                            <span class="location-icon" aria-hidden="true">
                                                <svg width="11" height="13" viewBox="0 0 11 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M1.78795 1.75234C2.73221 0.826967 4.00352 0.311624 5.3256 0.318301C6.64769 0.324979 7.91372 0.853137 8.84859 1.78801C9.78346 2.72287 10.3116 3.98891 10.3183 5.31099C10.325 6.63308 9.80963 7.90439 8.88425 8.84865L6.23201 11.5009C5.99437 11.7385 5.67211 11.8719 5.3361 11.8719C5.00008 11.8719 4.67783 11.7385 4.44019 11.5009L1.78795 8.84865C0.846981 7.90759 0.318359 6.63129 0.318359 5.3005C0.318359 3.9697 0.846981 2.69341 1.78795 1.75234Z" stroke="#5E5E5E" stroke-width="0.636364" stroke-linejoin="round"/>
                                                    <path d="M5.33537 7.20137C6.38515 7.20137 7.23616 6.35036 7.23616 5.30058C7.23616 4.2508 6.38515 3.39978 5.33537 3.39978C4.28559 3.39978 3.43457 4.2508 3.43457 5.30058C3.43457 6.35036 4.28559 7.20137 5.33537 7.20137Z" stroke="#5E5E5E" stroke-width="0.636364" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                            </span>
                                            <?php echo esc_html($short_address); ?>
                                        </p>
                                    <?php endif; ?>

                                    <?php if ($show_capacity): ?>
                                        <div class="capacity-grid">
                                            <?php if ($show_capacity_guests && ($property['capacity']['max'] ?? '')): ?>
                                                <div class="capacity-item">
                                                    <span class="icon-svg" aria-hidden="true">
                                                        <svg width="19" height="14" viewBox="0 0 19 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M13.0667 12.1334V14H0V12.1334C0 12.1334 0 8.40004 6.53333 8.40004C13.0667 8.40004 13.0667 12.1334 13.0667 12.1334ZM9.8 3.2667C9.8 2.62062 9.60842 1.98904 9.24947 1.45184C8.89052 0.914638 8.38034 0.495941 7.78343 0.248695C7.18653 0.00144844 6.52971 -0.0632425 5.89604 0.0628026C5.26237 0.188848 4.6803 0.499968 4.22345 0.956819C3.7666 1.41367 3.45548 1.99574 3.32944 2.62941C3.20339 3.26308 3.26808 3.9199 3.51533 4.5168C3.76257 5.11371 4.18127 5.62389 4.71847 5.98284C5.25567 6.34178 5.88725 6.53337 6.53333 6.53337C7.39971 6.53337 8.2306 6.1892 8.84322 5.57658C9.45584 4.96396 9.8 4.13308 9.8 3.2667ZM13.0107 8.40004C13.5844 8.84407 14.0539 9.40844 14.3861 10.0534C14.7183 10.6984 14.9051 11.4084 14.9333 12.1334V14H18.6667V12.1334C18.6667 12.1334 18.6667 8.74537 13.0107 8.40004ZM12.1333 3.43434e-05C11.491 -0.00295339 10.8629 0.189063 10.332 0.550701C10.8989 1.34286 11.2038 2.29257 11.2038 3.2667C11.2038 4.24083 10.8989 5.19055 10.332 5.9827C10.8629 6.34434 11.491 6.53636 12.1333 6.53337C12.9997 6.53337 13.8306 6.1892 14.4432 5.57658C15.0558 4.96396 15.4 4.13308 15.4 3.2667C15.4 2.40033 15.0558 1.56944 14.4432 0.956819C13.8306 0.3442 12.9997 3.43434e-05 12.1333 3.43434e-05Z" fill="#274D55"/>
                                                        </svg>
                                                    </span>
                                                    <span class="capacity-text"><?= esc_html($property['capacity']['max']) ?> Guests</span>
                                                </div>
                                            <?php endif; ?>

                                            <?php if ($show_capacity_bedrooms && ($property['capacity']['bedrooms'] ?? '')): ?>
                                                <div class="capacity-item">
                                                    <span class="icon-svg" aria-hidden="true">
                                                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M9.77778 2.66667V16H0V14.2222H1.77778V0H9.77778V0.888889H14.2222V14.2222H16V16H12.4444V2.66667H9.77778ZM6.22222 7.11111V8.88889H8V7.11111H6.22222Z" fill="#274D55"/>
                                                        </svg>
                                                    </span>
                                                    <span class="capacity-text"><?= esc_html($property['capacity']['bedrooms']) ?> bedrooms</span>
                                                </div>
                                            <?php endif; ?>

                                            <?php if ($show_capacity_beds && ($property['capacity']['beds'] ?? '')): ?>
                                                <div class="capacity-item">
                                                    <span class="icon-svg" aria-hidden="true">
                                                        <svg width="20" height="14" viewBox="0 0 20 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M16.3636 1.81818H9.09091V8.18182H1.81818V0H0V13.6364H1.81818V10.9091H18.1818V13.6364H20V5.45455C20 4.49012 19.6169 3.5652 18.9349 2.88325C18.253 2.2013 17.3281 1.81818 16.3636 1.81818ZM5.45455 7.27273C6.17786 7.27273 6.87156 6.98539 7.38302 6.47393C7.89448 5.96247 8.18182 5.26877 8.18182 4.54545C8.18182 3.82214 7.89448 3.12844 7.38302 2.61698C6.87156 2.10552 6.17786 1.81818 5.45455 1.81818C4.73123 1.81818 4.03754 2.10552 3.52607 2.61698C3.01461 3.12844 2.72727 3.82214 2.72727 4.54545C2.72727 5.26877 3.01461 5.96247 3.52607 6.47393C4.03754 6.98539 4.73123 7.27273 5.45455 7.27273Z" fill="#274D55"/>
                                                        </svg>
                                                    </span>
                                                    <span class="capacity-text"><?= esc_html($property['capacity']['beds']) ?> beds</span>
                                                </div>
                                            <?php endif; ?>

                                            <?php if ($show_capacity_bathrooms && ($property['capacity']['bathrooms'] ?? '')): ?>
                                                <div class="capacity-item">
                                                    <span class="icon-svg" aria-hidden="true">
                                                        <svg width="19" height="19" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M1.15624 13.8751C1.15723 14.3605 1.26074 14.8402 1.46 15.2829C1.65925 15.7255 1.94975 16.1211 2.31247 16.4437V17.9219C2.31247 18.0752 2.37338 18.2223 2.4818 18.3307C2.59022 18.4391 2.73727 18.5 2.89059 18.5H4.04683C4.20016 18.5 4.3472 18.4391 4.45562 18.3307C4.56404 18.2223 4.62495 18.0752 4.62495 17.9219V17.3438H13.8748V17.9219C13.8748 18.0752 13.9358 18.2223 14.0442 18.3307C14.1526 18.4391 14.2996 18.5 14.453 18.5H15.6092C15.7625 18.5 15.9096 18.4391 16.018 18.3307C16.1264 18.2223 16.1873 18.0752 16.1873 17.9219V16.4437C16.55 16.1211 16.8405 15.7255 17.0398 15.2829C17.239 14.8402 17.3426 14.3605 17.3436 13.8751V12.1407H1.15624V13.8751ZM17.9217 9.2501H2.89059V2.50238C2.89092 2.35065 2.93618 2.20241 3.02065 2.07637C3.10513 1.95033 3.22504 1.85212 3.36526 1.79415C3.50548 1.73618 3.65973 1.72103 3.80855 1.75061C3.95737 1.7802 4.09409 1.85319 4.20148 1.96039L4.89775 2.6563C4.42333 3.73594 4.62278 4.79209 5.20921 5.53714L5.20307 5.54328C5.09506 5.65164 5.03441 5.7984 5.03441 5.9514C5.03441 6.10439 5.09506 6.25115 5.20307 6.35951L5.61172 6.76817C5.66541 6.82187 5.72915 6.86446 5.7993 6.89352C5.86944 6.92258 5.94463 6.93754 6.02056 6.93754C6.09649 6.93754 6.17168 6.92258 6.24183 6.89352C6.31198 6.86446 6.37572 6.82187 6.4294 6.76817L10.2367 2.9609C10.2904 2.90721 10.333 2.84347 10.362 2.77333C10.3911 2.70318 10.406 2.62799 10.406 2.55206C10.406 2.47613 10.3911 2.40094 10.362 2.33079C10.333 2.26064 10.2904 2.19691 10.2367 2.14322L9.82801 1.73456C9.71961 1.62623 9.57262 1.56537 9.41936 1.56537C9.2661 1.56537 9.11911 1.62623 9.0107 1.73456L9.00456 1.74071C8.25951 1.15428 7.20408 0.954826 6.12372 1.42924L5.42781 0.732973C5.07787 0.382996 4.63201 0.144655 4.14661 0.0480909C3.66121 -0.0484729 3.15808 0.00107871 2.70084 0.190479C2.2436 0.379879 1.8528 0.70062 1.57786 1.11214C1.30292 1.52366 1.1562 2.00746 1.15624 2.50238V9.2501H0.578119C0.424792 9.2501 0.277745 9.31101 0.169327 9.41943C0.0609087 9.52785 0 9.6749 0 9.82822L0 10.4063C0 10.5597 0.0609087 10.7067 0.169327 10.8151C0.277745 10.9236 0.424792 10.9845 0.578119 10.9845H17.9217C18.075 10.9845 18.222 10.9236 18.3305 10.8151C18.4389 10.7067 18.4998 10.5597 18.4998 10.4063V9.82822C18.4998 9.6749 18.4389 9.52785 18.3305 9.41943C18.222 9.31101 18.075 9.2501 17.9217 9.2501Z" fill="#274D55"/>
                                                        </svg>
                                                    </span>
                                                    <span class="capacity-text"><?= esc_html($property['capacity']['bathrooms']) ?> baths</span>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <?php if ($total_pages > 1): ?>
                    <?php
                    $q = $_GET;

                    $brezy_letter_svgs = [
                        'B' => <<<'SVG'
<svg class="brezy-letter-icon" viewBox="0 0 80 127.41" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
    <path fill="currentColor" d="M63.6,64.01c-.77-5.91-5.08-10.82-10.15-13.69-2.99-1.7-5.52-2.73-8.79-3.72-1.99-.6-3.03-.93-7.34-1.38,5.35-2.68,4.6-2.22,5.94-3,5.61-3.28,12.02-7.87,11.31-15.18-.42-4.33-3.42-6.37-7.05-8.61-.58-.36-1.22-.61-1.85-.85-.93-.36-1.88-.68-2.84-.98-1.13-.35-2.26-.68-3.41-.99-1.14-.31-2.36-.61-3.56-.87-1.31-.29-2.63-.57-3.97-.74-1.44-.19-2.88-.24-4.33-.31-1.46-.07-2.93-.11-4.39-.14-.57,0-1.15-.01-1.72-.01-2.92,0-4.55-.08-7.63,0H3.21v74.85c7.37-.92,14.76.91,22.17,1.39,9.63.63,19.65-1.15,27.74-6.58,3.15-2.11,5.99-4.79,7.96-8.08,1.97-3.3,3.02-7.25,2.51-11.09v-.02ZM11.77,15.87c0-.11,0-.94,0-.94h1.79c1.09,0,2.19-.05,3.28-.06,1.1-.02,2.16-.02,3.23,0,1.08.01,2.09.05,3.13.11.68.04,1.35.08,2.03.14,2.24.19,4.19.58,6.52,1.14,2.42.48,4.58,1.31,6.48,2.5,1.9,1.19,3.45,2.24,4.66,4.31,1.21,1.99,1.78,2.83,1.78,5.85s-.98,6.3-2.52,8.97c-1.11,1.93-2.84,3.61-4.97,4.08-2.21.49-4.73-.05-6.98-.11-2.41-.06-4.82-.02-7.2.38-4.39.73-8.73,3.05-11.24,6.96V15.87h.02ZM11.75,45.39c-.03-1.07,0-2.15,0-3.22v3.22h0ZM52.43,78.68c-1.38,2.3-3.11,4.21-5.18,5.72-2.07,1.43-4.32,2.46-6.74,3.1-2.42.71-4.62,1.07-6.61,1.07s-4.06-.16-6.22-.48-4.27-.76-6.34-1.31c-1.99-.64-3.85-1.35-5.57-2.14-1.64-.87-2.98-1.82-4.02-2.86v-30.42c.53-.94,1.2-1.8,2.01-2.6.94-.92,2.06-1.7,3.37-2.35,1.31-.72,2.77-1.19,4.4-1.4,2.49-.31,4.58-.3,6.27.05,2.66.42,5.2,1.16,7.79,1.89,4.88,1.37,9.42,3.43,13.01,7.21,1.22,1.29,2.29,2.72,3.17,4.28,1.9,3.18,2.85,7.14,2.85,11.91,0,3.26-.73,6.04-2.2,8.34h.01Z"/>
</svg>
SVG,
                        'r' => <<<'SVG'
<svg class="brezy-letter-icon" viewBox="70 0 70 127.41" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
    <path fill="currentColor" d="M77.28,23.44v6.67c1.73-2.54,3.84-4.56,6.35-6.07,2.5-1.51,5.4-2.26,8.68-2.26,2.54,0,5.11.22,7.58.83,1.06.26,2.11.61,3.11,1.04,1.06.46,1.85,1.13,2.63,2.02,1.64,1.88,2.8,4.54,2.26,7.11-.11.53-.3,1.04-.55,1.51-.58,1.06-1.5,1.88-2.47,2.58-1.48,1.08-3.14,1.99-4.89,2.51-1,.3-1.83.35-2.99.43-.53.04-1.07.03-1.07.03.52-.59,1.85-2.03,2.22-2.72,1.08-2.02.65-4.54-.16-6.69-.67-1.79-1.6-3.52-2.93-4.86-1.33-1.35-2.95-1.8-4.82-1.88-2.46-.11-4.89.76-6.8,2.35-2.18,1.81-4.09,3.98-5.52,6.47-.24.43-.47.87-.58,1.35-.08.37-.08.76-.08,1.14v46.69c0,1.75-.02,6.43-.02,6.43h-8.53V26.75l8.55-3.3h.03Z"/>
</svg>
SVG,
                        'e' => <<<'SVG'
<svg class="brezy-letter-icon" viewBox="120 0 85 127.41" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
    <path fill="currentColor" d="M173.27,74.55c-1.25,2.06-2.79,4.05-4.62,5.96-1.83,1.83-3.91,3.45-6.24,4.88-2.25,1.43-4.74,2.54-7.49,3.33-2.74.87-5.74,1.31-8.99,1.31-4.16,0-8.32-.79-12.48-2.38-4.08-1.59-7.82-3.89-11.23-6.91-3.33-3.02-6.03-6.75-8.11-11.19-2.08-4.53-3.12-9.73-3.12-15.6,0-5.24.96-9.85,2.87-13.82,1.91-4.05,4.41-7.38,7.49-10,3.16-2.7,6.7-4.72,10.61-6.07,3.91-1.43,7.86-2.14,11.86-2.14s7.36.44,10.61,1.31c3.33.79,6.2,1.99,8.61,3.57,2.41,1.59,4.29,3.53,5.62,5.84,1.33,2.22,2,4.8,2,7.74,0,1.91-.37,3.77-1.12,5.6-1.65,4.02-3.95,6.98-7.92,8.33-5,1.7-10.44.78-15.34-.82-5.04-1.64-10.46-4.3-15.82-2.51-.08.03-.15.05-.23.08-2.29.82-4.3,2.46-5.61,4.57-1.21,1.95-3.35,5-2.73,7.31.57,2.11,1.52,3.95,2.68,5.76.26.41.52.81.78,1.22,2.08,3.18,4.49,5.91,7.24,8.22,2.75,2.3,5.7,4.09,8.86,5.36,3.24,1.19,6.41,1.79,9.49,1.79,4.74,0,8.99-1.03,12.73-3.1,3.75-2.14,9.61-7.62,9.61-7.62h0v-.02ZM142.26,24.9c-3.09.04-6.21.57-8.88,1.56-9.15,3.38-13.32,11.7-13.95,21.13-.07,1.12-.11,2.25-.11,3.37,0,1.03.04,2.06.12,3.1.08,1,.25,3.94,1.06,4.47,1.22-2.02,2.1-4.1,3.68-5.9,1.29-1.47,2.8-2.75,4.53-3.59,4.73-2.29,10.49-1.16,15.43-.33,1,.17,1.96.34,2.87.51,1.23.23,2.48.37,3.73.37.43,0,.84,0,1.26-.04h.12c10.17-.68,14.34-12.97,6.24-19.39-2.57-2.03-5.78-3.45-8.91-4.35-2.22-.63-4.7-.92-7.21-.89h0l.02-.02Z"/>
</svg>
SVG,
                        'z' => <<<'SVG'
<svg class="brezy-letter-icon" viewBox="180 0 80 127.41" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
    <path fill="currentColor" d="M188.45,86.68v.15l34.49-.2c2.37-.16,4.86-1.21,6.1-3.42.67-1.19.9-2.59.95-3.96.09-2.71-.51-5.42-1.72-7.82-.41-.82-1.01-1.52-1.43-2.32.25-.14,1.05.54,1.27.67.49.3.98.61,1.45.93,2.03,1.39,3.63,3.2,4.31,5.66.5,1.81.48,3.76.03,5.58-.41,1.66-1.18,3.26-2.39,4.43-.82.79-1.83,1.36-2.91,1.67-1.14.33-2.34.28-3.52.28h-26.66c-6.88,0-13.75-.08-20.62-.08v-1.19l46.11-62.05h.04l.11-.15-34.64.2c-2.37.16-4.86,1.21-6.1,3.42-.67,1.19-.9,2.59-.95,3.97-.09,2.7.51,5.42,1.73,7.82.41.82,1.01,1.52,1.43,2.32-.25.14-1.05-.53-1.27-.67-.49-.3-.98-.61-1.46-.94-2.03-1.39-3.63-3.2-4.31-5.66-.5-1.81-.48-3.76-.03-5.58.41-1.66,1.18-3.26,2.4-4.43.82-.79,1.83-1.37,2.91-1.68,1.14-.33,2.34-.28,3.52-.28h26.65c6.88,0,13.75.08,20.62.08v1.19l-46.12,62.05h.01Z"/>
</svg>
SVG,
                        'y' => <<<'SVG'
<svg class="brezy-letter-icon" viewBox="240 0 60 127.41" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
    <path fill="currentColor" d="M249.45,23.29l2.85,7.67,3.01,8.44,16.84,46.45c3.88-6.43,7.34-12.59,10.36-18.46,1.3-2.46,2.55-5,3.76-7.62,1.3-2.7,2.42-5.28,3.37-7.74,1.04-2.54,1.86-4.88,2.46-7.03.6-2.22.91-4.17.91-5.83,0-2.94-.78-5.36-2.33-7.27-2.03-2.49-7.08-4.07-9.89-2.15-1.29.89-1.95,2.48-2.25,4.05-.81,4.37.72,9.09,3.02,12.74-.28-.44-1.44-.89-1.88-1.24-.64-.52-1.16-1.1-1.69-1.74-1.21-1.48-2.36-3.02-3.23-4.74-1.13-2.22-1.79-4.78-1.4-7.26.33-2.09,1.38-4.01,2.78-5.56,6.12-6.78,18.38-4.72,20.31,4.89.19.97.3,1.95.33,2.93.1,3.12-.56,6.28-1.53,9.26-1.37,4.2-3.13,8.42-4.98,12.41-1.99,4.29-4.23,8.73-6.74,13.34-2.42,4.53-4.88,8.97-7.38,13.34-2.76,4.82-5.83,9.42-8.48,14.28-2.35,4.32-4.98,8.57-8.54,12.01-3.3,3.19-8.38,5.14-12.92,5.41-2.63.16-5.29-.24-7.75-1.22-1.85-.74-3.57-1.92-4.79-3.54-3.75-4.97-2.84-12.47.62-17.33-.4.56.13,3.05.2,3.75.12,1.1.3,2.2.64,3.26.64,2.02,1.8,3.9,3.58,5.11,2.43,1.65,5.49,2.11,8.36,2.35,8.2.71,15.73-4.84,17.16-12.94.85-4.81-.95-7.6-2.73-12.33-.3-.79-.6-1.58-.9-2.38-1.47-3.89-3.24-8.57-5.31-14.05-1.21-3.33-2.59-6.95-4.14-10.84-1.47-3.97-2.81-7.74-4.02-11.31-1.55-4.13-5.08-14.85-6.46-18.98l8.77-.11v-.02Z"/>
</svg>
SVG,
                    ];

                    $render_brezy_letter = static function (string $letter) use ($brezy_letter_svgs): string {
                        return $brezy_letter_svgs[$letter] ?? '';
                    };

                    $build_page_url = static function (int $page) use ($q): string {
                        $q['property_page'] = $page;
                        return '?' . http_build_query($q);
                    };

                    $chunk_size = 3;

                    $left_start = $current_page - ($chunk_size - 1);
                    $left_end = $current_page;

                    if ($left_start < 1) {
                        $left_end += 1 - $left_start;
                        $left_start = 1;
                    }

                    $left_end = min($left_end, $total_pages);
                    $left_start = max(1, $left_end - $chunk_size + 1);
                    $left_pages = range($left_start, $left_end);

                    $right_start = max($left_end + 1, $total_pages - $chunk_size + 1);
                    $right_pages = $right_start <= $total_pages ? range($right_start, $total_pages) : [];

                    if (!empty($right_pages) && $right_start <= $left_end) {
                        $pagination_pages = range($left_start, $total_pages);
                    } else {
                        $pagination_pages = array_merge($left_pages, $right_pages);
                    }

                    $pagination_pages = array_values(array_unique($pagination_pages));
                    ?>
                    <div class="digimanagement-pagination brezy-pagination" role="navigation" aria-label="<?php echo esc_attr__('Brezy pagination', 'digim'); ?>">
                        <?php
                        $first_disabled = $current_page <= 1;
                        $last_disabled = $current_page >= $total_pages;
                        ?>
                        <?php if ($first_disabled): ?>
                            <span class="pagination-letter letter-B is-disabled" aria-hidden="true">
                                <?php echo $render_brezy_letter('B'); ?>
                            </span>
                            <span class="pagination-letter letter-r is-disabled" aria-hidden="true">
                                <?php echo $render_brezy_letter('r'); ?>
                            </span>
                        <?php else: ?>
                            <a class="pagination-letter letter-B" href="<?php echo esc_url($build_page_url(1)); ?>" aria-label="<?php echo esc_attr__('Go to first page', 'digim'); ?>">
                                <?php echo $render_brezy_letter('B'); ?>
                            </a>
                            <a class="pagination-letter letter-r" href="<?php echo esc_url($build_page_url($current_page - 1)); ?>" aria-label="<?php echo esc_attr__('Go to previous page', 'digim'); ?>">
                                <?php echo $render_brezy_letter('r'); ?>
                            </a>
                        <?php endif; ?>

                        <?php
                        $previous_page = null;
                        foreach ($pagination_pages as $page) :
                            if ($previous_page !== null && $page - $previous_page > 1) :
                                ?>
                                <span class="pagination-dots" aria-hidden="true">…</span>
                            <?php
                            endif;
                            $is_active = ($page === (int) $current_page);
                            if ($is_active) :
                                ?>
                                <span class="pagination-letter letter-e is-active" aria-current="page" aria-label="<?php echo esc_attr(sprintf(__('Current page %d', 'digim'), $page)); ?>">
                                    <?php echo $render_brezy_letter('e'); ?>
                                </span>
                            <?php else : ?>
                                <a class="pagination-letter letter-e" href="<?php echo esc_url($build_page_url($page)); ?>" aria-label="<?php echo esc_attr(sprintf(__('Go to page %d', 'digim'), $page)); ?>">
                                    <?php echo $render_brezy_letter('e'); ?>
                                </a>
                            <?php
                            endif;
                            $previous_page = $page;
                        endforeach;
                        ?>

                        <?php if ($last_disabled): ?>
                            <span class="pagination-letter letter-z is-disabled" aria-hidden="true">
                                <?php echo $render_brezy_letter('z'); ?>
                            </span>
                            <span class="pagination-letter letter-y is-disabled" aria-hidden="true">
                                <?php echo $render_brezy_letter('y'); ?>
                            </span>
                        <?php else: ?>
                            <a class="pagination-letter letter-z" href="<?php echo esc_url($build_page_url($current_page + 1)); ?>" aria-label="<?php echo esc_attr__('Go to next page', 'digim'); ?>">
                                <?php echo $render_brezy_letter('z'); ?>
                            </a>
                            <a class="pagination-letter letter-y" href="<?php echo esc_url($build_page_url($total_pages)); ?>" aria-label="<?php echo esc_attr__('Go to last page', 'digim'); ?>">
                                <?php echo $render_brezy_letter('y'); ?>
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <?php if ($show_map): ?>
                <div class="digimanagement-map">
                    <?php if (is_admin() && isset($_GET['page']) && $_GET['page'] === 'DigiM-style'): ?>
                        <img src="<?php echo plugin_dir_url(__FILE__) . '../assets/mappreview.png'; ?>" alt="Map Preview" style="width: 100%; border-radius: 10px;" />
                    <?php else: ?>
                        <div id="digim-map" style="width: 100%; height: 400px; border-radius: 10px;"></div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php
    // Calculate hover and active colors if function exists
    $pc = $primary_color ?? '#0073aa';
    $primary_color_hover = function_exists('digim_darken_color') ? digim_darken_color($pc, 10) : '#005a87';
    $primary_color_active = function_exists('digim_darken_color') ? digim_darken_color($pc, 20) : '#004a6f';
    ?>
    <style>
        :root {
            --digim-primary-color: <?php echo $pc; ?>;
            --digim-primary-color-hover: <?php echo $primary_color_hover; ?>;
            --digim-primary-color-active: <?php echo $primary_color_active; ?>;
        }
        
        .digim-main .digimanagement-search .search-buttons button.search-button {
            background: var(--digim-primary-color) !important;
            background-color: var(--digim-primary-color) !important;
            color: #fff !important;
        }
        
        .digim-main .digimanagement-search .search-buttons button.search-button:hover,
        .digim-main .digimanagement-search .search-buttons button.search-button:focus {
            background: var(--digim-primary-color-hover) !important;
            background-color: var(--digim-primary-color-hover) !important;
            color: #fff !important;
        }
        
        .digim-main .digimanagement-search .search-buttons button.search-button:active {
            background: var(--digim-primary-color-active) !important;
            background-color: var(--digim-primary-color-active) !important;
            color: #fff !important;
        }
        
        .digimanagement-pagination .letter-e.is-active {
            background: var(--digim-primary-color) !important;
            border-color: var(--digim-primary-color) !important;
            color: #fff !important;
        }

        .digimanagement-card.highlight {
            outline: 2px solid var(--digim-primary-color) !important;
            box-shadow: 0 0 5px var(--digim-primary-color) !important;
        }
    </style>
</div>