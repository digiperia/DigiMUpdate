<?php
// Check if this is from UI builder
global $digim_from_ui_builder;
$container_class = 'digim-main';
if (!empty($digim_from_ui_builder)) {
    $container_class .= ' digim-shortcode';
}
?>



<div class="<?php echo esc_attr($container_class); ?>">

    <?php
    // Initialize mobile search variables if not already set (to prevent undefined variable warnings)
    if (!isset($mobile_location_text)) {
        $mobile_location_text = !empty($search) ? (is_array($search) ? implode(', ', $search) : $search) : 'Check Your Dates';
    }
    if (!isset($mobile_date_text)) {
        $mobile_date_text = '';
        if (!empty($checkin) && !empty($checkout)) {
            $checkin_ts = strtotime($checkin);
            $checkout_ts = strtotime($checkout);
            if ($checkin_ts && $checkout_ts) {
                $checkin_month = date('M', $checkin_ts);
                $checkin_day = date('j', $checkin_ts);
                $checkout_month = date('M', $checkout_ts);
                $checkout_day = date('j', $checkout_ts);
                $year = date('Y', $checkin_ts);

                // Format: "May 10-13 / 2026" (same month) or "May 10 - Jun 5 / 2026" (different months)
                if ($checkin_month === $checkout_month) {
                    $mobile_date_text = $checkin_month . ' ' . $checkin_day . '-' . $checkout_day . ' / ' . $year;
                } else {
                    $mobile_date_text = $checkin_month . ' ' . $checkin_day . ' - ' . $checkout_month . ' ' . $checkout_day . ' / ' . $year;
                }
            }
        }
    }
    if (!isset($mobile_guests_text)) {
        $mobile_guests_text = '';
        // Get guest details from GET parameters
        $adults = intval($_GET['adults'] ?? 0);
        $children = intval($_GET['children'] ?? 0);
        $infants = intval($_GET['infants'] ?? 0);
        $pets = intval($_GET['pets'] ?? 0);

        // Build guest text with all details
        $guest_parts = [];
        $total_guests = $adults + $children;
        if ($total_guests > 0) {
            $guest_parts[] = $total_guests . ' guest' . ($total_guests > 1 ? 's' : '');
        }
        if ($infants > 0) {
            $guest_parts[] = $infants . ' infant' . ($infants > 1 ? 's' : '');
        }
        if ($pets > 0) {
            $guest_parts[] = $pets . ' pet' . ($pets > 1 ? 's' : '');
        }

        if (!empty($guest_parts)) {
            $mobile_guests_text = implode(', ', $guest_parts);
        }

        // Also set guest_count for backward compatibility
        if (!isset($guest_count)) {
            $guest_count = $total_guests + $infants;
        }
    }
    ?>

    <!-- Mobile Search Trigger Button (Airbnb Style) -->
    <button type="button" class="digim-mobile-search-trigger" aria-label="Open search">
        <!-- <i class="fas fa-arrow-left"></i> -->
        <div class="mobile-search-button-content">
            <div class="mobile-search-title"><?php echo esc_html($mobile_location_text); ?></div>
            <div class="mobile-search-subtitle">
                <?php if ($mobile_date_text && $mobile_guests_text): ?>
                    <?php echo esc_html($mobile_date_text); ?><span style="margin-left:4px;"><?php echo esc_html(' - &nbsp;' . $mobile_guests_text); ?></span>
                <?php elseif ($mobile_date_text): ?>
                    <?php echo esc_html($mobile_date_text); ?>
                <?php elseif ($mobile_guests_text): ?>
                    <?php echo esc_html($mobile_guests_text); ?>
                <?php else: ?>
                    <span style="color: #999;">Add dates · Add guests</span>
                <?php endif; ?>
            </div>
        </div>
    </button>

    <!-- Mobile Search Modal -->
    <div class="digim-mobile-search-modal" id="digim-mobile-search-modal">
        <div class="digim-mobile-search-modal-content">
            <form class="digimanagement-search digimanagement-search-mobile" method="get">
                <div class="search-grid">
                    <!-- WHERE -->
                    <div class="search-group">
                        <label>Where</label>
                        <select name="property_search[]" class="city-select" multiple>
                            <?php foreach ($destination_names as $city): ?>
                                <option value="<?php echo esc_attr($city); ?>" <?php
                                                                                $search_array = is_array($search) ? $search : ($search ? [$search] : []);
                                                                                selected(true, in_array($city, $search_array));
                                                                                ?>>
                                    <?php echo esc_html($city); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- CHECKIN / CHECKOUT -->
                    <div class="search-group datecal">
                        <label>Check in / Check out</label>
                        <input type="text" class="flatpickr-range" placeholder="Add dates" autocomplete="off" readonly inputmode="none">
                        <input type="hidden" name="checkin" class="checkin-hidden" value="<?php echo esc_attr($checkin); ?>">
                        <input type="hidden" name="checkout" class="checkout-hidden" value="<?php echo esc_attr($checkout); ?>">
                    </div>

                    <!-- WHO -->
                    <div class="search-group">
                        <label>Who</label>
                        <div class="guest-dropdown-wrapper">
                            <button type="button" class="guest-toggle">Add guests</button>
                            <div class="guest-dropdown">
                                <?php
                                $guest_types = [
                                    'adults' => ['label' => 'Adults', 'desc' => 'Ages 13 or above'],
                                    'children' => ['label' => 'Children', 'desc' => 'Ages 2–12'],
                                    'infants' => ['label' => 'Infants', 'desc' => 'Under 2'],
                                    'pets' => ['label' => 'Pets', 'desc' => '<a href="/accessibility-policy" target="_blank" style="text-decoration: underline;">Bringing a service animal?</a>'],
                                ];
                                foreach ($guest_types as $type => $meta):
                                    $val = intval($_GET[$type] ?? 0);
                                ?>
                                    <div class="guest-row">
                                        <div class="guest-labels">
                                            <span><?= $meta['label'] ?></span>
                                            <span><?= $meta['desc'] ?></span>
                                        </div>
                                        <div class="guest-controls">
                                            <button type="button" class="minus">−</button>
                                            <span class="guest-count"><?= $val ?></span>
                                            <button type="button" class="plus">+</button>
                                            <input type="hidden" name="<?= $type ?>" value="<?= $val ?>" id="<?= $type ?>-input">
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <input type="hidden" name="guests" value="<?php echo esc_attr($guest_count); ?>" id="total-guests">
                        </div>
                    </div>

                    <!-- BUTTONS -->
                    <div class="search-buttons">
                        <button type="button" class="reset-button" title="Reset"><i class="fas fa-undo"></i></button>
                        <button type="submit" class="search-button" title="Search"><i class="fas fa-search"></i></button>
                    </div>
                </div>
            </form>
        </div>
        <div class="digim-mobile-search-modal-header">
            <button type="button" class="digim-mobile-search-close" aria-label="Close search">Close</button>
        </div>
    </div>

    <!-- Search Form -->
    <div class="bg-white">
        <form class="digimanagement-search" method="get">

            <div class="search-grid">
                <!-- WHERE -->
                <div class="search-group">
                    <label>Where</label>
                    <select name="property_search[]" class="city-select" multiple>
                        <?php foreach ($destination_names as $city): ?>
                            <option value="<?php echo esc_attr($city); ?>" <?php
                                                                            $search_array = is_array($search) ? $search : ($search ? [$search] : []);
                                                                            selected(true, in_array($city, $search_array));
                                                                            ?>>
                                <?php echo esc_html($city); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- CHECKIN / CHECKOUT -->
                <div class="search-group datecal">
                    <label>Check in / Check out</label>
                    <input type="text" class="flatpickr-range" placeholder="Add dates" autocomplete="off" readonly inputmode="none">
                    <input type="hidden" name="checkin" class="checkin-hidden" value="<?php echo esc_attr($checkin); ?>">
                    <input type="hidden" name="checkout" class="checkout-hidden" value="<?php echo esc_attr($checkout); ?>">
                </div>


                <!-- WHO -->
                <div class="search-group">
                    <label>Who</label>
                    <div class="guest-dropdown-wrapper">
                        <button type="button" class="guest-toggle">Add guests</button>
                        <div class="guest-dropdown">
                            <?php
                            $guest_types = [
                                'adults' => ['label' => 'Adults', 'desc' => 'Ages 13 or above'],
                                'children' => ['label' => 'Children', 'desc' => 'Ages 2–12'],
                                'infants' => ['label' => 'Infants', 'desc' => 'Under 2'],
                                'pets' => ['label' => 'Pets', 'desc' => '<a href="/accessibility-policy" target="_blank" style="text-decoration: underline;">Bringing a service animal?</a>'],
                            ];
                            foreach ($guest_types as $type => $meta):
                                $val = intval($_GET[$type] ?? 0);
                            ?>
                                <div class="guest-row">
                                    <div class="guest-labels">
                                        <span><?= $meta['label'] ?></span>
                                        <span><?= $meta['desc'] ?></span>
                                    </div>
                                    <div class="guest-controls">
                                        <button type="button" class="minus">−</button>
                                        <span class="guest-count"><?= $val ?></span>
                                        <button type="button" class="plus">+</button>
                                        <input type="hidden" name="<?= $type ?>" value="<?= $val ?>" id="<?= $type ?>-input">
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <input type="hidden" name="guests" value="<?php echo esc_attr($guest_count); ?>" id="total-guests">
                    </div>
                </div>

                <!-- BUTTONS -->
                <div class="search-buttons">
                    <button type="button" class="reset-button" title="Reset"><i class="fas fa-undo"></i></button>
                    <button type="submit" class="search-button" title="Search"><i class="fas fa-search"></i></button>
                </div>
            </div>

        </form>

        <script>
            document.addEventListener("DOMContentLoaded", function() {
                // Initialize all guest dropdown wrappers (both mobile and desktop)
                const allGuestWrappers = document.querySelectorAll(".guest-dropdown-wrapper");

                allGuestWrappers.forEach(function(wrapper) {
                    const toggleBtn = wrapper.querySelector(".guest-toggle");
                    const guestRows = wrapper.querySelectorAll(".guest-row");
                    const totalGuestsInput = wrapper.querySelector('input[name="guests"]');
                    const guestDropdown = wrapper.querySelector(".guest-dropdown");

                    if (!toggleBtn || !guestDropdown) return;

                    const updateGuestSummary = () => {
                        let guests = 0;
                        let infants = 0;
                        let pets = 0;

                        guestRows.forEach(row => {
                            const input = row.querySelector('input[type="hidden"]');
                            const count = parseInt(input.value) || 0;
                            const type = input.name;

                            if (type === "adults" || type === "children") guests += count;
                            else if (type === "infants") infants = count;
                            else if (type === "pets") pets = count;

                            const countElement = row.querySelector(".guest-count");
                            if (countElement) countElement.textContent = count;
                        });

                        let text = guests > 0 ? `${guests} guest${guests > 1 ? 's' : ''}` : "Add guests";
                        if (infants > 0) text += `, ${infants} infant${infants > 1 ? 's' : ''}`;
                        if (pets > 0) text += `, ${pets} pet${pets > 1 ? 's' : ''}`;

                        toggleBtn.textContent = text;
                        if (totalGuestsInput) totalGuestsInput.value = guests;
                    };

                    // Apply increment/decrement events
                    guestRows.forEach(row => {
                        const input = row.querySelector('input[type="hidden"]');
                        const minus = row.querySelector(".minus");
                        const plus = row.querySelector(".plus");

                        if (minus) {
                            minus.addEventListener("click", () => {
                                let val = parseInt(input.value) || 0;
                                input.value = Math.max(0, val - 1);
                                updateGuestSummary();
                            });
                        }

                        if (plus) {
                            plus.addEventListener("click", () => {
                                let val = parseInt(input.value) || 0;
                                input.value = val + 1;
                                updateGuestSummary();
                            });
                        }
                    });

                    // Toggle dropdown
                    toggleBtn.addEventListener("click", () => {
                        guestDropdown.classList.toggle("active");
                    });

                    // Close dropdown when clicking outside
                    document.addEventListener("click", function(e) {
                        if (!wrapper.contains(e.target)) {
                            guestDropdown.classList.remove("active");
                        }
                    });

                    // Initialize guest summary
                    updateGuestSummary();
                });

                // Get mobile modal reference for use in reset handler
                const mobileSearchModal = document.querySelector('.digim-mobile-search-modal');
                const mobileSearchButtonContent = document.querySelector('.mobile-search-button-content');

                // Function to show loading state
                const showLoading = function() {
                    if (mobileSearchButtonContent) {
                        const originalContent = mobileSearchButtonContent.innerHTML;
                        mobileSearchButtonContent.setAttribute('data-original-content', originalContent);
                        mobileSearchButtonContent.innerHTML = '<div style="text-align: center; padding: 8px 0;">Loading...</div>';
                        mobileSearchButtonContent.style.pointerEvents = 'none';
                    }
                };

                // Function to hide loading state
                const hideLoading = function() {
                    if (mobileSearchButtonContent) {
                        const originalContent = mobileSearchButtonContent.getAttribute('data-original-content');
                        if (originalContent) {
                            mobileSearchButtonContent.innerHTML = originalContent;
                            mobileSearchButtonContent.removeAttribute('data-original-content');
                        }
                        mobileSearchButtonContent.style.pointerEvents = '';
                    }
                };

                // Function to close modal and restore scroll
                const closeMobileModal = function() {
                    if (mobileSearchModal) {
                        mobileSearchModal.classList.remove('active');
                        // Restore body scroll
                        document.body.style.overflow = '';
                    }
                };

                // Reset form - attach to all reset buttons
                document.querySelectorAll('.reset-button').forEach(function(resetBtn) {
                    resetBtn.addEventListener("click", () => {
                        // Check if this is the mobile form reset button
                        const isMobileReset = resetBtn.closest('.digimanagement-search-mobile');

                        // Show loading if mobile reset
                        if (isMobileReset) {
                            showLoading();
                        }
                        // Reset city select dropdown
                        const citySelects = document.querySelectorAll('.city-select');
                        citySelects.forEach(function(citySelect) {
                            if (citySelect) {
                                if (window.jQuery && window.jQuery(citySelect).data('select2')) {
                                    window.jQuery(citySelect).val(null).trigger('change');
                                } else {
                                    citySelect.value = '';
                                }
                            }
                        });

                        // Reset date range (DateRangePicker) - reset all instances
                        const dateRangeInputs = document.querySelectorAll('.flatpickr-range');
                        dateRangeInputs.forEach(function(dateRangeInput) {
                            if (dateRangeInput && typeof jQuery !== 'undefined' && jQuery(dateRangeInput).data('daterangepicker')) {
                                const picker = jQuery(dateRangeInput).data('daterangepicker');
                                if (picker && typeof moment !== 'undefined') {
                                    picker.setStartDate(moment());
                                    picker.setEndDate(null);
                                }
                                jQuery(dateRangeInput).val('');
                            } else if (dateRangeInput) {
                                dateRangeInput.value = '';
                            }
                        });

                        // Reset hidden date inputs - reset all instances
                        const checkinHiddenInputs = document.querySelectorAll('.checkin-hidden');
                        const checkoutHiddenInputs = document.querySelectorAll('.checkout-hidden');
                        checkinHiddenInputs.forEach(function(input) {
                            if (input) input.value = '';
                        });
                        checkoutHiddenInputs.forEach(function(input) {
                            if (input) input.value = '';
                        });

                        // Reset guest inputs - reset all guest dropdowns
                        const allGuestWrappers = document.querySelectorAll('.guest-dropdown-wrapper');
                        allGuestWrappers.forEach(function(wrapper) {
                            const wrapperGuestRows = wrapper.querySelectorAll('.guest-row');
                            wrapperGuestRows.forEach(function(row) {
                                const input = row.querySelector('input[type="hidden"]');
                                if (input) {
                                    input.value = '0';
                                }
                            });
                            // Update guest summary for this wrapper
                            const wrapperToggleBtn = wrapper.querySelector(".guest-toggle");
                            const wrapperTotalGuestsInput = wrapper.querySelector('input[name="guests"]');
                            if (wrapperToggleBtn && wrapperTotalGuestsInput) {
                                let guests = 0;
                                let infants = 0;
                                let pets = 0;
                                wrapperGuestRows.forEach(function(row) {
                                    const input = row.querySelector('input[type="hidden"]');
                                    const count = parseInt(input.value) || 0;
                                    const type = input.name;
                                    if (type === "adults" || type === "children") guests += count;
                                    else if (type === "infants") infants = count;
                                    else if (type === "pets") pets = count;
                                    row.querySelector(".guest-count").textContent = count;
                                });
                                let text = guests > 0 ? `${guests} guest${guests > 1 ? 's' : ''}` : "Add guests";
                                if (infants > 0) text += `, ${infants} infant${infants > 1 ? 's' : ''}`;
                                if (pets > 0) text += `, ${pets} pet${pets > 1 ? 's' : ''}`;
                                wrapperToggleBtn.textContent = text;
                                wrapperTotalGuestsInput.value = guests;
                            }
                        });

                        // Clear URL parameters - reload only if URL has parameters
                        if (window.location.search) {
                            // URL has parameters, reload with clean URL
                            // Loading will disappear on reload
                            window.location.href = window.location.pathname;
                        } else {
                            // If no URL parameters, just reset inputs (already done above, no reload)
                            // Close mobile modal if this is the mobile reset button
                            if (isMobileReset && mobileSearchModal) {
                                closeMobileModal();
                                // Hide loading after a short delay since page won't reload
                                setTimeout(function() {
                                    hideLoading();
                                }, 300);
                            }
                        }
                    });
                });

                // Mobile search modal toggle
                const mobileSearchTrigger = document.querySelector('.digim-mobile-search-trigger');
                const mobileSearchClose = document.querySelector('.digim-mobile-search-close');

                // Track if user has scrolled
                let hasScrolled = false;
                let lastScrollPosition = 0;

                // Track scroll to detect if user has scrolled
                window.addEventListener('scroll', function() {
                    const currentScroll = window.pageYOffset || document.documentElement.scrollTop;
                    if (currentScroll > 0) {
                        hasScrolled = true;
                        lastScrollPosition = currentScroll;
                    }
                }, {
                    passive: true
                });

                if (mobileSearchTrigger && mobileSearchModal) {
                    mobileSearchTrigger.addEventListener('click', function() {
                        mobileSearchModal.classList.add('active');
                        // Prevent body scroll when modal is open
                        document.body.style.overflow = 'hidden';
                    });
                }

                // Close modal on back arrow click
                if (mobileSearchClose && mobileSearchModal) {
                    mobileSearchClose.addEventListener('click', function() {
                        closeMobileModal();
                    });
                }

                // Close modal on search button click (mobile form)
                const mobileSearchButton = document.querySelector('.digimanagement-search-mobile .search-button');
                if (mobileSearchButton && mobileSearchModal) {
                    mobileSearchButton.addEventListener('click', function() {
                        // Show loading before form submits
                        showLoading();
                        closeMobileModal();
                    });
                }

                // Also handle form submit event for mobile search form
                const mobileSearchForm = document.querySelector('.digimanagement-search-mobile');
                if (mobileSearchForm) {
                    mobileSearchForm.addEventListener('submit', function() {
                        // Show loading when form is submitted
                        showLoading();
                    });
                }
            });
        </script>

        <?php
        $grid_class = $layout_style === 'list' ? 'digimanagement-list' : "digimanagement-grid grid-cols-$grid_columns";
        $show_capacity_setting = [
            'row'       => intval(get_option('digim_show_capacity', 1)),
            'guests'    => intval(get_option('digim_show_capacity_guests', 1)),
            'bedrooms'  => intval(get_option('digim_show_capacity_bedrooms', 1)),
            'beds'      => intval(get_option('digim_show_capacity_beds', 1)),
            'bathrooms' => intval(get_option('digim_show_capacity_bathrooms', 1)),
        ];
        ?>
        <div class="dm-grid <?php echo $show_map ? 'map-listing' : ''; ?>">
            <div class="dm-property">
                <div class="<?php echo esc_attr($grid_class); ?>" id="digim-properties-grid">

                    <?php if (empty($properties_to_show)): ?>
                        <?php
                        $empty_checkin = isset($checkin) ? $checkin : ($_GET['checkin'] ?? '');
                        $empty_checkout = isset($checkout) ? $checkout : ($_GET['checkout'] ?? '');
                        ?>
                        <?php if (!empty($empty_checkin) && !empty($empty_checkout)): ?>
                            <div style="grid-column: 1 / -1; margin-bottom: 0; display: flex; align-items: center; padding: 8px 12px 0;">
                                <div class="digim-listing-title">
                                    <h2 class="digim-listing-title-text"><?php echo esc_html__('Listing properties', 'digim'); ?></h2>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php else:
                        // Batch fetch images for all properties that need them (parallel API calls)
                        $uuids_needing_images = [];
                        foreach ($properties_to_show as $property) {
                            $uuid = $property['uuid'] ?? $property['id'] ?? '';
                            // Only fetch if property doesn't have images in payload
                            if (!empty($uuid) && (empty($property['images']) || !is_array($property['images']) || count($property['images']) === 0)) {
                                $uuids_needing_images[] = $uuid;
                            }
                        }

                        // Fetch all images in parallel
                        $fetched_images = [];
                        if (!empty($uuids_needing_images) && function_exists('digimanagement_parallel_fetch_images')) {
                            $fetched_images = digimanagement_parallel_fetch_images($uuids_needing_images);
                        }

                        // Check for checkout-blocked dates if checkout date is provided
                        // Use dates from above if already set, otherwise get from GET
                        if (empty($checkout_date)) {
                            $checkout_date = isset($_GET['checkout']) ? sanitize_text_field($_GET['checkout']) : '';
                        }
                        if (empty($checkin_date)) {
                            $checkin_date = isset($_GET['checkin']) ? sanitize_text_field($_GET['checkin']) : '';
                        }
                        $show_available_only = isset($_GET['show_available_only']) && $_GET['show_available_only'] === '1';
                        $checkout_blocked_data = [];
                        $checkout_blocked_suggestions = [];

                        // Performance: only fetch checkout-blocked for the current page (same as availability).
                        // Use $properties_to_show so we never call the API for more than per_page UUIDs.
                        global $digim_all_properties_for_filter, $digim_per_page, $digim_checkin_date, $digim_checkout_date;
                        $properties_for_checkout_check = $properties_to_show;

                        // Use global dates if available (for consistency)
                        if (empty($checkin_date) && !empty($digim_checkin_date)) {
                            $checkin_date = $digim_checkin_date;
                        }
                        if (empty($checkout_date) && !empty($digim_checkout_date)) {
                            $checkout_date = $digim_checkout_date;
                        }

                        // Validate dates - check if they are valid date strings
                        $invalid_date_strings = ['Invalid date', 'invalid date', 'Invalid Date', 'NaN', 'null', 'undefined'];
                        if (in_array($checkin_date, $invalid_date_strings, true) || in_array($checkout_date, $invalid_date_strings, true)) {
                            $checkin_date = '';
                            $checkout_date = '';
                        } else {
                            // Try to parse dates to ensure they're valid
                            $checkin_test = DateTimeImmutable::createFromFormat('Y-m-d', $checkin_date, wp_timezone());
                            $checkout_test = DateTimeImmutable::createFromFormat('Y-m-d', $checkout_date, wp_timezone());
                            if (!$checkin_test || !$checkout_test) {
                                $checkin_date = '';
                                $checkout_date = '';
                            }
                        }

                        if (!empty($checkout_date) && !empty($checkin_date)) {
                            // Performance: reuse checkout_blocked from parallel_calendar_check (one API batch instead of two).
                            global $digim_checkout_blocked_data;
                            $all_uuids = [];
                            $suggested_properties_uuids = [];
                            $max_suggested_date = $checkout_date;

                            foreach ($properties_for_checkout_check as $property) {
                                $uuid = $property['uuid'] ?? $property['id'] ?? '';
                                if (!empty($uuid)) {
                                    $all_uuids[] = $uuid;
                                    if (!empty($property['_digim_is_suggestion']) && !empty($property['_digim_suggested_start'])) {
                                        $suggested_properties_uuids[] = $uuid;
                                        try {
                                            $suggested_start_obj = new DateTimeImmutable($property['_digim_suggested_start'], wp_timezone());
                                            $suggested_end = $suggested_start_obj->modify('+20 days')->format('Y-m-d');
                                            if ($suggested_end > $max_suggested_date) {
                                                $max_suggested_date = $suggested_end;
                                            }
                                        } catch (Exception $e) {
                                            // Ignore
                                        }
                                    }
                                }
                            }

                            if (!empty($all_uuids)) {
                                // Use data already fetched by parallel_calendar_check when present (avoids second API batch).
                                $checkout_blocked_data = [];
                                if (is_array($digim_checkout_blocked_data) && !empty($digim_checkout_blocked_data)) {
                                    $missing = array_diff($all_uuids, array_keys($digim_checkout_blocked_data));
                                    if (empty($missing)) {
                                        $checkout_blocked_data = $digim_checkout_blocked_data;
                                    }
                                }
                                if (empty($checkout_blocked_data) && function_exists('digimanagement_parallel_fetch_checkout_blocked_dates')) {
                                    $checkout_blocked_data = digimanagement_parallel_fetch_checkout_blocked_dates($all_uuids, $checkin_date, $max_suggested_date);
                                }

                                // For each property, check if checkout date is blocked and find next available
                                // Check ALL properties (not just current page) for proper filtering
                                // Skip properties that are unavailable (suggestions) - they shouldn't show checkout-blocked badges
                                foreach ($properties_for_checkout_check as $property) {
                                    // Skip if property is unavailable (is a suggestion)
                                    $is_prop_suggestion = !empty($property['_digim_is_suggestion']);
                                    if ($is_prop_suggestion) {
                                        continue; // Don't process checkout-blocked dates for unavailable properties
                                    }

                                    $uuid = $property['uuid'] ?? $property['id'] ?? '';
                                    if (!empty($uuid) && isset($checkout_blocked_data[$uuid])) {
                                        // Get checkout-blocked and unavailable dates
                                        $calendar_data = $checkout_blocked_data[$uuid];
                                        $blocked_dates = is_array($calendar_data) && isset($calendar_data['checkout_blocked'])
                                            ? $calendar_data['checkout_blocked']
                                            : (is_array($calendar_data) ? $calendar_data : []);
                                        $unavailable_dates = is_array($calendar_data) && isset($calendar_data['unavailable'])
                                            ? $calendar_data['unavailable']
                                            : [];

                                        // Calculate requested nights
                                        try {
                                            $checkin_obj = new DateTimeImmutable($checkin_date, wp_timezone());
                                            $checkout_obj = new DateTimeImmutable($checkout_date, wp_timezone());
                                            $requested_nights = $checkin_obj->diff($checkout_obj)->days;
                                        } catch (Exception $e) {
                                            // Invalid dates, skip this property
                                            continue;
                                        }

                                        // Check property minimum nights requirement
                                        $property_min_nights = $property['minimum_nights']
                                            ?? $property['min_nights']
                                            ?? $property['min_stay']
                                            ?? $property['minimum_stay']
                                            ?? null;

                                        // Also check from _digim_min_nights_required (from calendar check)
                                        $calendar_min_nights = isset($property['_digim_min_nights_required']) ? intval($property['_digim_min_nights_required']) : null;

                                        // Use the maximum of calendar and property minimum nights
                                        $final_min_nights = null;
                                        if ($calendar_min_nights !== null && $property_min_nights !== null) {
                                            $final_min_nights = max((int)$calendar_min_nights, (int)$property_min_nights);
                                        } elseif ($calendar_min_nights !== null) {
                                            $final_min_nights = (int)$calendar_min_nights;
                                        } elseif ($property_min_nights !== null) {
                                            $final_min_nights = (int)$property_min_nights;
                                        }

                                        // First, check if property is available for the original date range
                                        // If any date in the range is unavailable, skip this property entirely
                                        $original_range_available = true;
                                        $current_check = clone $checkin_obj;
                                        while ($current_check < $checkout_obj) {
                                            $date_str = $current_check->format('Y-m-d');
                                            if (in_array($date_str, $unavailable_dates, true)) {
                                                $original_range_available = false;
                                                break;
                                            }
                                            $current_check = $current_check->modify('+1 day');
                                        }

                                        // If the original range is not available, skip this property
                                        if (!$original_range_available) {
                                            continue; // Property is unavailable for selected dates
                                        }

                                        // Check if minimum nights requirement is not met
                                        if ($final_min_nights !== null && $final_min_nights > 0 && $requested_nights < $final_min_nights) {
                                            // Find next available checkout date that meets minimum nights requirement
                                            // Start from the original checkout date and find next available date
                                            // Limit search to +20 days from original checkout date
                                            $suggested_checkout = null;
                                            $max_days_to_check = 20; // Check up to 20 days ahead from original checkout
                                            $checkout_candidate = clone $checkout_obj;

                                            for ($i = 0; $i <= $max_days_to_check; $i++) {
                                                if ($i > 0) {
                                                    $checkout_candidate = $checkout_candidate->modify('+1 day');
                                                }
                                                $candidate_date = $checkout_candidate->format('Y-m-d');

                                                // Check if this date meets minimum nights requirement
                                                $candidate_nights = $checkin_obj->diff($checkout_candidate)->days;
                                                if ($candidate_nights < $final_min_nights) {
                                                    continue; // Doesn't meet minimum nights yet
                                                }

                                                // Check if this checkout date is not checkout-blocked
                                                if (in_array($candidate_date, $blocked_dates, true)) {
                                                    continue; // Checkout is blocked on this date
                                                }

                                                // Check if the checkout date itself is not unavailable
                                                if (in_array($candidate_date, $unavailable_dates, true)) {
                                                    continue; // Checkout date is unavailable
                                                }

                                                // Check if the entire range (checkin to candidate checkout) is available
                                                $range_available = true;
                                                $range_check = clone $checkin_obj;
                                                while ($range_check < $checkout_candidate) {
                                                    $range_date_str = $range_check->format('Y-m-d');
                                                    if (in_array($range_date_str, $unavailable_dates, true)) {
                                                        $range_available = false;
                                                        break;
                                                    }
                                                    $range_check = $range_check->modify('+1 day');
                                                }

                                                if ($range_available) {
                                                    $suggested_checkout = $candidate_date;
                                                    break; // Found valid checkout date
                                                }
                                            }

                                            // Only show suggestion if we found an available date within +20 days
                                            if ($suggested_checkout) {
                                                $checkout_blocked_suggestions[$uuid] = [
                                                    'blocked_date' => $checkout_date,
                                                    'suggested_checkout' => $suggested_checkout,
                                                    'is_min_nights_related' => true,
                                                ];
                                            }
                                            // If no available date found within +20 days, don't show this property
                                            // (it will be filtered out or won't show badges)
                                        } else {
                                            // Minimum nights is met, check if checkout date is blocked
                                            $is_checkout_blocked = in_array($checkout_date, $blocked_dates, true);

                                            if ($is_checkout_blocked) {
                                                // Find next available checkout date (not in blocked dates)
                                                try {
                                                    $checkout_obj = new DateTimeImmutable($checkout_date, wp_timezone());
                                                    $next_checkout = null;
                                                    $max_days_to_check = 30; // Check up to 30 days ahead

                                                    for ($i = 1; $i <= $max_days_to_check; $i++) {
                                                        $candidate_date = $checkout_obj->modify("+$i days")->format('Y-m-d');
                                                        if (!in_array($candidate_date, $blocked_dates, true)) {
                                                            $next_checkout = $candidate_date;
                                                            break;
                                                        }
                                                    }

                                                    if ($next_checkout) {
                                                        $checkout_blocked_suggestions[$uuid] = [
                                                            'blocked_date' => $checkout_date,
                                                            'suggested_checkout' => $next_checkout,
                                                            'is_min_nights_related' => false,
                                                        ];
                                                    }
                                                } catch (Exception $e) {
                                                    // Invalid date, skip
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // When "show available only" is on, filter current page to hide checkout-blocked suggestions.
                            // (We only have checkout_blocked data for the current page for performance.)
                            if ($show_available_only && !empty($checkout_blocked_suggestions)) {
                                $properties_to_show = array_values(array_filter($properties_to_show, function ($property) use ($checkout_blocked_suggestions) {
                                    $uuid = $property['uuid'] ?? $property['id'] ?? '';
                                    return empty($uuid) || !isset($checkout_blocked_suggestions[$uuid]);
                                }));
                            }
                        }

                        // Check if we have any checkout-blocked badges to show the filter
                        $has_checkout_blocked_badges = !empty($checkout_blocked_suggestions);

                        // Collect unique bedrooms and beds values from all properties for filters
                        $all_bedrooms = [];
                        $all_beds = [];
                        foreach ($properties_to_show as $property) {
                            $bedrooms = isset($property['capacity']['bedrooms']) ? intval($property['capacity']['bedrooms']) : 0;
                            $beds = isset($property['capacity']['beds']) ? intval($property['capacity']['beds']) : 0;
                            if ($bedrooms > 0 && !in_array($bedrooms, $all_bedrooms)) {
                                $all_bedrooms[] = $bedrooms;
                            }
                            if ($beds > 0 && !in_array($beds, $all_beds)) {
                                $all_beds[] = $beds;
                            }
                        }
                        sort($all_bedrooms);
                        sort($all_beds);

                        // Get current filter values from URL
                        $filter_bedrooms = isset($_GET['filter_bedrooms']) ? sanitize_text_field($_GET['filter_bedrooms']) : '';
                        $filter_beds = isset($_GET['filter_beds']) ? sanitize_text_field($_GET['filter_beds']) : '';
                        $filter_price_min = isset($_GET['filter_price_min']) ? sanitize_text_field($_GET['filter_price_min']) : '';
                        $filter_price_max = isset($_GET['filter_price_max']) ? sanitize_text_field($_GET['filter_price_max']) : '';
                        $filter_amenities_raw = isset($_GET['filter_amenities']) ? $_GET['filter_amenities'] : [];
                        $filter_amenities_arr = is_array($filter_amenities_raw) ? array_map('sanitize_text_field', array_filter($filter_amenities_raw)) : (is_string($filter_amenities_raw) && $filter_amenities_raw !== '' ? array_map('trim', array_filter(explode(',', sanitize_text_field($filter_amenities_raw)))) : []);
                        $has_price_filter = ($filter_price_min !== '' && (int) $filter_price_min > 0) || ($filter_price_max !== '' && (int) $filter_price_max < 10000);
                        $has_any_filter = $filter_bedrooms || $filter_beds || $has_price_filter || !empty($filter_amenities_arr);
                        $all_amenities_for_filter = isset($digim_all_amenities_for_filter) && is_array($digim_all_amenities_for_filter) ? $digim_all_amenities_for_filter : [];
                    ?>
                        <?php if (!empty($checkin_date) && !empty($checkout_date)): ?>
                            <div style="grid-column: 1 / -1; margin-bottom: 0px; display: flex; align-items: center; gap: 16px; flex-wrap: wrap; justify-content: space-between; padding: 8px 12px 0;">
                                <div class="digim-listing-title">
                                    <h2 class="digim-listing-title-text">Listing properties</h2>
                                </div>
                                <div class="digim-filters-wrapper" style="margin-left: auto; position: relative;">
                                    <button type="button" class="digim-filter-toggle-btn" id="digim-filter-toggle-btn" aria-expanded="false" aria-controls="digim-filter-dropdown">
                                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 8px;">
                                            <path d="M2 4h12M4 8h8M6 12h4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                                        </svg>
                                        Filters
                                    </button>
                                    <?php if ($has_any_filter): ?>
                                        <button type="button" class="digim-filter-reset-btn" title="Reset all filters">
                                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 6px;">
                                                <path d="M1 1l12 12M13 1L1 13" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                        </button>
                                    <?php endif; ?>
                                    <!-- Advanced filter dropdown (digim-filter-dropdown active) -->
                                    <div class="digim-filter-dropdown" id="digim-filter-dropdown" aria-hidden="true">
                                        <div class="digim-filter-dropdown-inner">
                                            <div class="digim-filter-dropdown-header">
                                                <h3 class="digim-filter-dropdown-title">Filters</h3>
                                                <a href="#" class="digim-filter-clear-all" data-clear-filters>Clear all</a>
                                            </div>
                                            <div class="digim-filter-dropdown-body">
                                                <?php
                                                $price_slider_min = 0;
                                                $price_slider_max = 10000;
                                                $price_slider_step = 50;
                                                $slider_min_val = $filter_price_min !== '' ? max($price_slider_min, min($price_slider_max, intval($filter_price_min))) : $price_slider_min;
                                                $slider_max_val = $filter_price_max !== '' ? max($price_slider_min, min($price_slider_max, intval($filter_price_max))) : $price_slider_max;
                                                if ($slider_min_val > $slider_max_val) {
                                                    $slider_max_val = $slider_min_val;
                                                }
                                                ?>
                                                <section class="digim-filter-dropdown-section">
                                                    <h4 class="digim-filter-section-title">Price range</h4>
                                                    <div class="digim-filter-price-range-slider-wrap">
                                                        <div class="digim-filter-price-range-labels">
                                                            <span id="digim-price-range-display"><?php echo esc_html('$' . number_format($slider_min_val) . ' – $' . number_format($slider_max_val)); ?></span>
                                                        </div>
                                                        <div class="digim-filter-dual-range">
                                                            <input type="range" id="digim-filter-price-min" name="filter_price_min" class="digim-range-input digim-range-min" min="<?php echo (int) $price_slider_min; ?>" max="<?php echo (int) $price_slider_max; ?>" step="<?php echo (int) $price_slider_step; ?>" value="<?php echo (int) $slider_min_val; ?>" aria-label="Minimum price">
                                                            <input type="range" id="digim-filter-price-max" name="filter_price_max" class="digim-range-input digim-range-max" min="<?php echo (int) $price_slider_min; ?>" max="<?php echo (int) $price_slider_max; ?>" step="<?php echo (int) $price_slider_step; ?>" value="<?php echo (int) $slider_max_val; ?>" aria-label="Maximum price">
                                                        </div>
                                                    </div>
                                                </section>
                                                <section class="digim-filter-dropdown-section">
                                                    <h4 class="digim-filter-section-title">Rooms and beds</h4>
                                                    <div class="digim-filter-rooms-beds">
                                                        <div class="digim-filter-field">
                                                            <label for="digim-filter-bedrooms" class="digim-filter-label-text">Bedrooms</label>
                                                            <select id="digim-filter-bedrooms" name="filter_bedrooms" class="digim-filter-select">
                                                                <option value="">Any</option>
                                                                <?php foreach ($all_bedrooms as $bedroom_count): ?>
                                                                    <option value="<?php echo esc_attr($bedroom_count); ?>" <?php selected($filter_bedrooms, (string)$bedroom_count); ?>><?php echo esc_html($bedroom_count); ?> <?php echo $bedroom_count == 1 ? 'bedroom' : 'bedrooms'; ?></option>
                                                                <?php endforeach; ?>
                                                            </select>
                                                        </div>
                                                        <div class="digim-filter-field">
                                                            <label for="digim-filter-beds" class="digim-filter-label-text">Beds</label>
                                                            <select id="digim-filter-beds" name="filter_beds" class="digim-filter-select">
                                                                <option value="">Any</option>
                                                                <?php foreach ($all_beds as $bed_count): ?>
                                                                    <option value="<?php echo esc_attr($bed_count); ?>" <?php selected($filter_beds, (string)$bed_count); ?>><?php echo esc_html($bed_count); ?> <?php echo $bed_count == 1 ? 'bed' : 'beds'; ?></option>
                                                                <?php endforeach; ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </section>
                                                <?php
                                                if (!empty($all_amenities_for_filter)):
                                                    $amenity_icons = function_exists('digim_get_amenity_icons') ? digim_get_amenity_icons() : [];
                                                    $default_icon_name = function_exists('digim_get_amenity_default_icon') ? digim_get_amenity_default_icon() : 'check-square';
                                                    $amenities_initial_count = 6;
                                                    $has_more_amenities = count($all_amenities_for_filter) > $amenities_initial_count;
                                                ?>
                                                    <section class="digim-filter-dropdown-section digim-filter-amenities-section">
                                                        <h4 class="digim-filter-section-title">Amenities</h4>
                                                        <div class="digim-filter-amenities-list" id="digim-amenities-list">
                                                            <?php
                                                            $idx = 0;
                                                            foreach ($all_amenities_for_filter as $amenity_slug => $amenity_label):
                                                                $icon_name = isset($amenity_icons[$amenity_slug]) ? $amenity_icons[$amenity_slug] : $default_icon_name;
                                                                $is_more = $idx >= $amenities_initial_count;
                                                                $idx++;
                                                            ?>
                                                                <label class="digim-filter-amenity-item<?php echo $is_more ? ' digim-amenity-more' : ''; ?>">
                                                                    <input type="checkbox" name="filter_amenities[]" value="<?php echo esc_attr($amenity_slug); ?>" class="digim-filter-amenity-cb" <?php echo in_array($amenity_slug, $filter_amenities_arr, true) ? ' checked' : ''; ?>>
                                                                    <i class="amenity-icon digim-amenity-icon" data-feather="<?php echo esc_attr($icon_name); ?>" aria-hidden="true"></i>
                                                                    <span class="digim-amenity-label"><?php echo esc_html($amenity_label); ?></span>
                                                                </label>
                                                            <?php endforeach; ?>
                                                        </div>
                                                        <?php if ($has_more_amenities): ?>
                                                            <div class="digim-amenities-toggle-wrap">
                                                                <button type="button" class="digim-amenities-show-more" id="digim-amenities-show-more" aria-expanded="false">
                                                                    <span>Show more</span>
                                                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                                                                        <path d="M6 9l6 6 6-6" />
                                                                    </svg>
                                                                </button>
                                                                <button type="button" class="digim-amenities-show-less" id="digim-amenities-show-less" aria-expanded="true" style="display: none;">
                                                                    <span>Show less</span>
                                                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                                                                        <path d="M18 15l-6-6-6 6" />
                                                                    </svg>
                                                                </button>
                                                            </div>
                                                        <?php endif; ?>
                                                    </section>
                                                <?php endif; ?>
                                            </div>
                                            <footer class="digim-filter-dropdown-footer">
                                                <button type="button" class="digim-filter-show-places" id="digim-filter-show-places">Show places</button>
                                            </footer>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php if ($has_any_filter): ?>
                                <div style="grid-column: 1 / -1; width:fit-content; margin-bottom: 0px; padding: 0 24px; display: flex; align-items: center; gap:0px;">
                                    <span class="digim-filter-label">Filtered:</span>
                                    <span class="digim-filter-badge" id="digim-filter-badge">
                                        <?php
                                        $badge_parts = [];
                                        if ($filter_bedrooms) {
                                            $bedroom_label = intval($filter_bedrooms) == 1 ? 'bedroom' : 'bedrooms';
                                            $badge_parts[] = esc_html($filter_bedrooms) . ' ' . $bedroom_label;
                                        }
                                        if ($filter_beds) {
                                            $bed_label = intval($filter_beds) == 1 ? 'bed' : 'beds';
                                            $badge_parts[] = esc_html($filter_beds) . ' ' . $bed_label;
                                        }
                                        if ($has_price_filter) {
                                            $price_part = '';
                                            if ($filter_price_min !== '' && $filter_price_max !== '') {
                                                $price_part = esc_html__('Price: ', 'digim') . esc_html($filter_price_min) . ' – ' . esc_html($filter_price_max);
                                            } elseif ($filter_price_min !== '') {
                                                $price_part = esc_html__('Price: from ', 'digim') . esc_html($filter_price_min);
                                            } else {
                                                $price_part = esc_html__('Price: up to ', 'digim') . esc_html($filter_price_max);
                                            }
                                            $badge_parts[] = $price_part;
                                        }
                                        if (!empty($filter_amenities_arr) && !empty($all_amenities_for_filter)) {
                                            $amenity_labels = array_intersect_key($all_amenities_for_filter, array_flip($filter_amenities_arr));
                                            if (!empty($amenity_labels)) {
                                                $badge_parts[] = esc_html__('Amenities: ', 'digim') . implode(', ', array_map('esc_html', $amenity_labels));
                                            }
                                        }
                                        echo esc_html(implode(' · ', $badge_parts));
                                        ?>
                                    </span>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php
                        // Fetch pricing from Hospitable Quote API for current page (calendar-driven dates)
                        // IMPORTANT: Always fetch quotes when dates are provided, regardless of availability filtering
                        $digim_quote_map = [];

                        // Ensure we have dates - check globals first, then $_GET
                        if (empty($checkin_date) && !empty($digim_checkin_date)) {
                            $checkin_date = $digim_checkin_date;
                        }
                        if (empty($checkout_date) && !empty($digim_checkout_date)) {
                            $checkout_date = $digim_checkout_date;
                        }

                        // Also check $_GET as fallback
                        if (empty($checkin_date)) {
                            $checkin_date = isset($_GET['checkin']) ? sanitize_text_field($_GET['checkin']) : '';
                        }
                        if (empty($checkout_date)) {
                            $checkout_date = isset($_GET['checkout']) ? sanitize_text_field($_GET['checkout']) : '';
                        }

                        // Fetch quotes if we have dates and properties (skip if already from combined calendar+quote round-trip)
                        if (!empty($checkin_date) && !empty($checkout_date) && !empty($properties_to_show) && is_array($properties_to_show) && empty($GLOBALS['digim_quote_map']) && function_exists('digimanagement_parallel_quote_fetch')) {
                            // Normalize UUIDs to ensure consistent format for matching
                            $quote_uuids = [];
                            foreach ($properties_to_show as $p) {
                                $u = $p['uuid'] ?? $p['id'] ?? '';
                                if (!empty($u)) {
                                    $u_normalized = trim((string) $u);
                                    if ($u_normalized !== '') {
                                        $quote_uuids[] = $u_normalized;
                                    }
                                }
                            }
                            $quote_uuids = array_values(array_unique($quote_uuids));

                            if (!empty($quote_uuids)) {
                                $adults_q = isset($adults) ? (int) $adults : (int) ($_GET['adults'] ?? 1);
                                $children_q = isset($children) ? (int) $children : (int) ($_GET['children'] ?? 0);
                                $infants_q = isset($infants) ? (int) $infants : (int) ($_GET['infants'] ?? 0);
                                $pets_q = isset($pets) ? (int) $pets : (int) ($_GET['pets'] ?? 0);
                                if ($adults_q <= 0) {
                                    $adults_q = 1;
                                }
                                $digim_quote_map = digimanagement_parallel_quote_fetch($quote_uuids, $checkin_date, $checkout_date, $adults_q, $children_q, $infants_q, $pets_q);

                                // Debug: Log quote map for troubleshooting
                                if (empty($digim_quote_map)) {
                                    error_log("DigiM: Quote fetch returned empty map for UUIDs: " . implode(', ', $quote_uuids));
                                } else {
                                    error_log("DigiM: Quote fetch successful. Got quotes for " . count($digim_quote_map) . " properties. UUIDs: " . implode(', ', array_keys($digim_quote_map)));
                                }
                            }
                        }
                        // Use quote map from combined calendar+quote round-trip when set
                        if (!empty($GLOBALS['digim_quote_map']) && is_array($GLOBALS['digim_quote_map'])) {
                            $digim_quote_map = $GLOBALS['digim_quote_map'];
                        }

                        // OPTIMIZATION: Pre-fetch calendar data for all suggested properties in parallel
                        // This prevents sequential API calls inside the loop (major performance bottleneck)
                        $suggested_calendar_cache = [];
                        if (function_exists('curl_multi_init')) {
                            $suggested_properties_needing_calendar = [];
                            foreach ($properties_to_show as $property) {
                                $is_suggestion = !empty($property['_digim_is_suggestion']);
                                $suggested_start = $property['_digim_suggested_start'] ?? '';
                                $uuid_raw = $property['uuid'] ?? $property['id'] ?? '';
                                $uuid = !empty($uuid_raw) ? trim((string) $uuid_raw) : '';
                                $calendar_min_nights = isset($property['_digim_min_nights_required']) ? intval($property['_digim_min_nights_required']) : null;
                                $property_min_nights = $property['minimum_nights'] ?? $property['min_nights'] ?? $property['min_stay'] ?? $property['minimum_stay'] ?? null;

                                // Only fetch if we need calendar data (missing min nights and have suggested start)
                                if ($is_suggestion && $suggested_start && $uuid && empty($calendar_min_nights) && empty($property_min_nights)) {
                                    $suggested_properties_needing_calendar[] = [
                                        'uuid' => $uuid,
                                        'suggested_start' => $suggested_start
                                    ];
                                }
                            }

                            // Fetch all calendars in parallel
                            if (!empty($suggested_properties_needing_calendar)) {
                                $api_base_url = digimanagement_get_api_url();
                                $api_token = digimanagement_get_api_token();
                                $mh = curl_multi_init();
                                $handles = [];

                                foreach ($suggested_properties_needing_calendar as $item) {
                                    try {
                                        $checkin_obj_temp = new DateTimeImmutable($item['suggested_start'], wp_timezone());
                                        $end_date_temp = $checkin_obj_temp->modify('+30 days')->format('Y-m-d');

                                        $query_args = http_build_query([
                                            'start_date' => $item['suggested_start'],
                                            'end_date' => $end_date_temp,
                                        ]);

                                        $url = $api_base_url . "/properties/{$item['uuid']}/calendar?{$query_args}";
                                        $ch = curl_init();
                                        curl_setopt_array($ch, [
                                            CURLOPT_URL => $url,
                                            CURLOPT_RETURNTRANSFER => true,
                                            CURLOPT_HTTPHEADER => [
                                                'Authorization: ' . $api_token,
                                                'Accept: application/json',
                                            ],
                                            CURLOPT_TIMEOUT => 5,
                                            CURLOPT_CONNECTTIMEOUT => 3,
                                        ]);
                                        curl_multi_add_handle($mh, $ch);
                                        $handles[$item['uuid']] = ['ch' => $ch, 'suggested_start' => $item['suggested_start']];
                                    } catch (Exception $e) {
                                        // Skip invalid dates
                                    }
                                }

                                // Execute all requests in parallel
                                if (!empty($handles)) {
                                    do {
                                        $status = curl_multi_exec($mh, $active);
                                        if ($active) {
                                            curl_multi_select($mh, 0.3);
                                        }
                                    } while ($active && $status === CURLM_OK);

                                    // Process responses
                                    foreach ($handles as $uuid => $handle_data) {
                                        $ch = $handle_data['ch'];
                                        $suggested_start = $handle_data['suggested_start'];
                                        $body = curl_multi_getcontent($ch);
                                        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                                        curl_multi_remove_handle($mh, $ch);
                                        curl_close($ch);

                                        if ($http_code === 200 && !empty($body)) {
                                            $calendar_response = json_decode($body, true);
                                            $days = $calendar_response['data']['days'] ?? [];

                                            // Find the check-in day and get its minimum nights
                                            $checkin_day_min_nights = null;
                                            foreach ($days as $day) {
                                                if (isset($day['date']) && $day['date'] === $suggested_start) {
                                                    $checkin_day_min_nights = $day['min_nights']
                                                        ?? $day['minimum_nights']
                                                        ?? $day['min_stay']
                                                        ?? $day['minimum_stay']
                                                        ?? (isset($day['pricing']) && isset($day['pricing']['min_nights']) ? $day['pricing']['min_nights'] : null)
                                                        ?? null;
                                                    if ($checkin_day_min_nights !== null) {
                                                        $checkin_day_min_nights = (int) $checkin_day_min_nights;
                                                    }
                                                    break;
                                                }
                                            }

                                            // Store in cache for use in loop
                                            $suggested_calendar_cache[$uuid] = [
                                                'min_nights' => $checkin_day_min_nights,
                                                'days' => $days
                                            ];
                                        }
                                    }
                                }

                                curl_multi_close($mh);
                            }
                        }
                        ?>
                        <?php foreach ($properties_to_show as $property):
                            $is_suggestion = !empty($property['_digim_is_suggestion']);
                            $min_nights_required = isset($property['_digim_min_nights_required']) ? intval($property['_digim_min_nights_required']) : null;
                            $suggested_start = $property['_digim_suggested_start'] ?? '';
                            $suggested_checkout = $property['_digim_suggested_checkout'] ?? '';
                            $suggested_nights = intval($property['_digim_suggested_nights'] ?? 0);
                            $suggestion_label = '';

                            if ($is_suggestion && $suggested_start) {
                                $start_ts = strtotime($suggested_start);
                                $start_label = $start_ts ? wp_date('M j', $start_ts) : '';

                                // Only show start date, not end date
                                if ($start_label) {
                                    $suggestion_label = sprintf(__('Next available %s', 'digim'), $start_label);
                                }
                            }

                            $original_picture = $property['picture'] ?? '';
                            $high_res_picture = preg_replace('/\?.*/', '', $original_picture);
                            // Normalize UUID to match format used in quote map
                            $uuid_raw = $property['uuid'] ?? $property['id'] ?? '';
                            $uuid = !empty($uuid_raw) ? trim((string) $uuid_raw) : '';
                            $property_slug = digimanagement_create_property_slug(
                                $property['name'] ?? '',
                                $property['address']['city'] ?? ''
                            );
                            $query_params = $_GET;

                            // Remove date_range from URL (it's only for display, we use checkin/checkout)
                            unset($query_params['date_range']);

                            // If this is a suggested property, add checkin date and find actual available checkout date
                            if ($is_suggestion && $suggested_start) {
                                $query_params['checkin'] = $suggested_start;

                                // Calculate requested nights from original search
                                $requested_nights = 0;
                                if (!empty($checkin_date) && !empty($checkout_date)) {
                                    try {
                                        $original_checkin = new DateTimeImmutable($checkin_date, wp_timezone());
                                        $original_checkout = new DateTimeImmutable($checkout_date, wp_timezone());
                                        $requested_nights = max(1, (int) $original_checkin->diff($original_checkout)->days);
                                    } catch (Exception $e) {
                                        $requested_nights = $suggested_nights > 0 ? $suggested_nights : 10;
                                    }
                                } else {
                                    $requested_nights = $suggested_nights > 0 ? $suggested_nights : 10;
                                }

                                // Get minimum nights requirement FIRST - we need this to validate any checkout date
                                $property_min_nights = $property['minimum_nights']
                                    ?? $property['min_nights']
                                    ?? $property['min_stay']
                                    ?? $property['minimum_stay']
                                    ?? null;

                                $calendar_min_nights = isset($property['_digim_min_nights_required']) ? intval($property['_digim_min_nights_required']) : null;

                                // Performance: use only pre-fetched calendar data; never call API inside loop (avoids N requests per search).
                                $checkin_day_min_nights = null;
                                if (empty($calendar_min_nights) && empty($property_min_nights) && !empty($uuid) && !empty($suggested_start) && isset($suggested_calendar_cache[$uuid])) {
                                    $checkin_day_min_nights = $suggested_calendar_cache[$uuid]['min_nights'];
                                }

                                // Use the maximum of all sources (calendar check takes precedence if higher)
                                $required_min_nights = null;
                                $all_min_nights = array_filter([
                                    $checkin_day_min_nights,
                                    $calendar_min_nights,
                                    $property_min_nights
                                ], function ($val) {
                                    return $val !== null && $val > 0;
                                });

                                if (!empty($all_min_nights)) {
                                    $required_min_nights = max($all_min_nights);
                                } else {
                                    // If we still don't have minimum nights, default to 7 (common minimum) instead of 1
                                    // This prevents showing 1-night stays when property requires more
                                    $required_min_nights = 7;
                                }

                                // Find actual available checkout date by checking calendar
                                $actual_checkout = null;

                                // First, try to use suggested_checkout if available and verify it meets minimum nights and is available
                                if (!empty($suggested_checkout)) {
                                    try {
                                        $checkin_obj = new DateTimeImmutable($suggested_start, wp_timezone());
                                        $suggested_checkout_obj = new DateTimeImmutable($suggested_checkout, wp_timezone());
                                        $max_checkout_date = $checkin_obj->modify('+20 days');

                                        // Calculate actual nights for suggested checkout
                                        $suggested_nights = (int) $checkin_obj->diff($suggested_checkout_obj)->days;

                                        // CRITICAL: Check if suggested_checkout meets minimum nights requirement
                                        if ($suggested_nights >= $required_min_nights && $suggested_checkout_obj <= $max_checkout_date) {
                                            // Verify suggested_checkout is available by checking calendar data
                                            if (!empty($uuid) && isset($checkout_blocked_data[$uuid])) {
                                                $calendar_data = $checkout_blocked_data[$uuid];
                                                $unavailable_dates = is_array($calendar_data) && isset($calendar_data['unavailable'])
                                                    ? $calendar_data['unavailable']
                                                    : [];
                                                $blocked_dates = is_array($calendar_data) && isset($calendar_data['checkout_blocked'])
                                                    ? $calendar_data['checkout_blocked']
                                                    : [];

                                                // Check if suggested checkout is available
                                                $suggested_checkout_available = true;
                                                if (
                                                    in_array($suggested_checkout, $unavailable_dates, true) ||
                                                    in_array($suggested_checkout, $blocked_dates, true)
                                                ) {
                                                    $suggested_checkout_available = false;
                                                } else {
                                                    // Verify entire range is available
                                                    $range_check = clone $checkin_obj;
                                                    while ($range_check < $suggested_checkout_obj) {
                                                        $range_date_str = $range_check->format('Y-m-d');
                                                        if (in_array($range_date_str, $unavailable_dates, true)) {
                                                            $suggested_checkout_available = false;
                                                            break;
                                                        }
                                                        $range_check = $range_check->modify('+1 day');
                                                    }
                                                }

                                                // Only use suggested_checkout if it meets minimum nights AND is available
                                                if ($suggested_checkout_available && $suggested_nights >= $required_min_nights) {
                                                    $actual_checkout = $suggested_checkout;
                                                }
                                            } else {
                                                // No calendar data available, but still verify minimum nights
                                                if ($suggested_nights >= $required_min_nights) {
                                                    $actual_checkout = $suggested_checkout;
                                                }
                                            }
                                        }
                                        // If suggested_checkout doesn't meet minimum nights or is beyond 20 days, ignore it
                                    } catch (Exception $e) {
                                        // Invalid dates, will find closest below
                                    }
                                }

                                // If suggested_checkout is not available or not set, find closest available checkout date
                                if (empty($actual_checkout) && !empty($uuid) && isset($checkout_blocked_data[$uuid])) {
                                    $calendar_data = $checkout_blocked_data[$uuid];
                                    $unavailable_dates = is_array($calendar_data) && isset($calendar_data['unavailable'])
                                        ? $calendar_data['unavailable']
                                        : [];
                                    $blocked_dates = is_array($calendar_data) && isset($calendar_data['checkout_blocked'])
                                        ? $calendar_data['checkout_blocked']
                                        : [];

                                    try {
                                        $checkin_obj = new DateTimeImmutable($suggested_start, wp_timezone());

                                        // Use the required_min_nights we already calculated above
                                        // CRITICAL: Start checking from suggested_start + required_min_nights
                                        // This ensures we only consider checkout dates that meet the minimum nights requirement
                                        $candidate_checkout = $checkin_obj->modify("+{$required_min_nights} days");
                                        $max_checkout_date = $checkin_obj->modify('+20 days');

                                        // Find the CLOSEST available checkout date by checking from minimum nights forward
                                        while ($candidate_checkout <= $max_checkout_date) {
                                            $candidate_date = $candidate_checkout->format('Y-m-d');

                                            // Calculate actual nights for this candidate
                                            $actual_nights = (int) $checkin_obj->diff($candidate_checkout)->days;

                                            // CRITICAL: Verify this checkout date meets minimum nights requirement
                                            // Since we start from minimum nights, this should always be true, but double-check
                                            if ($actual_nights < $required_min_nights) {
                                                // Skip this date - doesn't meet minimum nights
                                                $candidate_checkout = $candidate_checkout->modify('+1 day');
                                                continue;
                                            }

                                            // Check if this checkout date is available
                                            if (
                                                !in_array($candidate_date, $unavailable_dates, true) &&
                                                !in_array($candidate_date, $blocked_dates, true)
                                            ) {
                                                // Verify entire range is available
                                                $range_available = true;
                                                $range_check = clone $checkin_obj;

                                                while ($range_check < $candidate_checkout) {
                                                    $range_date_str = $range_check->format('Y-m-d');

                                                    // Check if date is unavailable
                                                    if (in_array($range_date_str, $unavailable_dates, true)) {
                                                        $range_available = false;
                                                        break;
                                                    }

                                                    $range_check = $range_check->modify('+1 day');
                                                }

                                                // Final verification: ensure actual nights meets minimum nights requirement
                                                if ($range_available && $actual_nights >= $required_min_nights) {
                                                    // Found closest available checkout date that meets minimum nights - stop immediately
                                                    $actual_checkout = $candidate_date;
                                                    break;
                                                }
                                            }

                                            // Move to next day to find closest available
                                            $candidate_checkout = $candidate_checkout->modify('+1 day');
                                        }
                                    } catch (Exception $e) {
                                        // Error in date calculation
                                    }
                                }

                                // If no available checkout found within 20 days, skip this property
                                if (empty($actual_checkout)) {
                                    continue; // Don't show property - no available checkout within 20 days
                                }

                                $query_params['checkout'] = $actual_checkout;
                            }

                            // Check if this property has a checkout-blocked date and suggestion
                            // Update URL with suggested checkout (for both checkout-blocked and minimum nights)
                            // But first verify the suggested checkout is actually available
                            $checkout_blocked_info = null;
                            if (!empty($uuid) && isset($checkout_blocked_suggestions[$uuid])) {
                                $checkout_blocked_info = $checkout_blocked_suggestions[$uuid];

                                // Verify suggested checkout is available
                                if (!empty($checkout_blocked_info['suggested_checkout'])) {
                                    $suggested_checkout = $checkout_blocked_info['suggested_checkout'];

                                    // Check if suggested checkout is in unavailable dates
                                    if (isset($checkout_blocked_data[$uuid])) {
                                        $calendar_data = $checkout_blocked_data[$uuid];
                                        $unavailable_dates = is_array($calendar_data) && isset($calendar_data['unavailable'])
                                            ? $calendar_data['unavailable']
                                            : [];

                                        // If suggested checkout is unavailable, don't use it - skip this property
                                        if (in_array($suggested_checkout, $unavailable_dates, true)) {
                                            continue; // Skip property - suggested checkout is unavailable
                                        }

                                        // Also verify the entire range is available
                                        if (!empty($checkin_date)) {
                                            try {
                                                $checkin_obj = new DateTimeImmutable($checkin_date, wp_timezone());
                                                $suggested_checkout_obj = new DateTimeImmutable($suggested_checkout, wp_timezone());
                                                $range_available = true;
                                                $range_check = clone $checkin_obj;

                                                while ($range_check < $suggested_checkout_obj) {
                                                    $range_date_str = $range_check->format('Y-m-d');
                                                    if (in_array($range_date_str, $unavailable_dates, true)) {
                                                        $range_available = false;
                                                        break;
                                                    }
                                                    $range_check = $range_check->modify('+1 day');
                                                }

                                                if (!$range_available) {
                                                    continue; // Skip property - range is not available
                                                }
                                            } catch (Exception $e) {
                                                // Invalid dates, skip this property
                                                continue;
                                            }
                                        }
                                    }

                                    // Update checkout date in query params to use suggested checkout
                                    $query_params['checkout'] = $suggested_checkout;
                                }
                            }

                            $query_string = http_build_query($query_params);
                            $property_url = site_url('/property/' . esc_attr($property_slug) . '/') . ($query_string ? '?' . $query_string : '');
                            $show_capacity = apply_filters('digim_show_capacity_grid', $show_capacity_setting['row'], $property);
                            $show_capacity_guests = apply_filters('digim_show_capacity_guests', $show_capacity_setting['guests'], $property);
                            $show_capacity_bedrooms = apply_filters('digim_show_capacity_bedrooms', $show_capacity_setting['bedrooms'], $property);
                            $show_capacity_beds = apply_filters('digim_show_capacity_beds', $show_capacity_setting['beds'], $property);
                            $show_capacity_bathrooms = apply_filters('digim_show_capacity_bathrooms', $show_capacity_setting['bathrooms'], $property);

                            $gallery_images = [];
                            $seen_urls = []; // Track existing URLs to avoid duplicates

                            // Priority 1: Use images already present on the property payload (no extra requests)
                            if (!empty($property['images']) && is_array($property['images'])) {
                                foreach ($property['images'] as $img) {
                                    $url = '';
                                    if (is_array($img)) {
                                        // Prefer url (medium-res) for crisp card gallery at ~260–300px
                                        $url = $img['url'] ?? $img['original_url'] ?? $img['thumbnail_url'] ?? '';
                                        if (!$url && isset($img[0]) && is_string($img[0])) {
                                            $url = $img[0];
                                        }
                                    } elseif (is_string($img)) {
                                        $url = $img;
                                    }
                                    if ($url && !in_array($url, $seen_urls, true)) {
                                        $gallery_images[] = $url;
                                        $seen_urls[] = $url;
                                        if (count($gallery_images) >= 3) {
                                            break;
                                        }
                                    }
                                }
                            }

                            // Priority 2: Use batched images if available (from parallel fetch)
                            if (empty($gallery_images) && !empty($uuid) && isset($fetched_images[$uuid]) && is_array($fetched_images[$uuid])) {
                                foreach ($fetched_images[$uuid] as $url) {
                                    if ($url && !in_array($url, $seen_urls, true)) {
                                        $gallery_images[] = $url;
                                        $seen_urls[] = $url;
                                        if (count($gallery_images) >= 3) {
                                            break;
                                        }
                                    }
                                }
                            }

                            // Priority 3: Fallback to high_res_picture if no images found
                            if (empty($gallery_images) && !empty($high_res_picture)) {
                                $gallery_images[] = $high_res_picture;
                            }
                            $gallery_count = count($gallery_images);

                            $rating_value = null;
                            $rating_source_keys = ['average_rating', 'rating', 'overall_rating', 'review_rating'];
                            foreach ($rating_source_keys as $rating_key) {
                                if (isset($property[$rating_key]) && is_numeric($property[$rating_key])) {
                                    $rating_value = round(floatval($property[$rating_key]), 2);
                                    break;
                                }
                                if (isset($property['reviews'][$rating_key]) && is_numeric($property['reviews'][$rating_key])) {
                                    $rating_value = round(floatval($property['reviews'][$rating_key]), 2);
                                    break;
                                }
                            }

                            $reviews_count = null;
                            $review_count_keys = ['reviews_count', 'review_count', 'total_reviews', 'count'];
                            foreach ($review_count_keys as $review_key) {
                                if (isset($property[$review_key]) && is_numeric($property[$review_key])) {
                                    $reviews_count = intval($property[$review_key]);
                                    break;
                                }
                                if (isset($property['reviews'][$review_key]) && is_numeric($property['reviews'][$review_key])) {
                                    $reviews_count = intval($property['reviews'][$review_key]);
                                    break;
                                }
                            }
                        ?>
                            <?php
                            // Only show badges if property is available (not a suggestion)
                            // If property is unavailable, it will show as suggestion badge instead
                            $is_property_available = !$is_suggestion;

                            // Get checkout_blocked_info if it exists (for badge display)
                            // If minimum nights required but no valid suggestion found, skip this property
                            $checkout_blocked_info = null;
                            if (!empty($uuid) && isset($checkout_blocked_suggestions[$uuid])) {
                                $checkout_blocked_info = $checkout_blocked_suggestions[$uuid];
                            } elseif (!empty($checkin_date) && !empty($checkout_date)) {
                                // Check if minimum nights requirement is not met and we don't have a suggestion
                                try {
                                    $checkin_obj = new DateTimeImmutable($checkin_date, wp_timezone());
                                    $checkout_obj = new DateTimeImmutable($checkout_date, wp_timezone());
                                    $requested_nights = $checkin_obj->diff($checkout_obj)->days;
                                } catch (Exception $e) {
                                    // Invalid dates, skip this property
                                    continue;
                                }

                                $property_min_nights = $property['minimum_nights']
                                    ?? $property['min_nights']
                                    ?? $property['min_stay']
                                    ?? $property['minimum_stay']
                                    ?? null;

                                $calendar_min_nights = isset($property['_digim_min_nights_required']) ? intval($property['_digim_min_nights_required']) : null;

                                $final_min_nights = null;
                                if ($calendar_min_nights !== null && $property_min_nights !== null) {
                                    $final_min_nights = max((int)$calendar_min_nights, (int)$property_min_nights);
                                } elseif ($calendar_min_nights !== null) {
                                    $final_min_nights = (int)$calendar_min_nights;
                                } elseif ($property_min_nights !== null) {
                                    $final_min_nights = (int)$property_min_nights;
                                }

                                // If minimum nights not met and no valid suggestion found, skip this property
                                if ($final_min_nights !== null && $final_min_nights > 0 && $requested_nights < $final_min_nights) {
                                    continue; // Skip property - no available date found within +20 days
                                }
                            }

                            // Calculate requested nights and check minimum nights requirement
                            $requested_nights = 0;
                            $actual_min_nights_required = null;
                            $show_min_nights_badge = false;

                            if ($is_property_available && !empty($checkin_date) && !empty($checkout_date)) {
                                try {
                                    $checkin_obj = new DateTimeImmutable($checkin_date, wp_timezone());
                                    $checkout_obj = new DateTimeImmutable($checkout_date, wp_timezone());
                                    $requested_nights = $checkin_obj->diff($checkout_obj)->days;
                                } catch (Exception $e) {
                                    // Invalid dates, skip calculation
                                    $requested_nights = 0;
                                }

                                // Check property minimum nights requirement
                                $property_min_nights = $property['minimum_nights']
                                    ?? $property['min_nights']
                                    ?? $property['min_stay']
                                    ?? $property['minimum_stay']
                                    ?? null;

                                // Also check from _digim_min_nights_required (from calendar check)
                                $calendar_min_nights = isset($property['_digim_min_nights_required']) ? intval($property['_digim_min_nights_required']) : null;

                                // Use the maximum of calendar and property minimum nights
                                if ($calendar_min_nights !== null && $property_min_nights !== null) {
                                    $actual_min_nights_required = max((int)$calendar_min_nights, (int)$property_min_nights);
                                } elseif ($calendar_min_nights !== null) {
                                    $actual_min_nights_required = (int)$calendar_min_nights;
                                } elseif ($property_min_nights !== null) {
                                    $actual_min_nights_required = (int)$property_min_nights;
                                }

                                // Only show min nights badge if requested nights don't meet requirement
                                // Don't check availability of calculated dates - just show the badge
                                if ($actual_min_nights_required && $actual_min_nights_required > 0 && $requested_nights < $actual_min_nights_required) {
                                    $show_min_nights_badge = true;
                                }
                            }

                            $card_classes = [$card_style];
                            if ($is_suggestion) {
                                $card_classes[] = 'digim-card-suggested';
                            } elseif ($show_min_nights_badge) {
                                $card_classes[] = 'digim-card-min-nights';
                            } elseif ($checkout_blocked_info) {
                                $card_classes[] = 'digim-card-checkout-blocked';
                            }

                            // Prepare checkout-blocked badge message
                            // Show for both checkout-blocked and minimum nights (both suggest a new checkout date)
                            $checkout_blocked_label = '';
                            $show_checkout_blocked_badge = false;
                            if ($is_property_available && $checkout_blocked_info) {
                                $has_suggested_checkout = !empty($checkout_blocked_info['suggested_checkout']);

                                if ($has_suggested_checkout) {
                                    $blocked_date_obj = new DateTimeImmutable($checkout_blocked_info['blocked_date'], wp_timezone());
                                    $suggested_date_obj = new DateTimeImmutable($checkout_blocked_info['suggested_checkout'], wp_timezone());

                                    // Format: "16 Jul" (day + capitalized month, no year)
                                    $blocked_date_formatted = $blocked_date_obj->format('j M');
                                    $suggested_date_formatted = $suggested_date_obj->format('j M');

                                    $checkout_blocked_label = sprintf(
                                        __('%s checkout not available. Please try %s.', 'digim'),
                                        $blocked_date_formatted,
                                        $suggested_date_formatted
                                    );
                                    $show_checkout_blocked_badge = true;
                                }
                            }
                            ?>
                            <?php
                            // Determine if this property has checkout-blocked suggestions (not fully available)
                            $has_checkout_blocked = !empty($checkout_blocked_info) && !empty($checkout_blocked_info['suggested_checkout']);
                            $is_fully_available = !$has_checkout_blocked;
                            ?>
                            <?php
                            $card_data_price = '';
                            if (!empty($checkin_date) && !empty($checkout_date) && !empty($uuid)) {
                                $uuid_norm = trim((string) $uuid);
                                if (isset($digim_quote_map[$uuid_norm]) && is_array($digim_quote_map[$uuid_norm])) {
                                    $q = $digim_quote_map[$uuid_norm];
                                    $total_bt_card = isset($q['total']) ? (float) $q['total'] : 0;
                                    if ($total_bt_card <= 0 && isset($q['subtotal'])) {
                                        $total_bt_card = (float) $q['subtotal'];
                                    }
                                    if ($total_bt_card > 0) {
                                        $card_data_price = (string) $total_bt_card;
                                    }
                                }
                            }
                            $prop_amenities = $property['amenities'] ?? [];
                            $card_amenity_slugs = array_map(function ($a) {
                                return function_exists('digim_normalize_amenity') ? digim_normalize_amenity($a) : '';
                            }, is_array($prop_amenities) ? $prop_amenities : []);
                            $card_data_amenities = implode(',', array_filter($card_amenity_slugs));
                            ?>
                            <a href="<?php echo esc_url($property_url); ?>"
                                target="_blank" rel="noopener"
                                class="digimanagement-card <?php echo esc_attr(implode(' ', $card_classes)); ?>"
                                data-available="<?php echo $is_fully_available ? 'true' : 'false'; ?>"
                                data-bedrooms="<?php echo esc_attr($property['capacity']['bedrooms'] ?? '0'); ?>"
                                data-beds="<?php echo esc_attr($property['capacity']['beds'] ?? '0'); ?>"
                                data-price="<?php echo esc_attr($card_data_price); ?>"
                                data-amenities="<?php echo esc_attr($card_data_amenities); ?>"
                                data-property-uuid="<?php echo esc_attr($uuid); ?>">
                                <?php if ($gallery_count > 0): ?>
                                    <div class="digim-card-media" data-digim-gallery>
                                        <?php if ($is_suggestion && $suggestion_label): ?>
                                            <span class="digim-suggestion-badge">
                                                <span class="suggestion-dot" aria-hidden="true"></span>
                                                <?php echo esc_html($suggestion_label); ?>
                                            </span>
                                        <?php else: ?>
                                            <?php if ($show_checkout_blocked_badge && $checkout_blocked_label): ?>
                                                <span class="digim-checkout-blocked-badge">
                                                    <span class="checkout-blocked-dot" aria-hidden="true"></span>
                                                    <?php echo esc_html($checkout_blocked_label); ?>
                                                </span>
                                            <?php endif; ?>
                                            <?php if ($show_min_nights_badge && $actual_min_nights_required && $actual_min_nights_required > 0): ?>
                                                <span class="digim-min-nights-badge" <?php echo ($show_checkout_blocked_badge && $checkout_blocked_label) ? 'style="top: 48px;"' : ''; ?>>
                                                    <span class="min-nights-dot" aria-hidden="true"></span>
                                                    <?php echo esc_html(sprintf(__('Min. %d night%s required', 'digim'), $actual_min_nights_required, $actual_min_nights_required > 1 ? 's' : '')); ?>
                                                </span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <div class="digim-card-gallery" data-digim-gallery-track>
                                            <?php foreach ($gallery_images as $index => $image_url): ?>
                                                <div class="digim-card-slide <?php echo $index === 0 ? 'is-active' : ''; ?>" data-digim-gallery-slide="<?php echo esc_attr($index); ?>">
                                                    <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($property['name'] ?? 'Property image'); ?>" <?php echo $index > 0 ? 'loading="lazy" ' : ''; ?>decoding="async" />
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                        <?php if ($gallery_count > 1): ?>
                                            <button class="digim-gallery-nav previous" type="button" aria-label="<?php echo esc_attr__('View previous image', 'digim'); ?>" data-digim-gallery-prev>
                                                <span aria-hidden="true">&lsaquo;</span>
                                            </button>
                                            <button class="digim-gallery-nav next" type="button" aria-label="<?php echo esc_attr__('View next image', 'digim'); ?>" data-digim-gallery-next>
                                                <span aria-hidden="true">&rsaquo;</span>
                                            </button>
                                            <div class="digim-gallery-indicators" role="tablist">
                                                <?php foreach ($gallery_images as $index => $image_url): ?>
                                                    <button type="button" class="digim-gallery-dot <?php echo $index === 0 ? 'is-active' : ''; ?>" aria-label="<?php echo esc_attr(sprintf(__('Show image %d', 'digim'), $index + 1)); ?>" data-digim-gallery-dot="<?php echo esc_attr($index); ?>"></button>
                                                <?php endforeach; ?>
                                            </div>
                                            <!-- <span class="digim-gallery-counter" aria-live="polite">
                                                <span class="current-index">1</span>
                                                <span class="separator">/</span>
                                                <span class="total-count"><?php echo esc_html($gallery_count); ?></span>
                                            </span> -->
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                                <div class="digim-card-content">
                                    <div class="digim-card-header">
                                        <h3 class="digim-title"><?php echo esc_html($property['name'] ?? 'Untitled'); ?></h3>
                                        <?php if ($rating_value !== null): ?>
                                            <div class="digim-rating">
                                                <span class="rating-icon" aria-hidden="true">★</span>
                                                <span class="rating-value"><?php echo esc_html($rating_value); ?></span>
                                                <?php if ($reviews_count !== null): ?>
                                                    <span class="rating-count">(<?php echo esc_html($reviews_count); ?>)</span>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>

                                    <?php
                                    $city = trim((string) ($property['address']['city'] ?? ''));
                                    $state = trim((string) ($property['address']['state'] ?? $property['address']['state_name'] ?? ''));
                                    $country = trim((string) ($property['address']['country'] ?? ''));
                                    $country_code = trim((string) ($property['address']['country_code'] ?? ''));

                                    $short_address_parts = array_filter([
                                        $city,
                                        $state,
                                        $country ?: $country_code,
                                    ], static function ($part) {
                                        return $part !== '';
                                    });

                                    $short_address_parts = array_values(array_unique($short_address_parts));
                                    $short_address = implode(', ', $short_address_parts);

                                    if ($short_address === '' && !empty($property['address']['display'])) {
                                        $short_address = $property['address']['display'];
                                    }
                                    ?>
                                    <?php if ($short_address !== ''): ?>
                                        <p class="digim-address">
                                            <?php echo esc_html($short_address); ?>
                                        </p>
                                    <?php endif; ?>

                                    <?php if ($show_capacity): ?>
                                        <?php
                                        $capacity_parts = [];
                                        if ($show_capacity_bedrooms && ($property['capacity']['bedrooms'] ?? '')) {
                                            $n = intval($property['capacity']['bedrooms']);
                                            $capacity_parts[] = $n . ' ' . ($n === 1 ? 'bedroom' : 'bedrooms');
                                        }
                                        if ($show_capacity_beds && ($property['capacity']['beds'] ?? '')) {
                                            $n = intval($property['capacity']['beds']);
                                            $capacity_parts[] = $n . ' ' . ($n === 1 ? 'bed' : 'beds');
                                        }
                                        if ($show_capacity_bathrooms && ($property['capacity']['bathrooms'] ?? '')) {
                                            $n = intval($property['capacity']['bathrooms']);
                                            $capacity_parts[] = $n . ' ' . ($n === 1 ? 'bath' : 'baths');
                                        }
                                        $capacity_text = implode(' · ', $capacity_parts);
                                        if ($capacity_text !== ''):
                                        ?>
                                        <p class="digim-capacity-inline"><?php echo esc_html($capacity_text); ?></p>
                                        <?php endif; ?>
                                    <?php endif; ?>

                                    <?php
                                    // Pricing section: exact Hospitable Quote API (matches iframe widget). Airbnb-style, no gradients.
                                    // Always show pricing section (even if empty) for consistent card layout

                                    // Normalize UUID for lookup (ensure it matches the format used in quote map)
                                    $uuid_normalized = !empty($uuid) ? trim((string) $uuid) : '';

                                    // Try multiple UUID formats for lookup
                                    $quote = null;
                                    if (!empty($uuid_normalized) && isset($digim_quote_map) && is_array($digim_quote_map) && !empty($digim_quote_map)) {
                                        // Try exact match first
                                        if (isset($digim_quote_map[$uuid_normalized])) {
                                            $quote = $digim_quote_map[$uuid_normalized];
                                        } else {
                                            // If not found, try case-insensitive search and also try with/without trimming
                                            foreach ($digim_quote_map as $map_uuid => $map_quote) {
                                                $map_uuid_normalized = trim((string) $map_uuid);
                                                if (
                                                    $map_uuid_normalized === $uuid_normalized ||
                                                    strcasecmp($map_uuid_normalized, $uuid_normalized) === 0 ||
                                                    $map_uuid === $uuid_normalized ||
                                                    strcasecmp($map_uuid, $uuid_normalized) === 0
                                                ) {
                                                    $quote = $map_quote;
                                                    break;
                                                }
                                            }
                                        }
                                    }

                                    // Calculate total_before_tax - check multiple possible fields
                                    $total_bt = 0;
                                    if ($quote && is_array($quote)) {
                                        $total_bt = isset($quote['total_before_tax']) ? (float) $quote['total_before_tax'] : 0;
                                        if ($total_bt <= 0 && isset($quote['total'])) {
                                            $total_bt = (float) $quote['total'];
                                        }
                                        // If still 0, try calculating from subtotal + fees - discounts
                                        if ($total_bt <= 0) {
                                            $subtotal = isset($quote['subtotal']) ? (float) $quote['subtotal'] : 0;
                                            $cleaning_fee = isset($quote['cleaning_fee']) ? (float) $quote['cleaning_fee'] : 0;
                                            $service_fee = isset($quote['service_fee']) ? (float) $quote['service_fee'] : 0;
                                            $discount_sum = 0;
                                            if (isset($quote['discounts']) && is_array($quote['discounts'])) {
                                                foreach ($quote['discounts'] as $d) {
                                                    $discount_sum += isset($d['amount']) ? (float) $d['amount'] : 0;
                                                }
                                            }
                                            $total_bt = $subtotal - $discount_sum + $cleaning_fee + $service_fee;
                                        }
                                    }

                                    $show_pricing = $quote && is_array($quote) && $total_bt > 0;

                                    // Debug: Log if quote is missing (remove in production)
                                    if (!empty($checkin_date) && !empty($checkout_date) && !$quote && !empty($uuid_normalized)) {
                                        $available_keys = isset($digim_quote_map) && is_array($digim_quote_map) ? array_keys($digim_quote_map) : [];
                                        error_log("DigiM: No quote found for UUID: $uuid_normalized. Available UUIDs in map: " . implode(', ', $available_keys));
                                        error_log("DigiM: Quote map exists: " . (isset($digim_quote_map) ? 'yes' : 'no') . ", is_array: " . (is_array($digim_quote_map ?? null) ? 'yes' : 'no') . ", count: " . count($digim_quote_map ?? []));
                                    }
                                    ?>
                                    <div class="digim-pricing-section">
                                        <?php if ($show_pricing): ?>
                                            <?php
                                            $symbol = $quote['symbol'] ?? '$';
                                            $nights = (int) ($quote['nights'] ?? 1);
                                            $checkin_fmt = '';
                                            $checkout_fmt = '';
                                            if (!empty($quote['checkin']) && !empty($quote['checkout'])) {
                                                $ci = DateTimeImmutable::createFromFormat('Y-m-d', $quote['checkin'], wp_timezone());
                                                $co = DateTimeImmutable::createFromFormat('Y-m-d', $quote['checkout'], wp_timezone());
                                                if ($ci && $co) {
                                                    $checkin_fmt = $ci->format('M j');
                                                    $checkout_fmt = $co->format('M j');
                                                }
                                            }
                                            $date_range = ($checkin_fmt && $checkout_fmt) ? $checkin_fmt . ' – ' . $checkout_fmt : '';
                                            $discounts = isset($quote['discounts']) && is_array($quote['discounts']) ? $quote['discounts'] : [];
                                            $discount_sum = 0.0;
                                            foreach ($discounts as $d) {
                                                $discount_sum += (float) (isset($d['amount']) ? $d['amount'] : 0);
                                            }
                                            $has_discount = $discount_sum > 0;
                                            $original_price = $has_discount ? $total_bt + $discount_sum : $total_bt;
                                            ?>
                                            <?php if ($date_range !== ''): ?>
                                                <p class="digim-price-date-range"><?php echo esc_html($date_range); ?></p>
                                            <?php endif; ?>
                                            <p class="digim-price-display">
                                                <?php if ($has_discount): ?>
                                                    <span class="digim-price-original"><?php echo esc_html($symbol . number_format($original_price, 0)); ?></span>
                                                <?php endif; ?>
                                                <span class="digim-price-total"><?php echo esc_html($symbol . number_format($total_bt, 0)); ?></span> <span class="digim-price-for-nights"><?php echo esc_html(sprintf(__('for %d night%s', 'digim'), $nights, $nights !== 1 ? 's' : '')); ?></span>
                                            </p>
                                            <?php foreach ($discounts as $d): ?>
                                                <?php
                                                $d_name = isset($d['name']) ? (string) $d['name'] : '';
                                                $d_amt = isset($d['amount']) ? (float) $d['amount'] : 0;
                                                if ($d_name === '') {
                                                    continue;
                                                }
                                                ?>
                                                <p class="digim-price-discount-line"><?php echo esc_html($d_name . ' -' . $symbol . number_format($d_amt, 2)); ?></p>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <div class="digim-no-available-message<?php echo (!empty($properties_to_show) ? '' : ' show'); ?>" id="digim-no-available-message">
                    <h3><?php echo esc_html__('No available properties found', 'digim'); ?></h3>
                    <p><?php echo esc_html__('There are no properties available for the exact dates you selected. Please check the availability from the suggested checkout dates shown on the properties above, or try adjusting your search dates.', 'digim'); ?></p>
                </div>

                <?php if ($total_pages > 1): ?>
                    <?php
                    $q = $_GET;
                    // Remove date_range from pagination URLs (it's only for display, we use checkin/checkout)
                    unset($q['date_range']);

                    $brezy_letter_svgs = [
                        'B' => <<<'SVG'
<svg class="brezy-letter-icon" viewBox="0 0 80 127.41" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
    <path fill="currentColor" d="M63.6,64.01c-.77-5.91-5.08-10.82-10.15-13.69-2.99-1.7-5.52-2.73-8.79-3.72-1.99-.6-3.03-.93-7.34-1.38,5.35-2.68,4.6-2.22,5.94-3,5.61-3.28,12.02-7.87,11.31-15.18-.42-4.33-3.42-6.37-7.05-8.61-.58-.36-1.22-.61-1.85-.85-.93-.36-1.88-.68-2.84-.98-1.13-.35-2.26-.68-3.41-.99-1.14-.31-2.36-.61-3.56-.87-1.31-.29-2.63-.57-3.97-.74-1.44-.19-2.88-.24-4.33-.31-1.46-.07-2.93-.11-4.39-.14-.57,0-1.15-.01-1.72-.01-2.92,0-4.55-.08-7.63,0H3.21v74.85c7.37-.92,14.76.91,22.17,1.39,9.63.63,19.65-1.15,27.74-6.58,3.15-2.11,5.99-4.79,7.96-8.08,1.97-3.3,3.02-7.25,2.51-11.09v-.02ZM11.77,15.87c0-.11,0-.94,0-.94h1.79c1.09,0,2.19-.05,3.28-.06,1.1-.02,2.16-.02,3.23,0,1.08.01,2.09.05,3.13.11.68.04,1.35.08,2.03.14,2.24.19,4.19.58,6.52,1.14,2.42.48,4.58,1.31,6.48,2.5,1.9,1.19,3.45,2.24,4.66,4.31,1.21,1.99,1.78,2.83,1.78,5.85s-.98,6.3-2.52,8.97c-1.11,1.93-2.84,3.61-4.97,4.08-2.21.49-4.73-.05-6.98-.11-2.41-.06-4.82-.02-7.2.38-4.39.73-8.73,3.05-11.24,6.96V15.87h.02ZM11.75,45.39c-.03-1.07,0-2.15,0-3.22v3.22h0ZM52.43,78.68c-1.38,2.3-3.11,4.21-5.18,5.72-2.07,1.43-4.32,2.46-6.74,3.1-2.42.71-4.62,1.07-6.61,1.07s-4.06-.16-6.22-.48-4.27-.76-6.34-1.31c-1.99-.64-3.85-1.35-5.57-2.14-1.64-.87-2.98-1.82-4.02-2.86v-30.42c.53-.94,1.2-1.8,2.01-2.6.94-.92,2.06-1.7,3.37-2.35,1.31-.72,2.77-1.19,4.4-1.4,2.49-.31,4.58-.3,6.27.05,2.66.42,5.2,1.16,7.79,1.89,4.88,1.37,9.42,3.43,13.01,7.21,1.22,1.29,2.29,2.72,3.17,4.28,1.9,3.18,2.85,7.14,2.85,11.91,0,3.26-.73,6.04-2.2,8.34h.01Z"/>
</svg>
SVG,
                        'r' => <<<'SVG'
<svg class="brezy-letter-icon" viewBox="70 0 70 127.41" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
    <path fill="currentColor" d="M77.28,23.44v6.67c1.73-2.54,3.84-4.56,6.35-6.07,2.5-1.51,5.4-2.26,8.68-2.26,2.54,0,5.11.22,7.58.83,1.06.26,2.11.61,3.11,1.04,1.06.46,1.85,1.13,2.63,2.02,1.64,1.88,2.8,4.54,2.26,7.11-.11.53-.3,1.04-.55,1.51-.58,1.06-1.5,1.88-2.47,2.58-1.48,1.08-3.14,1.99-4.89,2.51-1,.3-1.83.35-2.99.43-.53.04-1.07.03-1.07.03.52-.59,1.85-2.03,2.22-2.72,1.08-2.02.65-4.54-.16-6.69-.67-1.79-1.6-3.52-2.93-4.86-1.33-1.35-2.95-1.8-4.82-1.88-2.46-.11-4.89.76-6.8,2.35-2.18,1.81-4.09,3.98-5.52,6.47-.24.43-.47.87-.58,1.35-.08.37-.08.76-.08,1.14v46.69c0,1.75-.02,6.43-.02,6.43h-8.53V26.75l8.55-3.3h.03Z"/>
</svg>
SVG,
                        'e' => <<<'SVG'
<svg class="brezy-letter-icon" viewBox="120 0 85 127.41" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
    <path fill="currentColor" d="M173.27,74.55c-1.25,2.06-2.79,4.05-4.62,5.96-1.83,1.83-3.91,3.45-6.24,4.88-2.25,1.43-4.74,2.54-7.49,3.33-2.74.87-5.74,1.31-8.99,1.31-4.16,0-8.32-.79-12.48-2.38-4.08-1.59-7.82-3.89-11.23-6.91-3.33-3.02-6.03-6.75-8.11-11.19-2.08-4.53-3.12-9.73-3.12-15.6,0-5.24.96-9.85,2.87-13.82,1.91-4.05,4.41-7.38,7.49-10,3.16-2.7,6.7-4.72,10.61-6.07,3.91-1.43,7.86-2.14,11.86-2.14s7.36.44,10.61,1.31c3.33.79,6.2,1.99,8.61,3.57,2.41,1.59,4.29,3.53,5.62,5.84,1.33,2.22,2,4.8,2,7.74,0,1.91-.37,3.77-1.12,5.6-1.65,4.02-3.95,6.98-7.92,8.33-5,1.7-10.44.78-15.34-.82-5.04-1.64-10.46-4.3-15.82-2.51-.08.03-.15.05-.23.08-2.29.82-4.3,2.46-5.61,4.57-1.21,1.95-3.35,5-2.73,7.31.57,2.11,1.52,3.95,2.68,5.76.26.41.52.81.78,1.22,2.08,3.18,4.49,5.91,7.24,8.22,2.75,2.3,5.7,4.09,8.86,5.36,3.24,1.19,6.41,1.79,9.49,1.79,4.74,0,8.99-1.03,12.73-3.1,3.75-2.14,9.61-7.62,9.61-7.62h0v-.02ZM142.26,24.9c-3.09.04-6.21.57-8.88,1.56-9.15,3.38-13.32,11.7-13.95,21.13-.07,1.12-.11,2.25-.11,3.37,0,1.03.04,2.06.12,3.1.08,1,.25,3.94,1.06,4.47,1.22-2.02,2.1-4.1,3.68-5.9,1.29-1.47,2.8-2.75,4.53-3.59,4.73-2.29,10.49-1.16,15.43-.33,1,.17,1.96.34,2.87.51,1.23.23,2.48.37,3.73.37.43,0,.84,0,1.26-.04h.12c10.17-.68,14.34-12.97,6.24-19.39-2.57-2.03-5.78-3.45-8.91-4.35-2.22-.63-4.7-.92-7.21-.89h0l.02-.02Z"/>
</svg>
SVG,
                        'z' => <<<'SVG'
<svg class="brezy-letter-icon" viewBox="180 0 80 127.41" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
    <path fill="currentColor" d="M188.45,86.68v.15l34.49-.2c2.37-.16,4.86-1.21,6.1-3.42.67-1.19.9-2.59.95-3.96.09-2.71-.51-5.42-1.72-7.82-.41-.82-1.01-1.52-1.43-2.32.25-.14,1.05.54,1.27.67.49.3.98.61,1.45.93,2.03,1.39,3.63,3.2,4.31,5.66.5,1.81.48,3.76.03,5.58-.41,1.66-1.18,3.26-2.39,4.43-.82.79-1.83,1.36-2.91,1.67-1.14.33-2.34.28-3.52.28h-26.66c-6.88,0-13.75-.08-20.62-.08v-1.19l46.11-62.05h.04l.11-.15-34.64.2c-2.37.16-4.86,1.21-6.1,3.42-.67,1.19-.9,2.59-.95,3.97-.09,2.7.51,5.42,1.73,7.82.41.82,1.01,1.52,1.43,2.32-.25.14-1.05-.53-1.27-.67-.49-.3-.98-.61-1.46-.94-2.03-1.39-3.63-3.2-4.31-5.66-.5-1.81-.48-3.76-.03-5.58.41-1.66,1.18-3.26,2.4-4.43.82-.79,1.83-1.37,2.91-1.68,1.14-.33,2.34-.28,3.52-.28h26.65c6.88,0,13.75.08,20.62.08v1.19l-46.12,62.05h.01Z"/>
</svg>
SVG,
                        'y' => <<<'SVG'
<svg class="brezy-letter-icon" viewBox="240 0 60 127.41" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
    <path fill="currentColor" d="M249.45,23.29l2.85,7.67,3.01,8.44,16.84,46.45c3.88-6.43,7.34-12.59,10.36-18.46,1.3-2.46,2.55-5,3.76-7.62,1.3-2.7,2.42-5.28,3.37-7.74,1.04-2.54,1.86-4.88,2.46-7.03.6-2.22.91-4.17.91-5.83,0-2.94-.78-5.36-2.33-7.27-2.03-2.49-7.08-4.07-9.89-2.15-1.29.89-1.95,2.48-2.25,4.05-.81,4.37.72,9.09,3.02,12.74-.28-.44-1.44-.89-1.88-1.24-.64-.52-1.16-1.1-1.69-1.74-1.21-1.48-2.36-3.02-3.23-4.74-1.13-2.22-1.79-4.78-1.4-7.26.33-2.09,1.38-4.01,2.78-5.56,6.12-6.78,18.38-4.72,20.31,4.89.19.97.3,1.95.33,2.93.1,3.12-.56,6.28-1.53,9.26-1.37,4.2-3.13,8.42-4.98,12.41-1.99,4.29-4.23,8.73-6.74,13.34-2.42,4.53-4.88,8.97-7.38,13.34-2.76,4.82-5.83,9.42-8.48,14.28-2.35,4.32-4.98,8.57-8.54,12.01-3.3,3.19-8.38,5.14-12.92,5.41-2.63.16-5.29-.24-7.75-1.22-1.85-.74-3.57-1.92-4.79-3.54-3.75-4.97-2.84-12.47.62-17.33-.4.56.13,3.05.2,3.75.12,1.1.3,2.2.64,3.26.64,2.02,1.8,3.9,3.58,5.11,2.43,1.65,5.49,2.11,8.36,2.35,8.2.71,15.73-4.84,17.16-12.94.85-4.81-.95-7.6-2.73-12.33-.3-.79-.6-1.58-.9-2.38-1.47-3.89-3.24-8.57-5.31-14.05-1.21-3.33-2.59-6.95-4.14-10.84-1.47-3.97-2.81-7.74-4.02-11.31-1.55-4.13-5.08-14.85-6.46-18.98l8.77-.11v-.02Z"/>
</svg>
SVG,
                    ];

                    $render_brezy_letter = static function (string $letter) use ($brezy_letter_svgs): string {
                        return $brezy_letter_svgs[$letter] ?? '';
                    };

                    $render_arrow = static function (string $direction): string {
                        if ($direction === 'left') {
                            return <<<'SVG'
<svg class="pagination-arrow-icon" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
    <path fill="currentColor" d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"/>
</svg>
SVG;
                        } else {
                            return <<<'SVG'
<svg class="pagination-arrow-icon" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
    <path fill="currentColor" d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"/>
</svg>
SVG;
                        }
                    };

                    $build_page_url = static function (int $page) use ($q): string {
                        $q['property_page'] = $page;
                        return '?' . http_build_query($q);
                    };

                    $chunk_size = 3;

                    $left_start = $current_page - ($chunk_size - 1);
                    $left_end = $current_page;

                    if ($left_start < 1) {
                        $left_end += 1 - $left_start;
                        $left_start = 1;
                    }

                    $left_end = min($left_end, $total_pages);
                    $left_start = max(1, $left_end - $chunk_size + 1);
                    $left_pages = range($left_start, $left_end);

                    $right_start = max($left_end + 1, $total_pages - $chunk_size + 1);
                    $right_pages = $right_start <= $total_pages ? range($right_start, $total_pages) : [];

                    if (!empty($right_pages) && $right_start <= $left_end) {
                        $pagination_pages = range($left_start, $total_pages);
                    } else {
                        $pagination_pages = array_merge($left_pages, $right_pages);
                    }

                    $pagination_pages = array_values(array_unique($pagination_pages));
                    ?>
                    <div class="digimanagement-pagination brezy-pagination" role="navigation" aria-label="<?php echo esc_attr__('Brezy pagination', 'digim'); ?>">
                        <?php
                        $first_disabled = $current_page <= 1;
                        $last_disabled = $current_page >= $total_pages;
                        ?>
                        <?php if ($first_disabled): ?>
                            <span class="pagination-arrow pagination-arrow-left is-disabled" aria-hidden="true">
                                <?php echo $render_arrow('left'); ?>
                            </span>
                            <span class="pagination-letter letter-B is-disabled" aria-hidden="true">
                                <?php echo $render_brezy_letter('B'); ?>
                            </span>
                            <span class="pagination-letter letter-r is-disabled" aria-hidden="true">
                                <?php echo $render_brezy_letter('r'); ?>
                            </span>
                        <?php else: ?>
                            <a class="pagination-arrow pagination-arrow-left" href="<?php echo esc_url($build_page_url($current_page - 1)); ?>" aria-label="<?php echo esc_attr__('Go to previous page', 'digim'); ?>">
                                <?php echo $render_arrow('left'); ?>
                            </a>
                            <a class="pagination-letter letter-B" href="<?php echo esc_url($build_page_url(1)); ?>" aria-label="<?php echo esc_attr__('Go to first page', 'digim'); ?>">
                                <?php echo $render_brezy_letter('B'); ?>
                            </a>
                            <a class="pagination-letter letter-r" href="<?php echo esc_url($build_page_url($current_page - 1)); ?>" aria-label="<?php echo esc_attr__('Go to previous page', 'digim'); ?>">
                                <?php echo $render_brezy_letter('r'); ?>
                            </a>
                        <?php endif; ?>

                        <?php
                        $previous_page = null;
                        foreach ($pagination_pages as $page) :
                            if ($previous_page !== null && $page - $previous_page > 1) :
                        ?>
                                <span class="pagination-dots" aria-hidden="true">…</span>
                            <?php
                            endif;
                            $is_active = ($page === (int) $current_page);
                            if ($is_active) :
                            ?>
                                <span class="pagination-letter letter-e is-active" aria-current="page" aria-label="<?php echo esc_attr(sprintf(__('Current page %d', 'digim'), $page)); ?>">
                                    <?php echo $render_brezy_letter('e'); ?>
                                </span>
                            <?php else : ?>
                                <a class="pagination-letter letter-e" href="<?php echo esc_url($build_page_url($page)); ?>" aria-label="<?php echo esc_attr(sprintf(__('Go to page %d', 'digim'), $page)); ?>">
                                    <?php echo $render_brezy_letter('e'); ?>
                                </a>
                        <?php
                            endif;
                            $previous_page = $page;
                        endforeach;
                        ?>

                        <?php if ($last_disabled): ?>
                            <span class="pagination-letter letter-z is-disabled" aria-hidden="true">
                                <?php echo $render_brezy_letter('z'); ?>
                            </span>
                            <span class="pagination-letter letter-y is-disabled" aria-hidden="true">
                                <?php echo $render_brezy_letter('y'); ?>
                            </span>
                            <span class="pagination-arrow pagination-arrow-right is-disabled" aria-hidden="true">
                                <?php echo $render_arrow('right'); ?>
                            </span>
                        <?php else: ?>
                            <a class="pagination-letter letter-z" href="<?php echo esc_url($build_page_url($current_page + 1)); ?>" aria-label="<?php echo esc_attr__('Go to next page', 'digim'); ?>">
                                <?php echo $render_brezy_letter('z'); ?>
                            </a>
                            <a class="pagination-letter letter-y" href="<?php echo esc_url($build_page_url($total_pages)); ?>" aria-label="<?php echo esc_attr__('Go to last page', 'digim'); ?>">
                                <?php echo $render_brezy_letter('y'); ?>
                            </a>
                            <a class="pagination-arrow pagination-arrow-right" href="<?php echo esc_url($build_page_url($current_page + 1)); ?>" aria-label="<?php echo esc_attr__('Go to next page', 'digim'); ?>">
                                <?php echo $render_arrow('right'); ?>
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <?php if ($show_map): ?>
                <div class="digimanagement-map">
                    <?php if (is_admin() && isset($_GET['page']) && $_GET['page'] === 'DigiM-style'): ?>
                        <img src="<?php echo plugin_dir_url(__FILE__) . '../assets/mappreview.png'; ?>" alt="Map Preview" style="width: 100%; border-radius: 10px;" />
                    <?php else: ?>
                        <div id="digim-map" style="width: 100%; height: 400px; border-radius: 10px;"></div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php
    // Calculate hover and active colors if function exists
    $pc = $primary_color ?? '#0073aa';
    $primary_color_hover = function_exists('digim_darken_color') ? digim_darken_color($pc, 10) : '#005a87';
    $primary_color_active = function_exists('digim_darken_color') ? digim_darken_color($pc, 20) : '#004a6f';
    ?>
    <style>
        :root {
            --digim-primary-color: <?php echo $pc; ?>;
            --digim-primary-color-hover: <?php echo $primary_color_hover; ?>;
            --digim-primary-color-active: <?php echo $primary_color_active; ?>;
        }

        .digim-main .digimanagement-search .search-buttons button.search-button {
            background: var(--digim-primary-color) !important;
            background-color: var(--digim-primary-color) !important;
            color: #fff !important;
        }

        .digim-main .digimanagement-search .search-buttons button.search-button:hover,
        .digim-main .digimanagement-search .search-buttons button.search-button:focus {
            background: var(--digim-primary-color-hover) !important;
            background-color: var(--digim-primary-color-hover) !important;
            color: #fff !important;
        }

        .digim-main .digimanagement-search .search-buttons button.search-button:active {
            background: var(--digim-primary-color-active) !important;
            background-color: var(--digim-primary-color-active) !important;
            color: #fff !important;
        }

        .digimanagement-pagination .letter-e.is-active {
            background: var(--digim-primary-color) !important;
            border-color: var(--digim-primary-color) !important;
            color: #fff !important;
        }

        .digimanagement-card.highlight {
            outline: 2px solid var(--digim-primary-color) !important;
            box-shadow: 0 0 5px var(--digim-primary-color) !important;
        }

        /* Filters Wrapper */
        .digim-filters-wrapper {
            position: relative;
            grid-column: 1 / -1;
            justify-content: space-between;
            display: flex;
            gap: 24px;
        }

        button.digim-filter-toggle-btn {
            display: flex;
            align-items: center;
        }

        .digim-filter-toggle-btn {
            display: inline-flex;
            align-items: center;
            padding: 10px 16px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background: #fff;
            font-size: 14px;
            font-weight: 500;
            color: #333;
            cursor: pointer;
            transition: all 0.2s;
        }

        .digim-filter-toggle-btn:hover {
            border-color: #999;
        }

        .digim-filter-reset-btn {
            display: inline-flex;
            align-items: center;
            padding: 10px 16px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background: #fff;
            font-size: 14px;
            font-weight: 500;
            color: #666;
            cursor: pointer;
            transition: all 0.2s;
            margin-left: 8px;
        }

        .digim-filter-label {
            font-size: 14px;
            font-weight: 500;
            color: #666;
        }

        .digim-filter-badge {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 20px;
            height: 20px;
            padding: 0 8px;
            margin-left: 8px;
            background: var(--digim-primary-color, #0073aa);
            color: #fff;
            border-radius: 10px;
            font-size: 11px;
            font-weight: 600;
            white-space: nowrap;
            max-width: 200px;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        /* Advanced filter dropdown (digim-filter-dropdown active) */
        .digim-filter-dropdown {
            position: absolute;
            top: 100%;
            right: 0;
            margin-top: 8px;
            width: 500px;
            max-width: calc(100vw - 24px);
            max-height: 70vh;
            background: #fff;
            border: 1px solid #ebebeb;
            border-radius: 12px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
            z-index: 1000;
            display: none;
            overflow: hidden;
            flex-direction: column;

            @media screen and (max-width: 600px) {
                width: max-content;
            }
        }

        .digim-filter-dropdown.active {
            display: flex !important;
        }

        .digim-filter-dropdown-inner {
            display: flex;
            flex-direction: column;
            max-height: 80vh;
            overflow: hidden;

            @media screen and (max-width: 600px) {
                max-height: 50dvh;
            }
        }

        .digim-filter-dropdown-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 16px 20px;
            border-bottom: 1px solid #ebebeb;
            flex-shrink: 0;
        }

        .digim-filter-dropdown-title {
            margin: 0;
            font-size: 16px;
            font-weight: 600;
            color: #222;
        }

        .digim-filter-clear-all {
            font-size: 14px;
            font-weight: 500;
            color: #222;
            text-decoration: underline;
        }

        .digim-filter-clear-all:hover {
            color: #000;
        }

        .digim-filter-dropdown-body {
            padding: 16px 20px;
            overflow-y: auto;
            flex: 1;
        }

        .digim-filter-dropdown-section {
            padding: 16px 0;
            border-bottom: 1px solid #ebebeb;
        }

        .digim-filter-dropdown-section:last-child {
            border-bottom: none;
        }

        .digim-filter-section-title {
            margin: 0 0 16px 0;
            font-size: 16px;
            font-weight: 600;
            color: #222;
        }

        /* Price range dual-handle slider */
        .digim-filter-price-range-slider-wrap {
            padding: 8px 0;
        }

        .digim-filter-price-range-labels {
            margin-bottom: 12px;
            font-size: 15px;
            font-weight: 600;
            color: #222;
        }

        .digim-filter-dual-range {
            position: relative;
            height: 24px;
        }

        .digim-range-input {
            position: absolute;
            width: 100%;
            height: 24px;
            margin: 0;
            padding: 0;
            pointer-events: none;
            -webkit-appearance: none;
            appearance: none;
            background: transparent;
        }

        .digim-range-input::-webkit-slider-runnable-track {
            height: 6px;
            background: #ebebeb;
            border-radius: 3px;
        }

        .digim-range-input::-webkit-slider-thumb {
            -webkit-appearance: none;
            appearance: none;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: #222;
            cursor: pointer;
            margin-top: -7px;
            pointer-events: auto;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
        }

        .digim-range-input::-moz-range-track {
            height: 6px;
            background: #ebebeb;
            border-radius: 3px;
        }

        .digim-range-input::-moz-range-thumb {
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: #222;
            cursor: pointer;
            border: none;
            pointer-events: auto;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
        }

        .digim-range-max {
            pointer-events: none;
        }

        .digim-range-max::-webkit-slider-thumb {
            pointer-events: auto;
        }

        .digim-range-max::-moz-range-thumb {
            pointer-events: auto;
        }

        .digim-filter-rooms-beds {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }

        .digim-filter-field .digim-filter-label-text {
            display: block;
            font-size: 14px;
            font-weight: 500;
            color: #333;
            margin-bottom: 8px;
        }

        .digim-filter-select {
            width: 100%;
            padding: 12px 14px;
            border: 1px solid #b0b0b0;
            border-radius: 8px;
            font-size: 14px;
            background: #fff;
            cursor: pointer;
            color: #222;
            height: 44px;
            line-height: normal;
        }

        .digim-filter-select:focus {
            outline: none;
            border-color: #222;
        }

        .digim-filter-amenities-list {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
        }

        .digim-filter-amenity-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 14px;
            font-size: 14px;
            font-weight: 500;
            color: #222;
            cursor: pointer;
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            transition: border-color 0.15s, background 0.15s;
        }

        .digim-filter-amenity-item:hover {
            border-color: #b0b0b0;
        }

        .digim-filter-amenity-item input {
            position: absolute;
            opacity: 0;
            pointer-events: none;
            width: 0;
            height: 0;
        }

        .digim-filter-amenity-item:has(input:checked) {
            border-color: #222;
            background: #f7f7f7;
        }

        .digim-amenity-icon {
            flex-shrink: 0;
            width: 20px;
            height: 20px;
            color: #222;
            stroke: currentColor;
        }

        .digim-amenity-icon.feather,
        .digim-filter-amenity-item .feather {
            width: 20px;
            height: 20px;
        }

        .digim-amenity-label {
            flex: 1;
            min-width: 0;
        }

        .digim-amenity-more {
            display: none;
        }

        .digim-filter-amenities-list.show-more .digim-amenity-more {
            display: flex;
        }

        .digim-amenities-toggle-wrap {
            margin-top: 12px;
            text-align: center;
        }

        .digim-amenities-show-more,
        .digim-amenities-show-less {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 4px;
            padding: 0;
            border: none;
            background: none;
            font-size: 14px;
            font-weight: 500;
            color: #222;
            text-decoration: underline;
            cursor: pointer;
        }

        .digim-amenities-show-more:hover,
        .digim-amenities-show-less:hover {
            color: #000;
        }

        .digim-amenities-show-more svg,
        .digim-amenities-show-less svg {
            flex-shrink: 0;
        }

        .digim-filter-dropdown-footer {
            padding: 12px 20px;
            border-top: 1px solid #ebebeb;
            flex-shrink: 0;
        }

        .digim-filter-show-places {
            padding: 8px 12px !important;
            background: #264c54 !important;
            border-radius: 5px !important;
            color: #fff !important;
            margin: 0 auto !important;
            display: flex !important;
        }

        .digim-filter-label-text {
            display: block;
            font-size: 14px;
            font-weight: 500;
            color: #333;
            margin-bottom: 8px;
        }

        /* Listing Title */
        .digim-listing-title {
            margin-bottom: 0;
            padding: 0 10px;
        }

        .digim-listing-title-text {
            font-size: 20px;
            font-weight: 600;
            color: #222;
            margin: 0;
            line-height: 1.4;
        }

        /* No listings found (empty search) */
        .digim-no-listings-message {
            grid-column: 1 / -1;
            padding: 40px 24px;
            text-align: center;
            background: #f8f9fa;
            border-radius: 12px;
            margin: 24px 0;
            display: block;
        }
        .digim-no-listings-message h3 {
            font-size: 18px;
            font-weight: 600;
            color: #222;
            margin: 0 0 12px 0;
        }
        .digim-no-listings-message p {
            font-size: 14px;
            color: #666;
            margin: 0;
            line-height: 1.6;
        }

        /* No available properties message */
        .digim-no-available-message {
            display: none;
            padding: 32px 24px;
            text-align: center;
            background: #f8f9fa;
            border-radius: 12px;
            margin-top: 24px;
        }

        .digim-no-available-message.show {
            display: block;
        }

        .digim-no-available-message h3 {
            font-size: 18px;
            font-weight: 600;
            color: #222;
            margin: 0 0 12px 0;
        }

        .digim-no-available-message p {
            font-size: 14px;
            color: #666;
            margin: 0;
            line-height: 1.6;
        }
    </style>

    <script>
        (function() {
            const filterWrapper = document.querySelector('.digim-filters-wrapper');
            const filterToggleBtn = document.querySelector('.digim-filter-toggle-btn');
            const filterDropdown = document.getElementById('digim-filter-dropdown');
            const filterToggle = document.getElementById('digim-show-available-only');
            const propertiesGrid = document.getElementById('digim-properties-grid');
            const noAvailableMessage = document.getElementById('digim-no-available-message');
            const bedroomsFilter = document.getElementById('digim-filter-bedrooms');
            const bedsFilter = document.getElementById('digim-filter-beds');

            function closeFilterDropdown() {
                if (filterDropdown) {
                    filterDropdown.classList.remove('active');
                    filterDropdown.setAttribute('aria-hidden', 'true');
                    if (filterToggleBtn) filterToggleBtn.setAttribute('aria-expanded', 'false');
                }
            }

            if (filterToggleBtn && filterDropdown) {
                filterToggleBtn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    const isActive = filterDropdown.classList.contains('active');
                    if (isActive) {
                        closeFilterDropdown();
                    } else {
                        filterDropdown.classList.add('active');
                        filterDropdown.setAttribute('aria-hidden', 'false');
                        filterToggleBtn.setAttribute('aria-expanded', 'true');
                    }
                });
            }
            document.addEventListener('click', function(e) {
                const activeDropdown = document.querySelector('.digim-filter-dropdown.active');
                if (!activeDropdown) return;
                const wrapper = activeDropdown.closest('.digim-filters-wrapper');
                if (!wrapper) return;
                const toggleBtn = wrapper.querySelector('.digim-filter-toggle-btn');
                const isInsideDropdown = activeDropdown.contains(e.target);
                const isOnToggleBtn = toggleBtn && toggleBtn.contains(e.target);
                const isOnResetBtn = e.target.closest('.digim-filter-reset-btn');
                if (!isInsideDropdown && !isOnToggleBtn && !isOnResetBtn) {
                    activeDropdown.classList.remove('active');
                    activeDropdown.setAttribute('aria-hidden', 'true');
                    if (toggleBtn) toggleBtn.setAttribute('aria-expanded', 'false');
                }
            });

            var PRICE_SLIDER_MIN = 0,
                PRICE_SLIDER_MAX = 10000;

            function updatePriceRangeDisplay() {
                const priceMinEl = document.getElementById('digim-filter-price-min');
                const priceMaxEl = document.getElementById('digim-filter-price-max');
                const displayEl = document.getElementById('digim-price-range-display');
                if (!priceMinEl || !priceMaxEl || !displayEl) return;
                let minV = parseInt(priceMinEl.value, 10) || PRICE_SLIDER_MIN;
                let maxV = parseInt(priceMaxEl.value, 10) || PRICE_SLIDER_MAX;
                if (minV > maxV) {
                    maxV = minV;
                    priceMaxEl.value = maxV;
                }
                if (maxV < minV) {
                    minV = maxV;
                    priceMinEl.value = minV;
                }
                displayEl.textContent = '$' + minV.toLocaleString() + ' – $' + maxV.toLocaleString();
            }

            function setupPriceRangeSliders() {
                const priceMinEl = document.getElementById('digim-filter-price-min');
                const priceMaxEl = document.getElementById('digim-filter-price-max');
                if (!priceMinEl || !priceMaxEl) return;

                function onPriceInput() {
                    let minV = parseInt(priceMinEl.value, 10);
                    let maxV = parseInt(priceMaxEl.value, 10);
                    if (minV > maxV) {
                        priceMaxEl.value = minV;
                    }
                    if (maxV < minV) {
                        priceMinEl.value = maxV;
                    }
                    updatePriceRangeDisplay();
                }
                priceMinEl.addEventListener('input', onPriceInput);
                priceMinEl.addEventListener('change', onPriceInput);
                priceMaxEl.addEventListener('input', onPriceInput);
                priceMaxEl.addEventListener('change', onPriceInput);
                updatePriceRangeDisplay();
            }

            function setupAmenitiesShowMore() {
                const list = document.getElementById('digim-amenities-list');
                const showMoreBtn = document.getElementById('digim-amenities-show-more');
                const showLessBtn = document.getElementById('digim-amenities-show-less');
                if (!list) return;
                if (showMoreBtn && !showMoreBtn._digimAmenitiesBound) {
                    showMoreBtn._digimAmenitiesBound = true;
                    showMoreBtn.addEventListener('click', function() {
                        list.classList.add('show-more');
                        showMoreBtn.style.display = 'none';
                        if (showLessBtn) showLessBtn.style.display = 'inline-flex';
                        showMoreBtn.setAttribute('aria-expanded', 'true');
                        if (showLessBtn) showLessBtn.setAttribute('aria-expanded', 'false');
                    });
                }
                if (showLessBtn && !showLessBtn._digimAmenitiesBound) {
                    showLessBtn._digimAmenitiesBound = true;
                    showLessBtn.addEventListener('click', function() {
                        list.classList.remove('show-more');
                        showMoreBtn.style.display = 'inline-flex';
                        showLessBtn.style.display = 'none';
                        showMoreBtn.setAttribute('aria-expanded', 'false');
                        showLessBtn.setAttribute('aria-expanded', 'true');
                    });
                }
            }
            setupPriceRangeSliders();
            setupAmenitiesShowMore();

            document.querySelector('[data-clear-filters]')?.addEventListener('click', function(e) {
                e.preventDefault();
                const priceMin = document.getElementById('digim-filter-price-min');
                const priceMax = document.getElementById('digim-filter-price-max');
                if (priceMin) priceMin.value = PRICE_SLIDER_MIN;
                if (priceMax) priceMax.value = PRICE_SLIDER_MAX;
                if (bedroomsFilter) bedroomsFilter.value = '';
                if (bedsFilter) bedsFilter.value = '';
                document.querySelectorAll('.digim-filter-amenity-cb').forEach(function(cb) {
                    cb.checked = false;
                });
                updatePriceRangeDisplay();
                closeFilterDropdown();
                updateFilterBadge('', '', '', '', []);
                loadFilteredListings(false, '', '', '', '', []);
            });

            // Filter only when "Show places" is clicked — no change listeners on bedrooms/beds/price/amenities.
            document.getElementById('digim-filter-show-places')?.addEventListener('click', function() {
                const bedrooms = bedroomsFilter ? bedroomsFilter.value : '';
                const beds = bedsFilter ? bedsFilter.value : '';
                const priceMinEl = document.getElementById('digim-filter-price-min');
                const priceMaxEl = document.getElementById('digim-filter-price-max');
                const priceMin = priceMinEl ? priceMinEl.value.trim() : '';
                const priceMax = priceMaxEl ? priceMaxEl.value.trim() : '';
                const amenities = [];
                document.querySelectorAll('.digim-filter-amenity-cb:checked').forEach(function(cb) {
                    if (cb.value) amenities.push(cb.value);
                });
                closeFilterDropdown();
                const showAvailableOnly = filterToggle ? filterToggle.checked : false;
                loadFilteredListings(showAvailableOnly, bedrooms, beds, priceMin, priceMax, amenities);
            });

            // Reset filters button (outside modal)
            const resetBtn = document.querySelector('.digim-filter-reset-btn');
            if (resetBtn) {
                resetBtn.addEventListener('click', function() {
                    const priceMin = document.getElementById('digim-filter-price-min');
                    const priceMax = document.getElementById('digim-filter-price-max');
                    if (priceMin) priceMin.value = PRICE_SLIDER_MIN;
                    if (priceMax) priceMax.value = PRICE_SLIDER_MAX;
                    if (bedroomsFilter) bedroomsFilter.value = '';
                    if (bedsFilter) bedsFilter.value = '';
                    document.querySelectorAll('.digim-filter-amenity-cb').forEach(function(cb) {
                        cb.checked = false;
                    });
                    updatePriceRangeDisplay();
                    updateFilterBadge('', '', '', '', []);
                    loadFilteredListings(false, '', '', '', '', []);
                });
            }

            if (!propertiesGrid) return;

            // Performance: debounce (300–500ms) so only one AJAX request per calendar/filter change.
            let filterDebounceTimer = null;

            function debounceFilter(callback, delay = 400) {
                if (filterDebounceTimer) clearTimeout(filterDebounceTimer);
                filterDebounceTimer = setTimeout(callback, delay);
            }

            function getCurrentFilterValues() {
                const bedrooms = document.getElementById('digim-filter-bedrooms');
                const beds = document.getElementById('digim-filter-beds');
                const priceMinEl = document.getElementById('digim-filter-price-min');
                const priceMaxEl = document.getElementById('digim-filter-price-max');
                const amenities = [];
                document.querySelectorAll('.digim-filter-amenity-cb:checked').forEach(function(cb) {
                    if (cb.value) amenities.push(cb.value);
                });
                return {
                    bedrooms: bedrooms ? bedrooms.value : '',
                    beds: beds ? beds.value : '',
                    priceMin: priceMinEl ? priceMinEl.value.trim() : '',
                    priceMax: priceMaxEl ? priceMaxEl.value.trim() : '',
                    amenities: amenities
                };
            }

            function updateFilterBadge(bedrooms, beds, priceMin, priceMax, amenities) {
                const badge = document.getElementById('digim-filter-badge');
                const filtersWrapper = document.querySelector('.digim-filters-wrapper');
                if (!filtersWrapper) return;
                let badgeContainer = filtersWrapper.closest('[style*="grid-column: 1 / -1"]')?.nextElementSibling;
                if (!badgeContainer || !badgeContainer.getAttribute('style')?.includes('grid-column: 1 / -1')) {
                    badgeContainer = document.createElement('div');
                    badgeContainer.style.cssText = 'grid-column: 1 / -1; width:fit-content; margin-bottom: 0px; padding: 0 24px; display: flex; align-items: center; gap:0px;';
                    const filtersParent = filtersWrapper.closest('[style*="grid-column: 1 / -1"]');
                    if (filtersParent && filtersParent.parentNode) {
                        filtersParent.parentNode.insertBefore(badgeContainer, filtersParent.nextSibling);
                    }
                }
                var hasMeaningfulPrice = (priceMin && parseInt(priceMin, 10) > 0) || (priceMax && parseInt(priceMax, 10) < 10000);
                const badgeParts = [];
                if (bedrooms) {
                    badgeParts.push(bedrooms + ' ' + (parseInt(bedrooms, 10) === 1 ? 'bedroom' : 'bedrooms'));
                }
                if (beds) {
                    badgeParts.push(beds + ' ' + (parseInt(beds, 10) === 1 ? 'bed' : 'beds'));
                }
                if (hasMeaningfulPrice) {
                    if (priceMin && priceMax) {
                        badgeParts.push('Price: ' + priceMin + ' – ' + priceMax);
                    } else if (priceMin) {
                        badgeParts.push('Price: from ' + priceMin);
                    } else {
                        badgeParts.push('Price: up to ' + priceMax);
                    }
                }
                var amenityLabels = [];
                document.querySelectorAll('.digim-filter-amenity-cb:checked').forEach(function(cb) {
                    var labelEl = cb.closest('.digim-filter-amenity-item')?.querySelector('.digim-amenity-label');
                    if (labelEl && labelEl.textContent) {
                        amenityLabels.push(labelEl.textContent.trim());
                    }
                });
                if (amenityLabels.length > 0) {
                    badgeParts.push('Amenities: ' + amenityLabels.join(', '));
                }
                if (badgeParts.length > 0) {
                    let filterLabel = badgeContainer.querySelector('.digim-filter-label');
                    if (!filterLabel) {
                        filterLabel = document.createElement('span');
                        filterLabel.className = 'digim-filter-label';
                        filterLabel.textContent = 'Filtered:';
                        badgeContainer.appendChild(filterLabel);
                    }
                    const text = badgeParts.join(' · ');
                    if (!badge) {
                        const newBadge = document.createElement('span');
                        newBadge.className = 'digim-filter-badge';
                        newBadge.id = 'digim-filter-badge';
                        newBadge.textContent = text;
                        badgeContainer.appendChild(newBadge);
                    } else {
                        badge.textContent = text;
                    }
                } else {
                    if (badge) badge.remove();
                    const filterLabel = badgeContainer.querySelector('.digim-filter-label');
                    if (filterLabel) filterLabel.remove();
                    if (badgeContainer && badgeContainer.children.length === 0) {
                        badgeContainer.remove();
                    }
                }
            }

            function updateURL(showAvailableOnly, bedrooms, beds, priceMin, priceMax, amenities, updateHistory = true) {
                const url = new URL(window.location.href);
                if (showAvailableOnly) url.searchParams.set('show_available_only', '1');
                else url.searchParams.delete('show_available_only');
                if (bedrooms) url.searchParams.set('filter_bedrooms', bedrooms);
                else url.searchParams.delete('filter_bedrooms');
                if (beds) url.searchParams.set('filter_beds', beds);
                else url.searchParams.delete('filter_beds');
                if (priceMin) url.searchParams.set('filter_price_min', priceMin);
                else url.searchParams.delete('filter_price_min');
                if (priceMax) url.searchParams.set('filter_price_max', priceMax);
                else url.searchParams.delete('filter_price_max');
                if (amenities && amenities.length) {
                    url.searchParams.delete('filter_amenities');
                    amenities.forEach(function(a) {
                        url.searchParams.append('filter_amenities[]', a);
                    });
                } else {
                    url.searchParams.delete('filter_amenities');
                }
                url.searchParams.set('property_page', '1');
                if (updateHistory) window.history.pushState({}, '', url.toString());
                return url;
            }

            function applyPriceFilter(priceMin, priceMax) {
                if (!propertiesGrid) return;
                const min = priceMin !== '' && priceMin != null ? parseFloat(priceMin) : null;
                const max = priceMax !== '' && priceMax != null ? parseFloat(priceMax) : null;
                if (min == null && max == null) return;
                if (min === 0 && max >= 10000) return;
                propertiesGrid.querySelectorAll('.digimanagement-card').forEach(function(card) {
                    const p = card.getAttribute('data-price');
                    const val = p ? parseFloat(p) : null;
                    if (val == null) {
                        card.style.display = (min != null || max != null) ? 'none' : '';
                        return;
                    }
                    const inRange = (min == null || val >= min) && (max == null || val <= max);
                    card.style.display = inRange ? '' : 'none';
                });
            }

            let filterInFlight = false;

            function loadFilteredListings(showAvailableOnly, bedrooms, beds, priceMin, priceMax, amenities) {
                priceMin = priceMin || '';
                priceMax = priceMax || '';
                amenities = amenities || [];
                if (filterInFlight) return;
                filterInFlight = true;
                // Show loading state
                const gridContainer = propertiesGrid ? propertiesGrid.closest('.dm-property') : null;
                if (gridContainer) {
                    gridContainer.style.opacity = '0.6';
                    gridContainer.style.pointerEvents = 'none';
                    gridContainer.style.position = 'relative';

                    // Add loading overlay with more informative message
                    let loadingOverlay = gridContainer.querySelector('.digim-loading-overlay');
                    if (!loadingOverlay) {
                        loadingOverlay = document.createElement('div');
                        loadingOverlay.className = 'digim-loading-overlay';
                        loadingOverlay.style.cssText = 'position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(255,255,255,0.9); display: flex; flex-direction: column; align-items: center; justify-content: flex-start; z-index: 1000; padding-top: 10rem;';
                        gridContainer.appendChild(loadingOverlay);
                    }

                    // Update loading message based on filter type
                    let loadingMessage = 'Loading properties...';
                    if (showAvailableOnly) {
                        // Enhanced message for date range searches
                        const checkinInput = document.querySelector('.checkin-hidden');
                        const checkoutInput = document.querySelector('.checkout-hidden');
                        const hasDateRange = checkinInput && checkoutInput && checkinInput.value && checkoutInput.value;

                        if (hasDateRange) {
                            loadingMessage = '<div style="display: flex; flex-direction: column; align-items: center;"><div style="width: 40px; height: 40px; border: 3px solid #f3f3f3; border-top: 3px solid #0073aa; border-radius: 50%; animation: spin 1s linear infinite; margin-bottom: 16px;"></div><div style="font-size: 16px; color: #333; font-weight: 500;">Checking availability for your dates...</div><small style="color: #999; margin-top: 8px; display: block;">Searching through properties</small><small style="color: #666; margin-top: 4px; display: block; font-size: 12px;">⚡ Optimized for faster results</small></div>';
                        } else {
                            loadingMessage = '<div style="display: flex; flex-direction: column; align-items: center;"><div style="width: 40px; height: 40px; border: 3px solid #f3f3f3; border-top: 3px solid #0073aa; border-radius: 50%; animation: spin 1s linear infinite; margin-bottom: 16px;"></div><div style="font-size: 16px; color: #333; font-weight: 500;">Checking availability...</div><small style="color: #999; margin-top: 8px; display: block;">This may take a few moments</small></div>';
                        }
                    } else if (bedrooms || beds) {
                        loadingMessage = '<div style="display: flex; flex-direction: column; align-items: center;"><div style="width: 40px; height: 40px; border: 3px solid #f3f3f3; border-top: 3px solid #0073aa; border-radius: 50%; animation: spin 1s linear infinite; margin-bottom: 16px;"></div><div style="font-size: 16px; color: #333; font-weight: 500;">Filtering properties...</div></div>';
                    } else {
                        loadingMessage = '<div style="display: flex; flex-direction: column; align-items: center;"><div style="width: 40px; height: 40px; border: 3px solid #f3f3f3; border-top: 3px solid #0073aa; border-radius: 50%; animation: spin 1s linear infinite; margin-bottom: 16px;"></div><div style="font-size: 16px; color: #333; font-weight: 500;">Loading properties...</div></div>';
                    }

                    // Add spinner animation if not already in style
                    if (!document.getElementById('digim-spinner-style')) {
                        const style = document.createElement('style');
                        style.id = 'digim-spinner-style';
                        style.textContent = '@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }';
                        document.head.appendChild(style);
                    }

                    loadingOverlay.innerHTML = loadingMessage;
                    loadingOverlay.style.display = 'flex';
                }

                // Get current URL parameters
                const urlParams = new URLSearchParams(window.location.search);
                const formData = new FormData();

                // Add all current search parameters
                formData.append('action', 'digim_filter_listings');
                const searchParam = urlParams.get('property_search');
                if (searchParam) {
                    if (searchParam.includes(',')) {
                        searchParam.split(',').forEach(s => formData.append('property_search[]', s));
                    } else {
                        formData.append('property_search[]', searchParam);
                    }
                }
                formData.append('checkin', urlParams.get('checkin') || '');
                formData.append('checkout', urlParams.get('checkout') || '');
                formData.append('adults', urlParams.get('adults') || '0');
                formData.append('children', urlParams.get('children') || '0');
                formData.append('infants', urlParams.get('infants') || '0');
                formData.append('property_page', '1');
                formData.append('show_available_only', showAvailableOnly ? '1' : '');
                formData.append('filter_bedrooms', bedrooms || '');
                formData.append('filter_beds', beds || '');
                formData.append('filter_price_min', priceMin);
                formData.append('filter_price_max', priceMax);
                amenities.forEach(function(a) {
                    formData.append('filter_amenities[]', a);
                });

                fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success && data.data && data.data.html) {
                            // Create a temporary container to parse the HTML
                            const tempDiv = document.createElement('div');
                            tempDiv.innerHTML = data.data.html;

                            // Find the properties grid in the response
                            const newGrid = tempDiv.querySelector('#digim-properties-grid');
                            // Be specific - only get the filters container from within dm-property, not from map area
                            const tempDmProperty = tempDiv.querySelector('.dm-property');
                            const newFiltersContainer = tempDmProperty ? tempDmProperty.querySelector('[style*="grid-column: 1 / -1"]') : null;
                            const newPagination = tempDiv.querySelector('.digimanagement-pagination');
                            const newNoAvailable = tempDiv.querySelector('#digim-no-available-message');

                            // Preserve scroll position before DOM updates
                            const scrollY = window.scrollY;

                            // Preserve map container structure - only replace grid content, not the dm-grid or dm-property containers
                            // Replace properties grid (only innerHTML to preserve container structure and map)
                            if (newGrid && propertiesGrid) {
                                propertiesGrid.innerHTML = newGrid.innerHTML;
                            }

                            // Replace filters container (only the filters div, not the parent container)
                            // Be very specific - only replace the div with grid-column style inside dm-property, not any parent containers
                            if (newFiltersContainer) {
                                // Find the exact filters container div (the one with grid-column style inside dm-property)
                                // Use a more specific selector to avoid affecting map container
                                const dmProperty = document.querySelector('.dm-property');
                                if (dmProperty) {
                                    // Find all containers with grid-column: 1 / -1 inside dm-property
                                    const allContainers = Array.from(dmProperty.querySelectorAll('[style*="grid-column: 1 / -1"]'));
                                    // The first one is the filters wrapper, the second (if exists) is the badge container
                                    const currentFiltersContainer = allContainers[0];

                                    if (currentFiltersContainer && newFiltersContainer) {
                                        // Only replace the filters container, preserve all parent structure (dm-property, dm-grid, map, etc.)
                                        currentFiltersContainer.outerHTML = newFiltersContainer.outerHTML;

                                        // Also check if there's a badge container in the new HTML
                                        const newBadgeContainer = tempDmProperty ? Array.from(tempDmProperty.querySelectorAll('[style*="grid-column: 1 / -1"]'))[1] : null;
                                        const currentBadgeContainer = allContainers[1];

                                        if (newBadgeContainer) {
                                            // Replace or add badge container
                                            if (currentBadgeContainer) {
                                                currentBadgeContainer.outerHTML = newBadgeContainer.outerHTML;
                                            } else {
                                                // Insert badge container after filters container
                                                const updatedFiltersContainer = dmProperty.querySelector('[style*="grid-column: 1 / -1"]');
                                                if (updatedFiltersContainer && updatedFiltersContainer.nextSibling) {
                                                    updatedFiltersContainer.parentNode.insertBefore(newBadgeContainer.cloneNode(true), updatedFiltersContainer.nextSibling);
                                                } else if (updatedFiltersContainer) {
                                                    updatedFiltersContainer.insertAdjacentHTML('afterend', newBadgeContainer.outerHTML);
                                                }
                                            }
                                        } else if (currentBadgeContainer) {
                                            // Remove badge container if it doesn't exist in new HTML
                                            currentBadgeContainer.remove();
                                        }

                                        // Re-initialize filter event listeners
                                        setTimeout(() => {
                                            initializeFilters();
                                        }, 50);
                                    }
                                }
                            }

                            // Replace pagination (keep existing pagination links working - they use regular href links)
                            // IMPORTANT: Pagination should be inside dm-property, before it closes (not after, which would put it before map)
                            const currentPagination = document.querySelector('.digimanagement-pagination');
                            const dmProperty = document.querySelector('.dm-property');

                            if (newPagination) {
                                if (currentPagination) {
                                    // Replace existing pagination in place
                                    currentPagination.outerHTML = newPagination.outerHTML;
                                } else {
                                    // Insert pagination inside dm-property, at the end (before closing tag, so it's before map)
                                    if (dmProperty) {
                                        // Find the properties grid and insert pagination right after it, inside dm-property
                                        const grid = dmProperty.querySelector('#digim-properties-grid');
                                        if (grid) {
                                            grid.insertAdjacentHTML('afterend', newPagination.outerHTML);
                                        } else {
                                            // Fallback: insert at end of dm-property
                                            dmProperty.insertAdjacentHTML('beforeend', newPagination.outerHTML);
                                        }
                                    }
                                }
                            } else if (currentPagination) {
                                currentPagination.remove();
                            }

                            // Replace no available message
                            // IMPORTANT: Message should be inside dm-property, before it closes
                            const currentNoAvailable = document.getElementById('digim-no-available-message');
                            if (newNoAvailable) {
                                if (currentNoAvailable) {
                                    currentNoAvailable.outerHTML = newNoAvailable.outerHTML;
                                } else {
                                    // Insert message inside dm-property, after grid
                                    if (dmProperty) {
                                        const grid = dmProperty.querySelector('#digim-properties-grid');
                                        if (grid) {
                                            grid.insertAdjacentHTML('afterend', newNoAvailable.outerHTML);
                                        } else {
                                            dmProperty.insertAdjacentHTML('beforeend', newNoAvailable.outerHTML);
                                        }
                                    }
                                }
                            } else if (currentNoAvailable) {
                                currentNoAvailable.remove();
                            }

                            updateURL(showAvailableOnly, bedrooms, beds, priceMin, priceMax, amenities, true);
                            updateFilterBadge(bedrooms, beds, priceMin, priceMax, amenities);
                            applyPriceFilter(priceMin, priceMax);

                            // Update map to show only filtered properties (same as the list)
                            if (typeof window.digimUpdateMapMarkers === 'function' && data.data.markers) {
                                window.digimUpdateMapMarkers(data.data.markers);
                            }

                            // Restore scroll position after all DOM updates (use double requestAnimationFrame for reliability)
                            requestAnimationFrame(() => {
                                requestAnimationFrame(() => {
                                    window.scrollTo(0, scrollY);
                                });
                            });
                        } else {
                            console.error('AJAX error:', data);
                        }
                    })
                    .catch(error => {
                        console.error('Error loading filtered listings:', error);
                        alert('Error loading filtered results. Please try again.');
                    })
                    .finally(() => {
                        filterInFlight = false;
                        // Remove loading state
                        if (gridContainer) {
                            gridContainer.style.opacity = '1';
                            gridContainer.style.pointerEvents = 'auto';
                            const loadingOverlay = gridContainer.querySelector('.digim-loading-overlay');
                            if (loadingOverlay) {
                                loadingOverlay.style.display = 'none';
                            }
                        }

                        // Ensure map container structure is preserved
                        // Check if map exists and reinitialize if needed
                        const mapContainer = document.querySelector('.digimanagement-map');
                        const mapElement = document.getElementById('digim-map');
                        if (mapContainer && mapElement && typeof window.digimMapData !== 'undefined') {
                            // Map should still be intact, but ensure it's visible
                            mapContainer.style.display = '';
                        }
                    });
            }

            function initializeFilters() {
                const newFilterToggle = document.getElementById('digim-show-available-only');
                const newBedroomsFilter = document.getElementById('digim-filter-bedrooms');
                const newBedsFilter = document.getElementById('digim-filter-beds');
                const newResetBtn = document.querySelector('.digim-filter-reset-btn');
                const newFilterToggleBtn = document.querySelector('.digim-filter-toggle-btn');
                const newFilterDropdown = document.getElementById('digim-filter-dropdown');
                setupPriceRangeSliders();
                setupAmenitiesShowMore();
                if (window.feather) {
                    try {
                        feather.replace();
                    } catch (e) {}
                }
                const v = getCurrentFilterValues();
                updateFilterBadge(v.bedrooms, v.beds, v.priceMin, v.priceMax, v.amenities);
                if (newResetBtn) {
                    newResetBtn.addEventListener('click', function() {
                        const priceMinEl = document.getElementById('digim-filter-price-min');
                        const priceMaxEl = document.getElementById('digim-filter-price-max');
                        if (priceMinEl) priceMinEl.value = PRICE_SLIDER_MIN;
                        if (priceMaxEl) priceMaxEl.value = PRICE_SLIDER_MAX;
                        if (newBedroomsFilter) newBedroomsFilter.value = '';
                        if (newBedsFilter) newBedsFilter.value = '';
                        document.querySelectorAll('.digim-filter-amenity-cb').forEach(function(cb) {
                            cb.checked = false;
                        });
                        updatePriceRangeDisplay();
                        updateFilterBadge('', '', '', '', []);
                        loadFilteredListings(false, '', '', '', '', []);
                    });
                }
                if (newFilterToggleBtn && newFilterDropdown) {
                    newFilterToggleBtn.addEventListener('click', function(e) {
                        e.stopPropagation();
                        if (newFilterDropdown.classList.contains('active')) {
                            closeFilterDropdown();
                        } else {
                            newFilterDropdown.classList.add('active');
                            newFilterDropdown.setAttribute('aria-hidden', 'false');
                            newFilterToggleBtn.setAttribute('aria-expanded', 'true');
                        }
                    });
                }
                const showPlacesBtn = document.getElementById('digim-filter-show-places');
                if (showPlacesBtn && !showPlacesBtn._digimBound) {
                    showPlacesBtn._digimBound = true;
                    showPlacesBtn.addEventListener('click', function() {
                        const v2 = getCurrentFilterValues();
                        closeFilterDropdown();
                        loadFilteredListings(newFilterToggle ? newFilterToggle.checked : false, v2.bedrooms, v2.beds, v2.priceMin, v2.priceMax, v2.amenities);
                    });
                }
                const clearAllLink = document.querySelector('[data-clear-filters]');
                if (clearAllLink && !clearAllLink._digimBound) {
                    clearAllLink._digimBound = true;
                    clearAllLink.addEventListener('click', function(ev) {
                        ev.preventDefault();
                        const priceMinEl = document.getElementById('digim-filter-price-min');
                        const priceMaxEl = document.getElementById('digim-filter-price-max');
                        if (priceMinEl) priceMinEl.value = PRICE_SLIDER_MIN;
                        if (priceMaxEl) priceMaxEl.value = PRICE_SLIDER_MAX;
                        if (newBedroomsFilter) newBedroomsFilter.value = '';
                        if (newBedsFilter) newBedsFilter.value = '';
                        document.querySelectorAll('.digim-filter-amenity-cb').forEach(function(cb) {
                            cb.checked = false;
                        });
                        updatePriceRangeDisplay();
                        closeFilterDropdown();
                        updateFilterBadge('', '', '', '', []);
                        loadFilteredListings(false, '', '', '', '', []);
                    });
                }
            }

            function updateFilter() {
                const showAvailableOnly = filterToggle ? filterToggle.checked : false;
                const selectedBedrooms = bedroomsFilter ? bedroomsFilter.value : '';
                const selectedBeds = bedsFilter ? bedsFilter.value : '';
                const cards = propertiesGrid.querySelectorAll('.digimanagement-card');
                let availableCount = 0;
                let totalCards = cards.length;

                cards.forEach(card => {
                    const isAvailable = card.getAttribute('data-available') === 'true';
                    const cardBedrooms = card.getAttribute('data-bedrooms') || '0';
                    const cardBeds = card.getAttribute('data-beds') || '0';

                    let shouldShow = true;

                    // Check availability filter
                    if (showAvailableOnly && !isAvailable) {
                        shouldShow = false;
                    }

                    // Check bedrooms filter
                    if (shouldShow && selectedBedrooms && cardBedrooms !== selectedBedrooms) {
                        shouldShow = false;
                    }

                    // Check beds filter
                    if (shouldShow && selectedBeds && cardBeds !== selectedBeds) {
                        shouldShow = false;
                    }

                    if (shouldShow) {
                        card.style.display = '';
                        if (isAvailable) availableCount++;
                    } else {
                        card.style.display = 'none';
                    }
                });

                // Show/hide no available message
                // Show when: (a) filter "available only" hides all cards, or (b) no results at all (totalCards === 0)
                if (noAvailableMessage) {
                    if ((showAvailableOnly && availableCount === 0 && totalCards > 0) || totalCards === 0) {
                        noAvailableMessage.classList.add('show');
                    } else {
                        noAvailableMessage.classList.remove('show');
                    }
                }
                const v = getCurrentFilterValues();
                applyPriceFilter(v.priceMin, v.priceMax);
            }

            function initializePage() {
                updateFilter();
                const v = getCurrentFilterValues();
                updateFilterBadge(v.bedrooms, v.beds, v.priceMin, v.priceMax, v.amenities);
                applyPriceFilter(v.priceMin, v.priceMax);
                if (window.feather) {
                    try {
                        feather.replace();
                    } catch (e) {}
                }
            }
            window.addEventListener('load', function() {
                if (window.feather) {
                    try {
                        feather.replace();
                    } catch (e) {}
                }
            });

            document.addEventListener('DOMContentLoaded', function() {
                initializePage();
            });

            // Also run immediately in case DOM is already loaded
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', initializePage);
            } else {
                initializePage();
            }
        })();
    </script>
</div>