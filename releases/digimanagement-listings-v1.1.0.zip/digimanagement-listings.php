<?php

/**
 * Plugin Name: DigiM
 * Plugin URI: https://digiperia.com
 * Description: A professional WordPress plugin that integrates with Hospitable API to display property listings with flexible shortcode parameters.
 * Version: 1.1.0
 * Author: Altin Beqiri & Barlet Hamzai
 * Author URI: https://digiperia.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wml-hospitable
 * Domain Path: /languages
 * Requires at least: 5.0
 * Tested up to: 6.5.3
 * Requires PHP: 7.4
 * Network: false
 */

// === Plugin Path Constant ===
define('DIGIMANAGEMENT_PLUGIN_PATH', plugin_dir_path(__FILE__));

require_once __DIR__ . '/plugin-update-checker/plugin-update-checker.php';

use YahnisElsts\PluginUpdateChecker\v5p6\PucFactory;

$myUpdateChecker = PucFactory::buildUpdateChecker(
  'https://raw.githubusercontent.com/digiperia/DigiMUpdate/main/digim-plugin-update.json',
  __FILE__,
  'digimanagement-listings'
);



// === Admin-only CSS (load everywhere in admin first; scope later once IDs known) ===
add_action('admin_enqueue_scripts', function () {
  $admin_css_path = plugin_dir_path(__FILE__) . 'assets/css/admin.css';
  if (!file_exists($admin_css_path)) {
    error_log('DigiM admin.css not found at: ' . $admin_css_path);
    return;
  }
  wp_enqueue_style(
    'digim-admin',
    plugin_dir_url(__FILE__) . 'assets/css/admin.css',
    [],
    filemtime($admin_css_path)
  );
});




// === Admin Pages ===
if (is_admin()) {
  require_once DIGIMANAGEMENT_PLUGIN_PATH . 'admin/menu.php';
  require_once DIGIMANAGEMENT_PLUGIN_PATH . 'admin/admin-settings.php';
}

// === Frontend Shortcode ===
require_once DIGIMANAGEMENT_PLUGIN_PATH . 'includes/shortcode.php';


// === Enqueue Plugin Styles & Scripts ===
add_action('wp_enqueue_scripts', function () {
  global $post;
  
  // Check if we should load the styles and scripts
  $should_load = false;
  
  // Check if shortcode exists in post content
  if (isset($post) && has_shortcode($post->post_content, 'digimanagement_listings')) {
    $should_load = true;
  }
  
  // Check if we're on a page that might contain listings (like /listings/)
  if (is_page() && (strpos($_SERVER['REQUEST_URI'], '/listings') !== false || 
                   strpos($_SERVER['REQUEST_URI'], 'listings') !== false)) {
    $should_load = true;
  }
  
  // Check if we're on a property single page
  if (get_query_var('dm_property_uuid')) {
    $should_load = true;
  }
  
  // Check if the current page template or content contains digim classes
  if (isset($post) && (strpos($post->post_content, 'digim-main') !== false || 
                      strpos($post->post_content, 'digimanagement') !== false)) {
    $should_load = true;
  }
  
  // Fallback: Check if we're on any page that might need the plugin styles
  // This can be customized based on your specific needs
  $force_load_pages = ['listings', 'properties', 'search'];
  foreach ($force_load_pages as $page_slug) {
    if (is_page($page_slug) || strpos($_SERVER['REQUEST_URI'], $page_slug) !== false) {
      $should_load = true;
      break;
    }
  }
  
  if (!$should_load) return;

  // ✅ Leaflet CSS & JS
  wp_enqueue_style('leaflet', 'https://unpkg.com/leaflet/dist/leaflet.css');
  wp_enqueue_script('leaflet', 'https://unpkg.com/leaflet/dist/leaflet.js', [], null, true);

  // ✅ Leaflet Marker Cluster
  wp_enqueue_style('leaflet-cluster', 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css');
  wp_enqueue_script('leaflet-cluster', 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js', ['leaflet'], null, true);

  // ✅ Plugin Styles (ensure loaded after Leaflet to override)
  $style_path = plugin_dir_path(__FILE__) . 'assets/css/style.css';
  if (file_exists($style_path)) {
    wp_enqueue_style(
      'digim-style',
      plugin_dir_url(__FILE__) . 'assets/css/style.css',
      [],
      filemtime($style_path)
    );
  }

  // ✅ Plugin Frontend JS (map logic, interactivity)
  $js_path = plugin_dir_path(__FILE__) . 'assets/js/frontend.js';
  if (file_exists($js_path)) {
    wp_enqueue_script(
      'digim-frontend',
      plugin_dir_url(__FILE__) . 'assets/js/frontend.js',
      ['jquery', 'leaflet', 'leaflet-cluster'],
      filemtime($js_path),
      true
    );
  }
});


function digimanagement_get_api_url()
{
  return trim(get_option('digimanagement_api_url', 'https://public.api.hospitable.com/v2'));
}

function digimanagement_get_api_token()
{
  $token = trim(get_option('digimanagement_api_key', ''));
  
  // If no token is stored, use the hardcoded one temporarily
  if (empty($token)) {
    $token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiI5YTYyNGRmMC0xMmYxLTQ0OGUtYjg4NC00MzY3ODBhNWQzY2QiLCJqdGkiOiI1MmI3YmVhOTc1YWExZTViODYzMDAyNjg4ODI3MTM0MTNkNjRmMzhlN2UwZDZiZGFkNGVkMTczYTNmMTExYzllNjZjMTQ4ZTNmODI2YWM4YSIsImlhdCI6MTc1MDI1MDc0Ni4yODAyMTEsIm5iZiI6MTc1MDI1MDc0Ni4yODAyMTMsImV4cCI6MTc4MTc4Njc0Ni4yNzY2Nywic3ViIjoiMTU1NDQ2Iiwic2NvcGVzIjpbInBhdDpyZWFkIiwicGF0OndyaXRlIl19.I5iiT2U-EoxxI3ek9KsLstoYujqZrunlkNjIEdOS2XakLYX5yeL1813wyxYKqK0ad1ZXMGkSe1En9g-tUkjGukRG0yLSxSDpSmo4S-xh8zsZcgNf2MvTwIJn4_Y4aHWV-F6L6-3uwEAGPp6ypjEJyaqiWHE-4vnxUdKfNQTh9HnLTxvsqiHRZpl5fOyvFZFpDu5-oeUQvTK55_8uMyLMVg4jgmjPpwpg1Oqmnpz-0Art01KqdtAe5eShrRQvQzd8D-8E4GHwoXplVuwp-C-P9ZCrfYlkCinCHuRZCw4TiVqfkEF-KwQ8VxmOjnVsuxuA-kzSAEkg9p2J0a97KdqyuWkFqVtbFqn0sa5ZN91rPkvJ-kEvlgjvhfbcVMkDkVDOxV04MdxqkuDYgULKDOkt03V7n7VtXkccQDU3iDEF0H8QvdnPZc2eFO85TMociRVX8TTGdtz-y8tQMDiLCL8IItWCXBzmmEeDfrAwUo7MTmw2fk9_VKVw-tp8KLeBQZlrKQ641X4afOAm0oBWmLh-NyoP9ojU_U5cLkeroek_JAJTDfQ0u7jg22_ZqQZvlmkpJbuawICP0KlqDYaoUFPaRiJOK2CsfOBdHWPlobqtnzpyd82L62h8lnqysMsJLll6_OmDuqGyI8nOxXoa7T-w6N4fBF_L6kdpmDAVEnJhLvY';
    error_log("Using hardcoded token - stored token is empty");
  }
  
  return 'Bearer ' . $token;
}

// Debug function to test API response for a specific property
function digimanagement_debug_property_api($property_uuid) {
    error_log("=== DEBUGGING PROPERTY API FOR UUID: $property_uuid ===");
    
    // Test 1: Get property details
    $property_url = digimanagement_get_api_url() . "/properties/$property_uuid";
    $property_response = wp_remote_get($property_url, [
        'headers' => [
            'Authorization' => digimanagement_get_api_token(),
            'Accept' => 'application/json',
        ],
        'timeout' => 15,
    ]);
    
    if (is_wp_error($property_response)) {
        error_log("Property API Error: " . $property_response->get_error_message());
        return;
    }
    
    $property_data = json_decode(wp_remote_retrieve_body($property_response), true);
    error_log("Property API Response Code: " . wp_remote_retrieve_response_code($property_response));
    error_log("Property API Response: " . wp_remote_retrieve_body($property_response));
    
    if ($property_data && isset($property_data['data'])) {
        $property = $property_data['data'];
        error_log("Property Name: " . ($property['name'] ?? 'N/A'));
        error_log("Property Fields: " . implode(', ', array_keys($property)));
        
        // Check for pricing fields
        if (isset($property['pricing'])) {
            error_log("Pricing Fields: " . implode(', ', array_keys($property['pricing'])));
            error_log("Pricing Data: " . print_r($property['pricing'], true));
        }
    }
    
    // Test 2: Get rates
    $rates_url = digimanagement_get_api_url() . "/properties/$property_uuid/rates";
    $rates_response = wp_remote_get($rates_url, [
        'headers' => [
            'Authorization' => digimanagement_get_api_token(),
            'Accept' => 'application/json',
        ],
        'timeout' => 15,
    ]);
    
    if (!is_wp_error($rates_response)) {
        error_log("Rates API Response Code: " . wp_remote_retrieve_response_code($rates_response));
        error_log("Rates API Response: " . wp_remote_retrieve_body($rates_response));
    }
    
    error_log("=== END DEBUGGING FOR UUID: $property_uuid ===");
}

// Test function to debug API responses
function digimanagement_test_api_ajax() {
    // Skip nonce verification for local testing
    error_log("Test API function called - skipping nonce verification for local testing");
    
    $property_uuid = sanitize_text_field($_POST['property_uuid'] ?? '');
    if (empty($property_uuid)) {
        wp_send_json_error('Property UUID required');
        return;
    }
    
    // Test property API - first test the working listings endpoint
    $listings_url = digimanagement_get_api_url() . "/properties?page=1";
    $listings_response = wp_remote_get($listings_url, [
        'headers' => [
            'Authorization' => digimanagement_get_api_token(),
            'Accept' => 'application/json',
            'Cache-Control' => 'no-cache',
            'Pragma' => 'no-cache',
        ],
        'timeout' => 15,
    ]);
    
    // Test specific property API
    $property_url = digimanagement_get_api_url() . "/properties/$property_uuid";
    $property_response = wp_remote_get($property_url, [
        'headers' => [
            'Authorization' => digimanagement_get_api_token(),
            'Accept' => 'application/json',
        ],
        'timeout' => 15,
    ]);
    
    $property_data = null;
    $property_response_body = '';
    if (!is_wp_error($property_response)) {
        $property_response_body = wp_remote_retrieve_body($property_response);
        $property_data = json_decode($property_response_body, true);
    } else {
        error_log("Property API Error: " . $property_response->get_error_message());
    }
    
    // Test rates API
    $rates_url = digimanagement_get_api_url() . "/properties/$property_uuid/rates";
    $rates_response = wp_remote_get($rates_url, [
        'headers' => [
            'Authorization' => digimanagement_get_api_token(),
            'Accept' => 'application/json',
        ],
        'timeout' => 15,
    ]);
    
    $rates_data = null;
    $rates_response_body = '';
    if (!is_wp_error($rates_response)) {
        $rates_response_body = wp_remote_retrieve_body($rates_response);
        $rates_data = json_decode($rates_response_body, true);
    } else {
        error_log("Rates API Error: " . $rates_response->get_error_message());
    }
    
    // Test quote API
    $quote_url = digimanagement_get_api_url() . "/properties/$property_uuid/quote";
    $quote_data = array(
        'checkin' => '2025-11-09',
        'checkout' => '2025-11-12',
        'adults' => 2,
        'children' => 0,
        'infants' => 0
    );
    
    $quote_response = wp_remote_post($quote_url, array(
        'headers' => array(
            'Authorization' => digimanagement_get_api_token(),
            'Accept' => 'application/json',
            'Content-Type' => 'application/json'
        ),
        'body' => json_encode($quote_data),
        'timeout' => 30
    ));
    
    $quote_data = null;
    $quote_response_body = '';
    if (!is_wp_error($quote_response)) {
        $quote_response_body = wp_remote_retrieve_body($quote_response);
        $quote_data = json_decode($quote_response_body, true);
    } else {
        error_log("Quote API Error: " . $quote_response->get_error_message());
    }
    
    // Test with hardcoded token to see if that works
    $test_token = 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiI5YTYyNGRmMC0xMmYxLTQ0OGUtYjg4NC00MzY3ODBhNWQzY2QiLCJqdGkiOiI1MmI3YmVhOTc1YWExZTViODYzMDAyNjg4ODI3MTM0MTNkNjRmMzhlN2UwZDZiZGFkNGVkMTczYTNmMTExYzllNjZjMTQ4ZTNmODI2YWM4YSIsImlhdCI6MTc1MDI1MDc0Ni4yODAyMTEsIm5iZiI6MTc1MDI1MDc0Ni4yODAyMTMsImV4cCI6MTc4MTc4Njc0Ni4yNzY2Nywic3ViIjoiMTU1NDQ2Iiwic2NvcGVzIjpbInBhdDpyZWFkIiwicGF0OndyaXRlIl19.I5iiT2U-EoxxI3ek9KsLstoYujqZrunlkNjIEdOS2XakLYX5yeL1813wyxYKqK0ad1ZXMGkSe1En9g-tUkjGukRG0yLSxSDpSmo4S-xh8zsZcgNf2MvTwIJn4_Y4aHWV-F6L6-3uwEAGPp6ypjEJyaqiWHE-4vnxUdKfNQTh9HnLTxvsqiHRZpl5fOyvFZFpDu5-oeUQvTK55_8uMyLMVg4jgmjPpwpg1Oqmnpz-0Art01KqdtAe5eShrRQvQzd8D-8E4GHwoXplVuwp-C-P9ZCrfYlkCinCHuRZCw4TiVqfkEF-KwQ8VxmOjnVsuxuA-kzSAEkg9p2J0a97KdqyuWkFqVtbFqn0sa5ZN91rPkvJ-kEvlgjvhfbcVMkDkVDOxV04MdxqkuDYgULKDOkt03V7n7VtXkccQDU3iDEF0H8QvdnPZc2eFO85TMociRVX8TTGdtz-y8tQMDiLCL8IItWCXBzmmEeDfrAwUo7MTmw2fk9_VKVw-tp8KLeBQZlrKQ641X4afOAm0oBWmLh-NyoP9ojU_U5cLkeroek_JAJTDfQ0u7jg22_ZqQZvlmkpJbuawICP0KlqDYaoUFPaRiJOK2CsfOBdHWPlobqtnzpyd82L62h8lnqysMsJLll6_OmDuqGyI8nOxXoa7T-w6N4fBF_L6kdpmDAVEnJhLvY';
    
    $test_response = wp_remote_get($property_url, [
        'headers' => [
            'Authorization' => $test_token,
            'Accept' => 'application/json',
        ],
        'timeout' => 15,
    ]);
    
    $test_response_body = '';
    if (!is_wp_error($test_response)) {
        $test_response_body = wp_remote_retrieve_body($test_response);
    }
    
    $listings_data = null;
    $listings_response_body = '';
    if (!is_wp_error($listings_response)) {
        $listings_response_body = wp_remote_retrieve_body($listings_response);
        $listings_data = json_decode($listings_response_body, true);
    }
    
    wp_send_json_success([
        'listings_test' => [
            'url' => $listings_url,
            'response_code' => wp_remote_retrieve_response_code($listings_response),
            'raw_response' => substr($listings_response_body, 0, 500),
            'is_error' => is_wp_error($listings_response),
            'data_count' => isset($listings_data['data']) ? count($listings_data['data']) : 0
        ],
        'property' => [
            'url' => $property_url,
            'response_code' => wp_remote_retrieve_response_code($property_response),
            'raw_response' => substr($property_response_body, 0, 500), // First 500 chars
            'data' => $property_data
        ],
        'rates' => [
            'url' => $rates_url,
            'response_code' => wp_remote_retrieve_response_code($rates_response),
            'raw_response' => substr($rates_response_body, 0, 500), // First 500 chars
            'data' => $rates_data
        ],
        'quote' => [
            'url' => $quote_url,
            'response_code' => wp_remote_retrieve_response_code($quote_response),
            'raw_response' => substr($quote_response_body, 0, 500), // First 500 chars
            'data' => $quote_data
        ],
        'test_with_hardcoded_token' => [
            'response_code' => wp_remote_retrieve_response_code($test_response),
            'raw_response' => substr($test_response_body, 0, 500),
            'is_error' => is_wp_error($test_response)
        ],
        'api_token' => digimanagement_get_api_token(),
        'api_url' => digimanagement_get_api_url(),
        'stored_token_option' => get_option('digimanagement_api_key', 'NOT_SET')
    ]);
}

// Simple test function
function digimanagement_simple_test_ajax() {
    wp_send_json_success([
        'message' => 'Simple test works!',
        'timestamp' => current_time('mysql'),
        'api_token' => digimanagement_get_api_token(),
        'api_url' => digimanagement_get_api_url()
    ]);
}


// === Slug Functions === //
function digimanagement_create_property_slug($property_name, $address = '') {
  // Create a slug from property name and address
  $slug = $property_name;
  if ($address) {
    $slug .= ' ' . $address;
  }
  
  // Convert to lowercase and replace spaces/special chars with hyphens
  $slug = strtolower($slug);
  $slug = preg_replace('/[^a-z0-9\s-]/', '', $slug);
  $slug = preg_replace('/[\s-]+/', '-', $slug);
  $slug = trim($slug, '-');
  
  // Limit length
  $slug = substr($slug, 0, 100);
  
  return $slug;
}

function digimanagement_get_property_by_slug($slug) {
  // Get all properties and find one with matching slug
  $all_properties = digim_get_all_properties();
  
  foreach ($all_properties as $property) {
    $property_slug = digimanagement_create_property_slug(
      $property['name'] ?? '', 
      $property['address']['city'] ?? ''
    );
    
    if ($property_slug === $slug) {
      return $property;
    }
  }
  
  return null;
}

function digimanagement_get_property_uuid_by_slug($slug) {
  $property = digimanagement_get_property_by_slug($slug);
  return $property ? ($property['uuid'] ?? $property['id'] ?? null) : null;
}

// Ajax UI BUILDER
add_action('wp_ajax_digim_preview_shortcode', function () {
  update_option('digim_layout_style', sanitize_text_field($_POST['layout']));
  update_option('digim_grid_columns', intval($_POST['columns']));

  echo do_shortcode('[digimanagement_listings]');
  wp_die();
});


// === Helper: Parallel Calendar Check === //
function digimanagement_parallel_calendar_check($uuids, $checkin, $checkout)
{
  $mh = curl_multi_init();
  $handles = [];
  $results = [];

  foreach ($uuids as $uuid) {
    $url = digimanagement_get_api_url() . "/properties/$uuid/calendar";
    $ch = curl_init();
    curl_setopt_array($ch, [
      CURLOPT_URL => $url,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_HTTPHEADER => [
        'Authorization: ' . digimanagement_get_api_token(),
        'Accept: application/json',
        'Cache-Control: no-cache',
        'Pragma: no-cache',
      ],
      CURLOPT_TIMEOUT => 10,
    ]);
    curl_multi_add_handle($mh, $ch);
    $handles[$uuid] = $ch;
  }

  do {
    $status = curl_multi_exec($mh, $active);
    curl_multi_select($mh);
  } while ($active && $status === CURLM_OK);

  foreach ($handles as $uuid => $ch) {
    $body = curl_multi_getcontent($ch);
    $calendar = json_decode($body, true);
    $calendar_days = $calendar['data']['days'] ?? [];
    $range_available = true;

    $current = strtotime($checkin);
    $end = strtotime($checkout); // do NOT subtract 1 day

    // Loop through each night from checkin to (checkout - 1)
    while ($current < $end) {
      $date_str = date('Y-m-d', $current);
      $day_found = null;

      foreach ($calendar_days as $d) {
        if ($d['date'] === $date_str) {
          $day_found = $d;
          break;
        }
      }

      if (!$day_found || empty($day_found['status']['available'])) {
        $range_available = false;
        break;
      }

      $current = strtotime('+1 day', $current);
    }

    if ($range_available) {
      $results[] = $uuid;
    }

    curl_multi_remove_handle($mh, $ch);
    curl_close($ch);
  }

  curl_multi_close($mh);
  return $results;
}

// === Shortcode === //
require_once plugin_dir_path(__FILE__) . 'includes/shortcode.php';

// === SINGLE PAGE === //
add_action('init', function () {
  // Support both UUID and slug-based URLs
  add_rewrite_rule('^property/([^/]+)/?', 'index.php?dm_property_identifier=$matches[1]', 'top');
  add_rewrite_tag('%dm_property_identifier%', '([^&]+)');
});
add_filter('template_include', function ($template) {
  if (get_query_var('dm_property_identifier')) {
    return plugin_dir_path(__FILE__) . 'templates/property-single.php';
  }
  return $template;
});

// === Flush === //
register_activation_hook(__FILE__, function () {
  flush_rewrite_rules();
});
register_deactivation_hook(__FILE__, function () {
  flush_rewrite_rules();
});

// === AJAX HANDLER === //
add_action('wp_ajax_digimanagement_get_listings', 'digimanagement_get_listings_ajax');
add_action('wp_ajax_nopriv_digimanagement_get_listings', 'digimanagement_get_listings_ajax');

// Booking submission AJAX handler
add_action('wp_ajax_digim_submit_booking', 'digimanagement_submit_booking_ajax');
add_action('wp_ajax_nopriv_digim_submit_booking', 'digimanagement_submit_booking_ajax');
// Create reservation and return hosted checkout URL
add_action('wp_ajax_digim_create_reservation', 'digimanagement_create_reservation_ajax');
add_action('wp_ajax_nopriv_digim_create_reservation', 'digimanagement_create_reservation_ajax');

// Pricing and availability AJAX handlers
add_action('wp_ajax_digim_get_pricing', 'digimanagement_get_pricing_ajax');
add_action('wp_ajax_nopriv_digim_get_pricing', 'digimanagement_get_pricing_ajax');

add_action('wp_ajax_digim_check_availability', 'digimanagement_check_availability_ajax');
add_action('wp_ajax_nopriv_digim_check_availability', 'digimanagement_check_availability_ajax');

// Test endpoint to debug API responses
add_action('wp_ajax_digim_test_api', 'digimanagement_test_api_ajax');
add_action('wp_ajax_nopriv_digim_test_api', 'digimanagement_test_api_ajax');

// Simple test endpoint
add_action('wp_ajax_digim_simple_test', 'digimanagement_simple_test_ajax');
add_action('wp_ajax_nopriv_digim_simple_test', 'digimanagement_simple_test_ajax');


function digimanagement_get_listings_ajax()
{
  $search = sanitize_text_field($_GET['property_search'] ?? '');
  $checkin = sanitize_text_field($_GET['checkin'] ?? '');
  $checkout = sanitize_text_field($_GET['checkout'] ?? '');

  $page = 1;
  $all_properties = [];
  do {
    $response = wp_remote_get(digimanagement_get_api_url()
      . "/properties?page=$page", [
      'headers' => [
        'Authorization' => digimanagement_get_api_token(),
        'Accept' => 'application/json',
        'Cache-Control' => 'no-cache',
        'Pragma' => 'no-cache',
      ],
      'timeout' => 15,
    ]);
    if (is_wp_error($response)) wp_send_json_error($response->get_error_message());
    $data = json_decode(wp_remote_retrieve_body($response), true);
    if (!isset($data['data'])) break;
    $all_properties = array_merge($all_properties, $data['data']);
    $page++;
  } while (isset($data['links']['next']) && $data['links']['next']);

  if ($search) {
    $all_properties = array_filter($all_properties, function ($p) use ($search) {
      return stripos($p['public_name'] ?? $p['name'] ?? '', $search) !== false;
    });
  }

  if ($checkin && $checkout && count($all_properties) > 0) {
    $uuids = [];
    foreach ($all_properties as $p) {
      $uuids[] = $p['uuid'] ?? $p['id'];
    }
    $available_uuids = digimanagement_parallel_calendar_check($uuids, $checkin, $checkout);
    $all_properties = array_filter($all_properties, function ($p) use ($available_uuids) {
      return in_array($p['uuid'] ?? $p['id'], $available_uuids);
    });
  }

  wp_send_json_success(array_values($all_properties));
}

// Booking submission function
function digimanagement_submit_booking_ajax()
{
  // Verify nonce
  if (!wp_verify_nonce($_POST['nonce'], 'digim_booking_nonce')) {
    wp_send_json_error(['message' => 'Invalid nonce']);
    return;
  }

  // Get and sanitize booking data
  $property_uuid = sanitize_text_field($_POST['property_uuid'] ?? '');
  $checkin_date = sanitize_text_field($_POST['checkin_date'] ?? '');
  $checkout_date = sanitize_text_field($_POST['checkout_date'] ?? '');
  $adults = intval($_POST['adults'] ?? 0);
  $children = intval($_POST['children'] ?? 0);
  $infants = intval($_POST['infants'] ?? 0);
  $total_guests = intval($_POST['total_guests'] ?? 0);

  // Validate required fields
  if (empty($property_uuid) || empty($checkin_date) || empty($checkout_date) || $total_guests <= 0) {
    wp_send_json_error(['message' => 'Missing required booking information']);
    return;
  }

  // Validate dates
  $checkin = DateTime::createFromFormat('Y-m-d', $checkin_date);
  $checkout = DateTime::createFromFormat('Y-m-d', $checkout_date);
  
  if (!$checkin || !$checkout || $checkin >= $checkout) {
    wp_send_json_error(['message' => 'Invalid dates']);
    return;
  }

  // Check if check-in is in the future
  if ($checkin < new DateTime('today')) {
    wp_send_json_error(['message' => 'Check-in date must be in the future']);
    return;
  }

  try {
    // Prepare booking data for Hospitable API
    $booking_data = [
      'property_uuid' => $property_uuid,
      'checkin_date' => $checkin_date,
      'checkout_date' => $checkout_date,
      'adults' => $adults,
      'children' => $children,
      'infants' => $infants,
      'total_guests' => $total_guests,
      'status' => 'pending',
      'created_at' => current_time('mysql')
    ];

    // Submit to Hospitable API - using the booking endpoint
    $response = wp_remote_post(digimanagement_get_api_url() . '/bookings', [
      'headers' => [
        'Authorization' => digimanagement_get_api_token(),
        'Accept' => 'application/json',
        'Content-Type' => 'application/json',
      ],
      'body' => json_encode([
        'property_uuid' => $property_uuid,
        'checkin_date' => $checkin_date,
        'checkout_date' => $checkout_date,
        'adults' => $adults,
        'children' => $children,
        'infants' => $infants,
        'total_guests' => $total_guests,
        'status' => 'pending'
      ]),
      'timeout' => 30,
    ]);

    if (is_wp_error($response)) {
      wp_send_json_error(['message' => 'Failed to submit booking: ' . $response->get_error_message()]);
      return;
    }

    $response_code = wp_remote_retrieve_response_code($response);
    $response_body = json_decode(wp_remote_retrieve_body($response), true);

    if ($response_code >= 200 && $response_code < 300) {
      // Store booking locally for tracking
      $booking_id = wp_insert_post([
        'post_type' => 'digim_booking',
        'post_title' => 'Booking for Property ' . $property_uuid,
        'post_status' => 'publish',
        'meta_input' => $booking_data
      ]);

      wp_send_json_success([
        'message' => 'Booking submitted successfully',
        'booking_id' => $booking_id,
        'hospitable_response' => $response_body
      ]);
    } else {
      $error_message = $response_body['message'] ?? 'Unknown error occurred';
      wp_send_json_error(['message' => 'Booking failed: ' . $error_message]);
    }

  } catch (Exception $e) {
    wp_send_json_error(['message' => 'Booking error: ' . $e->getMessage()]);
  }
}

// Create reservation through Hospitable and return a hosted checkout URL
function digimanagement_create_reservation_ajax()
{
  // Verify nonce
  if (!wp_verify_nonce($_POST['nonce'], 'digim_booking_nonce')) {
    wp_send_json_error(['message' => 'Invalid nonce']);
    return;
  }

  $property_uuid = sanitize_text_field($_POST['property_uuid'] ?? '');
  $checkin_date = sanitize_text_field($_POST['checkin_date'] ?? '');
  $checkout_date = sanitize_text_field($_POST['checkout_date'] ?? '');
  $adults = intval($_POST['adults'] ?? 1);
  $children = intval($_POST['children'] ?? 0);
  $infants = intval($_POST['infants'] ?? 0);

  if (empty($property_uuid) || empty($checkin_date) || empty($checkout_date)) {
    wp_send_json_error(['message' => 'Missing required reservation parameters']);
    return;
  }

  try {
    $payload = [
      'property_uuid' => $property_uuid,
      'checkin_date' => $checkin_date,
      'checkout_date' => $checkout_date,
      'guests' => [
        'adults' => $adults,
        'children' => $children,
        'infants' => $infants,
      ],
      'source' => 'website',
      'status' => 'pending',
    ];

    $response = wp_remote_post(digimanagement_get_api_url() . '/reservations', [
      'headers' => [
        'Authorization' => digimanagement_get_api_token(),
        'Accept' => 'application/json',
        'Content-Type' => 'application/json',
      ],
      'body' => json_encode($payload),
      'timeout' => 30,
    ]);

    if (is_wp_error($response)) {
      wp_send_json_error(['message' => 'Reservation request failed: ' . $response->get_error_message()]);
      return;
    }

    $code = wp_remote_retrieve_response_code($response);
    $body_raw = wp_remote_retrieve_body($response);
    $body = json_decode($body_raw, true);

    if ($code >= 200 && $code < 300) {
      // Try common fields where checkout URL might be provided
      $checkout_url = $body['data']['checkout_url']
        ?? $body['data']['public_checkout_url']
        ?? $body['checkout_url']
        ?? $body['public_checkout_url']
        ?? null;
      $reservation_uuid = $body['data']['id'] ?? $body['data']['uuid'] ?? $body['id'] ?? $body['uuid'] ?? null;

      wp_send_json_success([
        'message' => 'Reservation created',
        'reservation_uuid' => $reservation_uuid,
        'checkout_url' => $checkout_url,
        'raw' => $body,
      ]);
    } else {
      $err = $body['message'] ?? $body_raw ?? 'Unknown error';
      wp_send_json_error(['message' => 'Reservation create failed: ' . $err, 'raw' => $body]);
    }
  } catch (Exception $e) {
    wp_send_json_error(['message' => 'Reservation error: ' . $e->getMessage()]);
  }
}

// Function to get quote from Hospitable API
function digimanagement_get_quote($property_uuid, $checkin_date, $checkout_date, $adults = 1, $children = 0, $infants = 0) {
    $api_url = digimanagement_get_api_url() . "/properties/$property_uuid/quote";
    $api_token = digimanagement_get_api_token();
    
    // Minimal payload for pricing only - no guest details needed
    $request_body = json_encode([
        'checkin_date' => $checkin_date,
        'checkout_date' => $checkout_date,
        'guests' => [
            'adults' => $adults,
            'children' => $children,
            'infants' => $infants,
            'pets' => 0
        ]
    ]);
    
    error_log("Quote API URL: " . $api_url);
    error_log("Quote API Token: " . substr($api_token, 0, 20) . "...");
    error_log("Quote API Request Body: " . $request_body);
    error_log("Quote API Request Headers: " . json_encode([
        'Authorization' => substr($api_token, 0, 20) . '...',
        'Accept' => 'application/json',
        'Content-Type' => 'application/json'
    ]));
    error_log("Property UUID for quote: " . $property_uuid);
    error_log("Property UUID length: " . strlen($property_uuid));
    
    $response = wp_remote_post($api_url, [
        'headers' => [
            'Authorization' => $api_token,
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
        ],
        'body' => $request_body,
        'timeout' => 30,
    ]);
    
    if (is_wp_error($response)) {
        error_log("Quote API error: " . $response->get_error_message());
        return [ 'error' => $response->get_error_message() ];
    }
    
    $response_code = wp_remote_retrieve_response_code($response);
    $response_body = json_decode(wp_remote_retrieve_body($response), true);
    
    error_log("Quote API response code: " . $response_code);
    error_log("Quote API response body: " . wp_remote_retrieve_body($response));
    error_log("Quote API response parsed: " . print_r($response_body, true));
    
    if ($response_code >= 200 && $response_code < 300) {
        // Some responses wrap data under 'data'
        return isset($response_body['data']) ? $response_body['data'] : $response_body;
    }
    // Return error details for debugging upstream
    return [
        'error' => 'non_2xx',
        'status' => $response_code,
        'body' => $response_body
    ];
}


// Get pricing data from Hospitable API
function digimanagement_get_pricing_ajax()
{
  // Verify nonce
  if (!wp_verify_nonce($_POST['nonce'], 'digim_booking_nonce')) {
    wp_send_json_error(['message' => 'Invalid nonce']);
    return;
  }

  $property_uuid = sanitize_text_field($_POST['property_uuid'] ?? '');
  $checkin_date = sanitize_text_field($_POST['checkin_date'] ?? '');
  $checkout_date = sanitize_text_field($_POST['checkout_date'] ?? '');
  $adults = intval($_POST['adults'] ?? 1);
  $children = intval($_POST['children'] ?? 0);
  $infants = intval($_POST['infants'] ?? 0);

  if (empty($property_uuid) || empty($checkin_date) || empty($checkout_date)) {
    wp_send_json_error(['message' => 'Missing required parameters']);
    return;
  }
  
  // Validate UUID format
  if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $property_uuid)) {
    wp_send_json_error(['message' => 'Invalid property UUID format: ' . $property_uuid]);
    return;
  }

  try {
    // Calculate nights
    $checkin = DateTime::createFromFormat('Y-m-d', $checkin_date);
    $checkout = DateTime::createFromFormat('Y-m-d', $checkout_date);
    $nights = $checkin->diff($checkout)->days;
    
    // Debug logging
    error_log("Pricing request - Property: $property_uuid, Checkin: $checkin_date, Checkout: $checkout_date, Nights: $nights");
    error_log("Property UUID type: " . gettype($property_uuid) . ", Length: " . strlen($property_uuid));
    error_log("Property UUID value: " . $property_uuid);

    // Always use Quote API per new logic
    $base_price = 0;
    $cleaning_fee = 0;
    $service_fee = 0;
    $security_deposit = 0;
    $subtotal = 0;
    $total = 0;
    $quote_data = digimanagement_get_quote($property_uuid, $checkin_date, $checkout_date, $adults, $children, $infants);

    // Handle error returned by helper
    if (isset($quote_data['error'])) {
      $err_message = 'Failed to generate quote';
      if (!empty($quote_data['status'])) {
        $err_message .= ' (HTTP ' . intval($quote_data['status']) . ')';
      }
      if (!empty($quote_data['body']['message'])) {
        $err_message .= ': ' . $quote_data['body']['message'];
      }
      if (!empty($quote_data['body']['errors'])) {
        $err_message .= ' - Errors: ' . json_encode($quote_data['body']['errors']);
      }
      $stored_token = get_option('digimanagement_api_key', '');
      $using_fallback_token = empty(trim($stored_token));
      wp_send_json_error([
        'message' => $err_message,
        'raw' => $quote_data,
        'token_source' => $using_fallback_token ? 'fallback' : 'stored'
      ]);
      return;
    }

    // Parse totals from quote financials (amounts are in cents)
    $currency = $quote_data['currency'] ?? 'USD';
    if (isset($quote_data['financials']['totals'])) {
      $totals = $quote_data['financials']['totals'];
      $sub_cents = null;
      $total_cents = null;
      if (isset($totals['sub_total']['amount'])) { $sub_cents = $totals['sub_total']['amount']; }
      if (isset($totals['sub_total'][0]['amount'])) { $sub_cents = $totals['sub_total'][0]['amount']; }
      if (isset($totals['total']['amount'])) { $total_cents = $totals['total']['amount']; }
      if (isset($totals['total'][0]['amount'])) { $total_cents = $totals['total'][0]['amount']; }

      if ($sub_cents !== null) { $subtotal = floatval($sub_cents) / 100.0; }
      if ($total_cents !== null) { $total = floatval($total_cents) / 100.0; }
    }

    // Derive per-night base price from subtotal
    if ($nights > 0 && $subtotal > 0) {
      $base_price = round($subtotal / $nights, 2);
    }

    // Map fees and taxes from quote
    $fees_cents = 0;
    if (isset($quote_data['financials']['fees']) && is_array($quote_data['financials']['fees'])) {
      foreach ($quote_data['financials']['fees'] as $f) {
        if (isset($f['amount'])) { $fees_cents += intval($f['amount']); }
      }
    }
    
    $taxes_cents = 0;
    if (isset($quote_data['financials']['taxes']) && is_array($quote_data['financials']['taxes'])) {
      foreach ($quote_data['financials']['taxes'] as $t) {
        if (isset($t['amount'])) { $taxes_cents += intval($t['amount']); }
      }
    }
    
    // Separate service fees and taxes
    $service_fee = round($fees_cents / 100.0, 2);
    $taxes_total = round($taxes_cents / 100.0, 2);
    
    // For now, we'll show taxes as a separate line item
    // In the future, we could break down individual taxes
    $cleaning_fee = 0; // Reset cleaning fee since it's not in the API response

    // Compose response
    $pricing_data = [
      'base_price' => $base_price,
      'cleaning_fee' => $cleaning_fee,
      'service_fee' => $service_fee,
      'taxes' => $taxes_total,
      'security_deposit' => $security_deposit,
      'nights' => $nights,
      'subtotal' => $subtotal,
      'total' => $total,
      'currency' => $currency,
      'quote_id' => $quote_data['quote_id'] ?? null,
      'booking_url' => $quote_data['booking_url'] ?? null,
    ];

    wp_send_json_success($pricing_data);

  } catch (Exception $e) {
    wp_send_json_error(['message' => 'Pricing error: ' . $e->getMessage()]);
  }
}

// Check availability from Hospitable API
function digimanagement_check_availability_ajax()
{
  // Verify nonce
  if (!wp_verify_nonce($_POST['nonce'], 'digim_booking_nonce')) {
    wp_send_json_error(['message' => 'Invalid nonce']);
    return;
  }

  $property_uuid = sanitize_text_field($_POST['property_uuid'] ?? '');
  $checkin_date = sanitize_text_field($_POST['checkin_date'] ?? '');
  $checkout_date = sanitize_text_field($_POST['checkout_date'] ?? '');

  if (empty($property_uuid) || empty($checkin_date) || empty($checkout_date)) {
    wp_send_json_error(['message' => 'Missing required parameters']);
    return;
  }

  try {
    // Check availability using Hospitable API
    // First try to get calendar data for the property
    $response = wp_remote_get(digimanagement_get_api_url() . "/properties/$property_uuid/calendar", [
      'headers' => [
        'Authorization' => digimanagement_get_api_token(),
        'Accept' => 'application/json',
      ],
      'timeout' => 15,
    ]);

    if (is_wp_error($response)) {
      wp_send_json_error(['message' => 'Failed to check availability']);
      return;
    }

    $calendar_data = json_decode(wp_remote_retrieve_body($response), true);
    
    // Check if the specific dates are available
    $is_available = true;
    $unavailable_dates = [];

    // For now, assume available if we can't get calendar data
    // In a real implementation, you'd parse the calendar data
    if (isset($calendar_data['data'])) {
      // Parse calendar data to check availability
      // This is a simplified check - you may need to adjust based on actual API response
      $is_available = true; // Default to available
    }

    wp_send_json_success([
      'available' => $is_available,
      'unavailable_dates' => $unavailable_dates,
      'checkin_date' => $checkin_date,
      'checkout_date' => $checkout_date
    ]);

  } catch (Exception $e) {
    wp_send_json_error(['message' => 'Availability check error: ' . $e->getMessage()]);
  }
}