document.addEventListener("DOMContentLoaded", function () {
  if (!window.digimMapData || !digimMapData.markers || !L) return;

  const mapContainer = document.getElementById("digim-map");
  if (!mapContainer) return;

  const map = L.map("digim-map", {
    scrollWheelZoom: false, // Disable scroll initially
  }).setView([46.8182, 8.2275], 8); // Slight zoom

  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "&copy; OpenStreetMap contributors",
  }).addTo(map);

  // 🖱️ Click-to-enable scroll zoom
  mapContainer.addEventListener("click", () => {
    map.scrollWheelZoom.enable();
    setTimeout(() => {
      map.scrollWheelZoom.disable(); // Disable again after 10s for UX
    }, 5000);
  });

  const markerCluster = L.markerClusterGroup();
  const markerRefs = {};

  function normalizeUrl(url) {
    try {
      const u = new URL(url, window.location.origin);
      return (u.origin + u.pathname).replace(/\/$/, "");
    } catch (e) {
      return url.replace(/\?.*$/, "").replace(/\/$/, "");
    }
  }

  digimMapData.markers.forEach((marker) => {
    const m = L.marker([marker.lat, marker.lng])
      .bindPopup(
        `
          <div class="popup-card">
            <a href="${marker.url}" target="_blank" style="text-decoration: none;">
              <img src="${marker.img}" class="popup-image" alt="${marker.name}" />
              <div class="popup-info">
                <strong class="popup-title">${marker.name}</strong><br/>
                <small class="popup-address">${marker.address}</small>
              </div>
            </a>
          </div>
        `
      )
      .on("click", function () {
        highlightCard(marker.url);
        m.openPopup();
      });

    markerCluster.addLayer(m);
    markerRefs[normalizeUrl(marker.url)] = m;
  });

  map.addLayer(markerCluster);

  if (digimMapData.markers.length > 0) {
    const bounds = L.latLngBounds(
      digimMapData.markers.map((m) => [m.lat, m.lng])
    );
    map.fitBounds(bounds, { padding: [30, 30] });
  }

  document.querySelectorAll(".digimanagement-card").forEach((card) => {
    const href = card.href;
    const marker = markerRefs[normalizeUrl(href)];
    if (!marker) return;

    card.addEventListener("mouseenter", () => {
      marker.openPopup();
      card.classList.add("hover-glow");
    });

    card.addEventListener("mouseleave", () => {
      marker.closePopup();
      card.classList.remove("hover-glow");
    });
  });

  const highlightUrl = new URLSearchParams(window.location.search).get(
    "highlight_url"
  );
  if (highlightUrl) {
    highlightCard(highlightUrl);
  }

  function highlightCard(url) {
    const target = normalizeUrl(url);
    const card = [...document.querySelectorAll(".digimanagement-card")].find(
      (el) => normalizeUrl(el.getAttribute("href")) === target
    );

    if (card) {
      card.scrollIntoView({ behavior: "smooth", block: "center" });
      card.classList.add("highlight");
      setTimeout(() => card.classList.remove("highlight"), 3500);
    }
  }
});
