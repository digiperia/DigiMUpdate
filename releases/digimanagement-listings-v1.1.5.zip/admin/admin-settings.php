<?php

// === Register Settings ===
add_action('admin_init', function () {
    register_setting('digimanagement_settings_group', 'digimanagement_api_key');
    register_setting('digimanagement_settings_group', 'digimanagement_api_url');

    // === Main Config Section
    add_settings_section(
        'digimanagement_api_section',
        __('API Configuration', 'digim-integration'),
        function () {
            echo '<p>' . esc_html__('Configure your Hospitable API connection settings.', 'digim-integration') . '</p>';
        },
        'digimanagement-settings'
    );

    add_settings_field(
        'digimanagement_api_key',
        __('Personal Access Token', 'digim-integration'),
        'digim_render_api_key_field',
        'digimanagement-settings',
        'digimanagement_api_section'
    );

    add_settings_field(
        'digimanagement_api_url',
        __('API Endpoint', 'digim-integration'),
        'digim_render_api_url_field',
        'digimanagement-settings',
        'digimanagement_api_section'
    );
});

// === Render API Key Field ===
function digim_render_api_key_field()
{
    $value = esc_attr(get_option('digimanagement_api_key', ''));
    echo '<div class="digim-input-group">';
    echo '<input type="password" name="digimanagement_api_key" value="' . $value . '" id="api_key_field" placeholder="Enter your Personal Access Token">';
    echo '<span class="input-icon dashicons dashicons-lock"></span>';
    echo '</div>';
    echo '<p class="digim-description">' . esc_html__('Enter your Hospitable Personal Access Token. You can find this in your Hospitable account settings.', 'digim-integration') . '</p>';
}

// === Render API URL Field ===
function digim_render_api_url_field()
{
    $value = esc_attr(get_option('digimanagement_api_url', ''));
    echo '<div class="digim-input-group">';
    echo '<input type="url" name="digimanagement_api_url" value="' . $value . '" id="api_url_field" placeholder="https://api.hospitable.com">';
    echo '<span class="input-icon dashicons dashicons-admin-links"></span>';
    echo '</div>';
    echo '<p class="digim-description">' . esc_html__('The Hospitable API endpoint URL. Usually: https://api.hospitable.com', 'digim-integration') . '</p>';
}

// === Render Full Settings Page ===
function digimanagement_render_settings_page()
{
    // Enqueue admin styles
    wp_enqueue_style('digim-admin-css', plugin_dir_url(__FILE__) . '../assets/css/admin.css', [], '1.0.0');
    wp_enqueue_script('digim-admin-js', plugin_dir_url(__FILE__) . '../assets/js/admin.js', ['jquery'], '1.0.0', true);
    
    // Localize script for AJAX
    wp_localize_script('digim-admin-js', 'digim_ajax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('digim_api_test_nonce'),
        'strings' => [
            'testing' => __('Testing API connection...', 'DigiM'),
            'success' => __('API connection successful!', 'DigiM'),
            'error' => __('API connection failed!', 'DigiM'),
            'invalid_credentials' => __('Please enter both API key and URL', 'DigiM')
        ]
    ]);

    echo '<div class="digim-admin-wrapper">';
    
    // Header
    echo '<div class="digim-header">';
    echo '<h1>' . esc_html__('DigiManagement Settings', 'DigiM') . '</h1>';
    echo '<p class="digim-subtitle">' . esc_html__('Configure your Hospitable integration settings', 'DigiM') . '</p>';
    echo '</div>';
    
    // Content
    echo '<div class="digim-content">';
    
    // Settings Form
    echo '<div class="digim-form-section">';
    
    echo '<form method="post" action="options.php" id="digim-settings-form">';
    settings_fields('digimanagement_settings_group');
    do_settings_sections('digimanagement-settings');
    
    echo '<div class="digim-button-group">';
    submit_button(__('Save Settings', 'DigiM'), 'primary', 'submit', false);
    echo '</div>';
    echo '</form>';
    echo '</div>';
    
    // API Testing Section
    echo '<div class="digim-api-test-section">';
    echo '<h3><span class="dashicons dashicons-admin-tools"></span> ' . esc_html__('API Connection Test', 'DigiM') . '</h3>';
    echo '<p>' . esc_html__('Test your API connection to ensure everything is working correctly.', 'DigiM') . '</p>';
    
    echo '<div class="digim-button-group">';
    echo '<button type="button" id="test-api-btn" class="button button-secondary">';
    echo '<span class="dashicons dashicons-admin-plugins"></span> ' . esc_html__('Test API Connection', 'DigiM');
    echo '</button>';
    echo '<button type="button" id="clear-test-results" class="button button-warning" style="display: none;">';
    echo '<span class="dashicons dashicons-dismiss"></span> ' . esc_html__('Clear Results', 'DigiM');
    echo '</button>';
    echo '</div>';
    
    echo '<div id="api-test-results" style="display: none;"></div>';
    echo '</div>';
    
    // Status Cards
    echo '<div class="digim-card">';
    echo '<div class="card-header">';
    echo '<h3><span class="dashicons dashicons-info"></span> ' . esc_html__('Connection Status', 'DigiM') . '</h3>';
    echo '</div>';
    echo '<div class="card-body">';
    echo '<div id="connection-status">';
    echo '<p>' . esc_html__('Configure your API settings above and test the connection to see status information.', 'DigiM') . '</p>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    
    echo '</div>'; // End digim-content
    echo '</div>'; // End digim-admin-wrapper
}

// === AJAX Handler for API Testing ===
add_action('wp_ajax_digim_test_api', 'digimanagement_ajax_test_api');

function digimanagement_ajax_test_api()
{
    // Verify nonce
    if (!wp_verify_nonce($_POST['nonce'], 'digim_api_test_nonce')) {
        wp_die('Security check failed');
    }

    $api_token = sanitize_text_field($_POST['api_key']);
    $api_url = sanitize_url($_POST['api_url']);

    if (empty($api_token) || empty($api_url)) {
        wp_send_json_error([
            'message' => __('Please enter both API key and URL', 'DigiM'),
            'type' => 'error'
        ]);
    }

    $api_url = rtrim($api_url, '/');
    $test_endpoint = $api_url . '/me';

    $response = wp_remote_get($test_endpoint, [
        'headers' => [
            'Authorization' => 'Bearer ' . $api_token,
            'Accept'        => 'application/json',
            'User-Agent'    => 'DigiManagement WordPress Plugin'
        ],
        'timeout' => 15,
        'sslverify' => true
    ]);

    $result = [
        'endpoint' => $test_endpoint,
        'timestamp' => current_time('mysql'),
        'response_time' => 0
    ];

    if (is_wp_error($response)) {
        $result['status'] = 'error';
        $result['message'] = $response->get_error_message();
        $result['error_code'] = $response->get_error_code();
        wp_send_json_error($result);
    }

    $code = wp_remote_retrieve_response_code($response);
    $headers = wp_remote_retrieve_headers($response);
    $body = wp_remote_retrieve_body($response);
    $response_time = microtime(true) - $_SERVER['REQUEST_TIME_FLOAT'];

    $result['status_code'] = $code;
    $result['response_time'] = round($response_time * 1000, 2);
    $result['headers'] = $headers->getAll();
    $result['body'] = $body;

    if ($code === 200) {
        $data = json_decode($body, true);
        if ($data && isset($data['email'])) {
            $result['status'] = 'success';
            $result['message'] = sprintf(__('Successfully connected as %s', 'DigiM'), $data['email']);
            $result['user_data'] = $data;
            wp_send_json_success($result);
        } else {
            $result['status'] = 'warning';
            $result['message'] = __('API responded with 200 but no user data found', 'DigiM');
            wp_send_json_success($result);
        }
    } else {
        $result['status'] = 'error';
        $result['message'] = sprintf(__('API returned HTTP %d', 'DigiM'), $code);
        wp_send_json_error($result);
    }
}

// === Legacy API Test Function (for backward compatibility) ===
function digimanagement_run_api_test()
{
    $api_token = get_option('digimanagement_api_key', '');
    $api_url = rtrim(get_option('digimanagement_api_url', ''), '/');

    if (!$api_token || !$api_url) {
        echo '<div class="notice notice-error"><p><strong>Missing API Key or URL.</strong></p></div>';
        return;
    }

    $response = wp_remote_get($api_url . '/me', [
        'headers' => [
            'Authorization' => 'Bearer ' . $api_token,
            'Accept'        => 'application/json',
        ],
        'timeout' => 10,
    ]);

    if (is_wp_error($response)) {
        echo '<div class="notice notice-error"><p><strong>API Test Failed:</strong> ' . esc_html($response->get_error_message()) . '</p></div>';
        return;
    }

    $code = wp_remote_retrieve_response_code($response);
    $body = json_decode(wp_remote_retrieve_body($response), true);

    if ($code === 200 && isset($body['email'])) {
        echo '<div class="notice notice-success"><p><strong>Success!</strong> Connected as <code>' . esc_html($body['email']) . '</code> ✅</p></div>';
    } else {
        echo '<div class="notice notice-warning"><p><strong>API Response:</strong> HTTP ' . esc_html($code) . '</p></div>';
    }
}
