jQuery(document).ready(function ($) {
    'use strict';

    if (typeof digimAmenities === 'undefined') {
        return;
    }

    const $list = $('#digim-amenities-list');
    const $status = $('#digim-amenities-status');
    const $saveBtn = $('#digim-amenities-save');

    function showStatus(type, message) {
        $status
            .removeClass('notice-success notice-error notice-warning')
            .addClass('notice-' + type)
            .text(message)
            .show();
    }

    function clearStatus() {
        $status.hide().text('').removeClass('notice-success notice-error notice-warning');
    }

    function renderAmenities(items) {
        $list.empty();

        if (!items || !items.length) {
            $list.append(
                $('<li>').text('No amenities found from Hospitable API.')
            );
            return;
        }

        items.forEach(function (item) {
            const slug = item.slug || '';
            const defaultLabel = item.label || slug;
            const customLabel = item.custom_label || '';
            const count = item.count || 0;

            const $li = $('<li>')
                .attr('data-slug', slug);

            const $handle = $('<span>')
                .addClass('amenity-handle dashicons dashicons-move')
                .attr('title', 'Drag to reorder');

            const $input = $('<input>')
                .attr('type', 'text')
                .addClass('regular-text amenity-label-input')
                .attr('placeholder', defaultLabel)
                .val(customLabel);

            const $meta = $('<span>')
                .addClass('amenity-meta')
                .text('#' + slug + ' • ' + count + ' properties');

            $li.append($handle, $input, $meta);
            $list.append($li);
        });

        // Enable sortable
        $list.sortable({
            axis: 'y',
            handle: '.amenity-handle',
            placeholder: 'ui-state-highlight'
        });
    }

    function fetchAmenities() {
        clearStatus();
        $('#digim-amenities-loading').show();

        $.ajax({
            url: digimAmenities.ajax_url,
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'digim_fetch_amenities',
                nonce: digimAmenities.nonce
            }
        })
            .done(function (response) {
                $('#digim-amenities-loading').hide();
                if (!response || !response.success) {
                    showStatus('error', digimAmenities.strings.error || 'Failed to load amenities.');
                    return;
                }
                renderAmenities(response.data.amenities || []);
            })
            .fail(function () {
                $('#digim-amenities-loading').hide();
                showStatus('error', digimAmenities.strings.error || 'Failed to load amenities.');
            });
    }

    function collectItems() {
        const items = [];
        $list.find('li').each(function () {
            const $li = $(this);
            const slug = $li.data('slug');
            if (!slug) {
                return;
            }
            const label = $.trim($li.find('.amenity-label-input').val());
            items.push({
                slug: slug,
                label: label
            });
        });
        return items;
    }

    function saveAmenities() {
        clearStatus();

        const items = collectItems();
        $saveBtn.prop('disabled', true).text(digimAmenities.strings.saving || 'Saving…');

        $.ajax({
            url: digimAmenities.ajax_url,
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'digim_save_amenities_order',
                nonce: digimAmenities.nonce,
                items: items
            }
        })
            .done(function (response) {
                if (response && response.success) {
                    showStatus('success', digimAmenities.strings.saved || 'Saved.');
                } else {
                    showStatus('error', digimAmenities.strings.error || 'Failed to save amenities.');
                }
            })
            .fail(function () {
                showStatus('error', digimAmenities.strings.error || 'Failed to save amenities.');
            })
            .always(function () {
                $saveBtn.prop('disabled', false).text(digimAmenities.strings.saved ? 'Save Amenities Order' : 'Save');
            });
    }

    // Initial load
    fetchAmenities();

    // Save button
    $saveBtn.on('click', function (e) {
        e.preventDefault();
        saveAmenities();
    });
});

