<?php
// Amenities Ordering admin page and AJAX

// Enqueue assets only on Amenities Ordering page
add_action('admin_enqueue_scripts', function ($hook) {
    if (!isset($_GET['page']) || $_GET['page'] !== 'DigiM-amenities') {
        return;
    }

    // Base admin styles
    wp_enqueue_style(
        'digim-admin-css',
        plugin_dir_url(__FILE__) . '../assets/css/admin.css',
        [],
        '1.0.0'
    );

    // jQuery UI Sortable for drag & drop
    wp_enqueue_script('jquery-ui-sortable');

    // Amenities Ordering JS
    $js_rel = '../assets/js/amenities-order.js';
    $js_abs = plugin_dir_path(__FILE__) . $js_rel;

    wp_enqueue_script(
        'digim-amenities-order-js',
        plugin_dir_url(__FILE__) . $js_rel,
        ['jquery', 'jquery-ui-sortable'],
        file_exists($js_abs) ? filemtime($js_abs) : '1.0.0',
        true
    );

    // Localize script with AJAX info
    wp_localize_script('digim-amenities-order-js', 'digimAmenities', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('digim_amenities_order_nonce'),
        'strings'  => [
            'loading' => __('Loading amenities…', 'DigiM'),
            'saving'  => __('Saving amenities…', 'DigiM'),
            'saved'   => __('Amenities order saved!', 'DigiM'),
            'error'   => __('Something went wrong while saving.', 'DigiM'),
        ],
    ]);
});

/**
 * Normalize an amenity value to a slug-like key.
 *
 * @param mixed $amenity
 * @return string
 */
function digim_normalize_amenity($amenity)
{
    if (is_array($amenity)) {
        $amenity = $amenity['name'] ?? $amenity['slug'] ?? $amenity['id'] ?? '';
    }
    $amenity = (string) $amenity;

    return trim(preg_replace('/[^a-z0-9]+/', '_', strtolower($amenity)), '_');
}

/**
 * Collect all amenities from Hospitable properties.
 *
 * @return array[] Each item: ['slug' => string, 'label' => string, 'count' => int]
 */
function digim_collect_all_amenities()
{
    if (!function_exists('digim_get_all_properties')) {
        return [];
    }

    $properties = digim_get_all_properties();
    $amenity_counts = [];

    foreach ($properties as $property) {
        $amenities = $property['amenities'] ?? [];
        if (!is_array($amenities)) {
            continue;
        }

        foreach ($amenities as $a) {
            $slug = digim_normalize_amenity($a);
            if ($slug === '') {
                continue;
            }

            // Derive a human label from the raw amenity
            if (is_array($a)) {
                $raw = $a['name'] ?? $a['slug'] ?? $a['id'] ?? $slug;
            } else {
                $raw = $a;
            }
            $default_label = ucwords(preg_replace('/[_-]+/', ' ', (string) $raw));

            if (!isset($amenity_counts[$slug])) {
                $amenity_counts[$slug] = [
                    'slug'   => $slug,
                    'label'  => $default_label,
                    'count'  => 0,
                ];
            }

            $amenity_counts[$slug]['count']++;
        }
    }

    return array_values($amenity_counts);
}

// AJAX: Fetch amenities list for admin UI
add_action('wp_ajax_digim_fetch_amenities', function () {
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'digim_amenities_order_nonce')) {
        wp_send_json_error(['message' => 'Bad nonce']);
    }
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Insufficient permissions']);
    }

    $all_amenities = digim_collect_all_amenities();
    $saved_order   = get_option('digim_amenities_order', []);
    $saved_labels  = get_option('digim_amenities_labels', []);

    // Index amenities by slug
    $by_slug = [];
    foreach ($all_amenities as $item) {
        $by_slug[$item['slug']] = $item;
    }

    $ordered = [];

    // First, add in the saved order
    foreach ($saved_order as $slug) {
        if (!isset($by_slug[$slug])) {
            continue;
        }

        $item = $by_slug[$slug];
        $item['custom_label'] = isset($saved_labels[$slug]) && $saved_labels[$slug] !== ''
            ? $saved_labels[$slug]
            : '';
        $ordered[] = $item;
        unset($by_slug[$slug]);
    }

    // Then append any new amenities not yet ordered
    foreach ($by_slug as $slug => $item) {
        $item['custom_label'] = isset($saved_labels[$slug]) && $saved_labels[$slug] !== ''
            ? $saved_labels[$slug]
            : '';
        $ordered[] = $item;
    }

    wp_send_json_success([
        'amenities' => $ordered,
    ]);
});

// AJAX: Save amenities order & custom labels
add_action('wp_ajax_digim_save_amenities_order', function () {
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'digim_amenities_order_nonce')) {
        wp_send_json_error(['message' => 'Bad nonce']);
    }
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Insufficient permissions']);
    }

    $raw_items = $_POST['items'] ?? [];
    if (!is_array($raw_items)) {
        $raw_items = [];
    }

    $order  = [];
    $labels = [];

    foreach ($raw_items as $item) {
        if (!is_array($item)) {
            continue;
        }

        $slug = isset($item['slug']) ? sanitize_key($item['slug']) : '';
        if ($slug === '') {
            continue;
        }

        $order[] = $slug;

        $label = isset($item['label']) ? wp_unslash($item['label']) : '';
        $label = trim($label);
        if ($label !== '') {
            $labels[$slug] = sanitize_text_field($label);
        }
    }

    update_option('digim_amenities_order', $order);
    update_option('digim_amenities_labels', $labels);

    wp_send_json_success([
        'order_count'  => count($order),
        'labels_count' => count($labels),
    ]);
});

/**
 * Render Amenities Ordering admin page.
 */
function digim_render_amenities_order_page()
{
    ?>
    <div class="digim-ui-builder digim-amenities-builder">
        <div class="ui-builder-header">
            <div class="header-content">
                <h1><span class="dashicons dashicons-list-view"></span> <?php esc_html_e('Amenities Ordering', 'DigiM'); ?></h1>
                <p><?php esc_html_e('Update amenity names for clarity and drag to reorder them by importance. The order you define here is used on the single property page.', 'DigiM'); ?></p>
            </div>
        </div>

        <div class="ui-builder-content">
            <div class="ui-builder-sidebar" style="max-width: 900px; width: 100%;">
                <div class="ui-builder-form">
                    <div class="control-group">
                        <h3><span class="dashicons dashicons-filter"></span> <?php esc_html_e('Amenities Priority', 'DigiM'); ?></h3>
                        <p><?php esc_html_e('Drag and drop amenities to set their display priority. Edit the label to make each amenity more user-friendly. Changes affect all property pages.', 'DigiM'); ?></p>
                        <div id="digim-amenities-status" class="notice" style="display:none;"></div>

                        <ul id="digim-amenities-list" class="digim-card-list digim-amenities-list" aria-label="<?php esc_attr_e('Amenities ordering', 'DigiM'); ?>">
                            <li class="cb-loading-state" id="digim-amenities-loading">
                                <span class="spinner is-active"></span>
                                <?php esc_html_e('Loading amenities…', 'DigiM'); ?>
                            </li>
                        </ul>

                        <p class="description">
                            <?php esc_html_e('Top amenities in this list will be shown first in the amenities grid on the single property page.', 'DigiM'); ?>
                        </p>

                        <div class="control-item" style="margin-top:20px;">
                            <button type="button" class="button button-primary" id="digim-amenities-save">
                                <span class="dashicons dashicons-yes-alt"></span>
                                <?php esc_html_e('Save Amenities Order', 'DigiM'); ?>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <style>
        .digim-amenities-list {
            max-height: 600px;
            overflow-y: auto;
            border: 1px solid #ddd;
            border-radius: 6px;
            padding: 10px;
            background: #fff;
        }
        .digim-amenities-list li {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 8px 10px;
            border-bottom: 1px solid #eee;
            cursor: move;
        }
        .digim-amenities-list li:last-child {
            border-bottom: none;
        }
        .digim-amenities-list .amenity-handle {
            cursor: move;
            color: #888;
        }
        .digim-amenities-list .amenity-label-input {
            flex: 1;
        }
        .digim-amenities-list .amenity-meta {
            font-size: 11px;
            color: #666;
            white-space: nowrap;
        }
    </style>
    <?php
}

