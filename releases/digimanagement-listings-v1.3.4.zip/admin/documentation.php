<?php
/**
 * DigiManagement Plugin Documentation
 * Comprehensive guide for setting up and using the plugin
 */

function render_documentation_page() {
    // Enqueue admin styles
    wp_enqueue_style('digim-admin-css', plugin_dir_url(__FILE__) . '../assets/css/admin.css', [], '1.0.0');
    ?>
    <div class="digim-admin-wrapper">
        <div class="digim-header">
            <h1><span class="dashicons dashicons-book-alt"></span> DigiManagement Plugin Documentation</h1>
            <p class="digim-subtitle">Complete guide to setting up and using the DigiManagement plugin</p>
        </div>

        <div class="digim-content" style="max-width: 1200px;">
            
            <!-- Table of Contents -->
            <div class="digim-card" style="margin-bottom: 30px;">
                <div class="card-header">
                    <h2><span class="dashicons dashicons-list-view"></span> Table of Contents</h2>
                </div>
                <div class="card-body">
                    <ol style="line-height: 2;">
                        <li><a href="#initial-setup">Initial Setup & Configuration</a></li>
                        <li><a href="#shortcode-basics">Shortcode Basics</a></li>
                        <li><a href="#card-builder">Card Builder Guide</a></li>
                        <li><a href="#ui-builder">UI Builder Guide</a></li>
                        <li><a href="#widget-setup">Widget Setup & Customization</a></li>
                        <li><a href="#advanced-usage">Advanced Usage</a></li>
                    </ol>
                </div>
            </div>

            <!-- Initial Setup Section -->
            <div id="initial-setup" class="digim-card" style="margin-bottom: 30px;">
                <div class="card-header">
                    <h2><span class="dashicons dashicons-admin-settings"></span> Initial Setup & Configuration</h2>
                </div>
                <div class="card-body">
                    <h3>Step 1: Configure API Settings</h3>
                    <p>Before using the plugin, you need to configure your Hospitable API connection:</p>
                    <ol>
                        <li>Navigate to <strong>DigiManagement → Settings</strong> in your WordPress admin</li>
                        <li>Enter your <strong>Personal Access Token</strong>:
                            <ul>
                                <li>You can find this in your Hospitable account settings</li>
                                <li>This token is required to fetch property data from the API</li>
                            </ul>
                        </li>
                        <li>Enter the <strong>API Endpoint</strong>:
                            <ul>
                                <li>Default endpoint: <code>https://public.api.hospitable.com/v2</code></li>
                                <li>This is the base URL for all API requests</li>
                            </ul>
                        </li>
                        <li>Click <strong>Save Settings</strong></li>
                        <li>Test your connection using the <strong>Test API Connection</strong> button</li>
                    </ol>

                    <h3>Step 2: Configure Widget ID (Optional but Recommended)</h3>
                    <p>For custom widget colors and styling, you need to add your Widget ID:</p>
                    <ol>
                        <li>Go to <strong>Hospitable → Direct</strong> in your Hospitable dashboard</li>
                        <li>Select your property site</li>
                        <li>Navigate to <strong>Properties</strong></li>
                        <li>Click on <strong>Enable widgets</strong> for your property</li>
                        <li>Copy the widget code URL. Example:
                            <div style="background: #f5f5f5; padding: 15px; border-radius: 5px; margin: 10px 0;">
                                <code style="font-size: 14px;">https://booking.hospitable.com/widget/<strong style="background: yellow; padding: 2px 4px;">9b9dd32a-2d37-4494-94ba-07bcf22fb1ac</strong>/xxxxxxx</code>
                            </div>
                        </li>
                        <li><strong>Important:</strong> Copy <strong>ONLY</strong> the highlighted part (the Widget ID):
                            <ul>
                                <li>From the example above, copy: <code>9b9dd32a-2d37-4494-94ba-07bcf22fb1ac</code></li>
                                <li>Ignore the rest of the URL (the property ID at the end)</li>
                            </ul>
                        </li>
                        <li>Paste this Widget ID into the <strong>Widget ID</strong> field in DigiManagement Settings</li>
                        <li>Save your settings</li>
                    </ol>

                    <div class="notice notice-info" style="margin: 20px 0; padding: 15px;">
                        <p><strong>Note:</strong> If you don't have a custom widget code, the plugin will use the default theme. The iframe and URL will automatically include <code>theme=default</code> parameter.</p>
                    </div>
                </div>
            </div>

            <!-- Shortcode Basics Section -->
            <div id="shortcode-basics" class="digim-card" style="margin-bottom: 30px;">
                <div class="card-header">
                    <h2><span class="dashicons dashicons-shortcode"></span> Shortcode Basics</h2>
                </div>
                <div class="card-body">
                    <h3>Main Listings Shortcode</h3>
                    <p>The main shortcode displays all your properties with the settings configured in the UI Builder:</p>
                    <div style="background: #f5f5f5; padding: 15px; border-radius: 5px; margin: 10px 0;">
                        <code>[digimanagement_listings]</code>
                    </div>
                    <p>This shortcode will display all properties in the layout style you've configured in the UI Builder.</p>

                    <h3>Card Shortcode (Custom Sets)</h3>
                    <p>Use the Card Builder to create custom property sets, then display them with:</p>
                    <div style="background: #f5f5f5; padding: 15px; border-radius: 5px; margin: 10px 0;">
                        <code>[digim_cards id="your-set-id"]</code>
                    </div>
                    <p>See the <a href="#card-builder">Card Builder Guide</a> section below for detailed instructions.</p>
                </div>
            </div>

            <!-- Card Builder Section -->
            <div id="card-builder" class="digim-card" style="margin-bottom: 30px;">
                <div class="card-header">
                    <h2><span class="dashicons dashicons-screenoptions"></span> Card Builder Guide</h2>
                </div>
                <div class="card-body">
                    <h3>What is the Card Builder?</h3>
                    <p>The Card Builder allows you to create curated sets of properties that you can display anywhere on your site using shortcodes. You can create multiple sets for different purposes (e.g., "Featured Properties", "Beachfront Villas", "City Apartments").</p>

                    <h3>How to Use the Card Builder</h3>
                    <ol>
                        <li>Navigate to <strong>DigiManagement → Card Builder</strong></li>
                        <li><strong>Create a New Set:</strong>
                            <ul>
                                <li>Click the <strong>New Set</strong> button in the header</li>
                                <li>Or select an existing set from the dropdown to edit it</li>
                            </ul>
                        </li>
                        <li><strong>Configure Settings:</strong>
                            <ul>
                                <li><strong>Title:</strong> Give your set a descriptive name (e.g., "Featured Villas")</li>
                                <li><strong>Display as slider:</strong> Enable this to show properties in a carousel/slider format</li>
                                <li><strong>Grid Columns:</strong> Choose how many columns to display (2-6 columns)</li>
                                <li><strong>Random properties listing:</strong> Enable to randomize the order of properties each time the page loads</li>
                            </ul>
                        </li>
                        <li><strong>Select Properties:</strong>
                            <ul>
                                <li>Use the search box to find properties by name or city</li>
                                <li>Click on properties in the <strong>Available Properties</strong> list to select them</li>
                                <li>Click the <strong>Add →</strong> button to move selected properties to your set</li>
                                <li>You can also drag and drop properties between lists</li>
                                <li>Reorder properties in the <strong>Selected Properties</strong> list by dragging them</li>
                            </ul>
                        </li>
                        <li><strong>Preview:</strong>
                            <ul>
                                <li>Click the <strong>Preview</strong> button to see how your set will look</li>
                                <li>The preview updates in real-time as you make changes</li>
                            </ul>
                        </li>
                        <li><strong>Save:</strong>
                            <ul>
                                <li>Click <strong>Save Set</strong> to save your configuration</li>
                                <li>After saving, you'll see a shortcode that you can copy</li>
                            </ul>
                        </li>
                    </ol>

                    <h3>Creating Shortcodes with Randomized Posts</h3>
                    <p>To create a shortcode that displays properties in random order:</p>
                    <ol>
                        <li>In the Card Builder, enable the <strong>Random properties listing</strong> checkbox</li>
                        <li>Select the properties you want to include</li>
                        <li>Save your set</li>
                        <li>Copy the generated shortcode (e.g., <code>[digim_cards id="abc123"]</code>)</li>
                        <li>Paste it into any page, post, or widget where you want to display the properties</li>
                    </ol>
                    <p><strong>Result:</strong> Each time a visitor loads the page, the properties will appear in a different random order.</p>

                    <h3>Creating Shortcodes with Slider</h3>
                    <p>To create a shortcode that displays properties in a slider/carousel:</p>
                    <ol>
                        <li>In the Card Builder, enable the <strong>Display as slider</strong> checkbox</li>
                        <li>Select the properties you want to include</li>
                        <li>Choose your <strong>Grid Columns</strong> (this determines how many properties are visible at once)</li>
                        <li>Save your set</li>
                        <li>Copy the generated shortcode</li>
                        <li>Paste it into any page, post, or widget</li>
                    </ol>
                    <p><strong>Result:</strong> Properties will be displayed in a beautiful slider with navigation arrows and pagination dots. Visitors can swipe or click to navigate through properties.</p>

                    <h3>Combining Features</h3>
                    <p>You can combine both features:</p>
                    <ul>
                        <li>Enable both <strong>Random properties listing</strong> and <strong>Display as slider</strong></li>
                        <li>This will create a slider that shows properties in random order</li>
                        <li>Each page load will show a different random arrangement</li>
                    </ul>

                    <h3>Example Use Cases</h3>
                    <ul>
                        <li><strong>Homepage Featured Section:</strong> Create a "Featured Properties" set with slider enabled, 3 columns</li>
                        <li><strong>Sidebar Widget:</strong> Create a "Random Properties" set with random enabled, 1 column</li>
                        <li><strong>Category Pages:</strong> Create different sets for different property types (villas, apartments, etc.)</li>
                        <li><strong>Special Promotions:</strong> Create temporary sets for seasonal promotions or special offers</li>
                    </ul>
                </div>
            </div>

            <!-- UI Builder Section -->
            <div id="ui-builder" class="digim-card" style="margin-bottom: 30px;">
                <div class="card-header">
                    <h2><span class="dashicons dashicons-admin-customizer"></span> UI Builder Guide</h2>
                </div>
                <div class="card-body">
                    <h3>What is the UI Builder?</h3>
                    <p>The UI Builder allows you to customize the appearance and behavior of your main property listings. All changes you make here will affect how properties are displayed when you use the <code>[digimanagement_listings]</code> shortcode.</p>

                    <h3>How the UI Builder Works</h3>
                    <ol>
                        <li>Navigate to <strong>DigiManagement → UI Builder</strong></li>
                        <li>The interface is split into two sections:
                            <ul>
                                <li><strong>Left Sidebar:</strong> All the customization controls</li>
                                <li><strong>Right Side:</strong> Live preview of your changes</li>
                            </ul>
                        </li>
                        <li><strong>Layout Settings:</strong>
                            <ul>
                                <li><strong>Layout Style:</strong> Choose between Grid or List layout</li>
                                <li><strong>Grid Columns:</strong> When using Grid layout, choose how many columns (2-6)</li>
                                <li><strong>Cards Per Page:</strong> Set how many properties to show per page</li>
                            </ul>
                        </li>
                        <li><strong>Card Style:</strong>
                            <ul>
                                <li>Choose from different card design styles</li>
                                <li>Each style has a different visual appearance</li>
                            </ul>
                        </li>
                        <li><strong>Color Customization:</strong>
                            <ul>
                                <li><strong>Primary Color:</strong> Set your brand color</li>
                                <li>This color is used for buttons, links, and accent elements</li>
                            </ul>
                        </li>
                        <li><strong>Display Options:</strong>
                            <ul>
                                <li>Toggle map display on/off</li>
                                <li>Show/hide capacity information (guests, bedrooms, beds, bathrooms)</li>
                                <li>Customize which capacity details to display</li>
                            </ul>
                        </li>
                        <li><strong>Live Preview:</strong>
                            <ul>
                                <li>As you make changes, the preview updates automatically</li>
                                <li>Use the <strong>Refresh</strong> button if the preview doesn't update</li>
                            </ul>
                        </li>
                        <li><strong>Save Settings:</strong>
                            <ul>
                                <li>Click <strong>Save UI Settings</strong> to apply your changes</li>
                                <li>All listings using <code>[digimanagement_listings]</code> will reflect your new settings</li>
                            </ul>
                        </li>
                    </ol>

                    <h3>Understanding the Preview</h3>
                    <p>The live preview shows exactly how your properties will appear to visitors. It uses real property data from your Hospitable account, so you can see actual images, prices, and details.</p>

                    <h3>Best Practices</h3>
                    <ul>
                        <li>Start with a layout style that matches your website's design</li>
                        <li>Use your brand's primary color for consistency</li>
                        <li>Test different card styles to see which looks best with your property images</li>
                        <li>Consider your visitors' devices - grid layouts work well on desktop, list layouts can be better for mobile</li>
                        <li>Don't show too many properties per page - 12-24 is usually optimal</li>
                    </ul>
                </div>
            </div>

            <!-- Widget Setup Section -->
            <div id="widget-setup" class="digim-card" style="margin-bottom: 30px;">
                <div class="card-header">
                    <h2><span class="dashicons dashicons-calendar-alt"></span> Widget Setup & Customization</h2>
                </div>
                <div class="card-body">
                    <h3>Booking Widget Overview</h3>
                    <p>The booking widget appears on individual property pages and allows visitors to check availability, select dates, and make reservations directly from your website.</p>

                    <h3>Custom Widget Colors</h3>
                    <p>To customize the widget colors to match your website:</p>
                    <ol>
                        <li>Go to <strong>Hospitable → Direct</strong> in your Hospitable dashboard</li>
                        <li>Select your property site</li>
                        <li>Navigate to <strong>Properties</strong></li>
                        <li>Click on <strong>Enable widgets</strong> for your property</li>
                        <li>Copy the widget code URL</li>
                        <li>Extract the Widget ID from the URL (the UUID part)</li>
                        <li>Add this Widget ID in <strong>DigiManagement → Settings → Widget ID</strong></li>
                        <li>Save your settings</li>
                    </ol>

                    <h3>Default Theme (No Custom Widget)</h3>
                    <p>If you don't have a custom widget code:</p>
                    <ul>
                        <li>The plugin will automatically use the default theme</li>
                        <li>Both the iframe and URL will include <code>theme=default</code> parameter</li>
                        <li>You can still customize the widget using CSS classes</li>
                        <li>Add theme classes to your custom CSS if needed</li>
                    </ul>

                    <h3>Widget URL Structure</h3>
                    <p>The widget URL follows this pattern:</p>
                    <div style="background: #f5f5f5; padding: 15px; border-radius: 5px; margin: 10px 0;">
                        <code>https://booking.hospitable.com/widget/{WIDGET_ID}/{PROPERTY_ID}?theme=default</code>
                    </div>
                    <p>Where:</p>
                    <ul>
                        <li><strong>WIDGET_ID:</strong> Your custom widget ID (from settings) or default ID</li>
                        <li><strong>PROPERTY_ID:</strong> The specific property's ID</li>
                        <li><strong>theme=default:</strong> Added automatically if no custom widget ID is set</li>
                    </ul>
                </div>
            </div>

            <!-- Advanced Usage Section -->
            <div id="advanced-usage" class="digim-card" style="margin-bottom: 30px;">
                <div class="card-header">
                    <h2><span class="dashicons dashicons-admin-tools"></span> Advanced Usage</h2>
                </div>
                <div class="card-body">
                    <h3>Using Shortcodes in Different Contexts</h3>
                    <ul>
                        <li><strong>Pages & Posts:</strong> Simply paste the shortcode in the content editor</li>
                        <li><strong>Widgets:</strong> Use a Text widget and paste the shortcode</li>
                        <li><strong>Theme Templates:</strong> Use <code>&lt;?php echo do_shortcode('[digim_cards id="your-id"]'); ?&gt;</code></li>
                        <li><strong>Elementor/Page Builders:</strong> Use the Shortcode widget element</li>
                    </ul>

                    <h3>Multiple Shortcodes on One Page</h3>
                    <p>You can use multiple shortcodes on the same page:</p>
                    <ul>
                        <li>Use different card sets for different sections</li>
                        <li>Combine the main listings shortcode with custom card sets</li>
                        <li>Each shortcode works independently</li>
                    </ul>

                    <h3>Troubleshooting</h3>
                    <h4>Properties Not Showing</h4>
                    <ul>
                        <li>Check that your API key and endpoint are correct in Settings</li>
                        <li>Test the API connection using the Test button</li>
                        <li>Verify that properties exist in your Hospitable account</li>
                    </ul>

                    <h4>Widget Not Loading</h4>
                    <ul>
                        <li>Verify your Widget ID is correct (if using custom widget)</li>
                        <li>Check browser console for JavaScript errors</li>
                        <li>Ensure the property ID is valid</li>
                    </ul>

                    <h4>Styling Issues</h4>
                    <ul>
                        <li>Clear your browser cache</li>
                        <li>Check for CSS conflicts with your theme</li>
                        <li>Use browser developer tools to inspect elements</li>
                    </ul>

                    <h3>API Endpoint Information</h3>
                    <p><strong>Current API Endpoint:</strong> <code>https://public.api.hospitable.com/v2</code></p>
                    <p>This endpoint is used for all property data fetching. Make sure this URL is correctly configured in your settings.</p>
                </div>
            </div>

            <!-- Quick Reference -->
            <div class="digim-card" style="margin-bottom: 30px;">
                <div class="card-header">
                    <h2><span class="dashicons dashicons-lightbulb"></span> Quick Reference</h2>
                </div>
                <div class="card-body">
                    <table class="widefat" style="margin-top: 15px;">
                        <thead>
                            <tr>
                                <th>Feature</th>
                                <th>Location</th>
                                <th>Shortcode</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>All Properties Listings</td>
                                <td>UI Builder</td>
                                <td><code>[digimanagement_listings]</code></td>
                            </tr>
                            <tr>
                                <td>Custom Property Sets</td>
                                <td>Card Builder</td>
                                <td><code>[digim_cards id="set-id"]</code></td>
                            </tr>
                            <tr>
                                <td>Randomized Properties</td>
                                <td>Card Builder → Random checkbox</td>
                                <td><code>[digim_cards id="set-id"]</code></td>
                            </tr>
                            <tr>
                                <td>Slider/Carousel</td>
                                <td>Card Builder → Slider checkbox</td>
                                <td><code>[digim_cards id="set-id"]</code></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Support Section -->
            <div class="digim-card">
                <div class="card-header">
                    <h2><span class="dashicons dashicons-sos"></span> Need Help?</h2>
                </div>
                <div class="card-body">
                    <p>If you encounter any issues or have questions:</p>
                    <ul>
                        <li>Review this documentation thoroughly</li>
                        <li>Check that all settings are configured correctly</li>
                        <li>Test your API connection in Settings</li>
                        <li>Verify your Widget ID format is correct</li>
                    </ul>
                    <p><strong>Remember:</strong> Always save your settings after making changes, and test your shortcodes on a test page before using them on your live site.</p>
                </div>
            </div>

        </div>
    </div>

    <style>
        .digim-content h3 {
            margin-top: 25px;
            margin-bottom: 15px;
            color: #23282d;
            font-size: 18px;
        }
        .digim-content h4 {
            margin-top: 20px;
            margin-bottom: 10px;
            color: #23282d;
            font-size: 16px;
        }
        .digim-content ol, .digim-content ul {
            margin-left: 20px;
            margin-bottom: 15px;
        }
        .digim-content li {
            margin-bottom: 8px;
        }
        .digim-content code {
            background: #f0f0f0;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: 'Courier New', monospace;
        }
        .digim-content table {
            margin-top: 15px;
        }
        .digim-content table th {
            font-weight: 600;
        }
        .digim-content a {
            color: #0073aa;
            text-decoration: none;
        }
        .digim-content a:hover {
            text-decoration: underline;
        }
    </style>
    <?php
}