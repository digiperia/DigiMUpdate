# Pricing Display Feature Documentation

## Overview
The DigiM plugin displays property prices on listing cards using **exact data from the Hospitable Quote API**, matching what users see in the Hospitable iframe widget. The layout and style match Airbnb: clean, minimal, **no gradients**—dark/medium grey typography on white.

- **Date range** (e.g. "Feb 3 – 8") from search check-in/check-out
- **Total for stay** (e.g. "$177 for 5 nights") — bold, underlined; same as widget
- **Discount lines** from Hospitable (e.g. "Long stay discount -$20") — all items from `financials.discounts` with exact API labels

**Calendar-driven:** Prices are fetched from the **Hospitable Quote API** using the search check-in and check-out dates. Pricing is shown only when the user has selected dates.

## How It Works

### Data Source
- **Quote API** `financials.totals`: `sub_total`, `total` (amounts in cents).
- **Quote API** `financials.discounts`: array of `{ name, amount }` — we use the **exact** `name` / `type` / `label` from Hospitable (e.g. "Long stay discount"). Amount in cents, converted to dollars for display.

No property-level `tags` or `special_offers` are used for pricing; only Quote API data.

### Display Logic
```
Feb 3 – 8
$177 for 5 nights
Long stay discount -$20
```
- Date range: medium grey, regular weight.
- Total: bold, dark grey (#222), underlined; "for X nights" regular.
- Each discount: medium grey, same as date range; "Label -$X".

## Visual Design (Airbnb-style, no gradients)

- **Colors:** `#222` (total), `#717171` (date range, discount lines), `#ebebeb` (border). White background.
- **Font:** DM Sans; bold for total, regular for secondary text.
- **No gradients, no badges, no strike-through** — only Hospitable totals and discount lines.

### CSS Classes
- `.digim-pricing-section` — Container; border-top `#ebebeb`.
- `.digim-price-date-range` — Date range (e.g. "Feb 3 – 8").
- `.digim-price-display` — Wrapper for total line.
- `.digim-price-total` — Total amount (bold, underline).
- `.digim-price-for-nights` — "for X nights" (regular).
- `.digim-price-discount-line` — Each Hospitable discount line.

## Implementation Files

- **`digimanagement-listings.php`** — `digimanagement_parallel_quote_fetch()`: stores `checkin`, `checkout`, `total`, `discounts` (full array from API).
- **`includes/listings-template.php`** — Pricing block in `digim-card-content`: date range, total for X nights, discount lines.
- **`includes/shortcode.php`** — `digim_render_property_card`: same pricing block when `$digim_quote_map` is set.
- **`assets/css/style.scss`** — Pricing section styles (Airbnb-like, no gradients).

## Notes

- Pricing matches the Hospitable iframe widget (same Quote API total and discounts).
- All discount labels come from Hospitable (e.g. "Long stay discount"); we do not invent labels.
- System gracefully handles missing data (no errors if fields are absent).
