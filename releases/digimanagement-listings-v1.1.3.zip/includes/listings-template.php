<div class="digim-main digim-shortcode">
    <!-- Search Form -->
    <div class="bg-white">
        <form class="digimanagement-search" method="get">

            <div class="search-grid">
                <!-- WHERE -->
                <div class="search-group">
                    <label>Where</label>
                    <select name="property_search" class="city-select">
                        <option value="">Search destinations</option>
                        <?php foreach ($destination_names as $city): ?>
                            <option value="<?php echo esc_attr($city); ?>" <?php selected($search, $city); ?>>
                                <?php echo esc_html($city); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- CHECKIN / CHECKOUT -->
                <div class="search-group datecal">
                    <label>Check in / Check out</label>
                    <input type="text" name="date_range" class="flatpickr-range" placeholder="Add dates">
                    <input type="hidden" name="checkin" class="checkin-hidden" value="<?php echo esc_attr($checkin); ?>">
                    <input type="hidden" name="checkout" class="checkout-hidden" value="<?php echo esc_attr($checkout); ?>">
                </div>


                <!-- WHO -->
                <div class="search-group">
                    <label>Who</label>
                    <div class="guest-dropdown-wrapper">
                        <button type="button" class="guest-toggle">Add guests</button>
                        <div class="guest-dropdown">
                            <?php
                            $guest_types = [
                                'adults' => ['label' => 'Adults', 'desc' => 'Ages 13 or above'],
                                'children' => ['label' => 'Children', 'desc' => 'Ages 2–12'],
                                'infants' => ['label' => 'Infants', 'desc' => 'Under 2'],
                                'pets' => ['label' => 'Pets', 'desc' => '<a href="#">Bringing a service animal?</a>'],
                            ];
                            foreach ($guest_types as $type => $meta):
                                $val = intval($_GET[$type] ?? 0);
                            ?>
                                <div class="guest-row">
                                    <div class="guest-labels">
                                        <span><?= $meta['label'] ?></span>
                                        <span><?= $meta['desc'] ?></span>
                                    </div>
                                    <div class="guest-controls">
                                        <button type="button" class="minus">−</button>
                                        <span class="guest-count"><?= $val ?></span>
                                        <button type="button" class="plus">+</button>
                                        <input type="hidden" name="<?= $type ?>" value="<?= $val ?>" id="<?= $type ?>-input">
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <input type="hidden" name="guests" value="<?php echo esc_attr($guest_count); ?>" id="total-guests">
                    </div>
                </div>

                <!-- BUTTONS -->
                <div class="search-buttons">
                    <button type="button" class="reset-button" title="Reset"><i class="fas fa-undo"></i></button>
                    <button type="submit" class="search-button" title="Search"><i class="fas fa-search"></i></button>
                </div>
            </div>

        </form>

        <script>
            document.addEventListener("DOMContentLoaded", function() {
                const wrapper = document.querySelector(".guest-dropdown-wrapper");
                const toggleBtn = wrapper.querySelector(".guest-toggle");
                const guestRows = wrapper.querySelectorAll(".guest-row");
                const totalGuestsInput = wrapper.querySelector('input[name="guests"]');

                const updateGuestSummary = () => {
                    let guests = 0;
                    let infants = 0;
                    let pets = 0;

                    guestRows.forEach(row => {
                        const input = row.querySelector('input[type="hidden"]');
                        const count = parseInt(input.value) || 0;
                        const type = input.name;

                        if (type === "adults" || type === "children") guests += count;
                        else if (type === "infants") infants = count;
                        else if (type === "pets") pets = count;

                        row.querySelector(".guest-count").textContent = count;
                    });

                    let text = guests > 0 ? `${guests} guest${guests > 1 ? 's' : ''}` : "Add guests";
                    if (infants > 0) text += `, ${infants} infant${infants > 1 ? 's' : ''}`;
                    if (pets > 0) text += `, ${pets} pet${pets > 1 ? 's' : ''}`;

                    toggleBtn.textContent = text;
                    totalGuestsInput.value = guests;
                };

                // Apply increment/decrement events
                guestRows.forEach(row => {
                    const input = row.querySelector('input[type="hidden"]');
                    const minus = row.querySelector(".minus");
                    const plus = row.querySelector(".plus");

                    minus.addEventListener("click", () => {
                        let val = parseInt(input.value) || 0;
                        input.value = Math.max(0, val - 1);
                        updateGuestSummary();
                    });

                    plus.addEventListener("click", () => {
                        let val = parseInt(input.value) || 0;
                        input.value = val + 1;
                        updateGuestSummary();
                    });
                });

                // Toggle dropdown
                toggleBtn.addEventListener("click", () => {
                    wrapper.querySelector(".guest-dropdown").classList.toggle("active");
                });

                document.addEventListener("click", e => {
                    if (!wrapper.contains(e.target)) {
                        wrapper.querySelector(".guest-dropdown").classList.remove("active");
                    }
                });

                // Reset form
                document.querySelector('.reset-button').addEventListener("click", () => {
                    window.location.href = window.location.pathname;
                });

                updateGuestSummary();
            });
        </script>

        <?php
        $grid_class = $layout_style === 'list' ? 'digimanagement-list' : "digimanagement-grid grid-cols-$grid_columns";
        ?>
        <div class="dm-grid <?php echo $show_map ? 'map-listing' : ''; ?>">
            <div class="dm-property">
                <div class="<?php echo esc_attr($grid_class); ?>">

                    <?php if (empty($properties_to_show)): ?>
                        <p class="no-results" style="margin-top: 1rem;">No listings match your filters. Try changing date, location, or guest count.</p>
                    <?php else: ?>
                        <?php foreach ($properties_to_show as $property):
                            $original_picture = $property['picture'] ?? '';
                            $high_res_picture = preg_replace('/\?.*/', '', $original_picture);
                            $uuid = $property['uuid'] ?? $property['id'] ?? '';
                            $property_slug = digimanagement_create_property_slug(
                                $property['name'] ?? '', 
                                $property['address']['city'] ?? ''
                            );
                            $query_params = $_GET;
                            $query_string = http_build_query($query_params);
                            $property_url = site_url('/property/' . esc_attr($property_slug) . '/') . ($query_string ? '?' . $query_string : ''); ?>
                            <a href="<?php echo esc_url($property_url); ?>" class="digimanagement-card <?php echo esc_attr($card_style); ?>">
                                <?php if (!empty($high_res_picture)): ?>
                                    <div class="digim-card-img">
                                        <img src="<?php echo esc_url($high_res_picture); ?>" alt="<?php echo esc_attr($property['name']); ?>" />
                                    </div>
                                <?php endif; ?>
                                <div class="digim-card-content">
                                    <h3 class="digim-title"><?php echo esc_html($property['name'] ?? 'Untitled'); ?></h3>
                                    <?php if (!empty($property['address']['display'])): ?>
                                        <p class="digim-address">
                                            <span class="location-icon" aria-hidden="true">
                                                <svg width="11" height="13" viewBox="0 0 11 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M1.78795 1.75234C2.73221 0.826967 4.00352 0.311624 5.3256 0.318301C6.64769 0.324979 7.91372 0.853137 8.84859 1.78801C9.78346 2.72287 10.3116 3.98891 10.3183 5.31099C10.325 6.63308 9.80963 7.90439 8.88425 8.84865L6.23201 11.5009C5.99437 11.7385 5.67211 11.8719 5.3361 11.8719C5.00008 11.8719 4.67783 11.7385 4.44019 11.5009L1.78795 8.84865C0.846981 7.90759 0.318359 6.63129 0.318359 5.3005C0.318359 3.9697 0.846981 2.69341 1.78795 1.75234Z" stroke="#5E5E5E" stroke-width="0.636364" stroke-linejoin="round"/>
                                                    <path d="M5.33537 7.20137C6.38515 7.20137 7.23616 6.35036 7.23616 5.30058C7.23616 4.2508 6.38515 3.39978 5.33537 3.39978C4.28559 3.39978 3.43457 4.2508 3.43457 5.30058C3.43457 6.35036 4.28559 7.20137 5.33537 7.20137Z" stroke="#5E5E5E" stroke-width="0.636364" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                            </span>
                                            <?php echo esc_html($property['address']['display']); ?>
                                        </p>
                                    <?php endif; ?>

                                    <div class="capacity-grid">
                                        <?php if ($property['capacity']['max'] ?? ''): ?>
                                            <div class="capacity-item">
                                                <span class="icon-svg" aria-hidden="true">
                                                    <svg width="19" height="14" viewBox="0 0 19 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M13.0667 12.1334V14H0V12.1334C0 12.1334 0 8.40004 6.53333 8.40004C13.0667 8.40004 13.0667 12.1334 13.0667 12.1334ZM9.8 3.2667C9.8 2.62062 9.60842 1.98904 9.24947 1.45184C8.89052 0.914638 8.38034 0.495941 7.78343 0.248695C7.18653 0.00144844 6.52971 -0.0632425 5.89604 0.0628026C5.26237 0.188848 4.6803 0.499968 4.22345 0.956819C3.7666 1.41367 3.45548 1.99574 3.32944 2.62941C3.20339 3.26308 3.26808 3.9199 3.51533 4.5168C3.76257 5.11371 4.18127 5.62389 4.71847 5.98284C5.25567 6.34178 5.88725 6.53337 6.53333 6.53337C7.39971 6.53337 8.2306 6.1892 8.84322 5.57658C9.45584 4.96396 9.8 4.13308 9.8 3.2667ZM13.0107 8.40004C13.5844 8.84407 14.0539 9.40844 14.3861 10.0534C14.7183 10.6984 14.9051 11.4084 14.9333 12.1334V14H18.6667V12.1334C18.6667 12.1334 18.6667 8.74537 13.0107 8.40004ZM12.1333 3.43434e-05C11.491 -0.00295339 10.8629 0.189063 10.332 0.550701C10.8989 1.34286 11.2038 2.29257 11.2038 3.2667C11.2038 4.24083 10.8989 5.19055 10.332 5.9827C10.8629 6.34434 11.491 6.53636 12.1333 6.53337C12.9997 6.53337 13.8306 6.1892 14.4432 5.57658C15.0558 4.96396 15.4 4.13308 15.4 3.2667C15.4 2.40033 15.0558 1.56944 14.4432 0.956819C13.8306 0.3442 12.9997 3.43434e-05 12.1333 3.43434e-05Z" fill="#274D55"/>
                                                    </svg>
                                                </span>
                                                <span class="capacity-text"><?= esc_html($property['capacity']['max']) ?> Guests</span>
                                            </div>
                                        <?php endif; ?>

                                        <?php if ($property['capacity']['bedrooms'] ?? ''): ?>
                                            <div class="capacity-item">
                                                <span class="icon-svg" aria-hidden="true">
                                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M9.77778 2.66667V16H0V14.2222H1.77778V0H9.77778V0.888889H14.2222V14.2222H16V16H12.4444V2.66667H9.77778ZM6.22222 7.11111V8.88889H8V7.11111H6.22222Z" fill="#274D55"/>
                                                    </svg>
                                                </span>
                                                <span class="capacity-text"><?= esc_html($property['capacity']['bedrooms']) ?> bedrooms</span>
                                            </div>
                                        <?php endif; ?>

                                        <?php if ($property['capacity']['beds'] ?? ''): ?>
                                            <div class="capacity-item">
                                                <span class="icon-svg" aria-hidden="true">
                                                    <svg width="20" height="14" viewBox="0 0 20 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M16.3636 1.81818H9.09091V8.18182H1.81818V0H0V13.6364H1.81818V10.9091H18.1818V13.6364H20V5.45455C20 4.49012 19.6169 3.5652 18.9349 2.88325C18.253 2.2013 17.3281 1.81818 16.3636 1.81818ZM5.45455 7.27273C6.17786 7.27273 6.87156 6.98539 7.38302 6.47393C7.89448 5.96247 8.18182 5.26877 8.18182 4.54545C8.18182 3.82214 7.89448 3.12844 7.38302 2.61698C6.87156 2.10552 6.17786 1.81818 5.45455 1.81818C4.73123 1.81818 4.03754 2.10552 3.52607 2.61698C3.01461 3.12844 2.72727 3.82214 2.72727 4.54545C2.72727 5.26877 3.01461 5.96247 3.52607 6.47393C4.03754 6.98539 4.73123 7.27273 5.45455 7.27273Z" fill="#274D55"/>
                                                    </svg>
                                                </span>
                                                <span class="capacity-text"><?= esc_html($property['capacity']['beds']) ?> beds</span>
                                            </div>
                                        <?php endif; ?>

                                        <?php if ($property['capacity']['bathrooms'] ?? ''): ?>
                                            <div class="capacity-item">
                                                <span class="icon-svg" aria-hidden="true">
                                                    <svg width="19" height="19" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1.15624 13.8751C1.15723 14.3605 1.26074 14.8402 1.46 15.2829C1.65925 15.7255 1.94975 16.1211 2.31247 16.4437V17.9219C2.31247 18.0752 2.37338 18.2223 2.4818 18.3307C2.59022 18.4391 2.73727 18.5 2.89059 18.5H4.04683C4.20016 18.5 4.3472 18.4391 4.45562 18.3307C4.56404 18.2223 4.62495 18.0752 4.62495 17.9219V17.3438H13.8748V17.9219C13.8748 18.0752 13.9358 18.2223 14.0442 18.3307C14.1526 18.4391 14.2996 18.5 14.453 18.5H15.6092C15.7625 18.5 15.9096 18.4391 16.018 18.3307C16.1264 18.2223 16.1873 18.0752 16.1873 17.9219V16.4437C16.55 16.1211 16.8405 15.7255 17.0398 15.2829C17.239 14.8402 17.3426 14.3605 17.3436 13.8751V12.1407H1.15624V13.8751ZM17.9217 9.2501H2.89059V2.50238C2.89092 2.35065 2.93618 2.20241 3.02065 2.07637C3.10513 1.95033 3.22504 1.85212 3.36526 1.79415C3.50548 1.73618 3.65973 1.72103 3.80855 1.75061C3.95737 1.7802 4.09409 1.85319 4.20148 1.96039L4.89775 2.6563C4.42333 3.73594 4.62278 4.79209 5.20921 5.53714L5.20307 5.54328C5.09506 5.65164 5.03441 5.7984 5.03441 5.9514C5.03441 6.10439 5.09506 6.25115 5.20307 6.35951L5.61172 6.76817C5.66541 6.82187 5.72915 6.86446 5.7993 6.89352C5.86944 6.92258 5.94463 6.93754 6.02056 6.93754C6.09649 6.93754 6.17168 6.92258 6.24183 6.89352C6.31198 6.86446 6.37572 6.82187 6.4294 6.76817L10.2367 2.9609C10.2904 2.90721 10.333 2.84347 10.362 2.77333C10.3911 2.70318 10.406 2.62799 10.406 2.55206C10.406 2.47613 10.3911 2.40094 10.362 2.33079C10.333 2.26064 10.2904 2.19691 10.2367 2.14322L9.82801 1.73456C9.71961 1.62623 9.57262 1.56537 9.41936 1.56537C9.2661 1.56537 9.11911 1.62623 9.0107 1.73456L9.00456 1.74071C8.25951 1.15428 7.20408 0.954826 6.12372 1.42924L5.42781 0.732973C5.07787 0.382996 4.63201 0.144655 4.14661 0.0480909C3.66121 -0.0484729 3.15808 0.00107871 2.70084 0.190479C2.2436 0.379879 1.8528 0.70062 1.57786 1.11214C1.30292 1.52366 1.1562 2.00746 1.15624 2.50238V9.2501H0.578119C0.424792 9.2501 0.277745 9.31101 0.169327 9.41943C0.0609087 9.52785 0 9.6749 0 9.82822L0 10.4063C0 10.5597 0.0609087 10.7067 0.169327 10.8151C0.277745 10.9236 0.424792 10.9845 0.578119 10.9845H17.9217C18.075 10.9845 18.222 10.9236 18.3305 10.8151C18.4389 10.7067 18.4998 10.5597 18.4998 10.4063V9.82822C18.4998 9.6749 18.4389 9.52785 18.3305 9.41943C18.222 9.31101 18.075 9.2501 17.9217 9.2501Z" fill="#274D55"/>
                                                    </svg>
                                                </span>
                                                <span class="capacity-text"><?= esc_html($property['capacity']['bathrooms']) ?> baths</span>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <?php if ($total_pages > 1): ?>
                    <div class="digimanagement-pagination">
                        <?php
                        $q = $_GET;
                        $show = 3;
                        $dot = false;
                        for ($i = 1; $i <= $total_pages; $i++) {
                            if ($i <= $show || $i > $total_pages - $show) {
                                $q['property_page'] = $i;
                                $url = '?' . esc_attr(http_build_query($q));
                                echo '<a href="' . $url . '" class="' . ($i == $current_page ? 'active' : '') . '">' . $i . '</a>';
                                $dot = true;
                            } elseif ($dot) {
                                echo '<span class="dots">…</span>';
                                $dot = false;
                            }
                        }
                        ?>
                    </div>
                <?php endif; ?>
            </div>

            <?php if ($show_map): ?>
                <div class="digimanagement-map">
                    <?php if (is_admin() && isset($_GET['page']) && $_GET['page'] === 'DigiM-style'): ?>
                        <img src="<?php echo plugin_dir_url(__FILE__) . '../assets/mappreview.png'; ?>" alt="Map Preview" style="width: 100%; border-radius: 10px;" />
                    <?php else: ?>
                        <div id="digim-map" style="width: 100%; height: 400px; border-radius: 10px;"></div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php
    // Calculate hover and active colors if function exists
    $pc = $primary_color ?? '#0073aa';
    $primary_color_hover = function_exists('digim_darken_color') ? digim_darken_color($pc, 10) : '#005a87';
    $primary_color_active = function_exists('digim_darken_color') ? digim_darken_color($pc, 20) : '#004a6f';
    ?>
    <style>
        :root {
            --digim-primary-color: <?php echo $pc; ?>;
            --digim-primary-color-hover: <?php echo $primary_color_hover; ?>;
            --digim-primary-color-active: <?php echo $primary_color_active; ?>;
        }
        
        .digim-main .digimanagement-search .search-buttons button.search-button {
            background: var(--digim-primary-color) !important;
            background-color: var(--digim-primary-color) !important;
            color: #fff !important;
        }
        
        .digim-main .digimanagement-search .search-buttons button.search-button:hover,
        .digim-main .digimanagement-search .search-buttons button.search-button:focus {
            background: var(--digim-primary-color-hover) !important;
            background-color: var(--digim-primary-color-hover) !important;
            color: #fff !important;
        }
        
        .digim-main .digimanagement-search .search-buttons button.search-button:active {
            background: var(--digim-primary-color-active) !important;
            background-color: var(--digim-primary-color-active) !important;
            color: #fff !important;
        }
        
        .digimanagement-pagination a.active {
            background: var(--digim-primary-color) !important;
            border-color: var(--digim-primary-color) !important;
        }

        .digimanagement-card.highlight {
            outline: 2px solid var(--digim-primary-color) !important;
            box-shadow: 0 0 5px var(--digim-primary-color) !important;
        }
    </style>
</div>