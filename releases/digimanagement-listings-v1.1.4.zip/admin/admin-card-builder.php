<?php
// Card Builder admin page and AJAX

add_action('admin_enqueue_scripts', function ($hook) {
	if (!isset($_GET['page']) || $_GET['page'] !== 'DigiM-cards') return;

	// CSS
	wp_enqueue_style('digim-admin-css', plugin_dir_url(__FILE__) . '../assets/css/admin.css', [], '1.0.0');

	// Frontend styles for preview (digim-main)
	$style_rel = '../assets/css/style.css';
	$style_abs = plugin_dir_path(__FILE__) . $style_rel;
	if (file_exists($style_abs)) {
		wp_enqueue_style('digim-style', plugin_dir_url(__FILE__) . $style_rel, [], filemtime($style_abs));
	}

	// Swiper CSS/JS for slider preview
	wp_enqueue_style('swiper-css', 'https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css', [], '10');
	wp_enqueue_script('swiper-js', 'https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js', [], '10', true);

	// JS
	$js_rel = '../assets/js/card-builder.js';
	$js_abs = plugin_dir_path(__FILE__) . $js_rel;
	wp_enqueue_script(
		'digim-card-builder-js',
		plugin_dir_url(__FILE__) . $js_rel,
		['jquery', 'swiper-js'],
		file_exists($js_abs) ? filemtime($js_abs) : '1.0.0',
		true
	);

	// Pass data
	$sets = get_option('digim_card_sets', []);
	wp_localize_script('digim-card-builder-js', 'digimCardBuilder', [
		'ajax_url' => admin_url('admin-ajax.php'),
		'nonce' => wp_create_nonce('digim_card_builder_nonce'),
		'sets' => $sets,
		'strings' => [
			'loading' => __('Loading properties…', 'DigiM'),
			'saving' => __('Saving…', 'DigiM'),
			'saved' => __('Saved!', 'DigiM'),
			'error' => __('Something went wrong', 'DigiM'),
		],
	]);
});

// AJAX: Fetch all properties for selector
add_action('wp_ajax_digim_fetch_properties', function () {
	if (!wp_verify_nonce($_POST['nonce'] ?? '', 'digim_card_builder_nonce')) wp_send_json_error('nonce');
	if (!current_user_can('manage_options')) wp_send_json_error('cap');

	if (!function_exists('digim_get_all_properties')) wp_send_json_error('missing');
	$props = digim_get_all_properties();

	// Minify payload
	$list = array_map(function ($p) {
		return [
			'uuid' => $p['uuid'] ?? ($p['id'] ?? ''),
			'name' => $p['name'] ?? '',
			'city' => $p['address']['city'] ?? '',
			'picture' => $p['picture'] ?? '',
		];
	}, $props);

	wp_send_json_success(['properties' => $list]);
});

// AJAX: Save card set
add_action('wp_ajax_digim_save_card_set', function () {
	if (!wp_verify_nonce($_POST['nonce'] ?? '', 'digim_card_builder_nonce')) wp_send_json_error('nonce');
	if (!current_user_can('manage_options')) wp_send_json_error('cap');

	$title = sanitize_text_field($_POST['title'] ?? 'Untitled Set');
	$selected = array_values(array_filter(array_map('sanitize_text_field', (array)($_POST['selected'] ?? []))));
	$slider = intval($_POST['slider'] ?? 0) ? 1 : 0;
	$columns = max(1, min(6, intval($_POST['columns'] ?? 3)));
	$id = sanitize_text_field($_POST['id'] ?? '');

	$sets = get_option('digim_card_sets', []);
	if (!$id) {
		// If no id provided, but a set with the same title exists, update that set instead of creating a new one
		foreach ($sets as $existingId => $existing) {
			if (!empty($existing['title']) && strtolower($existing['title']) === strtolower($title)) {
				$id = $existingId;
				break;
			}
		}
		if (!$id) {
			$id = uniqid('dmcs_', true);
		}
	}
	$sets[$id] = [
		'id' => $id,
		'title' => $title,
		'selected' => $selected,
		'slider' => $slider,
		'columns' => $columns,
		'updated_at' => current_time('mysql'),
	];
	update_option('digim_card_sets', $sets);

	$shortcode = '[digim_cards id="' . esc_attr($id) . '"]';
	wp_send_json_success(['id' => $id, 'shortcode' => $shortcode]);
});

// AJAX: Render preview HTML in admin
add_action('wp_ajax_digim_render_card_preview', function () {
	if (!wp_verify_nonce($_POST['nonce'] ?? '', 'digim_card_builder_nonce')) wp_send_json_error('nonce');
	if (!current_user_can('manage_options')) wp_send_json_error('cap');

	$id = sanitize_text_field($_POST['id'] ?? '');
	if (!$id) wp_send_json_error('missing id');

	$html = do_shortcode('[digim_cards id="' . $id . '"]');
	wp_send_json_success(['html' => $html]);
});

// AJAX: Preview from current unsaved selection
add_action('wp_ajax_digim_preview_card_set', function(){
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'digim_card_builder_nonce')) wp_send_json_error('nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('cap');

    $selected = array_values(array_filter(array_map('sanitize_text_field', (array)($_POST['selected'] ?? []))));
    $slider = intval($_POST['slider'] ?? 0) ? 1 : 0;
    $columns = max(1, min(6, intval($_POST['columns'] ?? 3)));
    $primary_color = get_option('digim_primary_color', '#0073aa');

    if (!function_exists('digim_build_props_from_uuids') || !function_exists('digim_render_cards_block')) wp_send_json_error('missing helpers');
    $props = digim_build_props_from_uuids($selected);
    $html = digim_render_cards_block($props, $slider, $columns, $primary_color);
    wp_send_json_success(['html' => $html]);
});

// AJAX: Delete card set
add_action('wp_ajax_digim_delete_card_set', function(){
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'digim_card_builder_nonce')) wp_send_json_error('nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('cap');

    $id = sanitize_text_field($_POST['id'] ?? '');
    if (!$id) wp_send_json_error('missing id');

    $sets = get_option('digim_card_sets', []);
    if (!isset($sets[$id])) wp_send_json_error('not found');
    unset($sets[$id]);
    update_option('digim_card_sets', $sets);
    wp_send_json_success(['deleted' => $id]);
});

function digim_render_card_builder_page() {
	$sets = get_option('digim_card_sets', []);
	$current_id = isset($_GET['set']) ? sanitize_text_field($_GET['set']) : '';
	$current = $current_id && isset($sets[$current_id]) ? $sets[$current_id] : null;
	$title = $current['title'] ?? '';
	$slider = isset($current['slider']) ? intval($current['slider']) : 0;
	$columns = isset($current['columns']) ? intval($current['columns']) : 3;
	$selected = $current['selected'] ?? [];
	?>
	<div class="digim-ui-builder digim-card-builder">
		<div class="ui-builder-header">
			<div class="header-content">
				<h1><span class="dashicons dashicons-screenoptions"></span> Card Builder</h1>
				<p>Create curated sets of listings and embed via shortcode.</p>
			</div>
			<div class="header-actions">
				<div class="header-select-wrapper">
					<label for="cb_set_selector" class="screen-reader-text">Load existing set</label>
					<select id="cb_set_selector" class="digim-select">
						<option value="">Load set…</option>
						<?php foreach ($sets as $sid => $s): ?>
							<option value="<?php echo esc_attr($sid); ?>" <?php selected($sid, $current_id); ?>><?php echo esc_html($s['title'] ?: $sid); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=DigiM-cards')); ?>"><span class="dashicons dashicons-plus"></span> New Set</a>
			</div>
		</div>

		<div class="ui-builder-content">
			<div class="ui-builder-sidebar">
				<form id="card-builder-form" class="ui-builder-form" onsubmit="return false;">
					<div class="control-group">
						<h3><span class="dashicons dashicons-admin-generic"></span> Settings</h3>
						<div class="control-item">
							<label for="cb_title">Title</label>
							<input type="text" id="cb_title" class="digim-input" value="<?php echo esc_attr($title); ?>" placeholder="e.g. Featured Villas" />
						</div>
						<div class="control-row">
							<div class="control-item">
								<label for="cb_slider">Display as slider</label>
								<label class="checkbox-control">
									<input type="checkbox" id="cb_slider" value="1" <?php checked($slider, 1); ?> />
									<span class="label-text">Enable slider</span>
									<div class="toggle-switch"></div>
								</label>
							</div>
							<div class="control-item">
								<label for="cb_columns">Grid Columns</label>
								<div class="cb-columns-selector">
									<input type="hidden" id="cb_columns" value="<?php echo esc_attr($columns); ?>" />
									<div class="cb-columns-buttons">
										<?php for ($i=2;$i<=6;$i++): ?>
											<button type="button" class="cb-column-btn <?php echo ($columns == $i) ? 'active' : ''; ?>" data-columns="<?php echo $i; ?>" title="<?php echo $i; ?> columns">
												<div class="cb-column-preview">
													<?php for ($j=0; $j<$i; $j++): ?>
														<span class="cb-column-box"></span>
													<?php endfor; ?>
												</div>
												<span class="cb-column-label"><?php echo $i; ?></span>
											</button>
										<?php endfor; ?>
									</div>
								</div>
							</div>
						</div>

						<div class="control-group">
							<h3><span class="dashicons dashicons-randomize"></span> Listings</h3>
							<div class="control-item">
								<input type="search" id="cb_search" class="digim-input" placeholder="Search properties…" />
							</div>
							<div class="control-item cb-listings-container">
								<div class="cb-list-column">
									<label>Available</label>
									<ul id="cb_available" class="digim-card-list" aria-label="Available properties">
										<li class="cb-loading-state"><span class="spinner is-active"></span> Loading properties…</li>
									</ul>
								</div>
								<div class="cb-list-actions">
									<button type="button" class="button button-secondary cb-action-btn" id="cb_add" title="Add selected">
										<span class="dashicons dashicons-arrow-right-alt"></span>
									</button>
									<button type="button" class="button button-secondary cb-action-btn" id="cb_remove" title="Remove selected">
										<span class="dashicons dashicons-arrow-left-alt"></span>
									</button>
								</div>
								<div class="cb-list-column">
									<label>Selected (drag to reorder)</label>
									<ul id="cb_selected" class="digim-card-list" aria-label="Selected properties"></ul>
								</div>
							</div>
						</div>

						<div class="control-group">
							<div class="control-item cb-actions-group">
								<div class="cb-buttons-row">
									<button type="button" class="button button-primary" id="cb_save">
										<span class="dashicons dashicons-yes-alt"></span> Save Set
									</button>
									<button type="button" class="button button-secondary" id="cb_delete" <?php echo $current_id ? '' : 'disabled'; ?>>
										<span class="dashicons dashicons-trash"></span> Delete
									</button>
								</div>
								<div class="cb-shortcode-display">
									<label>Shortcode:</label>
									<input type="text" id="cb_shortcode" class="digim-input" readonly value="" />
									<button type="button" class="button button-small cb-copy-shortcode" title="Copy shortcode">
										<span class="dashicons dashicons-clipboard"></span>
									</button>
								</div>
								<input type="hidden" id="cb_id" value="<?php echo esc_attr($current_id); ?>" />
							</div>
						</div>

						<div class="control-group">
							<h3><span class="dashicons dashicons-media-code"></span> Saved Sets</h3>
							<div class="control-item">
								<ul class="cb-saved-sets">
									<?php foreach ($sets as $sid => $s): $sc = '[digim_cards id="' . $sid . '"]'; ?>
									<li data-id="<?php echo esc_attr($sid); ?>">
										<a href="<?php echo esc_url(admin_url('admin.php?page=DigiM-cards&set='.$sid)); ?>" class="button button-secondary">Edit</a>
										<button type="button" class="button cb-delete-item">Delete</button>
										<strong><?php echo esc_html($s['title'] ?: $sid); ?></strong>
										<code><?php echo esc_html($sc); ?></code>
									</li>
									<?php endforeach; ?>
								</ul>
							</div>
						</div>
					</form>
			</div>

			<div class="ui-builder-preview">
				<div class="preview-header">
					<h3><span class="dashicons dashicons-visibility"></span> Preview</h3>
					<div class="preview-controls">
						<button type="button" class="button" id="cb_refresh"><span class="dashicons dashicons-update"></span> Refresh</button>
					</div>
				</div>
				<div class="preview-container">
					<div id="cb_preview" class="preview-content"></div>
				</div>
			</div>
		</div>
	</div>
	<style>
		/* Card Builder specific styles are in admin.css */
	</style>
	<?php
}


