<?php
// Listings admin page: show all Hospitable listings and toggle "Hide on frontend" per property.

add_action('admin_enqueue_scripts', function ($hook) {
    if (!isset($_GET['page']) || $_GET['page'] !== 'DigiM-listings') {
        return;
    }

    $admin_css = digim_asset('assets/css/admin.css');
    wp_enqueue_style('digim-admin-css', $admin_css['url'], [], file_exists($admin_css['path']) ? filemtime($admin_css['path']) : '1.0.0');

    $js_asset = digim_asset('assets/js/listings-visibility.js');
    wp_enqueue_script(
        'digim-listings-visibility-js',
        $js_asset['url'],
        ['jquery'],
        file_exists($js_asset['path']) ? filemtime($js_asset['path']) : '1.0.0',
        true
    );

    $props_for_counts = function_exists('digim_get_all_properties') ? digim_get_all_properties() : [];
    $total_listings   = is_array($props_for_counts) ? count($props_for_counts) : 0;

    wp_localize_script('digim-listings-visibility-js', 'digimListings', [
        'ajax_url'    => admin_url('admin-ajax.php'),
        'nonce'       => wp_create_nonce('digim_listings_visibility_nonce'),
        'total'       => $total_listings,
        'manual_mode' => digim_is_manual_listing_visibility(),
        'strings'     => [
            'loading' => __('Loading listings…', 'DigiM'),
            'saving'  => __('Saving…', 'DigiM'),
            'saved'   => __('Saved. Hidden on frontend.', 'DigiM'),
            'shown'   => __('Saved. Shown on frontend.', 'DigiM'),
            'error'   => __('Something went wrong.', 'DigiM'),
            'hide_on_frontend' => __('Hide on frontend', 'DigiM'),
            'show_on_frontend' => __('Show on frontend', 'DigiM'),
            'label_hidden_row' => __('Hidden', 'DigiM'),
            'label_shown_row'  => __('Shown', 'DigiM'),
            'manual_on'  => __('Manual visibility enabled. You control which listings appear on your site.', 'DigiM'),
            'manual_off' => __('Syncing with Hospitable. Visibility follows the Listed status in Hospitable (refreshes every 5 minutes).', 'DigiM'),
            'syncing'    => __('Syncing with Hospitable…', 'DigiM'),
        ],
    ]);
});

/**
 * How many listings in the current property list are hidden on the frontend.
 *
 * @param array $properties  From digim_get_all_properties().
 * @param array $hidden_uuids Stored UUIDs marked hidden.
 */
function digim_listings_count_hidden_among_properties(array $properties, array $hidden_uuids)
{
    if ($properties === [] || $hidden_uuids === []) {
        return 0;
    }
    $n = 0;
    foreach ($properties as $p) {
        $uuid = isset($p['uuid']) ? trim((string) $p['uuid']) : '';
        if ($uuid === '' && isset($p['id'])) {
            $uuid = trim((string) $p['id']);
        }
        if ($uuid !== '' && in_array($uuid, $hidden_uuids, true)) {
            $n++;
        }
    }
    return $n;
}

// AJAX: Toggle manual vs Hospitable-sync visibility mode
add_action('wp_ajax_digim_toggle_listings_manual_mode', function () {
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'digim_listings_visibility_nonce')) {
        wp_send_json_error(['message' => 'Bad nonce']);
    }
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Insufficient permissions']);
    }

    $manual = isset($_POST['manual']) && $_POST['manual'] === '1';
    update_option('digim_listings_manual_visibility', $manual ? '1' : '0');

    digim_manage_hospitable_listings_sync_cron();

    if (!$manual) {
        wp_clear_scheduled_hook('digim_sync_hospitable_listings');
        wp_schedule_single_event(time() + 1, 'digim_sync_hospitable_listings');
        if (function_exists('spawn_cron')) {
            spawn_cron();
        }
    }

    wp_send_json_success([
        'manual_mode' => $manual,
        'message'     => $manual
            ? __('Manual visibility enabled.', 'DigiM')
            : __('Syncing with Hospitable. Listings refresh every 5 minutes.', 'DigiM'),
        'last_sync'   => (int) get_option('digim_hospitable_listings_last_sync', 0),
    ]);
});

// AJAX: Toggle frontend visibility for one listing
add_action('wp_ajax_digim_toggle_listing_visibility', function () {
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'digim_listings_visibility_nonce')) {
        wp_send_json_error(['message' => 'Bad nonce']);
    }
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Insufficient permissions']);
    }
    if (!digim_is_manual_listing_visibility()) {
        wp_send_json_error(['message' => __('Visibility is synced from Hospitable. Enable manual mode to change listings here.', 'DigiM')]);
    }

    $uuid = isset($_POST['uuid']) ? sanitize_text_field($_POST['uuid']) : '';
    if ($uuid === '') {
        wp_send_json_error(['message' => 'Missing UUID']);
    }

    $hidden = get_option('digim_hidden_listings', []);
    if (!is_array($hidden)) {
        $hidden = [];
    }

    $hide = isset($_POST['hide']) && $_POST['hide'] === '1';

    if ($hide) {
        if (!in_array($uuid, $hidden, true)) {
            $hidden[] = $uuid;
        }
    } else {
        $hidden = array_values(array_filter($hidden, function ($id) use ($uuid) {
            return $id !== $uuid;
        }));
    }

    update_option('digim_hidden_listings', $hidden);

    $properties        = function_exists('digim_get_all_properties') ? digim_get_all_properties() : [];
    $total_listings    = is_array($properties) ? count($properties) : 0;
    $hidden_list_count = digim_listings_count_hidden_among_properties($properties, $hidden);

    wp_send_json_success([
        'hidden'       => $hide,
        'message'      => $hide ? __('Hidden on frontend.', 'DigiM') : __('Shown on frontend.', 'DigiM'),
        'hidden_count' => $hidden_list_count,
        'total'        => $total_listings,
    ]);
});

/**
 * Render Listings admin page.
 */
function digim_render_listings_page()
{
    $manual_mode  = digim_is_manual_listing_visibility();
    $hidden_uuids = digim_get_hidden_listing_uuids();
    $properties = [];
    if (function_exists('digim_get_all_properties')) {
        $properties = digim_get_all_properties();
    }
    $total_listings  = count($properties);
    $hidden_in_table = digim_listings_count_hidden_among_properties($properties, $hidden_uuids);
    $visible_count   = max(0, $total_listings - $hidden_in_table);
    $last_sync       = (int) get_option('digim_hospitable_listings_last_sync', 0);
    ?>
    <div class="digim-ui-builder digim-listings-page">
        <div class="ui-builder-header">
            <div class="header-content">
                <h1><span class="dashicons dashicons-building"></span> <?php esc_html_e('Listings', 'DigiM'); ?></h1>
                <p><?php echo $manual_mode
                    ? esc_html__('All properties from the Hospitable API. Use "Hide on frontend" to hide a listing on your site only—it remains active on Hospitable.', 'DigiM')
                    : esc_html__('Properties sync from Hospitable every 5 minutes. Visibility matches the Listed status in Hospitable—unlisted properties are hidden on your site.', 'DigiM'); ?></p>
            </div>
        </div>

        <div class="ui-builder-content">
            <div class="digim-listings-table-wrap">
                <div class="digim-listings-mode-card" id="digim-listings-mode-card">
                    <div class="digim-listings-mode-row">
                        <label class="digim-toggle-wrap digim-mode-toggle-wrap" for="digim-listings-manual-mode">
                            <input type="checkbox" id="digim-listings-manual-mode" class="digim-listings-manual-mode"
                                <?php checked($manual_mode); ?>
                                aria-label="<?php esc_attr_e('Manual visibility control', 'DigiM'); ?>">
                            <span class="digim-toggle-slider"></span>
                            <span class="digim-mode-toggle-text">
                                <strong><?php esc_html_e('Manual visibility control', 'DigiM'); ?></strong>
                                <span class="digim-mode-toggle-desc" id="digim-listings-mode-desc">
                                    <?php echo $manual_mode
                                        ? esc_html__('You choose which listings are shown or hidden on your site.', 'DigiM')
                                        : esc_html__('Visibility follows Hospitable Listed status (auto-sync every 5 min).', 'DigiM'); ?>
                                </span>
                            </span>
                        </label>
                    </div>
                    <?php if (!$manual_mode) : ?>
                        <p class="digim-listings-sync-meta" id="digim-listings-sync-meta">
                            <?php if ($last_sync > 0) : ?>
                                <?php printf(
                                    esc_html__('Last synced: %s ago.', 'DigiM'),
                                    esc_html(human_time_diff($last_sync, time()))
                                ); ?>
                            <?php else : ?>
                                <?php esc_html_e('Waiting for first sync…', 'DigiM'); ?>
                            <?php endif; ?>
                        </p>
                    <?php endif; ?>
                </div>
                <div class="digim-listings-stats" id="digim-listings-stats" role="status" aria-live="polite">
                    <span class="digim-listings-stat">
                        <span class="digim-listings-stat-value" id="digim-listings-count-total"><?php echo esc_html((string) $total_listings); ?></span>
                        <span class="digim-listings-stat-label"><?php esc_html_e('listings total', 'DigiM'); ?></span>
                    </span>
                    <span class="digim-listings-stat">
                        <span class="digim-listings-stat-value" id="digim-listings-count-visible"><?php echo esc_html((string) $visible_count); ?></span>
                        <span class="digim-listings-stat-label"><?php esc_html_e('shown on site', 'DigiM'); ?></span>
                    </span>
                    <span class="digim-listings-stat digim-listings-stat-hidden">
                        <span class="digim-listings-stat-value" id="digim-listings-count-hidden"><?php echo esc_html((string) $hidden_in_table); ?></span>
                        <span class="digim-listings-stat-label"><?php esc_html_e('hidden on site', 'DigiM'); ?></span>
                    </span>
                </div>
                <div id="digim-listings-status" class="notice" style="display:none;"></div>
                <?php if (empty($properties)) : ?>
                    <p class="description"><?php esc_html_e('No listings found. Check your Hospitable API settings and sync under Settings.', 'DigiM'); ?></p>
                <?php else : ?>
                    <table class="wp-list-table widefat fixed striped digim-listings-table">
                        <thead>
                            <tr>
                                <th scope="col" class="column-name"><?php esc_html_e('Property', 'DigiM'); ?></th>
                                <th scope="col" class="column-location"><?php esc_html_e('Location', 'DigiM'); ?></th>
                                <th scope="col" class="column-visibility"><?php esc_html_e('Frontend', 'DigiM'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($properties as $p) :
                                $uuid = $p['uuid'] ?? $p['id'] ?? '';
                                $uuid = $uuid !== '' ? trim((string) $uuid) : '';
                                $name = $p['public_name'] ?? $p['name'] ?? $uuid;
                                $city = $p['address']['city'] ?? '';
                                $country = $p['address']['country'] ?? '';
                                $location = trim($city . ($country ? ', ' . $country : ''));
                                $is_hidden = in_array($uuid, $hidden_uuids, true);
                                $hospitable_listed = digim_property_is_listed_on_hospitable($p);
                                ?>
                                <tr data-uuid="<?php echo esc_attr($uuid); ?>">
                                    <td class="column-name">
                                        <strong><?php echo esc_html($name); ?></strong>
                                        <?php if ($uuid) : ?>
                                            <br><code class="digim-uuid-small"><?php echo esc_html($uuid); ?></code>
                                        <?php endif; ?>
                                        <?php if (!$manual_mode) : ?>
                                            <br><span class="digim-hospitable-status <?php echo $hospitable_listed ? 'is-listed' : 'is-unlisted'; ?>">
                                                <?php echo $hospitable_listed
                                                    ? esc_html__('Listed on Hospitable', 'DigiM')
                                                    : esc_html__('Unlisted on Hospitable', 'DigiM'); ?>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="column-location"><?php echo esc_html($location); ?></td>
                                    <td class="column-visibility">
                                        <label class="digim-toggle-wrap<?php echo $manual_mode ? '' : ' digim-toggle-readonly'; ?>" title="<?php echo $manual_mode
                                            ? ($is_hidden ? esc_attr__('Currently hidden on frontend. Click to show.', 'DigiM') : esc_attr__('Currently shown on frontend. Click to hide.', 'DigiM'))
                                            : esc_attr__('Synced from Hospitable. Enable manual mode to change.', 'DigiM'); ?>">
                                            <input type="checkbox" class="digim-listing-toggle" data-uuid="<?php echo esc_attr($uuid); ?>"
                                                <?php checked(!$is_hidden); ?>
                                                <?php disabled(!$manual_mode); ?>
                                                aria-label="<?php echo $is_hidden ? esc_attr__('Show on frontend', 'DigiM') : esc_attr__('Hide on frontend', 'DigiM'); ?>">
                                            <span class="digim-toggle-slider"></span>
                                            <span class="digim-toggle-label"><?php echo $is_hidden ? esc_html__('Hidden', 'DigiM') : esc_html__('Shown', 'DigiM'); ?></span>
                                        </label>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <style>
        /* Full-viewport UI builder layout breaks this screen (no sidebar); keep normal flow */
        .digim-listings-page.digim-ui-builder {
            margin: 0;
            min-height: 0;
            background: transparent;
        }
        .digim-listings-page .ui-builder-header {
            padding-top: 12px;
            align-items: flex-start;
        }
        .digim-listings-page .ui-builder-content {
            display: block;
            height: auto;
            min-height: 0;
            padding: 0 0 24px;
        }
        .digim-listings-stats {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 12px 24px;
            margin-bottom: 16px;
            padding: 12px 16px;
            background: #fff;
            border: 1px solid #c3c4c7;
            border-radius: 4px;
        }
        .digim-listings-mode-card {
            margin-bottom: 16px;
            padding: 16px;
            background: #fff;
            border: 1px solid #c3c4c7;
            border-radius: 4px;
        }
        .digim-listings-mode-row { display: flex; align-items: flex-start; }
        .digim-mode-toggle-wrap { align-items: flex-start; gap: 12px; }
        .digim-mode-toggle-text { display: flex; flex-direction: column; gap: 4px; max-width: 640px; }
        .digim-mode-toggle-desc { font-size: 12px; color: #646970; font-weight: 400; }
        .digim-listings-sync-meta { margin: 10px 0 0 56px; font-size: 12px; color: #646970; }
        .digim-hospitable-status { font-size: 11px; color: #2271b1; }
        .digim-hospitable-status.is-unlisted { color: #b32d2e; }
        .digim-toggle-readonly { opacity: 0.75; cursor: not-allowed; }
        .digim-toggle-readonly .digim-toggle-slider { background: #dcdcde !important; }
        .digim-listings-stat {
            display: inline-flex;
            align-items: baseline;
            gap: 8px;
            font-size: 13px;
            color: #50575e;
        }
        .digim-listings-stat-value {
            font-size: 18px;
            font-weight: 600;
            color: #1d2327;
        }
        .digim-listings-stat-hidden .digim-listings-stat-value { color: #b32d2e; }
        .digim-listings-table-wrap { max-width: 960px; margin-top: 0; }
        .digim-listings-table { margin-top: 0; }
        .digim-listings-table .column-name { width: 35%; }
        .digim-listings-table .column-location { width: 35%; }
        .digim-listings-table .column-visibility { width: 30%; }
        .digim-uuid-small { font-size: 11px; color: #666; }
        .digim-toggle-wrap { display: inline-flex; align-items: center; gap: 8px; cursor: pointer; user-select: none; }
        .digim-toggle-wrap input { position: absolute; opacity: 0; width: 0; height: 0; }
        .digim-toggle-slider {
            position: relative;
            width: 44px;
            height: 24px;
            background: #c3c4c7;
            border-radius: 24px;
            transition: background 0.2s;
        }
        .digim-toggle-slider::before {
            content: '';
            position: absolute;
            height: 18px;
            width: 18px;
            left: 3px;
            bottom: 3px;
            background: #fff;
            border-radius: 50%;
            transition: transform 0.2s;
            box-shadow: 0 1px 3px rgba(0,0,0,0.2);
        }
        .digim-toggle-wrap input:checked + .digim-toggle-slider { background: #2271b1; }
        .digim-toggle-wrap input:checked + .digim-toggle-slider::before { transform: translateX(20px); }
        .digim-toggle-wrap input:focus + .digim-toggle-slider { box-shadow: 0 0 0 2px #2271b1; }
        .digim-toggle-label { font-size: 12px; color: #50575e; }
    </style>
    <?php
}
