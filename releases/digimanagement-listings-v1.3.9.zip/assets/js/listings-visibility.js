/**
 * DigiM Listings admin: manual mode toggle + per-property visibility.
 */
(function ($) {
    'use strict';

    $(function () {
        var L = window.digimListings || {};
        var $status = $('#digim-listings-status');
        var $totalEl = $('#digim-listings-count-total');
        var $visibleEl = $('#digim-listings-count-visible');
        var $hiddenEl = $('#digim-listings-count-hidden');
        var $manualMode = $('#digim-listings-manual-mode');

        if (!$manualMode.length) {
            return;
        }

        function updateCounts(hiddenCount) {
            var total = typeof L.total === 'number' ? L.total : parseInt($totalEl.text(), 10) || 0;
            if (typeof hiddenCount !== 'number' || isNaN(hiddenCount)) {
                return;
            }
            var visible = Math.max(0, total - hiddenCount);
            $hiddenEl.text(hiddenCount);
            $visibleEl.text(visible);
        }

        function showNotice(message, type) {
            type = type || 'success';
            $status.removeClass('notice-success notice-error').addClass('notice-' + type).html(message).show();
            setTimeout(function () { $status.fadeOut(); }, 4000);
        }

        $manualMode.on('change', function () {
            var $input = $(this);
            var manual = $input.prop('checked');
            var lbl = L.strings || {};

            $input.prop('disabled', true);
            showNotice(lbl.syncing || 'Saving…', 'success');

            $.ajax({
                url: L.ajax_url,
                type: 'POST',
                timeout: 30000,
                data: {
                    action: 'digim_toggle_listings_manual_mode',
                    nonce: L.nonce,
                    manual: manual ? '1' : '0'
                }
            })
                .done(function (res) {
                    if (res && res.success) {
                        window.location.reload();
                        return;
                    }
                    var msg = (res && res.data && res.data.message) ? res.data.message : (L.strings.error || 'Error');
                    showNotice(msg, 'error');
                    $input.prop('checked', !manual);
                })
                .fail(function (xhr, status) {
                    var msg = L.strings.error || 'Error';
                    if (status === 'timeout') {
                        msg = 'Request timed out. Please try again.';
                    }
                    showNotice(msg, 'error');
                    $input.prop('checked', !manual);
                })
                .always(function () {
                    $input.prop('disabled', false);
                });
        });

        $('.digim-listing-toggle').on('change', function () {
            if (!L.manual_mode) {
                return;
            }

            var $input = $(this);
            var uuid = $input.data('uuid');
            var hide = !$input.prop('checked');

            if (!uuid) {
                return;
            }

            var $row = $input.closest('tr');
            var $label = $row.find('.digim-toggle-label');
            $input.prop('disabled', true);

            $.post(L.ajax_url, {
                action: 'digim_toggle_listing_visibility',
                nonce: L.nonce,
                uuid: uuid,
                hide: hide ? '1' : '0'
            })
                .done(function (res) {
                    if (res.success) {
                        var lbl = L.strings || {};
                        $label.text(hide ? (lbl.label_hidden_row || 'Hidden') : (lbl.label_shown_row || 'Shown'));
                        if (res.data && typeof res.data.hidden_count === 'number') {
                            updateCounts(res.data.hidden_count);
                        }
                        if (res.data && typeof res.data.total === 'number') {
                            L.total = res.data.total;
                            $totalEl.text(res.data.total);
                        }
                        showNotice(res.data && res.data.message ? res.data.message : (hide ? L.strings.saved : L.strings.shown), 'success');
                    } else {
                        showNotice((res.data && res.data.message) || L.strings.error || 'Error', 'error');
                        $input.prop('checked', !hide);
                    }
                })
                .fail(function () {
                    showNotice(L.strings.error || 'Error', 'error');
                    $input.prop('checked', !hide);
                })
                .always(function () {
                    $input.prop('disabled', false);
                });
        });
    });
})(jQuery);
