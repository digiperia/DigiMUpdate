<?php

namespace RankMath\Sitemap\Providers;

defined('ABSPATH') || exit;

if (!interface_exists('RankMath\Sitemap\Providers\Provider') || class_exists('RankMath\Sitemap\Providers\Digim_Property')) {
  return;
}

class Digim_Property implements Provider
{
  public function handles_type($type)
  {
    return 'property' === $type;
  }

  public function get_index_links($max_entries)
  {
    if (!class_exists('\RankMath\Sitemap\Router')) {
      return [];
    }

    return [
      [
        'loc'     => \RankMath\Sitemap\Router::get_base_url('property-sitemap.xml'),
        'lastmod' => '',
      ],
    ];
  }

  public function get_sitemap_links($type, $max_entries, $current_page)
  {
    $entries = \digim_get_property_sitemap_entries();
    if (empty($entries)) {
      return [];
    }

    $max_entries = (int) $max_entries;
    $max_entries = $max_entries > 0 ? $max_entries : 200;
    $offset      = max(0, ((int) $current_page - 1) * $max_entries);
    $page        = array_slice($entries, $offset, $max_entries);
    $links       = [];

    foreach ($page as $entry) {
      $link = ['loc' => $entry['loc']];
      if (!empty($entry['lastmod'])) {
        $link['mod'] = $entry['lastmod'];
      }
      $links[] = $link;
    }

    return $links;
  }
}
