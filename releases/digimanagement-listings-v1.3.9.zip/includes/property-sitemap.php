<?php
/**
 * Property sitemap — expose Hospitable property URLs to search engines.
 * Works with WordPress core sitemaps, Yoast SEO, and Rank Math.
 */

if (!function_exists('digim_get_property_sitemap_entries')) {
  /**
   * Build sitemap entries for all visible Hospitable properties.
   *
   * @return array<int, array{loc: string, lastmod: string}>
   */
  function digim_get_property_sitemap_entries()
  {
    if (!function_exists('digim_get_all_properties') || !function_exists('digimanagement_create_property_slug')) {
      return [];
    }

    $properties = digim_get_all_properties();
    if (empty($properties) || !is_array($properties)) {
      return [];
    }

    $hidden_uuids = function_exists('digim_get_hidden_listing_uuids') ? digim_get_hidden_listing_uuids() : [];
    $entries = [];
    $seen_slugs = [];

    foreach ($properties as $property) {
      if (!is_array($property)) {
        continue;
      }

      $uuid = trim((string) ($property['uuid'] ?? $property['id'] ?? ''));
      if ($uuid !== '' && !empty($hidden_uuids) && in_array($uuid, $hidden_uuids, true)) {
        continue;
      }

      $name = trim((string) ($property['name'] ?? ''));
      if ($name === '') {
        continue;
      }

      $slug = digimanagement_create_property_slug($name, $property['address']['city'] ?? '');
      if ($slug === '' || isset($seen_slugs[$slug])) {
        continue;
      }
      $seen_slugs[$slug] = true;

      $lastmod = '';
      foreach (['updated_at', 'updatedAt', 'modified_at', 'modifiedAt'] as $key) {
        if (!empty($property[$key]) && is_string($property[$key])) {
          $ts = strtotime($property[$key]);
          if ($ts) {
            $lastmod = gmdate('c', $ts);
          }
          break;
        }
      }

      $entries[] = [
        'loc'     => trailingslashit(home_url('/property/' . $slug)),
        'lastmod' => $lastmod,
      ];
    }

    return $entries;
  }
}

if (!class_exists('Digim_Property_Sitemap_Provider') && class_exists('WP_Sitemaps_Provider')) {
  class Digim_Property_Sitemap_Provider extends WP_Sitemaps_Provider
  {
    public function __construct()
    {
      $this->name        = 'property';
      $this->object_type = 'property';
    }

    public function get_url_list($page_num, $object_subtype = '')
    {
      $entries = digim_get_property_sitemap_entries();
      if (empty($entries)) {
        return [];
      }

      $max_urls = (int) wp_sitemaps_get_max_urls($this->name);
      $max_urls = $max_urls > 0 ? $max_urls : 2000;
      $offset   = max(0, ((int) $page_num - 1) * $max_urls);
      $page     = array_slice($entries, $offset, $max_urls);
      $url_list = [];

      foreach ($page as $entry) {
        $item = ['loc' => $entry['loc']];
        if (!empty($entry['lastmod'])) {
          $item['lastmod'] = $entry['lastmod'];
        }
        $url_list[] = $item;
      }

      return $url_list;
    }

    public function get_max_num_pages($object_subtype = '')
    {
      $count = count(digim_get_property_sitemap_entries());
      if ($count === 0) {
        return 0;
      }

      $max_urls = (int) wp_sitemaps_get_max_urls($this->name);
      $max_urls = $max_urls > 0 ? $max_urls : 2000;

      return (int) ceil($count / $max_urls);
    }
  }
}

add_action('init', function () {
  if (function_exists('wp_register_sitemap_provider') && class_exists('Digim_Property_Sitemap_Provider')) {
    wp_register_sitemap_provider('property', new Digim_Property_Sitemap_Provider());
  }

  if (class_exists('WPSEO_Sitemaps')) {
    global $wpseo_sitemaps;
    if (isset($wpseo_sitemaps) && is_object($wpseo_sitemaps) && method_exists($wpseo_sitemaps, 'register_sitemap')) {
      $wpseo_sitemaps->register_sitemap('property', 'digim_yoast_property_sitemap_content');
    }
  }
}, 20);

if (!function_exists('digim_yoast_property_sitemap_content')) {
  function digim_yoast_property_sitemap_content()
  {
    global $wpseo_sitemaps;
    if (!isset($wpseo_sitemaps) || !is_object($wpseo_sitemaps)) {
      return;
    }

    $entries = digim_get_property_sitemap_entries();
    $output  = '';

    foreach ($entries as $entry) {
      $url = [
        'loc' => $entry['loc'],
        'mod' => !empty($entry['lastmod']) ? $entry['lastmod'] : '',
        'chf' => 'weekly',
        'pri' => 0.8,
      ];
      $output .= $wpseo_sitemaps->renderer->sitemap_url($url);
    }

    $wpseo_sitemaps->set_sitemap($output);
  }
}

add_action('plugins_loaded', function () {
  if (!interface_exists('RankMath\Sitemap\Providers\Provider')) {
    return;
  }

  require_once __DIR__ . '/property-sitemap-rankmath.php';

  add_filter('rank_math/sitemap/providers', function ($providers) {
    $providers['digim-property'] = new \RankMath\Sitemap\Providers\Digim_Property();
    return $providers;
  });
}, 20);
