<?php
add_action('admin_init', function () {
    register_setting('DigiM-style', 'digim_cards_per_page');
    register_setting('DigiM-style', 'digim_layout_style');
    register_setting('DigiM-style', 'digim_show_map');
    register_setting('DigiM-style', 'digim_grid_columns');
    register_setting('DigiM-style', 'digim_card_style');
    register_setting('DigiM-style', 'digim_primary_color'); // <-- this is the key line

});

add_action('admin_enqueue_scripts', 'digim_enqueue_admin_ui_assets');
function digim_enqueue_admin_ui_assets($hook_suffix)
{
    if (isset($_GET['page']) && $_GET['page'] === 'DigiM-style') {
        // CSS
        $css_file = plugin_dir_path(__DIR__) . 'assets/css/style.css';
        $css_url  = plugin_dir_url(__DIR__) . 'assets/css/style.css';

        if (file_exists($css_file)) {
            wp_enqueue_style('digim-admin-ui-style', $css_url, [], filemtime($css_file));
        } else {
            wp_enqueue_style('digim-admin-ui-style', $css_url);
        }

        // JS
        $js_file = plugin_dir_path(__DIR__) . 'assets/js/map-init.js';
        $js_url  = plugin_dir_url(__DIR__) . 'assets/js/map-init.js';

        if (file_exists($js_file)) {
            wp_enqueue_script('digim-admin-map-init', $js_url, ['jquery'], filemtime($js_file), true);
        }
    }
}

function digim_render_ui_builder_page()
{
    $per_page     = esc_attr(get_option('digim_cards_per_page', 12));
    $layout       = esc_attr(get_option('digim_layout_style', 'grid'));
    $grid_columns = esc_attr(get_option('digim_grid_columns', 3));
    $show_map     = get_option('digim_show_map', false);
    $card_style   = esc_attr(get_option('digim_card_style', 'classic'));
    $primary_color = esc_attr(get_option('digim_primary_color', '#0073aa'));
?>
    <div class="digim-main">
        <div class="wrap">
            <h1>UI Builder – Listings Shortcode Settings</h1>
            <div class="digim-grid">
                <div class="lefteditor">
                    <form method="post" action="options.php" class="digim-ui-form">
                        <?php settings_fields('DigiM-style'); ?>

                        <table class="form-table digim-table-form">
                            <tbody>
                                <tr>
                                    <th><label for="digim_cards_per_page">Cards per page</label></th>
                                    <td>
                                        <input type="number" name="digim_cards_per_page" id="digim_cards_per_page" value="<?php echo esc_attr($per_page); ?>" min="1" />
                                    </td>
                                </tr>

                                <tr>
                                    <th><label for="digim_layout_style">Layout style</label></th>
                                    <td>
                                        <select name="digim_layout_style" id="digim_layout_style">
                                            <option value="grid" <?php selected($layout, 'grid'); ?>>Grid</option>
                                            <option value="list" <?php selected($layout, 'list'); ?>>List</option>
                                        </select>
                                    </td>
                                </tr>

                                <tr>
                                    <th><label for="digim_grid_columns">Grid columns</label></th>
                                    <td>
                                        <select name="digim_grid_columns" id="digim_grid_columns">
                                            <option value="2" <?php selected($grid_columns, 2); ?>>2</option>
                                            <option value="3" <?php selected($grid_columns, 3); ?>>3</option>
                                            <option value="4" <?php selected($grid_columns, 4); ?>>4</option>
                                        </select>
                                    </td>
                                </tr>

                                <tr>
                                    <th><label for="digim_show_map">Show Map</label></th>
                                    <td>
                                        <label class="digim-checkbox-label">
                                            <input type="checkbox" name="digim_show_map" id="digim_show_map" value="1" <?php checked($show_map, 1); ?> />
                                            <span>Show Map below listings</span>
                                        </label>
                                    </td>
                                </tr>
                                <tr>
                                    <th><label for="digim_card_style">Card Style</label></th>
                                    <td>
                                        <select name="digim_card_style" id="digim_card_style">
                                            <option value="classic" <?php selected($card_style, 'classic'); ?>>Classic</option>
                                            <option value="minimal" <?php selected($card_style, 'minimal'); ?>>Minimal</option>
                                            <option value="outline" <?php selected($card_style, 'outline'); ?>>Outline</option>
                                        </select>
                                    </td>
                                </tr>

                                <tr>
                                    <th><label for="digim_primary_color">Primary Color</label></th>
                                    <td>
                                        <input type="color" name="digim_primary_color" id="digim_primary_color" value="<?php echo esc_attr($primary_color); ?>" />
                                    </td>
                                </tr>

                            </tbody>
                        </table>


                        <?php submit_button('Save UI Settings'); ?>
                    </form>
                </div>

                <!-- Ajax Form Live Update -->
                <div class="righteditor">
                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            const form = document.querySelector('.digim-ui-form');
                            if (!form) return;

                            form.addEventListener('submit', function() {
                                // Show loading state
                                const preview = document.getElementById('digim-preview');
                                if (preview) {
                                    preview.innerHTML = '<p><em>Updating preview...</em></p>';
                                }
                            });

                            // Refresh preview after submit
                            window.addEventListener('load', () => {
                                const hash = window.location.hash;
                                if (hash === '#settings-updated') {
                                    const iframe = document.createElement('iframe');
                                    iframe.src = window.location.href;
                                    iframe.style.display = 'none';
                                    iframe.onload = () => {
                                        const previewHtml = iframe.contentDocument.getElementById('digim-preview')?.innerHTML;
                                        if (previewHtml) {
                                            document.getElementById('digim-preview').innerHTML = previewHtml;
                                        }
                                        iframe.remove();
                                    };
                                    document.body.appendChild(iframe);
                                }
                            });
                        });
                    </script>
                    <h2>Live Preview</h2>
                    <div id="digim-preview" style="border: 1px solid #ddd; padding: 20px; border-radius: 8px; background: #f9f9f9; pointer-events:none !important;">
                        <?php echo do_shortcode('[digimanagement_listings]'); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
}
