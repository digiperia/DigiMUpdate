jQuery(document).ready(function($) {
    'use strict';

    // API Testing functionality
    $('#test-api-btn').on('click', function(e) {
        e.preventDefault();
        testApiConnection();
    });

    // Clear test results
    $('#clear-test-results').on('click', function(e) {
        e.preventDefault();
        clearTestResults();
    });

    // Form validation
    $('#digim-settings-form').on('submit', function(e) {
        if (!validateForm()) {
            e.preventDefault();
            return false;
        }
    });

    // Real-time validation
    $('#api_key_field, #api_url_field').on('blur', function() {
        validateField($(this));
    });

    // Auto-save functionality (optional)
    let saveTimeout;
    $('#api_key_field, #api_url_field').on('input', function() {
        clearTimeout(saveTimeout);
        saveTimeout = setTimeout(function() {
            // Auto-save could be implemented here
        }, 2000);
    });

    function testApiConnection() {
        const apiKey = $('#api_key_field').val().trim();
        const apiUrl = $('#api_url_field').val().trim();
        const $btn = $('#test-api-btn');
        const $results = $('#api-test-results');
        const $clearBtn = $('#clear-test-results');
        const $status = $('#connection-status');

        // Validate inputs
        if (!apiKey || !apiUrl) {
            showMessage('error', digim_ajax.strings.invalid_credentials);
            return;
        }

        // Show loading state
        $btn.prop('disabled', true);
        $btn.html('<span class="digim-loading-spinner"></span>' + digim_ajax.strings.testing);
        $results.show();
        $results.html('<div class="digim-api-status status-loading">' + 
                     '<span class="digim-loading-spinner"></span>' + 
                     digim_ajax.strings.testing + '</div>');

        // Make AJAX request
        $.ajax({
            url: digim_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'digim_test_api',
                nonce: digim_ajax.nonce,
                api_key: apiKey,
                api_url: apiUrl
            },
            timeout: 20000,
            success: function(response) {
                if (response.success) {
                    displayApiResults('success', response.data);
                    updateConnectionStatus('success', response.data);
                } else {
                    displayApiResults('error', response.data);
                    updateConnectionStatus('error', response.data);
                }
            },
            error: function(xhr, status, error) {
                const errorData = {
                    status: 'error',
                    message: 'Request failed: ' + error,
                    status_code: xhr.status || 0
                };
                displayApiResults('error', errorData);
                updateConnectionStatus('error', errorData);
            },
            complete: function() {
                // Reset button state
                $btn.prop('disabled', false);
                $btn.html('<span class="dashicons dashicons-admin-plugins"></span> Test API Connection');
                $clearBtn.show();
            }
        });
    }

    function displayApiResults(type, data) {
        const $results = $('#api-test-results');
        let statusClass = 'status-' + type;
        let icon = type === 'success' ? '✅' : type === 'warning' ? '⚠️' : '❌';
        
        let html = '<div class="digim-api-status ' + statusClass + '">';
        html += '<strong>' + icon + ' ' + data.message + '</strong>';
        
        if (data.status_code) {
            html += '<br><small>HTTP ' + data.status_code;
            if (data.response_time) {
                html += ' • Response time: ' + data.response_time + 'ms';
            }
            html += '</small>';
        }
        
        html += '</div>';

        // Add detailed information
        if (data.endpoint) {
            html += '<div class="digim-api-details">';
            html += '<strong>Endpoint:</strong> ' + data.endpoint + '<br>';
            html += '<strong>Timestamp:</strong> ' + data.timestamp + '<br>';
            
            if (data.user_data && data.user_data.email) {
                html += '<strong>Connected as:</strong> ' + data.user_data.email + '<br>';
            }
            
            if (data.headers) {
                html += '<strong>Response Headers:</strong><br>';
                html += '<pre>' + JSON.stringify(data.headers, null, 2) + '</pre>';
            }
            
            if (data.body && data.body.length < 1000) {
                html += '<strong>Response Body:</strong><br>';
                html += '<pre>' + data.body + '</pre>';
            }
            
            html += '</div>';
        }

        $results.html(html);
    }

    function updateConnectionStatus(type, data) {
        const $status = $('#connection-status');
        let statusClass = 'status-' + type;
        let icon = type === 'success' ? '✅' : type === 'warning' ? '⚠️' : '❌';
        
        let html = '<div class="digim-api-status ' + statusClass + '">';
        html += '<strong>' + icon + ' ' + data.message + '</strong>';
        
        if (data.user_data && data.user_data.email) {
            html += '<br><small>Connected as: ' + data.user_data.email + '</small>';
        }
        
        if (data.response_time) {
            html += '<br><small>Response time: ' + data.response_time + 'ms</small>';
        }
        
        html += '</div>';
        
        $status.html(html);
    }

    function clearTestResults() {
        $('#api-test-results').hide().html('');
        $('#clear-test-results').hide();
        $('#connection-status').html('<p>Configure your API settings above and test the connection to see status information.</p>');
    }

    function validateForm() {
        let isValid = true;
        
        // Validate API Key
        if (!validateField($('#api_key_field'))) {
            isValid = false;
        }
        
        // Validate API URL
        if (!validateField($('#api_url_field'))) {
            isValid = false;
        }
        
        return isValid;
    }

    function validateField($field) {
        const value = $field.val().trim();
        const fieldName = $field.attr('id');
        let isValid = true;
        let message = '';

        // Remove existing validation styling
        $field.removeClass('error success');
        $field.siblings('.validation-message').remove();

        if (fieldName === 'api_key_field') {
            if (!value) {
                isValid = false;
                message = 'API Key is required';
            } else if (value.length < 10) {
                isValid = false;
                message = 'API Key seems too short';
            }
        } else if (fieldName === 'api_url_field') {
            if (!value) {
                isValid = false;
                message = 'API URL is required';
            } else if (!isValidUrl(value)) {
                isValid = false;
                message = 'Please enter a valid URL';
            }
        }

        if (!isValid) {
            $field.addClass('error');
            $field.after('<div class="validation-message" style="color: #d63384; font-size: 12px; margin-top: 5px;">' + message + '</div>');
        } else {
            $field.addClass('success');
        }

        return isValid;
    }

    function isValidUrl(string) {
        try {
            new URL(string);
            return true;
        } catch (_) {
            return false;
        }
    }

    function showMessage(type, message) {
        const $results = $('#api-test-results');
        const statusClass = 'status-' + type;
        const icon = type === 'success' ? '✅' : type === 'warning' ? '⚠️' : '❌';
        
        $results.show().html('<div class="digim-api-status ' + statusClass + '">' + 
                           '<strong>' + icon + ' ' + message + '</strong></div>');
    }

    // Add some visual enhancements
    $('.digim-input-group input').on('focus', function() {
        $(this).parent().addClass('focused');
    }).on('blur', function() {
        $(this).parent().removeClass('focused');
    });

    // Add smooth scrolling for better UX
    $('a[href^="#"]').on('click', function(e) {
        e.preventDefault();
        const target = $(this.getAttribute('href'));
        if (target.length) {
            $('html, body').animate({
                scrollTop: target.offset().top - 100
            }, 500);
        }
    });

    // Add keyboard shortcuts
    $(document).on('keydown', function(e) {
        // Ctrl/Cmd + Enter to test API
        if ((e.ctrlKey || e.metaKey) && e.keyCode === 13) {
            e.preventDefault();
            testApiConnection();
        }
        
        // Escape to clear results
        if (e.keyCode === 27) {
            clearTestResults();
        }
    });

    // Add tooltips for better UX
    $('[title]').each(function() {
        $(this).tooltip({
            position: { my: "left+15 center", at: "right center" }
        });
    });

    // Initialize with current values
    const currentApiKey = $('#api_key_field').val();
    const currentApiUrl = $('#api_url_field').val();
    
    if (currentApiKey && currentApiUrl) {
        // Auto-validate on page load if values exist
        validateField($('#api_key_field'));
        validateField($('#api_url_field'));
    }
});
