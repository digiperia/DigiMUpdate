<?php

/**
 * Template: Single Property
 * Called by your plugin when visiting /property/{uuid}
 */

// From inside a file under /plugins/DigiM/templates/...
$plugin_dir = plugin_dir_path(dirname(__FILE__)); // -> /plugins/DigiM/
$plugin_url = plugin_dir_url(dirname(__FILE__));  // -> https://.../plugins/DigiM/

$rel        = 'assets/css/style.css';
$style_path = $plugin_dir . $rel;
$style_url  = $plugin_url . $rel;

if (file_exists($style_path)) {
    wp_enqueue_style('digim-style', $style_url, [], filemtime($style_path));
}

// Ensure frontend JS is loaded on the single property page
$js_rel  = 'assets/js/frontend.js';
$js_path = $plugin_dir . $js_rel;
$js_url  = $plugin_url . $js_rel;
if (file_exists($js_path)) {
    wp_enqueue_script('digim-frontend', $js_url, ['jquery'], filemtime($js_path), true);
}

// Lightgallery for modal images
wp_enqueue_style('lightgallery-css', 'https://cdn.jsdelivr.net/npm/lightgallery@2.7.2/css/lightgallery-bundle.min.css', [], '2.7.2');
wp_enqueue_script('lightgallery-js', 'https://cdn.jsdelivr.net/npm/lightgallery@2.7.2/lightgallery.min.js', [], '2.7.2', true);
wp_enqueue_script('lightgallery-thumbnail-js', 'https://cdn.jsdelivr.net/npm/lightgallery@2.7.2/plugins/thumbnail/lg-thumbnail.min.js', ['lightgallery-js'], '2.7.2', true);
wp_enqueue_script('lightgallery-zoom-js', 'https://cdn.jsdelivr.net/npm/lightgallery@2.7.2/plugins/zoom/lg-zoom.min.js', ['lightgallery-js'], '2.7.2', true);

// Get property identifier (could be UUID or slug)
$identifier = get_query_var('dm_property_identifier');
$uuid = null;
$property = null;

// Debug: Log the identifier
error_log("Property identifier from URL: " . $identifier);

// Check if identifier is a UUID (contains hyphens and is 36 chars long)
if (preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $identifier)) {
    // It's a UUID, use it directly
    $uuid = $identifier;
    error_log("Using UUID directly: " . $uuid);
} else {
    // It's a slug, look up the property to get the UUID
    $property = digimanagement_get_property_by_slug($identifier);
    if ($property) {
        $uuid = $property['uuid'] ?? $property['id'] ?? null;
        error_log("Found UUID from slug lookup: " . $uuid);
        error_log("Property data: " . print_r($property, true));
    } else {
        error_log("No property found for slug: " . $identifier);
    }
}

// If we don't have a property yet (UUID case), fetch it
if (!$property && $uuid) {
    $response = wp_remote_get(digimanagement_get_api_url() . "/properties/$uuid", [
        'headers' => [
            'Authorization' => digimanagement_get_api_token(),
            'Accept' => 'application/json',
            'Cache-Control' => 'no-cache',
        ],
        'timeout' => 15,
    ]);

    if (is_wp_error($response)) {
        echo '<p>Error: ' . esc_html($response->get_error_message()) . '</p>';
        get_footer();
        return;
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);
    $property = $data['data'] ?? null;
}

if (!$property || !$uuid) {
    status_header(404);
    if (function_exists('digimanagement_set_current_property_context')) {
        digimanagement_set_current_property_context(null);
    }

    include get_template_directory() . '/header.php';
    echo '<main class="digim-property-not-found"><p>Property not found.</p></main>';
    get_footer();
    return;
}

// ✅ Fetch reviews from /reviews endpoint
$reviews = [];
$total_reviews_count = 0;
$average_rating = 0;

$reviews_response = wp_remote_get(digimanagement_get_api_url() . "/properties/$uuid/reviews", [
    'headers' => [
        'Authorization' => digimanagement_get_api_token(),
        'Accept' => 'application/json',
        'Cache-Control' => 'no-cache',
    ],
    'timeout' => 10,
]);

if (!is_wp_error($reviews_response)) {
    $reviews_data = json_decode(wp_remote_retrieve_body($reviews_response), true);
    $reviews = $reviews_data['data'] ?? [];
    
    // Try to fetch reservations to get guest information
    // We'll match reviews to reservations by date
    $reservations = [];
    $reservations_response = wp_remote_get(digimanagement_get_api_url() . "/properties/$uuid/reservations", [
        'headers' => [
            'Authorization' => digimanagement_get_api_token(),
            'Accept' => 'application/json',
            'Cache-Control' => 'no-cache',
        ],
        'timeout' => 10,
    ]);
    
    if (!is_wp_error($reservations_response)) {
        $reservations_data = json_decode(wp_remote_retrieve_body($reservations_response), true);
        $reservations = $reservations_data['data'] ?? [];
        
        // Create a map of reservation dates to guest info
        $reservation_guest_map = [];
        foreach ($reservations as $reservation) {
            $checkout_date = $reservation['checkout'] ?? $reservation['checkout_date'] ?? null;
            if ($checkout_date) {
                // Normalize date to Y-m-d format for matching
                try {
                    $date_obj = new DateTime($checkout_date);
                    $date_key = $date_obj->format('Y-m-d');
                    
                    // Extract guest name from reservation
                    $guest_name = null;
                    if (isset($reservation['guest']) && is_array($reservation['guest'])) {
                        $guest = $reservation['guest'];
                        if (!empty($guest['first_name']) && !empty($guest['last_name'])) {
                            $guest_name = trim($guest['first_name'] . ' ' . $guest['last_name']);
                        } elseif (!empty($guest['name'])) {
                            $guest_name = $guest['name'];
                        } elseif (!empty($guest['full_name'])) {
                            $guest_name = $guest['full_name'];
                        } elseif (!empty($guest['first_name'])) {
                            $guest_name = $guest['first_name'];
                        }
                    }
                    
                    // Extract guest avatar
                    $guest_avatar = null;
                    if (isset($reservation['guest']) && is_array($reservation['guest'])) {
                        $avatar_fields = ['avatar', 'avatar_url', 'profile_picture', 'photo', 'profile_photo', 'picture_url', 'image_url'];
                        foreach ($avatar_fields as $field) {
                            if (!empty($reservation['guest'][$field])) {
                                $guest_avatar = $reservation['guest'][$field];
                                break;
                            }
                        }
                    }
                    
                    if ($guest_name || $guest_avatar) {
                        $reservation_guest_map[$date_key] = [
                            'name' => $guest_name,
                            'avatar' => $guest_avatar
                        ];
                    }
                } catch (Exception $e) {
                    // Skip invalid dates
                }
            }
        }
        
        // Match reviews to reservations by date and add guest info
        foreach ($reviews as &$review) {
            $review_date = $review['reviewed_at'] ?? null;
            if ($review_date) {
                try {
                    $date_obj = new DateTime($review_date);
                    $date_key = $date_obj->format('Y-m-d');
                    
                    // Check if we have guest info for this date (or nearby dates)
                    if (isset($reservation_guest_map[$date_key])) {
                        $review['_matched_guest'] = $reservation_guest_map[$date_key];
                    } else {
                        // Try checking a few days before/after
                        for ($i = -7; $i <= 7; $i++) {
                            $check_date = clone $date_obj;
                            $check_date->modify("$i days");
                            $check_key = $check_date->format('Y-m-d');
                            if (isset($reservation_guest_map[$check_key])) {
                                $review['_matched_guest'] = $reservation_guest_map[$check_key];
                                break;
                            }
                        }
                    }
                } catch (Exception $e) {
                    // Skip invalid dates
                }
            }
        }
        unset($review); // Break reference
    }
    
    // Extract total review count from API response metadata
    // Check multiple possible locations for total count
    if (isset($reviews_data['meta']['total'])) {
        $total_reviews_count = intval($reviews_data['meta']['total']);
    } elseif (isset($reviews_data['meta']['count'])) {
        $total_reviews_count = intval($reviews_data['meta']['count']);
    } elseif (isset($reviews_data['total'])) {
        $total_reviews_count = intval($reviews_data['total']);
    } elseif (isset($reviews_data['count'])) {
        $total_reviews_count = intval($reviews_data['count']);
    } elseif (isset($reviews_data['pagination']['total'])) {
        $total_reviews_count = intval($reviews_data['pagination']['total']);
    } elseif (isset($reviews_data['pagination']['count'])) {
        $total_reviews_count = intval($reviews_data['pagination']['count']);
    }
    
    // Extract average rating from API response if available
    if (isset($reviews_data['meta']['average_rating'])) {
        $average_rating = round(floatval($reviews_data['meta']['average_rating']), 2);
    } elseif (isset($reviews_data['average_rating'])) {
        $average_rating = round(floatval($reviews_data['average_rating']), 2);
    } elseif (isset($reviews_data['meta']['rating'])) {
        $average_rating = round(floatval($reviews_data['meta']['rating']), 2);
    } elseif (isset($reviews_data['rating'])) {
        $average_rating = round(floatval($reviews_data['rating']), 2);
    }
}

// If total count not found in reviews response, check property object
if ($total_reviews_count === 0) {
    // Check direct property fields
    $review_count_fields = ['reviews_count', 'review_count', 'total_reviews', 'reviews', 'count'];
    foreach ($review_count_fields as $field) {
        if (isset($property[$field]) && is_numeric($property[$field])) {
            $total_reviews_count = intval($property[$field]);
            break;
        }
    }
    
    // Check nested in reviews object
    if ($total_reviews_count === 0 && isset($property['reviews']) && is_array($property['reviews'])) {
        if (isset($property['reviews']['count']) && is_numeric($property['reviews']['count'])) {
            $total_reviews_count = intval($property['reviews']['count']);
        } elseif (isset($property['reviews']['total']) && is_numeric($property['reviews']['total'])) {
            $total_reviews_count = intval($property['reviews']['total']);
        } elseif (isset($property['reviews']['total_reviews']) && is_numeric($property['reviews']['total_reviews'])) {
            $total_reviews_count = intval($property['reviews']['total_reviews']);
        }
    }
    
    // Check nested in statistics or stats
    if ($total_reviews_count === 0 && isset($property['statistics']['reviews_count']) && is_numeric($property['statistics']['reviews_count'])) {
        $total_reviews_count = intval($property['statistics']['reviews_count']);
    }
    if ($total_reviews_count === 0 && isset($property['stats']['reviews_count']) && is_numeric($property['stats']['reviews_count'])) {
        $total_reviews_count = intval($property['stats']['reviews_count']);
    }
}

// If average rating not found in reviews response, check property object
if ($average_rating === 0) {
    $rating_fields = ['average_rating', 'rating', 'overall_rating', 'review_rating'];
    foreach ($rating_fields as $field) {
        if (isset($property[$field]) && is_numeric($property[$field])) {
            $average_rating = round(floatval($property[$field]), 2);
            break;
        }
    }
    
    // Check nested in reviews object
    if ($average_rating === 0 && isset($property['reviews']) && is_array($property['reviews'])) {
        foreach ($rating_fields as $field) {
            if (isset($property['reviews'][$field]) && is_numeric($property['reviews'][$field])) {
                $average_rating = round(floatval($property['reviews'][$field]), 2);
                break;
            }
        }
    }
    
    // Check nested in statistics or stats
    if ($average_rating === 0 && isset($property['statistics']['average_rating']) && is_numeric($property['statistics']['average_rating'])) {
        $average_rating = round(floatval($property['statistics']['average_rating']), 2);
    }
    if ($average_rating === 0 && isset($property['stats']['average_rating']) && is_numeric($property['stats']['average_rating'])) {
        $average_rating = round(floatval($property['stats']['average_rating']), 2);
    }
}

// If average rating still not found, calculate from returned reviews
if ($average_rating === 0 && !empty($reviews)) {
    $total_rating = 0;
    $review_count = 0;
    foreach ($reviews as $review) {
        $rating = $review['public']['rating'] ?? null;
        if ($rating !== null) {
            $total_rating += $rating;
            $review_count++;
        }
    }
    if ($review_count > 0) {
        $average_rating = round($total_rating / $review_count, 2);
    }
}

// If still no total count, use the count of returned reviews as fallback
if ($total_reviews_count === 0) {
    $total_reviews_count = count($reviews);
}

// ✅ Fetch images from dedicated /images endpoint
$images = [];
$images_response = wp_remote_get(digimanagement_get_api_url() . "/properties/$uuid/images", [
    'headers' => [
        'Authorization' => digimanagement_get_api_token(),
        'Accept' => 'application/json',
        'Cache-Control' => 'no-cache',
    ],
    'timeout' => 10,
]);

if (!is_wp_error($images_response)) {
    $images_data = json_decode(wp_remote_retrieve_body($images_response), true);

    $seen = [];
    foreach ($images_data['data'] ?? [] as $img) {
        $url = $img['original_url'] ?? $img['url'] ?? $img['thumbnail_url'] ?? null;
        if ($url && !in_array($url, $seen)) {
            $images[] = $url;
            $seen[] = $url;
        }
    }
}

$context_property = $property;
if (!empty($images)) {
    $context_property['images'] = array_map(function ($url) {
        return ['url' => $url];
    }, $images);
}

if (function_exists('digimanagement_set_current_property_context')) {
    digimanagement_set_current_property_context($context_property, $identifier ?: $uuid);
}

$coords = $property['address']['coordinates'] ?? null;
$amenities = $property['amenities'] ?? [];
$property_description = function_exists('digim_get_property_description')
    ? digim_get_property_description($property)
    : ($property['description'] ?? $property['summary'] ?? '');

wp_enqueue_script('digim-feather-icons', 'https://cdn.jsdelivr.net/npm/feather-icons@4.29.2/dist/feather.min.js', [], '4.29.2', true);

$normalized_amenities = array_map(function ($amenity) {
    return trim(preg_replace('/[^a-z0-9]+/', '_', strtolower($amenity)), '_');
}, $amenities);

$tags = $property['tags'] ?? [];
$normalized_tags = array_map(function ($tag) {
    return trim(preg_replace('/[^a-z0-9]+/', '_', strtolower($tag)), '_');
}, (array) $tags);

$highlight_map = [
    'free_parking' => 'Free Parking',
    'free_parking_on_premises' => 'Free Parking',
    'parking' => 'Free Parking',
    'pets_allowed' => 'Pet Friendly',
    'pet_friendly' => 'Pet Friendly',
    'pet_friendly_room' => 'Pet Friendly',
];

$highlight_badges = [];
foreach ($highlight_map as $key => $label) {
    if (in_array($key, $normalized_amenities, true) || in_array($key, $normalized_tags, true) || !empty($property[$key])) {
        $highlight_badges[] = $label;
    }
}
$highlight_badges = array_values(array_unique($highlight_badges));

$amenity_icons = [
    'ac' => 'wind',
    'alfresco_dining' => 'coffee',
    'alfresco_shower' => 'cloud-rain',
    'arcade_machine' => 'cpu',
    'baking_sheet' => 'grid',
    'barbeque_utensils' => 'tool',
    'bathtub' => 'droplet',
    'bbq_area' => 'sun',
    'beach_essentials' => 'umbrella',
    'bed_linens' => 'layers',
    'blender' => 'aperture',
    'board_games' => 'grid',
    'ceiling_fan' => 'rotate-cw',
    'coffee' => 'coffee',
    'conditioner' => 'droplet',
    'crib' => 'box',
    'dining_table' => 'grid',
    'dishes_and_silverware' => 'tool',
    'dishwasher' => 'droplet',
    'dryer' => 'wind',
    'ev_charger' => 'battery-charging',
    'fire_extinguisher' => 'shield',
    'first_aid_kit' => 'plus-square',
    'free_parking' => 'truck',
    'freezer' => 'thermometer',
    'game_console' => 'cpu',
    'hair_dryer' => 'wind',
    'hangers' => 'feather',
    'high_chair' => 'square',
    'hot_water' => 'thermometer',
    'iron' => 'slash',
    'keurig_coffee_machine' => 'coffee',
    'kitchen' => 'home',
    'laptop_friendly_workspace' => 'monitor',
    'laundromat_nearby' => 'refresh-ccw',
    'microwave' => 'cpu',
    'portable_fans' => 'wind',
    'refrigerator' => 'thermometer',
    'room_darkening_shades' => 'moon',
    'shampoo' => 'droplet',
    'sun_loungers' => 'sun',
    'toaster' => 'grid',
    'tv' => 'tv',
    'washer' => 'refresh-cw',
    'wine_glasses' => 'heart',
];
$default_icon_name = 'check-square';
$image_count = count($images);
$current_path = $_SERVER['REQUEST_URI'] ?? '';
$current_url = esc_url_raw(home_url($current_path));
$encoded_url = rawurlencode($current_url);
$encoded_title = rawurlencode($property['name'] ?? '');
$max_shown = 8;
?>

<?php include get_template_directory() . '/header.php'; ?>

<div class="airbnb-property-page" style="opacity: 0;">
    <style>
        :root {
            --digim-primary-color: <?php echo esc_attr(get_option('digim_primary_color', '#0073aa')); ?>;
            --digim-primary-color-dark: <?php echo esc_attr(get_option('digim_primary_color', '#0073aa')); ?>dd;
            --digim-primary-color-darker: <?php echo esc_attr(get_option('digim_primary_color', '#0073aa')); ?>cc;
        }
    </style>
    <!-- Hero Image Gallery -->
    <?php if (!empty($images)): ?>
        <div class="hero-gallery">
            <!-- Main large image -->
            <div class="main-image">
                <img src="<?php echo esc_url($images[0]); ?>" alt="Main Photo" loading="lazy" id="main-image">
            </div>
            
            <!-- Thumbnail grid (desktop only) -->
            <?php if (count($images) > 1): ?>
                <div class="thumbnail-grid">
                    <!-- Top row -->
                    <div class="thumbnail-item" onclick="changeMainImage('<?php echo esc_url($images[1]); ?>')">
                        <img src="<?php echo esc_url($images[1]); ?>" alt="Photo 2" loading="lazy">
                    </div>
                    <div class="thumbnail-item" onclick="changeMainImage('<?php echo esc_url($images[2]); ?>')">
                        <img src="<?php echo esc_url($images[2]); ?>" alt="Photo 3" loading="lazy">
                    </div>
                    
                    <!-- Bottom row -->
                    <div class="thumbnail-item" onclick="changeMainImage('<?php echo esc_url($images[3]); ?>')">
                        <img src="<?php echo esc_url($images[3]); ?>" alt="Photo 4" loading="lazy">
                    </div>
                    <div class="thumbnail-item show-all">
                        <img src="<?php echo esc_url($images[4] ?? $images[3]); ?>" alt="More photos" loading="lazy">
                        <div class="show-all-overlay">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M3 3h7v7H3V3zm11 0h7v7h-7V3zM3 14h7v7H3v-7zm11 0h7v7h-7v-7z"/>
                            </svg>
                            <span>Show all photos</span>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Mobile slider counter -->
            <div class="slider-counter" id="slider-counter">
                <span id="slider-counter-current">1</span>
                <span class="slider-counter-separator">/</span>
                <span id="slider-counter-total"><?php echo $image_count; ?></span>
            </div>

            <!-- Mobile slider arrows -->
            <button class="slider-arrow prev" onclick="previousSlide()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"/>
                </svg>
            </button>
            <button class="slider-arrow next" onclick="nextSlide()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"/>
                </svg>
            </button>
        </div>
    <?php endif; ?>

    <!-- Main Content Container -->
    <div class="content-container">
        <!-- Left Content -->
        <div class="left-content">
            <!-- Property Header -->
            <div class="property-header">
                <div class="property-title-group">
                    <h1 class="property-title"><?php echo esc_html($property['name'] ?? ''); ?></h1>
                    <div class="property-location">
                        <span class="location-text"><?php echo esc_html($property['address']['display'] ?? ''); ?></span>
                    </div>
                </div>
                <div class="property-share" aria-label="Share this property">
                    <span class="share-label">Share</span>
                    <div class="share-actions">
                        <a class="share-link share-facebook" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $encoded_url; ?>" target="_blank" rel="noopener noreferrer" aria-label="Share on Facebook">
                            <svg viewBox="0 0 320 512" width="18" height="18" aria-hidden="true" focusable="false">
                                <path fill="currentColor" d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z"/>
                            </svg>
                        </a>
                        <a class="share-link share-x" href="https://twitter.com/intent/tweet?url=<?php echo $encoded_url; ?>&text=<?php echo $encoded_title; ?>" target="_blank" rel="noopener noreferrer" aria-label="Share on X">
                            <svg viewBox="0 0 512 512" width="18" height="18" aria-hidden="true" focusable="false">
                                <path fill="currentColor" d="M389.2 48h70.6L322.3 224.2 487.4 464H345L233.4 306.9 106.5 464H35.8L204.2 274.8 47.9 48h146.1l99.7 134.4L389.2 48zm-24.7 373.8h39.1L151.1 86.1h-42z"/>
                            </svg>
                        </a>
                        <a class="share-link share-linkedin" href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo $encoded_url; ?>" target="_blank" rel="noopener noreferrer" aria-label="Share on LinkedIn">
                            <svg viewBox="0 0 448 512" width="18" height="18" aria-hidden="true" focusable="false">
                                <path fill="currentColor" d="M100.28 448H7.4V148.9h92.88zm-46.44-340.7C24 107.3 0 83.3 0 53.7A53.72 53.72 0 0 1 53.7 0a53.72 53.72 0 0 1 53.7 53.7c0 29.6-24 53.6-53.56 53.6zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.25-79.2-48.3 0-55.7 37.7-55.7 76.6V448h-92.7V148.9h88.9v40.8h1.3c12.4-23.5 42.7-48.3 87.9-48.3 94 0 111.3 61.9 111.3 142.3z"/>
                            </svg>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Property Details -->
            <div class="property-details">
                <!-- <div class="detail-item">
                    <span><b><?php echo intval($property['capacity']['max'] ?? 0); ?></b> guests</span>
                </div> -->
                <div class="detail-item">
                    <span><b><?php echo intval($property['capacity']['bedrooms'] ?? 0); ?></b> bedrooms</span>
                </div>
                <div class="detail-item">
                    <span><b><?php echo intval($property['capacity']['beds'] ?? 0); ?></b> beds</span>
                </div>
                <div class="detail-item">
                    <span><b><?php echo intval($property['capacity']['bathrooms'] ?? 0); ?></b> baths</span>
                </div>
            </div>

            <?php if (!empty($highlight_badges)): ?>
                <div class="property-highlights">
                    <?php foreach ($highlight_badges as $badge): ?>
                        <span class="highlight-badge"><?php echo esc_html($badge); ?></span>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <!-- Divider -->
            <div class="divider"></div>

            <?php if (!empty($property_description) || !empty($property['room_details'])): ?>
                <!-- Description with Tabs -->
                <div class="property-description">
                    <div class="description-tabs">
                        <button class="tab-button active" data-tab="about">About this place</button>
                        <?php if (!empty($property['room_details'])): ?>
                            <button class="tab-button" data-tab="rooms">Room details</button>
                        <?php endif; ?>
                    </div>
                    
                    <div class="tab-content active" id="tab-about">
                        <div class="description-content">
                            <p class="description-text"><?php echo nl2br(esc_html($property_description)); ?></p>
                            <button class="show-more-btn" onclick="toggleDescription()" style="display: none;">
                                <span class="btn-text">Show more</span>
                                <svg class="btn-icon" width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6 1.41-1.41z"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                    
                    <?php if (!empty($property['room_details'])): ?>
                        <div class="tab-content" id="tab-rooms">
                            <div class="room-details-content">
                                <?php 
                                $room_details = $property['room_details'] ?? [];
                                if (is_array($room_details) && !empty($room_details)): 
                                    // Function to create a bed signature for grouping
                                    $get_bed_signature = function($room) {
                                        $beds = $room['beds'] ?? [];
                                        if (empty($beds) || !is_array($beds)) {
                                            return 'no_beds';
                                        }
                                        
                                        // Create a signature based on bed types and counts
                                        $bed_signature_parts = [];
                                        foreach ($beds as $bed) {
                                            if (is_array($bed)) {
                                                $bed_type = $bed['type'] ?? ($bed['name'] ?? 'bed');
                                                $bed_count = isset($bed['count']) ? intval($bed['count']) : 1;
                                                $bed_signature_parts[] = $bed_count . '_' . $bed_type;
                                            } elseif (is_string($bed)) {
                                                $bed_signature_parts[] = '1_' . $bed;
                                            } else {
                                                $bed_signature_parts[] = '1_bed';
                                            }
                                        }
                                        
                                        // Sort to ensure consistent grouping (e.g., "1_king_bed,1_queen_bed" vs "1_queen_bed,1_king_bed")
                                        sort($bed_signature_parts);
                                        return implode(',', $bed_signature_parts);
                                    };
                                    
                                    // Group rooms by type AND bed configuration
                                    $grouped_rooms = [];
                                    foreach ($room_details as $room) {
                                        $type = $room['type'] ?? 'other';
                                        $bed_signature = $get_bed_signature($room);
                                        
                                        // Create a unique key combining type and bed signature
                                        $group_key = $type . '|' . $bed_signature;
                                        
                                        if (!isset($grouped_rooms[$group_key])) {
                                            $grouped_rooms[$group_key] = [];
                                        }
                                        $grouped_rooms[$group_key][] = $room;
                                    }
                                    
                                    // Function to format room type name
                                    $format_room_type = function($type) {
                                        return ucwords(str_replace(['_', '-'], ' ', $type));
                                    };
                                    
                                    // Define room type priority for sorting (bedrooms first, then others)
                                    $room_type_priority = [
                                        'bedroom' => 1,
                                        'living_room' => 2,
                                        'dining_room' => 3,
                                        'kitchen' => 4,
                                        'full_bathroom' => 5,
                                        'half_bathroom' => 6,
                                        'bathroom' => 7,
                                        'balcony' => 8,
                                        'backyard' => 9,
                                        'exterior' => 10,
                                        'laundry_room' => 11,
                                        'other' => 999,
                                    ];
                                    
                                    // Sort grouped rooms: bedrooms first, then by priority, then alphabetically
                                    uksort($grouped_rooms, function($a, $b) use ($room_type_priority) {
                                        $parts_a = explode('|', $a, 2);
                                        $parts_b = explode('|', $b, 2);
                                        $type_a = $parts_a[0] ?? 'other';
                                        $type_b = $parts_b[0] ?? 'other';
                                        
                                        // Get priority (default to 999 if not found)
                                        $priority_a = $room_type_priority[$type_a] ?? 999;
                                        $priority_b = $room_type_priority[$type_b] ?? 999;
                                        
                                        // If both are bedrooms, sort by bed signature (alphabetically)
                                        if ($type_a === 'bedroom' && $type_b === 'bedroom') {
                                            $bed_sig_a = $parts_a[1] ?? '';
                                            $bed_sig_b = $parts_b[1] ?? '';
                                            return strcmp($bed_sig_a, $bed_sig_b);
                                        }
                                        
                                        // If only one is bedroom, it comes first
                                        if ($type_a === 'bedroom' && $type_b !== 'bedroom') {
                                            return -1;
                                        }
                                        if ($type_a !== 'bedroom' && $type_b === 'bedroom') {
                                            return 1;
                                        }
                                        
                                        // Otherwise sort by priority, then alphabetically
                                        if ($priority_a !== $priority_b) {
                                            return $priority_a <=> $priority_b;
                                        }
                                        
                                        return strcmp($type_a, $type_b);
                                    });
                                ?>
                                    <div class="room-details-list">
                                        <?php foreach ($grouped_rooms as $group_key => $rooms): ?>
                                            <?php 
                                            $room_count = count($rooms);
                                            // Extract room type from group key (format: "type|bed_signature")
                                            $parts = explode('|', $group_key, 2);
                                            $room_type = $parts[0] ?? 'other';
                                            
                                            // Get beds from the first room (or aggregate if needed)
                                            $first_room = $rooms[0];
                                            ?>
                                            <div class="room-item">
                                                <div class="room-type">
                                                    <strong>
                                                        <?php 
                                                        echo esc_html($format_room_type($room_type));
                                                        if ($room_count > 1) {
                                                            echo ' <span class="room-count">(' . $room_count . 'x)</span>';
                                                        }
                                                        ?>
                                                    </strong>
                                                </div>
                                                <?php if (!empty($first_room['beds']) && is_array($first_room['beds']) && count($first_room['beds']) > 0): ?>
                                                    <div class="room-beds">
                                                        <?php 
                                                        $bed_types = [];
                                                        foreach ($first_room['beds'] as $bed) {
                                                            if (is_array($bed)) {
                                                                $bed_type = $bed['type'] ?? ($bed['name'] ?? 'bed');
                                                                $bed_count = isset($bed['count']) ? intval($bed['count']) : 1;
                                                                $bed_label = ucwords(str_replace(['_', '-'], ' ', $bed_type));
                                                                if ($bed_count > 1) {
                                                                    $bed_types[] = $bed_count . ' ' . $bed_label . 's';
                                                                } else {
                                                                    $bed_types[] = $bed_label;
                                                                }
                                                            } elseif (is_string($bed)) {
                                                                $bed_types[] = ucwords(str_replace(['_', '-'], ' ', $bed));
                                                            } else {
                                                                // Fallback for other types
                                                                $bed_types[] = 'Bed';
                                                            }
                                                        }
                                                        if (!empty($bed_types)):
                                                        ?>
                                                            <span class="beds-label"><?php echo esc_html(implode(', ', $bed_types)); ?></span>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else: ?>
                                    <p>No room details available.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <!-- Divider -->
            <div class="divider"></div>

            <!-- Amenities -->
            <?php if (!empty($amenities)): ?>
                <div class="amenities-section">
                    <h2>What this place offers</h2>
                    <div class="amenities-grid">
                        <?php foreach (array_slice($amenities, 0, $max_shown) as $a):
                            $normalized_amenity = trim(preg_replace('/[^a-z0-9]+/', '_', strtolower($a)), '_');
                            $label = ucwords(preg_replace('/[_-]+/', ' ', $a));
                            $icon_name = $amenity_icons[$normalized_amenity] ?? $default_icon_name;
                        ?>
                            <div class="amenity-item">
                                <i class="amenity-icon" data-feather="<?php echo esc_attr($icon_name); ?>" aria-hidden="true"></i>
                                <span class="amenity-label"><?php echo esc_html($label); ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <?php if (count($amenities) > $max_shown): ?>
                        <button class="show-all-amenities" onclick="document.getElementById('amenities-modal').style.display='block'">
                            Show all <?php echo count($amenities); ?> amenities
                        </button>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <!-- Divider -->
            <div class="divider"></div>

            <!-- Reviews Section -->
            <?php if (!empty($reviews)): ?>
                <div class="reviews-section">
                    <!-- Overall Rating -->
                    <div class="overall-rating">
                        <div class="rating-number"><?php echo esc_html($average_rating); ?></div>
                        <?php if ($total_reviews_count > 0): ?>
                            <div class="rating-stars">
                                <?php for ($i = 0; $i < 5; $i++): ?>
                                    <span class="star <?php echo $i < floor($average_rating) ? 'filled' : ''; ?>">★</span>
                                <?php endfor; ?>
                            </div>
                            <div class="rating-count"><?php echo esc_html($total_reviews_count); ?> Reviews</div>
                        <?php endif; ?>
                    </div>
                    <div class="guest-favorite-label">Guest favorite</div>
                    <p class="guest-favorite-desc">This home is a guest favorite based on ratings, reviews, and reliability</p>

                    <!-- Reviews Grid -->
                    <div class="reviews-grid" id="reviews-grid">
                        <?php foreach (array_slice($reviews, 0, 2) as $index => $review): 
                            // Debug: Log review structure (remove after debugging)
                            if ($index === 0) {
                                error_log("Review structure: " . print_r($review, true));
                                // Also output available keys for debugging
                                error_log("Review keys: " . implode(', ', array_keys($review)));
                                if (isset($review['public']) && is_array($review['public'])) {
                                    error_log("Public keys: " . implode(', ', array_keys($review['public'])));
                                }
                                if (isset($review['guest']) && is_array($review['guest'])) {
                                    error_log("Guest keys: " . implode(', ', array_keys($review['guest'])));
                                }
                                if (isset($review['reservation']) && is_array($review['reservation'])) {
                                    error_log("Reservation keys: " . implode(', ', array_keys($review['reservation'])));
                                    if (isset($review['reservation']['guest']) && is_array($review['reservation']['guest'])) {
                                        error_log("Reservation Guest keys: " . implode(', ', array_keys($review['reservation']['guest'])));
                                    }
                                }
                            }
                            
                            // Parse the API response structure
                            $rating = intval($review['public']['rating'] ?? 5);
                            $review_text = $review['public']['review'] ?? '';
                            $review_date = $review['reviewed_at'] ?? '';
                            $platform = $review['platform'] ?? '';
                            
                            // Format dates
                            if ($review_date) {
                                try {
                                    $date_obj = new DateTime($review_date);
                                    $formatted_date = $date_obj->format('F Y');
                                } catch (Exception $e) {
                                    $formatted_date = $review_date;
                                }
                            } else {
                                $formatted_date = '';
                            }
                            
                            // Extract reviewer name from API - check multiple possible fields and nested objects
                            $reviewer_name = null;
                            
                            // First, check if we matched guest info from reservations
                            if (isset($review['_matched_guest']['name']) && !empty($review['_matched_guest']['name'])) {
                                $reviewer_name = $review['_matched_guest']['name'];
                            }
                            
                            // Then check if there's a guest/reservation object that might have the name
                            if (empty($reviewer_name) && isset($review['reservation']) && is_array($review['reservation'])) {
                                if (isset($review['reservation']['guest']) && is_array($review['reservation']['guest'])) {
                                    $guest_obj = $review['reservation']['guest'];
                                    $name_fields = ['name', 'full_name', 'display_name', 'first_name', 'firstname'];
                                    foreach ($name_fields as $field) {
                                        if (!empty($guest_obj[$field]) && is_string($guest_obj[$field])) {
                                            $reviewer_name = $guest_obj[$field];
                                            if ($field === 'first_name' && !empty($guest_obj['last_name'])) {
                                                $reviewer_name = $guest_obj['first_name'] . ' ' . $guest_obj['last_name'];
                                            }
                                            break;
                                        }
                                    }
                                }
                            }
                            
                            // Check direct fields first
                            $name_fields = ['reviewer_name', 'guest_name', 'author_name', 'name', 'reviewer', 'guest'];
                            foreach ($name_fields as $field) {
                                if (!empty($review[$field]) && is_string($review[$field])) {
                                    $reviewer_name = $review[$field];
                                    break;
                                }
                                if (!empty($review['public'][$field]) && is_string($review['public'][$field])) {
                                    $reviewer_name = $review['public'][$field];
                                    break;
                                }
                            }
                            
                            // Check public.guest object
                            if (empty($reviewer_name) && isset($review['public']['guest']) && is_array($review['public']['guest'])) {
                                $name_fields = ['name', 'full_name', 'display_name', 'first_name', 'firstname'];
                                foreach ($name_fields as $field) {
                                    if (!empty($review['public']['guest'][$field]) && is_string($review['public']['guest'][$field])) {
                                        $reviewer_name = $review['public']['guest'][$field];
                                        if ($field === 'first_name' && !empty($review['public']['guest']['last_name'])) {
                                            $reviewer_name = $review['public']['guest']['first_name'] . ' ' . $review['public']['guest']['last_name'];
                                        }
                                        break;
                                    }
                                }
                            }
                            
                            // Check nested guest object (multiple possible structures)
                            if (empty($reviewer_name) && isset($review['guest']) && is_array($review['guest'])) {
                                $guest_name_fields = ['name', 'full_name', 'display_name', 'first_name', 'username', 'firstname', 'given_name'];
                                foreach ($guest_name_fields as $field) {
                                    if (!empty($review['guest'][$field]) && is_string($review['guest'][$field])) {
                                        $reviewer_name = $review['guest'][$field];
                                        // If we have first_name, try to combine with last_name
                                        if ($field === 'first_name' && !empty($review['guest']['last_name'])) {
                                            $reviewer_name = $review['guest']['first_name'] . ' ' . $review['guest']['last_name'];
                                        }
                                        break;
                                    }
                                }
                                // Also check if guest itself is a string
                                if (empty($reviewer_name) && is_string($review['guest'])) {
                                    $reviewer_name = $review['guest'];
                                }
                            }
                            
                            // Check if there's a reservation_guest or booking_guest
                            if (empty($reviewer_name) && isset($review['reservation_guest']) && is_array($review['reservation_guest'])) {
                                $name_fields = ['name', 'full_name', 'display_name', 'first_name'];
                                foreach ($name_fields as $field) {
                                    if (!empty($review['reservation_guest'][$field]) && is_string($review['reservation_guest'][$field])) {
                                        $reviewer_name = $review['reservation_guest'][$field];
                                        if ($field === 'first_name' && !empty($review['reservation_guest']['last_name'])) {
                                            $reviewer_name = $review['reservation_guest']['first_name'] . ' ' . $review['reservation_guest']['last_name'];
                                        }
                                        break;
                                    }
                                }
                            }
                            
                            // Check nested reviewer object
                            if (empty($reviewer_name) && isset($review['reviewer']) && is_array($review['reviewer'])) {
                                $reviewer_name_fields = ['name', 'full_name', 'display_name', 'first_name', 'username'];
                                foreach ($reviewer_name_fields as $field) {
                                    if (!empty($review['reviewer'][$field]) && is_string($review['reviewer'][$field])) {
                                        $reviewer_name = $review['reviewer'][$field];
                                        if ($field === 'first_name' && !empty($review['reviewer']['last_name'])) {
                                            $reviewer_name = $review['reviewer']['first_name'] . ' ' . $review['reviewer']['last_name'];
                                        }
                                        break;
                                    }
                                }
                            }
                            
                            // Check nested author object
                            if (empty($reviewer_name) && isset($review['author']) && is_array($review['author'])) {
                                $author_name_fields = ['name', 'full_name', 'display_name', 'first_name', 'username'];
                                foreach ($author_name_fields as $field) {
                                    if (!empty($review['author'][$field]) && is_string($review['author'][$field])) {
                                        $reviewer_name = $review['author'][$field];
                                        if ($field === 'first_name' && !empty($review['author']['last_name'])) {
                                            $reviewer_name = $review['author']['first_name'] . ' ' . $review['author']['last_name'];
                                        }
                                        break;
                                    }
                                }
                            }
                            
                            // Check nested user object
                            if (empty($reviewer_name) && isset($review['user']) && is_array($review['user'])) {
                                $user_name_fields = ['name', 'full_name', 'display_name', 'first_name', 'username'];
                                foreach ($user_name_fields as $field) {
                                    if (!empty($review['user'][$field]) && is_string($review['user'][$field])) {
                                        $reviewer_name = $review['user'][$field];
                                        if ($field === 'first_name' && !empty($review['user']['last_name'])) {
                                            $reviewer_name = $review['user']['first_name'] . ' ' . $review['user']['last_name'];
                                        }
                                        break;
                                    }
                                }
                            }
                            
                            // Fallback to platform name if not found
                            if (empty($reviewer_name)) {
                                $reviewer_name = ucfirst($platform);
                            }
                            
                            // Extract reviewer avatar from API - check multiple possible fields and nested objects
                            $reviewer_avatar = null;
                            
                            // First, check if we matched guest avatar from reservations
                            if (isset($review['_matched_guest']['avatar']) && !empty($review['_matched_guest']['avatar'])) {
                                $reviewer_avatar = $review['_matched_guest']['avatar'];
                            }
                            
                            // Check direct fields first
                            $avatar_fields = ['avatar', 'avatar_url', 'profile_picture', 'photo', 'profile_photo', 'picture_url', 'image_url', 'thumbnail_url', 'picture'];
                            if (empty($reviewer_avatar)) {
                                foreach ($avatar_fields as $field) {
                                    if (!empty($review[$field]) && is_string($review[$field])) {
                                        $reviewer_avatar = $review[$field];
                                        break;
                                    }
                                    if (!empty($review['public'][$field]) && is_string($review['public'][$field])) {
                                        $reviewer_avatar = $review['public'][$field];
                                        break;
                                    }
                                }
                            }
                            
                            // Check public.guest for avatar
                            if (empty($reviewer_avatar) && isset($review['public']['guest']) && is_array($review['public']['guest'])) {
                                foreach ($avatar_fields as $field) {
                                    if (!empty($review['public']['guest'][$field]) && is_string($review['public']['guest'][$field])) {
                                        $reviewer_avatar = $review['public']['guest'][$field];
                                        break;
                                    }
                                }
                            }
                            
                            // Check nested guest object
                            if (empty($reviewer_avatar) && isset($review['guest']) && is_array($review['guest'])) {
                                foreach ($avatar_fields as $field) {
                                    if (!empty($review['guest'][$field]) && is_string($review['guest'][$field])) {
                                        $reviewer_avatar = $review['guest'][$field];
                                        break;
                                    }
                                }
                            }
                            
                            // Check reservation.guest for avatar
                            if (empty($reviewer_avatar) && isset($review['reservation']['guest']) && is_array($review['reservation']['guest'])) {
                                foreach ($avatar_fields as $field) {
                                    if (!empty($review['reservation']['guest'][$field]) && is_string($review['reservation']['guest'][$field])) {
                                        $reviewer_avatar = $review['reservation']['guest'][$field];
                                        break;
                                    }
                                }
                            }
                            
                            // Check reservation_guest for avatar
                            if (empty($reviewer_avatar) && isset($review['reservation_guest']) && is_array($review['reservation_guest'])) {
                                foreach ($avatar_fields as $field) {
                                    if (!empty($review['reservation_guest'][$field]) && is_string($review['reservation_guest'][$field])) {
                                        $reviewer_avatar = $review['reservation_guest'][$field];
                                        break;
                                    }
                                }
                            }
                            
                            // Check nested reviewer object
                            if (empty($reviewer_avatar) && isset($review['reviewer']) && is_array($review['reviewer'])) {
                                foreach ($avatar_fields as $field) {
                                    if (!empty($review['reviewer'][$field]) && is_string($review['reviewer'][$field])) {
                                        $reviewer_avatar = $review['reviewer'][$field];
                                        break;
                                    }
                                }
                            }
                            
                            // Check nested author object
                            if (empty($reviewer_avatar) && isset($review['author']) && is_array($review['author'])) {
                                foreach ($avatar_fields as $field) {
                                    if (!empty($review['author'][$field]) && is_string($review['author'][$field])) {
                                        $reviewer_avatar = $review['author'][$field];
                                        break;
                                    }
                                }
                            }
                            
                            // Check nested user object
                            if (empty($reviewer_avatar) && isset($review['user']) && is_array($review['user'])) {
                                foreach ($avatar_fields as $field) {
                                    if (!empty($review['user'][$field]) && is_string($review['user'][$field])) {
                                        $reviewer_avatar = $review['user'][$field];
                                        break;
                                    }
                                }
                            }
                            
                            // Get initial for fallback avatar
                            $reviewer_initial = strtoupper(substr(trim($reviewer_name), 0, 1));
                            
                            // Truncate review text if too long
                            $max_review_length = 200;
                            $display_text = $review_text;
                            $show_more_btn = false;
                            if (strlen($review_text) > $max_review_length) {
                                $display_text = substr($review_text, 0, $max_review_length) . '...';
                                $show_more_btn = true;
                            }
                        ?>
                            <div class="review-card">
                                <div class="review-header">
                                    <div class="reviewer-photo">
                                        <?php if (!empty($reviewer_avatar)): ?>
                                            <img src="<?php echo esc_url($reviewer_avatar); ?>" alt="<?php echo esc_attr($reviewer_name); ?>" loading="lazy">
                                        <?php else: ?>
                                            <div class="reviewer-initial"><?php echo esc_html($reviewer_initial); ?></div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="reviewer-info">
                                        <div class="reviewer-name"><?php echo esc_html($reviewer_name); ?></div>
                                        <div class="reviewer-tenure">Guest Breezy</div>
                                    </div>
                                </div>
                                <div class="review-rating">
                                    <?php for ($i = 0; $i < 5; $i++): ?>
                                        <span class="star <?php echo $i < $rating ? 'filled' : ''; ?>">★</span>
                                    <?php endfor; ?>
                                </div>
                                <div class="review-meta">
                                    <span><?php echo esc_html($formatted_date); ?></span>
                                    <span> • </span>
                                    <span>Stayed a few nights</span>
                                </div>
                                <div class="review-text">
                                    <?php echo esc_html($display_text); ?>
                                </div>
                                <?php if ($show_more_btn): ?>
                                    <button class="show-more-review" onclick="toggleReviewFullText(this)" data-full-text="<?php echo esc_attr($review_text); ?>">Show more</button>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Load More Button -->
                    <?php if ($total_reviews_count > 2): ?>
                    <div class="reviews-load-more-wrapper" style="text-align: center; margin-top: 32px;">
                        <button class="load-more-reviews-btn" id="load-more-reviews" data-loaded="2" data-total="<?php echo esc_attr($total_reviews_count); ?>">
                            Show <?php echo min(2, $total_reviews_count - 2); ?> more reviews
                        </button>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Divider -->
                <div class="divider"></div>
            <?php endif; ?>

            <!-- Map Section -->
            <?php if ($coords): ?>
                <div class="map-section">
                    <h2>Where you'll be</h2>
                    <div id="map" class="property-map"></div>
                </div>
            <?php endif; ?>
        </div>

        <!-- Right Sidebar - Booking Widget -->
        <div class="right-sidebar">
            <div class="booking-widget">
                <div class="booking-header">
                   <span>Booking Request</span>
                   <button type="button" class="mobile-expand-btn">Expand</button>
                </div>
                
                <!-- Custom Airbnb-style Booking Form -->
                <div class="booking-form">
                    <form id="booking-form" class="airbnb-booking-form">
                        <!-- Date Range Picker -->
                        <div class="booking-field-group single-field">
                            <div class="booking-field date-field">
                                <label class="field-label">DATES</label>
                                <input type="text" id="date-range" class="date-input" placeholder="Add dates" readonly>
                </div>
            </div>

                        <!-- Guest Selector -->
                        <div class="booking-field-group">
                            <div class="booking-field guest-field">
                                <label class="field-label">GUESTS</label>
                                <button type="button" id="guest-selector" class="guest-selector">
                                    <span class="guest-text">Add guests</span>
                                    <svg class="dropdown-arrow" width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                                        <path d="M7 10l5 5 5-5z"/>
                                    </svg>
                                </button>
                                
                                <!-- Guest Dropdown -->
                                <div id="guest-dropdown" class="guest-dropdown">
                                    <div class="guest-row">
                                        <div class="guest-info">
                                            <div class="guest-type">Adults</div>
                                            <div class="guest-age">Ages 13 or above</div>
                                        </div>
                                        <div class="guest-controls">
                                            <button type="button" class="guest-btn minus" data-type="adults" data-action="decrease">−</button>
                                            <span class="guest-count" id="adults-count">1</span>
                                            <button type="button" class="guest-btn plus" data-type="adults" data-action="increase">+</button>
                                        </div>
                                    </div>
                                    <div class="guest-row">
                                        <div class="guest-info">
                                            <div class="guest-type">Children</div>
                                            <div class="guest-age">Ages 2-12</div>
                                        </div>
                                        <div class="guest-controls">
                                            <button type="button" class="guest-btn minus" data-type="children" data-action="decrease">−</button>
                                            <span class="guest-count" id="children-count">0</span>
                                            <button type="button" class="guest-btn plus" data-type="children" data-action="increase">+</button>
                                        </div>
                                    </div>
                                    <div class="guest-row">
                                        <div class="guest-info">
                                            <div class="guest-type">Infants</div>
                                            <div class="guest-age">Under 2</div>
                                        </div>
                                        <div class="guest-controls">
                                            <button type="button" class="guest-btn minus" data-type="infants" data-action="decrease">−</button>
                                            <span class="guest-count" id="infants-count">0</span>
                                            <button type="button" class="guest-btn plus" data-type="infants" data-action="increase">+</button>
                                        </div>
                                    </div>
                                    <div class="guest-row">
                                        <div class="guest-info">
                                            <div class="guest-type">Pets</div>
                                            <div class="guest-age"><a href="#">Bringing a service animal?</a></div>
                                        </div>
                                        <div class="guest-controls">
                                            <button type="button" class="guest-btn minus" data-type="pets" data-action="decrease">−</button>
                                            <span class="guest-count" id="pets-count">0</span>
                                            <button type="button" class="guest-btn plus" data-type="pets" data-action="increase">+</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Reserve Button -->
                        <button type="submit" class="reserve-button">
                            <span class="reserve-text">Book Now</span>
                        </button>

                        <!-- Pricing Breakdown (hidden until dates are selected) -->
                        <div class="pricing-breakdown" id="pricing-breakdown" style="display: none;">
                            <div class="pricing-section">
                                <h4>Price details</h4>
                                <div class="price-line">
                                    <span class="price-label" id="base-price-label">$0.00 × 0 nights</span>
                                    <span class="price-value" id="base-price-total">$0.00</span>
                                </div>
                                <div class="price-line">
                                    <span class="price-label">Cleaning fee</span>
                                    <span class="price-value" id="cleaning-fee">$0.00</span>
                                </div>
                                <div class="price-line">
                                    <span class="price-label">Service fee</span>
                                    <span class="price-value" id="service-fee">$0.00</span>
                                </div>
                                <div class="price-line">
                                    <span class="price-label">Taxes and fees</span>
                                    <span class="price-value" id="taxes">$0.00</span>
                                </div>
                                <div class="price-line total-line">
                                    <span class="price-label">Total</span>
                                    <span class="price-value" id="total-price">$0.00</span>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Photos Modal -->
<div id="photos-modal" class="modal photomodal">
    <div class="modal-content">
        <span class="close" onclick="document.getElementById('photos-modal').style.display='none'">&times;</span>
        <div class="modal-gallery">
            <?php foreach ($images as $index => $img): ?>
                <div class="modal-image">
                    <img src="<?php echo esc_url($img); ?>" alt="Photo <?php echo $index + 1; ?>" loading="lazy">
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- Amenities Modal -->
<div id="amenities-modal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="document.getElementById('amenities-modal').style.display='none'">&times;</span>
        <h2>All Amenities</h2>
        <div class="modal-amenities-grid">
            <?php foreach ($amenities as $a):
                $normalized_amenity = trim(preg_replace('/[^a-z0-9]+/', '_', strtolower($a)), '_');
                $label = ucwords(preg_replace('/[_-]+/', ' ', $a));
                $icon_name = $amenity_icons[$normalized_amenity] ?? $default_icon_name;
            ?>
                <div class="modal-amenity-item">
                    <i class="amenity-icon" data-feather="<?php echo esc_attr($icon_name); ?>" aria-hidden="true"></i>
                    <span class="amenity-label"><?php echo esc_html($label); ?></span>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<script>
// Image gallery functionality
let currentSlide = 0;
const images = [
    <?php foreach ($images as $index => $img): ?>
        '<?php echo esc_url($img); ?>'<?php echo $index < count($images) - 1 ? ',' : ''; ?>
    <?php endforeach; ?>
];
const sliderCounterCurrent = document.getElementById('slider-counter-current');
const sliderCounterTotal = document.getElementById('slider-counter-total');

if (sliderCounterTotal) {
    sliderCounterTotal.textContent = images.length;
}

function updateSliderCounter() {
    if (sliderCounterCurrent) {
        sliderCounterCurrent.textContent = currentSlide + 1;
    }
}

function changeMainImage(imageSrc) {
    document.getElementById('main-image').src = imageSrc;
}

// Mobile slider functionality
function goToSlide(slideIndex) {
    currentSlide = slideIndex;
    updateSlider();
}

function nextSlide() {
    currentSlide = (currentSlide + 1) % images.length;
    updateSlider();
}

function previousSlide() {
    currentSlide = (currentSlide - 1 + images.length) % images.length;
    updateSlider();
}

function updateSlider() {
    // Update main image
    document.getElementById('main-image').src = images[currentSlide];
    
    // Update dots
    const dots = document.querySelectorAll('.slider-dot');
    dots.forEach((dot, index) => {
        dot.classList.toggle('active', index === currentSlide);
    });

    updateSliderCounter();
}

// Touch/swipe support for mobile
let startX = 0;
let endX = 0;

document.addEventListener("DOMContentLoaded", function() {
    // Trigger fade-in animation once page is loaded
    const propertyPage = document.querySelector('.airbnb-property-page');
    if (propertyPage) {
        // Small delay to ensure all styles are loaded
        setTimeout(() => {
            propertyPage.style.opacity = '1';
            propertyPage.style.transition = 'opacity 0.6s ease-in-out';
        }, 50);
    }

    if (window.feather) {
        feather.replace();
    }

    updateSliderCounter();
    
    // Initialize description truncation
    initDescriptionTruncation();
    
    const gallery = document.querySelector('.hero-gallery');
    
    if (gallery) {
        gallery.addEventListener('touchstart', function(e) {
            startX = e.touches[0].clientX;
        });
        
        gallery.addEventListener('touchend', function(e) {
            endX = e.changedTouches[0].clientX;
            handleSwipe();
        });
    }
    
    function handleSwipe() {
        const threshold = 50;
        const diff = startX - endX;
        
        if (Math.abs(diff) > threshold) {
            if (diff > 0) {
                nextSlide(); // Swipe left - next slide
            } else {
                previousSlide(); // Swipe right - previous slide
            }
        }
    }
    
    <?php if ($coords): ?>
    var map = L.map('map').setView([<?php echo $coords['latitude']; ?>, <?php echo $coords['longitude']; ?>], 15);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);
    L.marker([<?php echo $coords['latitude']; ?>, <?php echo $coords['longitude']; ?>]).addTo(map);
    <?php endif; ?>
    
    // Initialize booking widget
    initBookingWidget();
});

// Helper function to update guest display
function updateGuestDisplayFromURL() {
    if (!window.guestState) return;
    
    // Update guest count displays
    const adultsCount = document.getElementById('adults-count');
    const childrenCount = document.getElementById('children-count');
    const infantsCount = document.getElementById('infants-count');
    const petsCount = document.getElementById('pets-count');
    const guestText = document.querySelector('.guest-text');
    
    if (adultsCount) adultsCount.textContent = window.guestState.adults;
    if (childrenCount) childrenCount.textContent = window.guestState.children;
    if (infantsCount) infantsCount.textContent = window.guestState.infants;
    if (petsCount) petsCount.textContent = window.guestState.pets || 0;
    
    // Update guest text
    if (guestText) {
        const total = window.guestState.adults + window.guestState.children + window.guestState.infants;
        if (total === 0) {
            guestText.textContent = 'Add guests';
            guestText.classList.remove('has-selection');
        } else {
            let text = `${total} guest${total !== 1 ? 's' : ''}`;
            if (window.guestState.infants > 0) {
                text += `, ${window.guestState.infants} infant${window.guestState.infants !== 1 ? 's' : ''}`;
            }
            if (window.guestState.pets > 0) {
                text += `, ${window.guestState.pets} pet${window.guestState.pets !== 1 ? 's' : ''}`;
            }
            guestText.textContent = text;
            guestText.classList.add('has-selection');
        }
    }
}

// Booking Widget Functionality
function initBookingWidget() {
    // Guest selection state (make it globally accessible)
    window.guestState = {
        adults: 1,
        children: 0,
        infants: 0,
        pets: 0
    };
    const guestState = window.guestState;
    
    // Date selection state
    let selectedDates = {
        checkin: null,
        checkout: null
    };
    
    // Don't load initial pricing - wait for user to select dates
    // loadInitialPricing();
    
    // Keep track of the actual selected dates array
    let selectedDatesArray = [];
    
    // Load initial pricing function (disabled - wait for user to select dates)
    async function loadInitialPricing() {
        // This function is disabled - pricing is now loaded when user selects dates
        return;
    }
    
    // Property pricing data (will be updated from API)
    let pricing = {
        basePrice: 0,
        cleaningFee: 0,
        serviceFee: 0,
        securityDeposit: 0,
        currency: 'USD'
    };
    
    // Property data from PHP
    const fullPropertyData = <?php echo json_encode($property ?? []); ?>;
    console.log('Property data:', fullPropertyData);

    const unavailableDateSet = new Set();
    const checkinBlockedDateSet = new Set(); // Dates where check-in is disallowed
    const checkoutOnlyDateSet = new Set(); // Dates that are closed_for_checkout (can be checkout but not check-in)
    const checkoutBlockedDateSet = new Set(); // Dates where checkout is blocked (closed_for_checkout = true)
    const minNightsByDate = new Map(); // Store minimum nights for each date
    let datePickerInstance = null;
    let dateWarningEl = null;
    let selectedStartDate = null; // Track the selected start date for minimum nights validation
    let pricingFetchController = null; // Store current pricing fetch AbortController
    const UNAVAILABLE_MESSAGE_TEXT = 'One or more dates within this period have been marked as unavailable.';
    
    // Helper function to format dates for API without timezone issues
    function formatDateForAPI(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }

    function showDateWarning(message) {
        if (!dateWarningEl) return;
        if (message) {
            dateWarningEl.textContent = message;
            dateWarningEl.style.display = 'block';
        } else {
            dateWarningEl.textContent = '';
            dateWarningEl.style.display = 'none';
        }
    }

    function isDateUnavailable(date) {
        if (!date) return false;
        return unavailableDateSet.has(formatDateForAPI(date));
    }

    function isCheckinBlocked(date) {
        if (!date) return false;
        return checkinBlockedDateSet.has(formatDateForAPI(date));
    }

    // Helper function to apply check-in blocked classes to calendar cells
    function applyCheckinBlockedClasses() {
        if (typeof jQuery === 'undefined' || checkinBlockedDateSet.size === 0) {
            return;
        }
        
        const $calendar = jQuery('.daterangepicker');
        if (!$calendar.length) {
            return;
        }
        
        let appliedCount = 0;
        
        // Month names (full and abbreviated) - 0-based index
        const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 
                           'July', 'August', 'September', 'October', 'November', 'December'];
        const monthAbbrevs = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                             'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        
        checkinBlockedDateSet.forEach((dateStr) => {
            const targetDate = moment(dateStr, 'YYYY-MM-DD');
            if (!targetDate.isValid()) {
                return;
            }
            
            const targetDay = targetDate.date();
            const targetMonth = targetDate.month(); // 0-based (0 = January, 5 = June)
            const targetYear = targetDate.year();
            
            // Check if this is a checkout-only date
            const isCheckoutOnly = checkoutOnlyDateSet.has(dateStr);
            
            // Find ALL tables in the calendar (table-condensed, calendar-table, etc.)
            $calendar.find('table').each(function() {
                const $table = jQuery(this);
                
                // Find the month element - it's a <th class="month"> inside the table thead
                let $monthEl = $table.find('th.month').first();
                if (!$monthEl.length) {
                    $monthEl = $table.find('thead th.month').first();
                }
                if (!$monthEl.length) {
                    $monthEl = $table.siblings('.month').first();
                }
                if (!$monthEl.length) {
                    $monthEl = $table.prev('.month').first();
                }
                
                if (!$monthEl.length) {
                    return;
                }
                
                const monthText = $monthEl.text().trim();
                const monthMatch = monthText.match(/(\w+)\s+(\d{4})/);
                if (!monthMatch) {
                    return;
                }
                
                const monthName = monthMatch[1];
                const tableYear = parseInt(monthMatch[2]);
                
                // Try to match month (handle both full and abbreviated names)
                let tableMonth = monthNames.findIndex(m => m.toLowerCase() === monthName.toLowerCase());
                if (tableMonth === -1) {
                    tableMonth = monthAbbrevs.findIndex(m => m.toLowerCase() === monthName.toLowerCase());
                }
                
                // Check if this table is for the target month/year
                if (tableMonth === targetMonth && tableYear === targetYear) {
                    // Find the cell with matching day
                    $table.find('td').each(function() {
                        const $td = jQuery(this);
                        const cellText = $td.text().trim();
                        const cellDay = parseInt(cellText);
                        
                        // Match the day number exactly
                        if (!isNaN(cellDay) && cellDay === targetDay) {
                            // Skip if this date is selected (has start-date or end-date class)
                            // Selected dates should not have checkin-blocked, off, or disabled classes
                            if ($td.hasClass('start-date') || $td.hasClass('end-date')) {
                                return;
                            }
                            
                            // Only add checkin-blocked class if it's NOT a checkout-only date
                            // (checkout-only dates can be used as checkout dates, so they shouldn't be marked as checkin-blocked)
                            if (!isCheckoutOnly) {
                                $td.addClass('checkin-blocked');
                                // If it's NOT a checkout-only date, fully disable it
                                // (checkout-only dates can still be selected as checkout dates)
                                $td.addClass('off disabled').removeClass('available in-range');
                            }
                            
                            appliedCount++;
                        }
                    });
                }
            });
        });
        
        if (appliedCount > 0) {
            console.log('✓ Applied checkin-blocked class to', appliedCount, 'cells');
        }
    }

    // Helper function to apply checkout-only classes to calendar cells
    // Only applies to dates where _final_is_checkout_only === true (verified from debug_info)
    function applyCheckoutOnlyClasses() {
        if (typeof jQuery === 'undefined' || checkoutOnlyDateSet.size === 0) {
            return;
        }
        
        const $calendar = jQuery('.daterangepicker');
        if (!$calendar.length) {
            return;
        }
        
        let appliedCount = 0;
        
        // Month names (full and abbreviated) - 0-based index
        const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 
                           'July', 'August', 'September', 'October', 'November', 'December'];
        const monthAbbrevs = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                             'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        
        // Only apply checkout-only class to dates confirmed as checkout-only
        // (checkoutOnlyDateSet is built from _final_is_checkout_only === true)
        checkoutOnlyDateSet.forEach((dateStr) => {
            const targetDate = moment(dateStr, 'YYYY-MM-DD');
            if (!targetDate.isValid()) {
                return;
            }
            
            const targetDay = targetDate.date();
            const targetMonth = targetDate.month(); // 0-based (0 = January, 5 = June)
            const targetYear = targetDate.year();
            
            // Find ALL tables in the calendar (table-condensed, calendar-table, etc.)
            $calendar.find('table').each(function() {
                const $table = jQuery(this);
                
                // Find the month element - it's a <th class="month"> inside the table thead
                let $monthEl = $table.find('th.month').first();
                if (!$monthEl.length) {
                    $monthEl = $table.find('thead th.month').first();
                }
                if (!$monthEl.length) {
                    $monthEl = $table.siblings('.month').first();
                }
                if (!$monthEl.length) {
                    $monthEl = $table.prev('.month').first();
                }
                
                if (!$monthEl.length) {
                    return;
                }
                
                const monthText = $monthEl.text().trim();
                const monthMatch = monthText.match(/(\w+)\s+(\d{4})/);
                if (!monthMatch) {
                    return;
                }
                
                const monthName = monthMatch[1];
                const tableYear = parseInt(monthMatch[2]);
                
                // Try to match month (handle both full and abbreviated names)
                let tableMonth = monthNames.findIndex(m => m.toLowerCase() === monthName.toLowerCase());
                if (tableMonth === -1) {
                    tableMonth = monthAbbrevs.findIndex(m => m.toLowerCase() === monthName.toLowerCase());
                }
                
                // Check if this table is for the target month/year
                if (tableMonth === targetMonth && tableYear === targetYear) {
                    // Find the cell with matching day
                    $table.find('td').each(function() {
                        const $td = jQuery(this);
                        const cellText = $td.text().trim();
                        const cellDay = parseInt(cellText);
                        
                        // Match the day number exactly
                        if (!isNaN(cellDay) && cellDay === targetDay) {
                            // Force add checkout-only class (don't check if it already has it)
                            $td.addClass('checkout-only');
                            // Remove checkin-blocked class if checkout-only is present
                            // (checkout-only dates can be used as checkout dates, so they shouldn't be marked as checkin-blocked)
                            $td.removeClass('checkin-blocked');
                            appliedCount++;
                        }
                    });
                }
            });
        });
        
        if (appliedCount > 0) {
            console.log('✓ Applied checkout-only class to', appliedCount, 'cells');
        }
    }

    // Helper function to clean up selected dates - remove checkin-blocked, off, disabled classes
    // This ensures selected dates (start-date, end-date) don't have conflicting classes
    function cleanupSelectedDates() {
        if (typeof jQuery === 'undefined') {
            return;
        }
        
        const $calendar = jQuery('.daterangepicker');
        if (!$calendar.length) {
            return;
        }
        
        // Remove checkin-blocked, off, and disabled classes from selected dates
        $calendar.find('td.start-date, td.end-date').each(function() {
            const $td = jQuery(this);
            $td.removeClass('checkin-blocked off disabled');
        });
    }

    function rangeIncludesUnavailable(startDate, endDate, { includeCheckout = false } = {}) {
        if (!startDate || !endDate || unavailableDateSet.size === 0) {
            return false;
        }

        const cursor = new Date(startDate);
        const end = new Date(endDate);
        const endDateStr = formatDateForAPI(end);

        const comparison = includeCheckout ? (current, endDateObj) => current <= endDateObj : (current, endDateObj) => current < endDateObj;

        while (comparison(cursor, end)) {
            const key = formatDateForAPI(cursor);
            
            // Skip checkout-only dates - they can be used as checkout dates
            // If this is the checkout date and it's checkout-only, allow it
            if (key === endDateStr && checkoutOnlyDateSet.has(key)) {
                cursor.setDate(cursor.getDate() + 1);
                continue;
            }
            
            // Check if date is unavailable (but not checkout-only)
            if (unavailableDateSet.has(key)) {
                // If it's a checkout-only date, skip it (can be used as checkout)
                if (checkoutOnlyDateSet.has(key)) {
                    cursor.setDate(cursor.getDate() + 1);
                    continue;
                }
                return true;
            }
            cursor.setDate(cursor.getDate() + 1);
        }
        return false;
    }

    function clearDateSelection(options = {}) {
        const { preserveMessage = false } = options;
        if (datePickerInstance && typeof jQuery !== 'undefined') {
            const $input = jQuery('#date-range');
            if ($input.data('daterangepicker')) {
                const picker = $input.data('daterangepicker');
                picker.setStartDate(moment());
                picker.setEndDate(null);
                $input.val('');
            }
        }
        selectedDates.checkin = null;
        selectedDates.checkout = null;
        selectedStartDate = null; // Clear selected start date
        if (!preserveMessage) {
            showDateWarning('');
        }
    }

    async function loadUnavailableDates(startDate = null, endDate = null) {
        try {
            const params = new URLSearchParams({
                action: 'digim_get_unavailable_dates',
                property_uuid: '<?php echo esc_js($uuid); ?>'
            });

            if (startDate) {
                params.set('start_date', startDate);
            }
            if (endDate) {
                params.set('end_date', endDate);
            }

            const response = await fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: params.toString()
            });

            const data = await response.json();
            if (!data || !data.success || !data.data) {
                console.warn('Failed to load calendar availability', data);
                return false;
            }

            // Debug: Log full response to see structure
            console.log('=== FULL API RESPONSE ===', data);
            console.log('=== DATA.DATA KEYS ===', Object.keys(data.data || {}));
            
            const dates = Array.isArray(data.data.dates) ? data.data.dates : [];
            unavailableDateSet.clear();
            console.log('Unavailable dates:', dates);
            console.log('Unavailable dates count:', dates.length);
            
            // Check if June 18-19 are in unavailable dates
            const june18_19 = ['2026-06-18', '2026-06-19'];
            const june18_19_unavailable = june18_19.filter(d => dates.includes(d));
            if (june18_19_unavailable.length > 0) {
                console.log('⚠️ June 18-19 found in UNAVAILABLE dates:', june18_19_unavailable);
            }
            dates.forEach((dateStr) => {
                if (typeof dateStr === 'string' && dateStr) {
                    unavailableDateSet.add(dateStr);
                }
            });
            
            // Store minimum nights data
            minNightsByDate.clear();
            if (data.data.min_nights && typeof data.data.min_nights === 'object') {
                Object.keys(data.data.min_nights).forEach((dateStr) => {
                    const minNights = parseInt(data.data.min_nights[dateStr]);
                    if (!isNaN(minNights) && minNights > 0) {
                        minNightsByDate.set(dateStr, minNights);
                    }
                });
            }

            // Store dates where check-in is not allowed
            checkinBlockedDateSet.clear();
            if (Array.isArray(data.data.checkin_blocked_dates)) {
                console.log('Check-in blocked dates:', data.data.checkin_blocked_dates);
                console.log('Check-in blocked dates count:', data.data.checkin_blocked_dates.length);
                data.data.checkin_blocked_dates.forEach((dateStr) => {
                    if (typeof dateStr === 'string' && dateStr) {
                        checkinBlockedDateSet.add(dateStr);
                 
                    }
                });
                
                // Check if June 18-19 are in check-in blocked dates
                const june18_19 = ['2026-06-18', '2026-06-19'];
                const june18_19_blocked = june18_19.filter(d => data.data.checkin_blocked_dates.includes(d));
                if (june18_19_blocked.length === 0) {
                    console.log('⚠️ June 18-19 NOT found in check-in blocked dates. Checking unavailable dates...');
                } else {
                    console.log('✓ June 18-19 found in check-in blocked dates:', june18_19_blocked);
                }
            }

            // Store dates that are checkout-only - ONLY use _final_is_checkout_only from debug_info
            // This ensures we only add dates that are actually confirmed as checkout-only in the final result
            checkoutOnlyDateSet.clear();
            
            // ONLY use debug_info's _final_is_checkout_only flag - ignore the API array
            // This is the source of truth based on actual API data analysis
            if (data.data.debug_info && typeof data.data.debug_info === 'object') {
                Object.keys(data.data.debug_info).forEach((dateStr) => {
                    // Skip meta keys that start with underscore
                    if (dateStr.startsWith('_')) {
                        return;
                    }
                    
                    const debugData = data.data.debug_info[dateStr];
                    // ONLY add if _final_is_checkout_only is explicitly true
                    if (debugData && debugData._final_is_checkout_only === true) {
                        checkoutOnlyDateSet.add(dateStr);
                        console.log('✓ Added checkout-only date (confirmed in debug_info):', dateStr);
                    }
                });
            }
            
            // Log for comparison (but don't use it)
            if (Array.isArray(data.data.checkout_only_dates)) {
                console.log('Checkout-only dates from API array (for reference only):', data.data.checkout_only_dates);
                console.log('Checkout-only dates from API count:', data.data.checkout_only_dates.length);
            }
            
            console.log('Final checkout-only dates (from _final_is_checkout_only):', Array.from(checkoutOnlyDateSet));
            console.log('Final checkout-only dates count:', checkoutOnlyDateSet.size);

            // Store dates where checkout is blocked (closed_for_checkout = true)
            checkoutBlockedDateSet.clear();
            if (Array.isArray(data.data.checkout_blocked_dates)) {
                console.log('Checkout-blocked dates:', data.data.checkout_blocked_dates);
                console.log('Checkout-blocked dates count:', data.data.checkout_blocked_dates.length);
                data.data.checkout_blocked_dates.forEach((dateStr) => {
                    if (typeof dateStr === 'string' && dateStr) {
                        checkoutBlockedDateSet.add(dateStr);
                    }
                });
            }

            // Debug info for June 15-19, 2026
            console.log('=== DEBUG INFO CHECK ===', {
                has_debug_info: !!data.data.debug_info,
                debug_info_type: typeof data.data.debug_info,
                debug_info: data.data.debug_info
            });
            
            if (data.data.debug_info && typeof data.data.debug_info === 'object') {
                console.log('=== DEBUG: API Response for June 15-19, 2026 ===');
                Object.keys(data.data.debug_info).forEach((dateStr) => {
                    console.log(`\nDate: ${dateStr}`, data.data.debug_info[dateStr]);
                });
                console.log('=== END DEBUG ===');
            } else {
                console.warn('No debug_info found in response. Response structure:', Object.keys(data.data || {}));
            }

            // Update daterangepicker with unavailable dates
            // The isInvalidDate function will handle this
            if (datePickerInstance && typeof jQuery !== 'undefined') {
                const $input = jQuery('#date-range');
                const picker = $input.data('daterangepicker');
                if (picker) {
                    // Force calendar to refresh and re-evaluate isInvalidDate
                    picker.updateView();
                    
                    // Re-initialize tooltips after dates are loaded
                    setTimeout(() => {
                        if (typeof initMinNightsTooltips === 'function') {
                            initMinNightsTooltips();
                        }
                    }, 150);
                    
                    // Apply check-in blocked classes after a short delay to ensure calendar is rendered
                    setTimeout(() => {
                        applyCheckinBlockedClasses();
                        
                        // Apply checkout-only classes with a longer delay to ensure calendar is fully rendered
                        setTimeout(() => {
                            applyCheckoutOnlyClasses();
                            cleanupSelectedDates(); // Clean up selected dates
                        }, 100);
                    }, 200);
                }
            }

            return true;
        } catch (error) {
            console.warn('Error fetching unavailable dates', error);
            return false;
        }
    }
    
    // The Hospitable API doesn't include pricing in the property object
    // We need to get pricing from the quote API, so we'll start with 0
    // and let the API calls populate the real pricing
    
    // Function to prefill booking widget from URL parameters
    function prefillBookingFromURL() {
        try {
            const urlParams = new URLSearchParams(window.location.search);
            
            // Get date parameters
            let checkinDate = urlParams.get('checkin');
            let checkoutDate = urlParams.get('checkout');
            const dateRange = urlParams.get('date_range');
            
            // Parse date_range if checkin/checkout not available
            if ((!checkinDate || !checkoutDate) && dateRange) {
                const decoded = decodeURIComponent(dateRange.replace(/\+/g, ' '));
                const parts = decoded.split(/\s+to\s+/i);
                if (parts.length === 2) {
                    checkinDate = parts[0].trim();
                    checkoutDate = parts[1].trim();
                }
            }
            
            // Set dates if both are available
            if (checkinDate && checkoutDate) {
                const dateInput = document.getElementById('date-range');
                if (dateInput && typeof jQuery !== 'undefined' && typeof jQuery.fn.daterangepicker !== 'undefined') {
                    // Get the existing daterangepicker instance
                    const picker = jQuery(dateInput).data('daterangepicker');
                    if (picker) {
                        // Parse dates using moment
                        const checkinMoment = moment(checkinDate);
                        const checkoutMoment = moment(checkoutDate);
                        
                        // Validate dates are valid
                        if (!checkinMoment.isValid() || !checkoutMoment.isValid()) {
                            console.warn('Invalid dates in URL:', checkinDate, checkoutDate);
                            return;
                        }
                        
                        // Check if dates are unavailable (now that unavailable dates are loaded)
                        const checkinDateObj = checkinMoment.toDate();
                        const checkoutDateObj = checkoutMoment.toDate();
                        const checkoutDateStr = formatDateForAPI(checkoutDateObj);
                        
                        // Check availability before setting
                        // IMPORTANT: Check-in blocked dates can be used within a date range (as checkout or middle dates)
                        // They should only block the START date, not dates within the range
                        const checkoutIsCheckoutOnly = checkoutOnlyDateSet.has(checkoutDateStr);
                        
                        // Allow checkout-only dates as checkout dates
                        const checkoutUnavailableButCheckoutOnly = isDateUnavailable(checkoutDateObj) && checkoutIsCheckoutOnly;
                        
                        // Check-in blocked dates are allowed as checkout dates (they only block START dates)
                        // Only block checkout if it's actually unavailable (not just check-in blocked)
                        const shouldBlock = isDateUnavailable(checkinDateObj) || 
                                          (isDateUnavailable(checkoutDateObj) && !checkoutIsCheckoutOnly) || 
                                          isCheckinBlocked(checkinDateObj) || // Block check-in blocked dates as START dates
                                          rangeIncludesUnavailable(checkinDateObj, checkoutDateObj);
                        
                        if (shouldBlock) {
                            console.warn('Suggested dates are unavailable or blocked for check-in, clearing selection');
                            const unavailableMsg = isCheckinBlocked(checkinDateObj) ? 'This property has check-in day restrictions. Please choose a different check-in date.' : 'One or more dates within this period have been marked as unavailable. Please choose different dates.';
                            showDateWarning(unavailableMsg);
                            if (typeof showPricingError === 'function') {
                                showPricingError(unavailableMsg);
                            }
                            return;
                        }
                        
                        // Check minimum nights requirement before setting dates
                        const nights = Math.ceil((checkoutDateObj - checkinDateObj) / (1000 * 60 * 60 * 24));
                        const checkinDateStr = formatDateForAPI(checkinDateObj);
                        const minNights = minNightsByDate.get(checkinDateStr);
                        
                        if (minNights && nights < minNights) {
                            const errorMsg = `Minimum stay requirement not met. This property requires a minimum stay of ${minNights} night${minNights > 1 ? 's' : ''}. Please select a longer stay or different dates.`;
                            showDateWarning(errorMsg);
                            if (typeof showPricingError === 'function') {
                                showPricingError(errorMsg);
                            }
                            // Still set the dates so user can see the error, but don't fetch pricing
                            picker.setStartDate(checkinMoment);
                            picker.setEndDate(checkoutMoment);
                            selectedDates.checkin = checkinDateObj;
                            selectedDates.checkout = checkoutDateObj;
                            dateInput.value = checkinMoment.format('MMMM D, YYYY') + ' - ' + checkoutMoment.format('MMMM D, YYYY');
                            return;
                        }
                        
                        // Set the dates which will trigger callback and pricing fetch
                        picker.setStartDate(checkinMoment);
                        picker.setEndDate(checkoutMoment);
                        
                        // Update selectedDates state before triggering callback
                        selectedDates.checkin = checkinDateObj;
                        selectedDates.checkout = checkoutDateObj;
                        
                        // Trigger the callback manually to update display and fetch pricing
                        if (typeof picker.callback === 'function') {
                            picker.callback(checkinMoment, checkoutMoment, picker.chosenLabel);
                        }
                    }
                }
            }
            
            // Get guest parameters
            const adults = parseInt(urlParams.get('adults') || '0');
            const children = parseInt(urlParams.get('children') || '0');
            const infants = parseInt(urlParams.get('infants') || '0');
            const pets = parseInt(urlParams.get('pets') || '0');
            const totalGuests = parseInt(urlParams.get('guests') || '0');
            
            // Update guest counts if provided
            if (adults > 0 || children > 0 || infants > 0 || pets >= 0 || totalGuests > 0) {
                // Update the guest state
                if (adults > 0) guestState.adults = adults;
                if (children > 0) guestState.children = children;
                if (infants > 0) guestState.infants = infants;
                // Always update pets if it's in the URL (even if 0)
                if (urlParams.has('pets')) guestState.pets = pets;
                
                // If only total guests provided, assign to adults
                if (adults === 0 && children === 0 && infants === 0 && totalGuests > 0) {
                    guestState.adults = totalGuests;
                    guestState.children = 0;
                    guestState.infants = 0;
                }
                
                // Update the display - update guest counts and text
                updateGuestDisplay();
                // Update guest text display
                const guestText = document.querySelector('.guest-text');
                if (guestText) {
                    const total = guestState.adults + guestState.children + guestState.infants;
                    if (total === 0) {
                        guestText.textContent = 'Add guests';
                        guestText.classList.remove('has-selection');
                    } else {
                        let text = `${total} guest${total !== 1 ? 's' : ''}`;
                        if (guestState.infants > 0) {
                            text += `, ${guestState.infants} infant${guestState.infants !== 1 ? 's' : ''}`;
                        }
                        if (guestState.pets > 0) {
                            text += `, ${guestState.pets} pet${guestState.pets !== 1 ? 's' : ''}`;
                        }
                        guestText.textContent = text;
                        guestText.classList.add('has-selection');
                    }
                }
            }
            
        } catch (error) {
            console.warn('Error prefilling from URL:', error);
        }
    }
    
    // Initialize date picker
    initDatePicker();
    
    // Initialize guest selector
    initGuestSelector();
    
    // Note: prefillBookingFromURL is now called after unavailable dates are loaded in initDatePicker
    
    // Debugging removed - pricing is now working!
    
    // Initialize form submission
    initFormSubmission();
    
    function initDatePicker() {
        const dateInput = document.getElementById('date-range');
        if (!dateInput) return;

        if (!dateWarningEl) {
            dateWarningEl = document.createElement('div');
            dateWarningEl.className = 'digim-date-warning';
            dateWarningEl.style.cssText = 'color: #e31c5f; font-size: 13px; margin-top: 8px; display: none;';
            if (dateInput.parentNode) {
                dateInput.parentNode.appendChild(dateWarningEl);
            }
        }
        
        // Initialize DateRangePicker for date range
        if (typeof jQuery === 'undefined' || typeof moment === 'undefined' || typeof jQuery.fn.daterangepicker === 'undefined') {
            console.error('DateRangePicker dependencies not loaded');
            return;
        }

        // Create a function that can be updated dynamically
        let isInvalidDateFunction = function(date) {
            const dateStr = date.format('YYYY-MM-DD');
            
            // Get picker reference once
            const picker = jQuery(dateInput).data('daterangepicker');
            const hasStartDate = picker && picker.startDate && !picker.endDate;
            
            // First check if this is a checkout-only date
            // Checkout-only dates can be used as checkout dates when a start date is selected
            const isCheckoutOnly = checkoutOnlyDateSet.has(dateStr);
            if (isCheckoutOnly) {
                // If start date is already selected, allow it as checkout date
                if (hasStartDate) {
                    return false; // Allow as checkout date
                }
                // If no start date selected, block it (cannot be used for check-in)
                return true;
            }
            
            // Check if date is unavailable (but not checkout-only)
            if (unavailableDateSet.has(dateStr)) {
                return true;
            }

            // Check if date is checkout-blocked (closed_for_checkout = true)
            // IMPORTANT: Checkout-blocked dates CAN be used as check-in dates
            // They should only block CHECKOUT dates, not check-in dates
            // This matches Hospitable's behavior: "No check-outs on this day" doesn't mean "No check-ins"
            if (checkoutBlockedDateSet.has(dateStr)) {
                // If start date is already selected, block it (cannot be used as checkout)
                if (hasStartDate) {
                    return true; // Block as checkout date
                }
                // If no start date selected, allow it (can be used as check-in date)
                return false;
            }

            // Check if date is in checkinBlockedDateSet
            // IMPORTANT: Check-in blocked dates can be used as checkout dates or within a range
            // They should only block the START date, not dates within the range
            if (checkinBlockedDateSet.has(dateStr)) {
                // If start date is already selected, allow check-in blocked dates as checkout dates
                // (they can be used within a range, just not as the start date)
                if (hasStartDate) {
                    return false; // Allow as checkout date
                }
                // If no start date selected, block it (cannot be used for check-in)
                return true;
            }
            
            // Check minimum nights requirement if start date is selected
            // Use picker's startDate if available, otherwise fall back to selectedStartDate
            const currentStartDate = (picker && picker.startDate) ? picker.startDate.toDate() : selectedStartDate;
            
            if (currentStartDate) {
                const startDateStr = formatDateForAPI(currentStartDate);
                const minNights = minNightsByDate.get(startDateStr);
                
                if (minNights && minNights > 0) {
                    const dateObj = date.toDate();
                    const startMoment = moment(currentStartDate);
                    const dateMoment = moment(dateObj);
                    
                    // Calculate nights between start date and this date
                    const nights = dateMoment.diff(startMoment, 'days');
                    
                    // Disable dates that are between startDate + 1 and startDate + (minimum_stay - 1)
                    // Example: if min is 2 nights and start is Feb 8, disable Feb 9 (nights = 1)
                    // Allow Feb 10 (nights = 2) and later
                    if (nights > 0 && nights < minNights) {
                        return true;
                    }
                }
            }
            
            return false;
        };
        
        // Function to force disable dates that don't meet minimum stay requirement
        function forceDisableInvalidDates() {
            const picker = jQuery(dateInput).data('daterangepicker');
            if (!picker || !picker.startDate || picker.endDate) {
                return;
            }
            
            const $calendar = jQuery('.daterangepicker');
            if (!$calendar.length || !$calendar.is(':visible')) {
                return;
            }
            
            const startDate = picker.startDate;
            const startDateStr = startDate.format('YYYY-MM-DD');
            const minNights = minNightsByDate.get(startDateStr);
            
            if (!minNights || minNights <= 0) {
                return;
            }
            
            // Get all date cells - use table-condensed selector to be more specific
            let $cells = $calendar.find('table.table-condensed td.available, table.table-condensed td.in-range');
            if ($cells.length === 0) {
                // Fallback: try without table-condensed
                $cells = $calendar.find('td.available, td.in-range');
            }
            
            let disabledCount = 0;
            
            // Find the start-date cell first
            const $startDateCell = $calendar.find('td.start-date');
            if (!$startDateCell.length) {
                return;
            }
            
            // Simpler approach: iterate through all cells and check each one
            // Get all cells
            const $allCells = $calendar.find('table.table-condensed td, table.calendar-table td');
            
            // Get all month elements to map tables to months
            const $monthElements = $calendar.find('.month');
            const monthsData = [];
            $monthElements.each(function() {
                const $monthEl = jQuery(this);
                const monthText = $monthEl.text().trim();
                const monthMatch = monthText.match(/(\w+)\s+(\d{4})/);
                
                if (monthMatch) {
                    const monthName = monthMatch[1];
                    const year = parseInt(monthMatch[2]);
                    
                    const monthMap = {
                        'January': 0, 'Jan': 0, 'February': 1, 'Feb': 1, 'March': 2, 'Mar': 2,
                        'April': 3, 'Apr': 3, 'May': 4, 'June': 5, 'Jun': 5, 'July': 6, 'Jul': 6,
                        'August': 7, 'Aug': 7, 'September': 8, 'Sep': 8, 'Sept': 8,
                        'October': 9, 'Oct': 9, 'November': 10, 'Nov': 10, 'December': 11, 'Dec': 11
                    };
                    const month = monthMap[monthName];
                    
                    if (month !== undefined) {
                        monthsData.push({ year, month, element: $monthEl });
                    }
                }
            });
            
            // Iterate through dates we need to disable
            for (let i = 1; i < minNights; i++) {
                const targetDate = startDate.clone().add(i, 'days');
                const targetDateStr = targetDate.format('YYYY-MM-DD');
                const targetDay = targetDate.date();
                const targetMonth = targetDate.month();
                const targetYear = targetDate.year();
                
                // Find the cell for this date
                let found = false;
                
                $allCells.each(function() {
                    if (found) return false;
                    
                    const $cell = jQuery(this);
                    
                    // Skip if already disabled or is start/end date
                    if ($cell.hasClass('off') || $cell.hasClass('start-date') || $cell.hasClass('end-date')) {
                        return;
                    }
                    
                    // Get cell day
                    const cellText = $cell.text().trim();
                    if (!cellText || isNaN(parseInt(cellText))) return;
                    const cellDay = parseInt(cellText);
                    
                    // Quick check: day must match
                    if (cellDay !== targetDay) return;
                    
                    // Find which month this cell belongs to
                    const $table = $cell.closest('table');
                    let cellMonth = null;
                    let cellYear = null;
                    
                    // Try to find the month element associated with this table
                    // Check each month element to see if it's near this table
                    for (let j = 0; j < monthsData.length; j++) {
                        const monthData = monthsData[j];
                        const $monthEl = monthData.element;
                        
                        // Check if this month element is associated with this table
                        // The month element should be a sibling or parent of the table
                        const $monthParent = $monthEl.parent();
                        const $tableParent = $table.parent();
                        
                        // If they're in the same container, or month is before/after table
                        if ($monthParent[0] === $tableParent[0] || 
                            $monthEl.nextAll('table').first()[0] === $table[0] ||
                            $table.prevAll('.month').first()[0] === $monthEl[0]) {
                            cellMonth = monthData.month;
                            cellYear = monthData.year;
                            break;
                        }
                    }
                    
                    // If we couldn't find it by structure, try by index
                    if (cellMonth === null) {
                        const $allTables = $calendar.find('table');
                        const tableIndex = $allTables.index($table);
                        if (tableIndex >= 0 && tableIndex < monthsData.length) {
                            cellMonth = monthsData[tableIndex].month;
                            cellYear = monthsData[tableIndex].year;
                        }
                    }
                    
                    // Check if this cell matches our target date
                    if (cellMonth !== null && cellYear !== null && 
                        cellDay === targetDay && cellMonth === targetMonth && cellYear === targetYear) {
                        // Force disable this cell with .off class
                        $cell.addClass('off').removeClass('available in-range active end-date');
                        $cell.css({
                            'pointer-events': 'none',
                            'opacity': '0.3',
                            'cursor': 'not-allowed',
                            'color': '#ccc'
                        });
                        
                        // Prevent clicks
                        $cell.off('click.digimMinStay').on('click.digimMinStay', function(e) {
                            e.preventDefault();
                            e.stopPropagation();
                            e.stopImmediatePropagation();
                            return false;
                        });
                        
                        disabledCount++;
                        found = true;
                        return false; // Break out of each loop
                    }
                });
            }
        }
        
        datePickerInstance = jQuery(dateInput).daterangepicker({
            startDate: moment(),
            endDate: null,
            minDate: moment(),
            singleDatePicker: false,
            autoUpdateInput: false,
            autoApply: true, // Automatically apply selection when both dates are chosen
            showDropdowns: false,
            locale: {
                format: 'MM/DD/YYYY',
                separator: ' - '
            },
            opens: 'left',
            isInvalidDate: function(date) {
                return isInvalidDateFunction(date);
            },
            // Callback when a date is selected (before apply)
            select: function(start, end) {
                const picker = jQuery(dateInput).data('daterangepicker');
                if (!picker) {
                    return;
                }
                
                // If start date is selected but no end date yet, store it for minimum stay validation
                if (start && !end) {
                    const startDateStr = start.format('YYYY-MM-DD');
                    const minNights = minNightsByDate.get(startDateStr);
                    
                    if (minNights && minNights > 0) {
                        // Store the selected start date
                        selectedStartDate = start.toDate();
                        // Update calendar view to disable invalid dates
                        setTimeout(() => {
                            picker.updateView();
                            // Force disable dates that don't meet minimum stay (with longer delay to ensure calendar is updated)
                            setTimeout(() => {
                                forceDisableInvalidDates();
                            }, 150);
                        }, 100);
                    } else {
                        // No minimum stay requirement for this date
                        selectedStartDate = null;
                        picker.updateView();
                    }
                } else if (!start) {
                    // Start date cleared
                    selectedStartDate = null;
                    picker.updateView();
                }
            }
        }, function(start, end, label) {
            // This callback is called when dates are automatically applied
            if (start && end) {
                const checkinDate = start.toDate();
                const checkoutDate = end.toDate();
                const checkoutDateStr = formatDateForAPI(checkoutDate);
                
                // Validate unavailable dates and check-in restrictions
                // IMPORTANT: Check-in blocked dates can be used as checkout dates or within a range
                // They should only block the START date, not dates within the range
                const checkinBlocked = isCheckinBlocked(checkinDate);
                // Checkout-only dates can be used as checkout but not as check-in
                const checkoutIsCheckoutOnly = checkoutOnlyDateSet.has(checkoutDateStr);
                // Check if checkout date is checkout-blocked (closed_for_checkout = true)
                const checkoutBlocked = checkoutBlockedDateSet.has(checkoutDateStr);
                // Check-in blocked dates are allowed as checkout dates (they only block START dates)
                // Only block checkout if it's actually unavailable (not just check-in blocked)
                const checkinUnavailable = isDateUnavailable(checkinDate);
                const checkoutUnavailable = isDateUnavailable(checkoutDate);
                const rangeUnavailable = rangeIncludesUnavailable(checkinDate, checkoutDate);
                
                console.log('=== DATE SELECTION VALIDATION ===', {
                    checkin: formatDateForAPI(checkinDate),
                    checkout: formatDateForAPI(checkoutDate),
                    checkinBlocked,
                    checkoutIsCheckoutOnly,
                    checkinUnavailable,
                    checkoutUnavailable,
                    rangeUnavailable,
                    checkinBlockedDateSet: Array.from(checkinBlockedDateSet),
                    checkoutOnlyDateSet: Array.from(checkoutOnlyDateSet)
                });
                
                // Allow checkout-only dates as checkout dates - don't block if checkout is checkout-only
                // Check-in blocked dates are allowed as checkout dates (they only block START dates)
                const checkoutUnavailableButCheckoutOnly = checkoutUnavailable && checkoutIsCheckoutOnly;
                const shouldBlock = checkinUnavailable || 
                                  (checkoutUnavailable && !checkoutIsCheckoutOnly) || 
                                  checkinBlocked || // Block check-in blocked dates as START dates only
                                  checkoutBlocked || // Block checkout-blocked dates as checkout dates
                                  rangeUnavailable;
                
                if (shouldBlock) {
                    let warningMsg = '';
                    if (checkoutBlocked) {
                        warningMsg = 'The selected check-out date has been marked as unavailable for check-out.';
                    } else if (checkinBlocked) {
                        warningMsg = 'This property has check-in day restrictions. The selected check-in date has been marked as unavailable for check-in. Please select different dates.';
                    } else {
                        warningMsg = 'One or more dates in this range are unavailable. Please choose different dates.';
                    }
                    console.log('=== BLOCKING DATE SELECTION ===', { reason: checkinBlocked ? 'check-in_blocked' : 'unavailable', message: warningMsg });
                    showDateWarning(warningMsg);
                    clearDateSelection({ preserveMessage: true });
                    return;
                }
                
                // Validate minimum nights requirement
                const nights = Math.ceil((checkoutDate - checkinDate) / (1000 * 60 * 60 * 24));
                const checkinDateStr = formatDateForAPI(checkinDate);
                const minNights = minNightsByDate.get(checkinDateStr);
                
                if (minNights && nights < minNights) {
                    const errorMsg = `Minimum stay requirement not met. This property requires a minimum stay of ${minNights} night${minNights > 1 ? 's' : ''} from ${start.format('MMM D, YYYY')}. Please select a checkout date at least ${minNights} nights later (${start.clone().add(minNights, 'days').format('MMM D, YYYY')} or later).`;
                    showDateWarning(errorMsg);
                    clearDateSelection({ preserveMessage: true });
                    // Prevent the dates from being set - get picker instance
                    const currentPicker = jQuery(dateInput).data('daterangepicker');
                    if (currentPicker) {
                        currentPicker.setStartDate(moment());
                        currentPicker.setEndDate(null);
                        currentPicker.updateView();
                    }
                    return;
                }
                
                // If validation passes, update our state and proceed
                selectedDates.checkin = checkinDate;
                selectedDates.checkout = checkoutDate;
                selectedStartDate = null; // Clear selected start date after successful selection
                showDateWarning('');
                
                // Update input display (American format: Month Day, Year)
                dateInput.value = start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY');
                
                // Fetch real pricing from API
                fetchPricingFromAPI();
            }
        });
        
        // Hide the apply/cancel buttons since we're using autoApply
        jQuery(dateInput).on('show.daterangepicker', function() {
            setTimeout(() => {
                const $calendar = jQuery('.daterangepicker');
                if ($calendar.length) {
                    // Add class to the daterangepicker div when it opens
                    $calendar.addClass('Digi-input-date-open');
                    // Hide the buttons
                    $calendar.find('.drp-buttons, .applyBtn, .cancelBtn').hide();
                    // Also hide via CSS
                    $calendar.find('.drp-buttons').css('display', 'none');
                    
                    // Add close button if it doesn't exist
                    if ($calendar.find('.digim-close-button').length === 0) {
                        const $closeButton = jQuery('<button type="button" class="digim-close-button">Close</button>');
                        $closeButton.on('click', function() {
                            const picker = jQuery(dateInput).data('daterangepicker');
                            if (picker) {
                                picker.hide();
                            }
                        });
                        $calendar.append($closeButton);
                    }
                    
                    // Add prev/next navigation arrows for mobile only
                    if ($calendar.find('.digim-calendar-prev').length === 0) {
                        const $prevButton = jQuery('<button type="button" class="digim-calendar-prev" aria-label="Previous month"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15 18L9 12L15 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>');
                        const $nextButton = jQuery('<button type="button" class="digim-calendar-next" aria-label="Next month"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9 18L15 12L9 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>');
                        
                        $prevButton.on('click', function(e) {
                            e.preventDefault();
                            e.stopPropagation();
                            // Click the daterangepicker's prev button
                            const $prevBtn = $calendar.find('.prev');
                            if ($prevBtn.length) {
                                $prevBtn.trigger('click');
                            }
                        });
                        
                        $nextButton.on('click', function(e) {
                            e.preventDefault();
                            e.stopPropagation();
                            // Click the daterangepicker's next button
                            const $nextBtn = $calendar.find('.next');
                            if ($nextBtn.length) {
                                $nextBtn.trigger('click');
                            }
                        });
                        
                        $calendar.append($prevButton);
                        $calendar.append($nextButton);
                    }
                    
                    // Apply checkout-only classes multiple times with delays to ensure calendar is fully rendered
                    setTimeout(() => {
                        applyCheckinBlockedClasses();
                        applyCheckoutOnlyClasses();
                        cleanupSelectedDates(); // Clean up selected dates
                    }, 100);
                    setTimeout(() => {
                        applyCheckinBlockedClasses();
                        applyCheckoutOnlyClasses();
                        cleanupSelectedDates(); // Clean up selected dates
                    }, 300);
                    setTimeout(() => {
                        applyCheckinBlockedClasses();
                        applyCheckoutOnlyClasses();
                        cleanupSelectedDates(); // Clean up selected dates
                    }, 500);
                    
                    // Watch for DOM changes and re-apply classes
                    if (typeof MutationObserver !== 'undefined') {
                        const observer = new MutationObserver(function() {
                            setTimeout(() => {
                                applyCheckinBlockedClasses();
                                applyCheckoutOnlyClasses();
                                cleanupSelectedDates(); // Clean up selected dates
                            }, 50);
                        });
                        
                        observer.observe($calendar[0], {
                            childList: true,
                            subtree: true
                        });
                        
                        // Store observer so we can disconnect it later
                        $calendar.data('checkout-only-observer', observer);
                    }
                }
            }, 10);
        });
        
        // Clean up observer when calendar closes
        jQuery(dateInput).on('hide.daterangepicker', function() {
            const $calendar = jQuery('.daterangepicker');
            const observer = $calendar.data('checkout-only-observer');
            if (observer) {
                observer.disconnect();
                $calendar.removeData('checkout-only-observer');
            }
        });
        
        // Remove class and close button when date picker closes
        jQuery(dateInput).on('hide.daterangepicker', function() {
            const $calendar = jQuery('.daterangepicker');
            if ($calendar.length) {
                $calendar.removeClass('Digi-input-date-open');
                // Remove close button and navigation arrows
                $calendar.find('.digim-close-button, .digim-calendar-prev, .digim-calendar-next').remove();
            }
        });
        
        // Handle when calendar opens - refresh view if start date is already selected
        jQuery(dateInput).on('show.daterangepicker', function() {
            showDateWarning('');
            // If start date is already selected, refresh the calendar to show disabled dates
            setTimeout(() => {
                const picker = jQuery(dateInput).data('daterangepicker');
                if (picker && picker.startDate && !picker.endDate) {
                    const startDateStr = picker.startDate.format('YYYY-MM-DD');
                    const minNights = minNightsByDate.get(startDateStr);
                    if (minNights && minNights > 0) {
                        selectedStartDate = picker.startDate.toDate();
                        picker.updateView();
                        // Force disable invalid dates
                        setTimeout(() => {
                            forceDisableInvalidDates();
                            // Apply check-in blocked and checkout-only classes after calendar updates
                            setTimeout(() => {
                                applyCheckinBlockedClasses();
                                applyCheckoutOnlyClasses();
                                cleanupSelectedDates(); // Clean up selected dates
                            }, 100);
                        }, 200);
                    }
                }
                // Always apply check-in blocked and checkout-only classes when calendar opens (with delay)
                setTimeout(() => {
                    applyCheckinBlockedClasses();
                    applyCheckoutOnlyClasses();
                    cleanupSelectedDates(); // Clean up selected dates
                }, 300);
            }, 100);
        });
        
        // Function to show tooltip when clicking disabled date or invalid date
        function showMinStayTooltip($cell, picker) {
            if (!picker || !picker.startDate) return;
            
            const startDateStr = picker.startDate.format('YYYY-MM-DD');
            const minNights = minNightsByDate.get(startDateStr);
            
            if (!minNights || minNights <= 0) return;
            
            // Remove existing tooltip
            jQuery('.digim-min-stay-toast').remove();
            
            // Create tooltip
            const tooltip = jQuery('<div class="digim-min-stay-toast"></div>');
            tooltip.text(`${minNights}-night minimum`);
            tooltip.css({
                position: 'fixed',
                background: '#222',
                color: '#fff',
                padding: '8px 12px',
                borderRadius: '6px',
                fontSize: '13px',
                fontWeight: '500',
                zIndex: '10000',
                pointerEvents: 'none',
                boxShadow: '0 2px 8px rgba(0,0,0,0.3)',
                whiteSpace: 'nowrap'
            });
            
            // Position tooltip near the cell
            const cellRect = $cell[0].getBoundingClientRect();
            tooltip.css({
                top: (cellRect.top - 35) + 'px',
                left: (cellRect.left + cellRect.width / 2 - 60) + 'px'
            });
            
            jQuery('body').append(tooltip);
            
            // Remove tooltip after 2 seconds
            setTimeout(() => {
                tooltip.fadeOut(300, function() {
                    jQuery(this).remove();
                });
            }, 2000);
        }
        
        // Function to show hover tooltip on start-date cell
        function showStartDateHoverTooltip($cell, minNights) {
            if (!minNights || minNights <= 0) return;
            
            // Remove existing hover tooltip
            jQuery('.digim-start-date-hover-tooltip').remove();
            
            // Create tooltip
            const tooltip = jQuery('<div class="digim-start-date-hover-tooltip"></div>');
            tooltip.text(`${minNights} - night minimum stay`);
            tooltip.css({
                position: 'absolute',
                background: '#222',
                color: '#fff',
                padding: '6px 10px',
                borderRadius: '4px',
                fontSize: '12px',
                fontWeight: '500',
                zIndex: '10001',
                pointerEvents: 'none',
                boxShadow: '0 2px 8px rgba(0,0,0,0.3)',
                whiteSpace: 'nowrap',
                bottom: '100%',
                left: '50%',
                transform: 'translateX(-50%)',
                marginBottom: '5px'
            });
            
            // Add arrow pointing down
            const arrow = jQuery('<div></div>');
            arrow.css({
                position: 'absolute',
                top: '100%',
                left: '50%',
                transform: 'translateX(-50%)',
                width: '0',
                height: '0',
                borderLeft: '5px solid transparent',
                borderRight: '5px solid transparent',
                borderTop: '5px solid #222'
            });
            tooltip.append(arrow);
            
            // Position tooltip relative to cell
            $cell.css('position', 'relative');
            $cell.append(tooltip);
        }
        
        // Function to hide hover tooltip
        function hideStartDateHoverTooltip() {
            jQuery('.digim-start-date-hover-tooltip').remove();
        }
        
        // Add hover tooltip to start-date cells using event delegation
        jQuery(document).on('mouseenter', '.daterangepicker td.start-date', function() {
            const $cell = jQuery(this);
            const picker = jQuery(dateInput).data('daterangepicker');
            
            if (!picker || !picker.startDate) return;
            
            const startDateStr = picker.startDate.format('YYYY-MM-DD');
            const minNights = minNightsByDate.get(startDateStr);
            
            if (minNights && minNights > 0) {
                showStartDateHoverTooltip($cell, minNights);
            }
        });
        
        jQuery(document).on('mouseleave', '.daterangepicker td.start-date', function() {
            hideStartDateHoverTooltip();
        });
        
        // Listen for clicks on calendar dates - intercept and disable invalid ones immediately
        // Use event delegation on the calendar container
        jQuery(document).on('click', '.daterangepicker table.table-condensed td', function(e) {
            const $cell = jQuery(this);
            const picker = jQuery(dateInput).data('daterangepicker');
            
            if (!picker) return;
            
            // If cell is already disabled, show tooltip and prevent click
            if ($cell.hasClass('off')) {
                e.preventDefault();
                e.stopPropagation();
                e.stopImmediatePropagation();
                
                // Show tooltip/toaster
                showMinStayTooltip($cell, picker);
                return false;
            }
            
            // Wait for daterangepicker to process the click and update startDate
            setTimeout(() => {
                const updatedPicker = jQuery(dateInput).data('daterangepicker');
                if (updatedPicker && updatedPicker.startDate && !updatedPicker.endDate) {
                    forceDisableInvalidDates();
                    
                    // Check if the clicked date should be disabled and show tooltip
                    checkAndShowTooltipForClickedDate($cell, updatedPicker);
                }
            }, 250);
        });
        
        // Function to check if clicked date should be disabled and show tooltip
        function checkAndShowTooltipForClickedDate($cell, picker) {
            if (!picker || !picker.startDate || picker.endDate) return;
            
            const startDate = picker.startDate;
            const startDateStr = startDate.format('YYYY-MM-DD');
            const minNights = minNightsByDate.get(startDateStr);
            
            if (!minNights || minNights <= 0) return;
            
            // Get the date from the clicked cell
            const cellText = $cell.text().trim();
            if (!cellText || isNaN(parseInt(cellText))) return;
            
            // Get month/year
            let $monthElement = $cell.closest('.calendar-table').siblings('.month').first();
            if (!$monthElement.length) {
                const $calendarTable = $cell.closest('table.calendar-table');
                if ($calendarTable.length) {
                    const calendarIndex = jQuery('.daterangepicker').find('table.calendar-table').index($calendarTable);
                    const $months = jQuery('.daterangepicker').find('.month');
                    $monthElement = $months.eq(calendarIndex);
                }
            }
            if (!$monthElement.length) {
                $monthElement = jQuery('.daterangepicker').find('.month').first();
            }
            
            if (!$monthElement.length) return;
            
            const monthText = $monthElement.text().trim();
            const monthMatch = monthText.match(/(\w+)\s+(\d{4})/);
            if (!monthMatch) return;
            
            const monthName = monthMatch[1];
            const year = parseInt(monthMatch[2]);
            const day = parseInt(cellText);
            
            const monthMap = {
                'January': 0, 'Jan': 0, 'February': 1, 'Feb': 1, 'March': 2, 'Mar': 2,
                'April': 3, 'Apr': 3, 'May': 4, 'June': 5, 'Jun': 5, 'July': 6, 'Jul': 6,
                'August': 7, 'Aug': 7, 'September': 8, 'Sep': 8, 'Sept': 8,
                'October': 9, 'Oct': 9, 'November': 10, 'Nov': 10, 'December': 11, 'Dec': 11
            };
            const month = monthMap[monthName];
            if (month === undefined) return;
            
            const cellDate = moment([year, month, day]);
            if (!cellDate.isValid()) return;
            
            // Calculate nights
            const nights = cellDate.diff(startDate, 'days');
            
            // If this date doesn't meet minimum stay, show tooltip
            if (nights > 0 && nights < minNights) {
                showMinStayTooltip($cell, picker);
            }
        }
        
        // Also prevent clicks on already disabled dates
        jQuery(document).on('mousedown', '.daterangepicker table.table-condensed td.off', function(e) {
            e.preventDefault();
            e.stopPropagation();
            e.stopImmediatePropagation();
            return false;
        });
        
        // Watch for calendar DOM changes and automatically disable dates when start date is selected
        let calendarObserver = null;
        jQuery(dateInput).on('show.daterangepicker', function() {
            const $calendar = jQuery('.daterangepicker');
            if ($calendar.length && calendarObserver === null) {
                calendarObserver = new MutationObserver(function(mutations) {
                    const picker = jQuery(dateInput).data('daterangepicker');
                    if (picker && picker.startDate && !picker.endDate) {
                        // Check if any cells have start-date class (meaning a date was just selected)
                        const $startDateCell = $calendar.find('td.start-date');
                        if ($startDateCell.length > 0) {
                            setTimeout(() => {
                                forceDisableInvalidDates();
                                cleanupSelectedDates(); // Clean up selected dates
                            }, 150);
                        }
                    }
                });
                
                calendarObserver.observe($calendar[0], {
                    childList: true,
                    subtree: true,
                    attributes: true,
                    attributeFilter: ['class']
                });
            }
        });
        
        jQuery(dateInput).on('hide.daterangepicker', function() {
            if (calendarObserver) {
                calendarObserver.disconnect();
                calendarObserver = null;
            }
        });
        
        // Handle when calendar closes - reset selected start date
        jQuery(dateInput).on('hide.daterangepicker', function() {
            // Only reset if no valid date range was selected
            const picker = jQuery(dateInput).data('daterangepicker');
            if (picker && (!picker.startDate || !picker.endDate)) {
                selectedStartDate = null;
            }
        });

        // Make calendar follow the input on scroll (for sticky booking widget)
        let scrollHandler = null;
        jQuery(dateInput).on('show.daterangepicker', function() {
            // When calendar opens, start tracking scroll
            scrollHandler = function() {
                const $calendar = jQuery('.daterangepicker');
                if ($calendar.length && $calendar.is(':visible')) {
                    const inputRect = dateInput.getBoundingClientRect();
                    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
                    const calendarHeight = $calendar.outerHeight();
                    
                    // Calculate absolute top position: input bottom + scroll position
                    let top = inputRect.bottom + scrollTop + 5;
                    
                    // Adjust if calendar would go off screen at bottom
                    const windowHeight = window.innerHeight;
                    if (inputRect.bottom + calendarHeight > windowHeight) {
                        // Position above input instead
                        top = inputRect.top + scrollTop - calendarHeight - 5;
                    }
                    
                    // Update only top position, keep left as is (daterangepicker handles it)
                    $calendar.css({
                        position: 'absolute',
                        top: top + 'px'
                    });
                }
            };
            
            // Add scroll listener
            jQuery(window).on('scroll', scrollHandler);
            jQuery(window).on('resize', scrollHandler);
            
            // Initial position update
            setTimeout(scrollHandler, 10);
            
            // Add hover tooltips for minimum nights
            setTimeout(() => {
                initMinNightsTooltips();
            }, 100);
        });
        
        // Helper function to extract date from cell (shared scope)
        function getDateFromCell($cell) {
                let dateStr = null;
                const dateText = $cell.text().trim();
                
                // Method 1: Try data-title attribute (daterangepicker sets this)
                let cellDate = $cell.attr('data-title') || $cell.data('title');
                if (cellDate) {
                    const dateMoment = moment(cellDate, 'YYYY-MM-DD');
                    if (dateMoment.isValid()) {
                        return dateMoment.format('YYYY-MM-DD');
                    }
                }
                
                // Method 2: Try data-date attribute
                cellDate = $cell.attr('data-date') || $cell.data('date');
                if (cellDate) {
                    const dateMoment = moment(cellDate);
                    if (dateMoment.isValid()) {
                        return dateMoment.format('YYYY-MM-DD');
                    }
                }
                
                // Method 3: Parse from calendar month/year and day number
                if (dateText && !isNaN(parseInt(dateText))) {
                    const $daterangepicker = $cell.closest('.daterangepicker');
                    const $calendarTable = $cell.closest('table.calendar-table');
                    
                    if ($daterangepicker.length && $calendarTable.length) {
                        const calendarIndex = $daterangepicker.find('table.calendar-table').index($calendarTable);
                        const $months = $daterangepicker.find('.month');
                        const $month = $months.eq(calendarIndex);
                        
                        if ($month.length) {
                            const monthYear = $month.text().trim();
                            // Try different date formats
                            let dateMoment = moment(monthYear + ' ' + dateText, 'MMMM YYYY D');
                            if (!dateMoment.isValid()) {
                                dateMoment = moment(monthYear + ' ' + dateText, 'MMM YYYY D');
                            }
                            if (!dateMoment.isValid()) {
                                dateMoment = moment(monthYear + ' ' + dateText, 'MM YYYY D');
                            }
                            if (dateMoment.isValid()) {
                                return dateMoment.format('YYYY-MM-DD');
                            }
                        }
                    }
                }
                
                return null;
        }
        
        // Function to initialize minimum nights tooltips
        function initMinNightsTooltips() {
            const $calendarTooltip = jQuery('.daterangepicker');
            if (!$calendarTooltip.length) return;
            
            // Remove existing tooltip and event handlers
            jQuery('.digim-min-nights-tooltip').remove();
            $calendarTooltip.off('mouseenter.digimTooltip mouseleave.digimTooltip');
            
            // Create tooltip element - styled like Hospitable calendar
            const tooltip = jQuery('<div class="digim-min-nights-tooltip"></div>');
            tooltip.css({
                position: 'fixed',
                background: '#f5f5f5',
                color: '#222',
                padding: '8px 12px',
                borderRadius: '6px',
                fontSize: '12px',
                fontWeight: '500',
                pointerEvents: 'none',
                zIndex: '10001',
                whiteSpace: 'nowrap',
                boxShadow: '0 2px 8px rgba(0, 0, 0, 0.15)',
                display: 'none',
                maxWidth: '200px',
                lineHeight: '1.4',
                border: '1px solid #e0e0e0'
            });
            // Append to body for fixed positioning
            jQuery('body').append(tooltip);
            
            // Handle hover on ALL calendar date cells (td elements in calendar-table)
            $calendarTooltip.on('mouseenter.digimTooltip', 'table.calendar-table td', function(e) {
                const $cell = jQuery(this);
                
                // Skip header cells and empty cells
                if ($cell.hasClass('off') && !$cell.text().trim()) {
                    return;
                }
                
                // Get date from cell
                const dateStr = getDateFromCell($cell);
                
                if (!dateStr) {
                    tooltip.hide();
                    return;
                }
                
                // Priority: checkout-blocked > check-in blocked > minimum nights
                let tooltipText = null;
                if (checkoutBlockedDateSet.has(dateStr)) {
                    tooltipText = 'Unavailable Check-out';
                } else if (checkinBlockedDateSet.has(dateStr)) {
                    tooltipText = 'Unavailable Check-in';
                } else if (minNightsByDate.has(dateStr)) {
                    // Show minimum nights if not check-in blocked or checkout-blocked
                    const minNights = minNightsByDate.get(dateStr);
                    tooltipText = `${minNights}-night minimum`;
                }
                
                // Show tooltip if we have text to display
                if (tooltipText) {
                    tooltip.text(tooltipText);
                    
                    // Get cell position relative to viewport (for fixed positioning)
                    const cellRect = this.getBoundingClientRect();
                    const cellWidth = cellRect.width;
                    const cellHeight = cellRect.height;
                    
                    // Show tooltip to measure dimensions
                    tooltip.css({ visibility: 'hidden', display: 'block' });
                    const tooltipWidth = tooltip.outerWidth();
                    const tooltipHeight = tooltip.outerHeight();
                    tooltip.css({ visibility: 'visible' });
                    
                    // Position tooltip above the cell, centered horizontally
                    let tooltipLeft = cellRect.left + (cellWidth / 2) - (tooltipWidth / 2);
                    let tooltipTop = cellRect.top - tooltipHeight - 8;
                    
                    // Ensure tooltip doesn't go off-screen to the left
                    if (tooltipLeft < 10) {
                        tooltipLeft = 10;
                    }
                    
                    // Ensure tooltip doesn't go off-screen to the right
                    const maxLeft = window.innerWidth - tooltipWidth - 10;
                    if (tooltipLeft > maxLeft) {
                        tooltipLeft = maxLeft;
                    }
                    
                    // If tooltip would go above viewport, show it below the cell
                    if (tooltipTop < 10) {
                        tooltipTop = cellRect.bottom + 8;
                    }
                    
                    tooltip.css({
                        top: tooltipTop + 'px',
                        left: tooltipLeft + 'px',
                        display: 'block'
                    });
                } else {
                    tooltip.hide();
                }
            });
            
            // Hide tooltip on mouse leave
            $calendarTooltip.on('mouseleave.digimTooltip', 'table.calendar-table td', function() {
                tooltip.hide();
            });
            
            // Re-initialize when calendar is updated (month navigation, etc.)
            $calendarTooltip.on('apply.daterangepicker', function() {
                setTimeout(initMinNightsTooltips, 100);
            });
            
            // Also re-initialize when month changes (daterangepicker updates)
            $calendarTooltip.on('click', '.prev, .next, .monthselect, .yearselect', function() {
                setTimeout(initMinNightsTooltips, 150);
            });
        }
        
        jQuery(dateInput).on('hide.daterangepicker', function() {
            // When calendar closes, remove scroll listener
            if (scrollHandler) {
                jQuery(window).off('scroll', scrollHandler);
                jQuery(window).off('resize', scrollHandler);
                scrollHandler = null;
            }
        });

        // Load unavailable dates after initialization, then prefill from URL
        loadUnavailableDates().then((loaded) => {
            if (loaded) {
                // Wait a bit for the date picker to be fully ready and minNightsByDate to be populated, then prefill
                setTimeout(() => {
                    prefillBookingFromURL();
                }, 300);
            } else {
                // Even if loading failed, try to prefill (dates might still be valid)
                setTimeout(() => {
                    prefillBookingFromURL();
                }, 300);
            }
        });
    }
    
    function initGuestSelector() {
        const guestSelector = document.getElementById('guest-selector');
        const guestDropdown = document.getElementById('guest-dropdown');
        const guestText = guestSelector.querySelector('.guest-text');
        const dropdownArrow = guestSelector.querySelector('.dropdown-arrow');
        const rightSidebar = document.querySelector('.airbnb-property-page .right-sidebar');
        const isMobile = () => window.matchMedia('(max-width: 991px)').matches;
        const getWidget = () => rightSidebar ? rightSidebar.querySelector('.booking-widget') : null;
        const shouldApplyBottom = () => {
            const widget = getWidget();
            if (!widget) return true;
            const widgetIsActive = widget.classList.contains('active');
            const widgetHeight = widget.offsetHeight || 0;
            return !(widgetIsActive && widgetHeight > 650);
        };
        const setSidebarBottom = (value) => {
            if (rightSidebar && isMobile() && shouldApplyBottom()) {
                rightSidebar.style.bottom = value;
            }
        };
        
        // Toggle dropdown
        guestSelector.addEventListener('click', function(e) {
            e.stopPropagation();
            const isActive = guestDropdown.classList.contains('active');
            
            if (isActive) {
                guestDropdown.classList.remove('active');
                dropdownArrow.style.transform = 'rotate(0deg)';
                setSidebarBottom('0px');
            } else {
                guestDropdown.classList.add('active');
                dropdownArrow.style.transform = 'rotate(180deg)';
                setSidebarBottom('165px');
            }
        });
        
        // Close dropdown when clicking outside
        document.addEventListener('click', function(e) {
            if (!guestDropdown.contains(e.target) && !guestSelector.contains(e.target)) {
                guestDropdown.classList.remove('active');
                dropdownArrow.style.transform = 'rotate(0deg)';
                setSidebarBottom('0px');
            }
        });

        // Close on Escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                guestDropdown.classList.remove('active');
                dropdownArrow.style.transform = 'rotate(0deg)';
                setSidebarBottom('0px');
            }
        });

        // Ensure correct bottom on resize
        window.addEventListener('resize', function() {
            if (!guestDropdown.classList.contains('active')) {
                setSidebarBottom('0px');
            } else {
                setSidebarBottom('165px');
            }
        });
        
        // Guest control buttons
        const guestButtons = document.querySelectorAll('.guest-btn');
        guestButtons.forEach(button => {
            button.addEventListener('click', function() {
                const type = this.dataset.type;
                const action = this.dataset.action;
                
                if (action === 'increase') {
                    if (type === 'adults' || guestState[type] < 5) {
                        guestState[type]++;
                    }
                } else if (action === 'decrease') {
                    if (guestState[type] > 0 && !(type === 'adults' && guestState[type] === 1)) {
                        guestState[type]--;
                    }
                }
                
                updateGuestDisplay();
                updateGuestText();
            });
        });
        
        updateGuestDisplay();
        updateGuestText();
    }
    
    function updateGuestDisplay() {
        document.getElementById('adults-count').textContent = guestState.adults;
        document.getElementById('children-count').textContent = guestState.children;
        document.getElementById('infants-count').textContent = guestState.infants;
        const petsCountEl = document.getElementById('pets-count');
        if (petsCountEl) petsCountEl.textContent = guestState.pets || 0;
        
        // Update button states
        const minusButtons = document.querySelectorAll('.guest-btn.minus');
        minusButtons.forEach(button => {
            const type = button.dataset.type;
            button.disabled = (type === 'adults' && guestState[type] <= 1) || guestState[type] <= 0;
        });
        
        const plusButtons = document.querySelectorAll('.guest-btn.plus');
        plusButtons.forEach(button => {
            const type = button.dataset.type;
            button.disabled = guestState[type] >= 5;
        });
    }
    
    function updateGuestText() {
        const guestText = document.querySelector('.guest-text');
        const totalGuests = guestState.adults + guestState.children + guestState.infants;
        
        if (totalGuests === 0) {
            guestText.textContent = 'Add guests';
            guestText.classList.remove('has-selection');
        } else {
            let text = `${totalGuests} guest${totalGuests !== 1 ? 's' : ''}`;
            if (guestState.infants > 0) {
                text += `, ${guestState.infants} infant${guestState.infants !== 1 ? 's' : ''}`;
            }
            if (guestState.pets > 0) {
                text += `, ${guestState.pets} pet${guestState.pets !== 1 ? 's' : ''}`;
            }
            guestText.textContent = text;
            guestText.classList.add('has-selection');
        }
    }
    
    // Fetch pricing from Hospitable API
    async function fetchPricingFromAPI() {
        if (!selectedDates.checkin || !selectedDates.checkout) {
            return;
        }

        // Debug: Log what we're checking
        const checkinStr = selectedDates.checkin ? formatDateForAPI(selectedDates.checkin) : 'null';
        const checkoutStr = selectedDates.checkout ? formatDateForAPI(selectedDates.checkout) : 'null';
        const checkoutDateStr = formatDateForAPI(selectedDates.checkout);
        const checkoutIsCheckoutOnly = checkoutOnlyDateSet.has(checkoutDateStr);
        
        console.log('=== PRICING CHECK ===', {
            checkin: checkinStr,
            checkout: checkoutStr,
            isCheckinUnavailable: isDateUnavailable(selectedDates.checkin),
            isCheckoutUnavailable: isDateUnavailable(selectedDates.checkout),
            isCheckinBlocked: isCheckinBlocked(selectedDates.checkin),
            isCheckoutBlocked: isCheckinBlocked(selectedDates.checkout),
            checkoutIsCheckoutOnly: checkoutIsCheckoutOnly,
            checkinBlockedDateSet: Array.from(checkinBlockedDateSet),
            checkoutOnlyDateSet: Array.from(checkoutOnlyDateSet),
            unavailableDateSet: Array.from(unavailableDateSet)
        });
        
        // Allow checkout-only dates as checkout dates
        // IMPORTANT: Check-in blocked dates can be used as checkout dates (they only block START dates)
        const isCheckoutBlocked = checkoutBlockedDateSet.has(checkoutDateStr);
        const shouldBlock = isDateUnavailable(selectedDates.checkin) || 
                           (isDateUnavailable(selectedDates.checkout) && !checkoutIsCheckoutOnly) || 
                           isCheckinBlocked(selectedDates.checkin) || // Block check-in blocked dates as START dates only
                           isCheckoutBlocked || // Block checkout-blocked dates as checkout dates
                           rangeIncludesUnavailable(selectedDates.checkin, selectedDates.checkout);
        
        if (shouldBlock) {
            const isCheckinBlockedFlag = isCheckinBlocked(selectedDates.checkin);
            const isCheckinUnavailableFlag = isDateUnavailable(selectedDates.checkin);
            const isCheckoutUnavailableFlag = isDateUnavailable(selectedDates.checkout) && !checkoutIsCheckoutOnly;
            const rangeUnavailableFlag = rangeIncludesUnavailable(selectedDates.checkin, selectedDates.checkout);
            
            let userMessage = '';
            if (isCheckoutBlocked) {
                userMessage = 'The selected check-out date has been marked as unavailable for check-out.';
            } else if (isCheckinBlockedFlag) {
                userMessage = 'This property has check-in day restrictions. The selected check-in date has been marked as unavailable for check-in. Please select different dates.';
            } else {
                userMessage = UNAVAILABLE_MESSAGE_TEXT + ' Please choose different dates.';
            }
            
            console.log('=== BLOCKING SELECTION ===', {
                reason: {
                    isCheckinBlocked: isCheckinBlockedFlag,
                    isCheckinUnavailable: isCheckinUnavailableFlag,
                    isCheckoutUnavailable: isCheckoutUnavailableFlag,
                    rangeUnavailable: rangeUnavailableFlag,
                    checkoutIsCheckoutOnly: checkoutIsCheckoutOnly
                },
                message: userMessage,
                checkinDate: checkinStr,
                checkoutDate: checkoutStr
            });
            showDateWarning(userMessage);
            clearDateSelection({ preserveMessage: true });
            showPricingError(userMessage);
            const reserveButton = document.querySelector('.reserve-button');
            if (reserveButton) {
                reserveButton.disabled = true;
                reserveButton.innerHTML = '<span class="reserve-text">Not Available</span>';
            }
            return;
        }
        
        // Fetching pricing for selected dates
        
        const pricingBreakdown = document.getElementById('pricing-breakdown');
        const reserveButton = document.querySelector('.reserve-button');
        let keepReserveDisabled = false;
        
        // Show loading state (do not change base per-night price)
        pricingBreakdown.innerHTML = '<div class="loading-pricing">Loading pricing...</div>';
        pricingBreakdown.style.display = 'block';
        reserveButton.disabled = true;
        
        let timeoutId = null;
        try {
            // Abort any previous pricing fetch request
            if (pricingFetchController) {
                pricingFetchController.abort();
            }
            
            // Create new AbortController for this request
            pricingFetchController = new AbortController();
            timeoutId = setTimeout(() => {
                if (pricingFetchController) {
                    pricingFetchController.abort();
                }
            }, 10000); // 10 second timeout
            
            const response = await fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'digim_get_pricing',
                    nonce: '<?php echo wp_create_nonce('digim_booking_nonce'); ?>',
                    property_uuid: '<?php echo $uuid; ?>',
                    checkin_date: formatDateForAPI(selectedDates.checkin),
                    checkout_date: formatDateForAPI(selectedDates.checkout),
                    adults: guestState.adults,
                    children: guestState.children,
                    infants: guestState.infants,
                    pets: guestState.pets || 0
                }),
                signal: pricingFetchController.signal
            });
            
            const responseText = await response.text();
            
            let data;
            try {
                data = JSON.parse(responseText);
            } catch (parseError) {
                console.error('JSON parse error:', parseError);
                console.error('Response text:', responseText);
                showPricingError('Invalid response from server. Please try again.');
                return;
            }
            
            
            if (data.success) {
                // Store listing_id and account_id from response if available
                if (data.data && data.data.listing_id) {
                    window.listingId = data.data.listing_id;
                }
                if (data.data && data.data.account_id) {
                    window.accountId = data.data.account_id;
                }
                // store quote metadata if present
                if (data.data && (data.data.quote_id || data.data.booking_url)) {
                    if (data.data.quote_id) window.quoteId = data.data.quote_id;
                    if (data.data.booking_url) window.bookingUrl = data.data.booking_url;
                    
                    console.log('Quote ID:', window.quoteId);
                    console.log('Booking URL:', window.bookingUrl);
                }
                
                updatePricingDisplay(data.data);
                // Check availability
                await checkAvailability();
            } else {
                console.error('API error:', data.data);

                const errorMessage = (data.data && data.data.message) ? String(data.data.message) : '';
                const reasonPhrase = (data.data && data.data.raw && data.data.raw.body && data.data.raw.body.reason_phrase)
                    ? String(data.data.raw.body.reason_phrase)
                    : '';
                if ((errorMessage && errorMessage.includes(UNAVAILABLE_MESSAGE_TEXT)) || (reasonPhrase && reasonPhrase.includes(UNAVAILABLE_MESSAGE_TEXT))) {
                    const userMessage = UNAVAILABLE_MESSAGE_TEXT + ' Please choose different dates.';
                    showDateWarning(userMessage);
                    clearDateSelection({ preserveMessage: true });
                    showPricingError(userMessage);
                    reserveButton.disabled = true;
                    reserveButton.innerHTML = '<span class="reserve-text">Not Available</span>';
                    keepReserveDisabled = true;
                    return;
                }
                
                // Check if it's a minimum stay error
                let minNightsMatch = null;
                if (data.data && data.data.message) {
                    const minNightsRegex = /minimum.*?(\d+).*?night/i;
                    minNightsMatch = data.data.message.match(minNightsRegex);
                }
                
                if (data.data && data.data.message && data.data.message.includes('minimum stay')) {
                    const minNights = minNightsMatch ? minNightsMatch[1] : '';
                    const errorMsg = minNights 
                        ? `This property requires a minimum stay of ${minNights} night${minNights > 1 ? 's' : ''}. Please select a longer stay.`
                        : 'Minimum stay requirement not met. Please select a longer stay.';
                    showPricingError(errorMsg);
                    return;
                }
                
                // Check if it's a 422 error with specific message
                if (data.data && data.data.raw && data.data.raw.body && data.data.raw.body.reason_phrase) {
                    const errorMsg = data.data.raw.body.reason_phrase;
                    const minNightsRegex = /minimum.*?(\d+).*?night/i;
                    const minNightsMatch = errorMsg.match(minNightsRegex);
                    
                    if (errorMsg.includes('minimum stay')) {
                        const minNights = minNightsMatch ? minNightsMatch[1] : '';
                        const userMsg = minNights 
                            ? `This property requires a minimum stay of ${minNights} night${minNights > 1 ? 's' : ''}. Please select a longer stay or different dates.`
                            : 'Minimum stay requirement not met. Please select a longer stay or different dates.';
                        showPricingError(userMsg);
                    } else if (errorMsg.toLowerCase().includes('check-in') || errorMsg.toLowerCase().includes('checkin')) {
                        // Check-in day restriction error
                        showPricingError('This property has check-in day restrictions. ' + errorMsg + ' Please select different dates.');
                    } else {
                        showPricingError(errorMsg);
                    }
                    return;
                }
                
                // Fallback to static pricing if API fails
                const nights = Math.ceil((selectedDates.checkout - selectedDates.checkin) / (1000 * 60 * 60 * 24));
                const fallbackPricing = {
                    base_price: pricing.basePrice,
                    cleaning_fee: pricing.cleaningFee,
                    service_fee: pricing.serviceFee,
                    security_deposit: pricing.securityDeposit,
                    currency: pricing.currency,
                    nights: nights,
                    subtotal: pricing.basePrice * nights,
                    long_stay_discount: 0,
                    long_stay_discount_label: '',
                    total: (pricing.basePrice * nights) + pricing.cleaningFee + pricing.serviceFee
                };
                updatePricingDisplay(fallbackPricing);
            }
        } catch (error) {
            // Ignore AbortError - it means the request was cancelled (either by timeout or new request)
            if (error.name === 'AbortError') {
                console.log('Pricing fetch cancelled (likely due to new request or timeout)');
                return; // Exit early, don't show error or fallback pricing
            }
            
            console.error('Pricing fetch error:', error);

            const errorMessage = error && error.message ? String(error.message) : '';
            if (errorMessage && errorMessage.includes(UNAVAILABLE_MESSAGE_TEXT)) {
                const userMessage = UNAVAILABLE_MESSAGE_TEXT + ' Please choose different dates.';
                showDateWarning(userMessage);
                clearDateSelection({ preserveMessage: true });
                showPricingError(userMessage);
                reserveButton.disabled = true;
                reserveButton.innerHTML = '<span class="reserve-text">Not Available</span>';
                keepReserveDisabled = true;
                return;
            }
            
            // Use fallback pricing on error
            const nights = Math.ceil((selectedDates.checkout - selectedDates.checkin) / (1000 * 60 * 60 * 24));
            const fallbackPricing = {
                base_price: pricing.basePrice,
                cleaning_fee: pricing.cleaningFee,
                service_fee: pricing.serviceFee,
                security_deposit: pricing.securityDeposit,
                currency: pricing.currency,
                nights: nights,
                subtotal: pricing.basePrice * nights,
                long_stay_discount: 0,
                long_stay_discount_label: '',
                total: (pricing.basePrice * nights) + pricing.cleaningFee + pricing.serviceFee
            };
            updatePricingDisplay(fallbackPricing);
        } finally {
            // Clear timeout if it's still active
            if (timeoutId) {
                clearTimeout(timeoutId);
            }
            // Clear the controller reference after request completes
            pricingFetchController = null;
            if (keepReserveDisabled) {
                reserveButton.disabled = true;
            } else {
                reserveButton.disabled = false;
                reserveButton.innerHTML = '<span class="reserve-text">Book Now</span>';
            }
        }
    }
    
    // Helper function to format numbers with comma separators
    function formatNumber(num) {
        return num.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    }
    
    // Update pricing display with API data
    function updatePricingDisplay(pricingData) {
        const pricingBreakdown = document.getElementById('pricing-breakdown');
        if (!pricingBreakdown) return;

        // Update local pricing cache
        pricing.basePrice = pricingData.base_price;
        pricing.cleaningFee = pricingData.cleaning_fee;
        pricing.serviceFee = pricingData.service_fee;
        pricing.taxes = pricingData.taxes || 0;
        pricing.securityDeposit = pricingData.security_deposit;
        pricing.currency = pricingData.currency;

        // Build the card content fresh to avoid missing elements
        pricingBreakdown.classList.add('show');
        pricingBreakdown.style.display = 'block';
        
        // Build discount line if long stay discount exists
        let discountLine = '';
        if (pricingData.long_stay_discount && pricingData.long_stay_discount > 0) {
            const discountLabel = pricingData.long_stay_discount_label || 'Long stay discount';
            discountLine = `
                <div class="price-line discount-line">
                    <span class="price-label">${discountLabel}</span>
                    <span class="price-value discount-value">-$${formatNumber(pricingData.long_stay_discount)}</span>
                </div>
            `;
        }
        
        // Use exact base_price from API - no rounding, display as-is
        const basePriceFormatted = parseFloat(pricingData.base_price || 0).toFixed(2);
        
        pricingBreakdown.innerHTML = `
            <div class="pricing-section">
                <h4>Price details</h4>
                <div class="price-line">
                    <span class="price-label" id="base-price-label">$${basePriceFormatted} × ${pricingData.nights} nights</span>
                    <span class="price-value" id="base-price-total">$${formatNumber(pricingData.subtotal)}</span>
                </div>
                ${discountLine}
                <div class="price-line">
                    <span class="price-label">Cleaning fee</span>
                    <span class="price-value" id="cleaning-fee">$${formatNumber(pricingData.cleaning_fee)}</span>
                </div>
                <div class="price-line">
                    <span class="price-label">Service fee</span>
                    <span class="price-value" id="service-fee">$${formatNumber(pricingData.service_fee)}</span>
                </div>
                <div class="price-line">
                    <span class="price-label">Taxes and fees</span>
                    <span class="price-value" id="taxes">$${formatNumber(pricingData.taxes || 0)}</span>
                </div>
                <div class="price-line total-line">
                    <span class="price-label">Total</span>
                    <span class="price-value" id="total-price">$${formatNumber(pricingData.total)}</span>
                </div>
            </div>
        `;
    }
    
    // Check availability
    async function checkAvailability() {
        if (!selectedDates.checkin || !selectedDates.checkout) return;
        
        // Allow checkout-only dates as checkout dates
        const checkoutDateStr = formatDateForAPI(selectedDates.checkout);
        const checkoutIsCheckoutOnly = checkoutOnlyDateSet.has(checkoutDateStr);
        
        console.log('=== CHECK AVAILABILITY ===', {
            checkin: formatDateForAPI(selectedDates.checkin),
            checkout: checkoutDateStr,
            checkoutIsCheckoutOnly: checkoutIsCheckoutOnly,
            isCheckinBlocked_checkin: isCheckinBlocked(selectedDates.checkin),
            isCheckinBlocked_checkout: isCheckinBlocked(selectedDates.checkout)
        });
        
        // Block if check-in is blocked (check-in blocked dates can only be used as START dates)
        // IMPORTANT: Check-in blocked dates can be used as checkout dates or within a range
        // They should only block the START date, not dates within the range
        if (isCheckinBlocked(selectedDates.checkin)) {
            console.log('=== BLOCKING: Check-in date is blocked ===');
            showPricingError('This property has check-in day restrictions. Please choose a different check-in date.');
            return;
        }
        
        // Block if checkout is blocked (checkout-blocked dates cannot be used as checkout dates)
        if (checkoutBlockedDateSet.has(checkoutDateStr)) {
            console.log('=== BLOCKING: Checkout date is blocked ===');
            showPricingError('The selected check-out date has been marked as unavailable for check-out.');
            return;
        }
        
        // Check-in blocked dates are allowed as checkout dates (they only block START dates)
        // No need to block checkout dates that are check-in blocked
        
        console.log('=== AVAILABILITY CHECK PASSED ===');
        
        try {
            const response = await fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'digim_check_availability',
                    nonce: '<?php echo wp_create_nonce('digim_booking_nonce'); ?>',
                    property_uuid: '<?php echo $uuid; ?>',
                    checkin_date: selectedDates.checkin.toISOString().split('T')[0],
                    checkout_date: selectedDates.checkout.toISOString().split('T')[0]
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                updateAvailabilityStatus(data.data.available);
            }
        } catch (error) {
            console.error('Availability check error:', error);
        }
    }
    
    // Update availability status
    function updateAvailabilityStatus(isAvailable) {
        const reserveButton = document.querySelector('.reserve-button');
        const pricingBreakdown = document.getElementById('pricing-breakdown');
        
        if (!isAvailable) {
            reserveButton.disabled = true;
            reserveButton.innerHTML = '<span class="reserve-text">Not Available</span>';
            
            // Add availability warning
            let warning = pricingBreakdown.querySelector('.availability-warning');
            if (!warning) {
                warning = document.createElement('div');
                warning.className = 'availability-warning';
                warning.style.cssText = 'color: #e31c5f; font-size: 14px; margin-bottom: 12px; text-align: center;';
                pricingBreakdown.insertBefore(warning, pricingBreakdown.firstChild);
            }
            warning.textContent = 'These dates are not available for booking';
        } else {
            reserveButton.disabled = false;
            reserveButton.innerHTML = '<span class="reserve-text">Book Now</span>';
            
            // Remove warning if exists
            const warning = pricingBreakdown.querySelector('.availability-warning');
            if (warning) {
                warning.remove();
            }
        }
    }
    
    // Show pricing error
    function showPricingError(message) {
        const pricingBreakdown = document.getElementById('pricing-breakdown');
        pricingBreakdown.innerHTML = `<div class="pricing-error" style="color: #e31c5f; text-align: center; padding: 20px;">${message}</div>`;
        pricingBreakdown.style.display = 'block';
    }
    
    function initFormSubmission() {
        const form = document.getElementById('booking-form');
        const reserveButton = document.querySelector('.reserve-button');
        
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            
            // Validate form
            if (!selectedDates.checkin || !selectedDates.checkout) {
                alert('Please select check-in and check-out dates');
                return;
            }
            
            if (guestState.adults + guestState.children + guestState.infants === 0) {
                alert('Please select number of guests');
                return;
            }
            
            // Show loading state
            reserveButton.disabled = true;
            reserveButton.innerHTML = '<span class="reserve-text">Processing...</span>';
            
            // Prepare booking data
            const bookingData = {
                property_uuid: '<?php echo $uuid; ?>',
                checkin_date: selectedDates.checkin.toISOString().split('T')[0],
                checkout_date: selectedDates.checkout.toISOString().split('T')[0],
                adults: guestState.adults,
                children: guestState.children,
                infants: guestState.infants,
                total_guests: guestState.adults + guestState.children + guestState.infants
            };
            
            // Use the existing formatDateForAPI function

            // Use booking_url directly from quote if available
            if (window.bookingUrl && window.quoteId) {
                // Construct the correct booking URL format: book/{property_uuid}/{property_id}/{quote_id}
                // Extract property ID from the original booking URL
                const urlParts = window.bookingUrl.split('/');
                const propertyId = urlParts[urlParts.length - 2]; // Get property ID before quote_id
                
                // Get the property UUID from the current page
                const propertyUuid = '<?php echo $uuid; ?>';
                
                // Construct the correct URL format with query parameters
                let finalBookingUrl = `https://booking.hospitable.com/book/${propertyUuid}/${propertyId}/${window.quoteId}`;
                
                // Add query parameters for guests and pets
                const queryParams = new URLSearchParams();
                queryParams.append('adults', guestState.adults);
                queryParams.append('children', guestState.children);
                queryParams.append('infants', guestState.infants);
                if (guestState.pets > 0) {
                    queryParams.append('pets', guestState.pets);
                }
                
                const queryString = queryParams.toString();
                if (queryString) {
                    finalBookingUrl += '?' + queryString;
                }
                
                console.log('Original booking URL:', window.bookingUrl);
                console.log('Property UUID:', propertyUuid);
                console.log('Property ID:', propertyId);
                console.log('Quote ID:', window.quoteId);
                console.log('Final booking URL:', finalBookingUrl);
                
                window.location.href = finalBookingUrl;
                return;
            }
            
            // If no booking_url, show error
            alert('Booking URL not available. Please try selecting dates again.');
            
            // Reset button state
            reserveButton.disabled = false;
            reserveButton.innerHTML = '<span class="reserve-text">Book Now</span>';
        });
    }
    
    // Function to submit booking to Hospitable API
    async function submitBooking(bookingData) {
        try {
            
            const response = await fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'digim_submit_booking',
                    nonce: '<?php echo wp_create_nonce('digim_booking_nonce'); ?>',
                    ...bookingData
                })
            });
            
            const responseText = await response.text();
            
            let data;
            try {
                data = JSON.parse(responseText);
            } catch (parseError) {
                console.error('JSON parse error:', parseError);
                console.error('Response text:', responseText);
                return {
                    success: false,
                    message: 'Invalid response from server',
                    data: { message: responseText }
                };
            }
            
            return data;
        } catch (error) {
            console.error('Booking submission error:', error);
            return {
                success: false,
                message: error.message || 'Network error',
                error: error
            };
        }
    }

    // Create reservation and return checkout URL (server makes API call)
    async function createReservation(bookingData) {
        try {
            const res = await fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'digim_create_reservation',
                    nonce: '<?php echo wp_create_nonce('digim_booking_nonce'); ?>',
                    ...bookingData
                })
            });
            const txt = await res.text();
            try {
                return JSON.parse(txt);
            } catch (e) {
                return { success: false, message: 'Invalid reservation response', raw: txt };
            }
        } catch (e) {
            return { success: false, message: e.message || 'Network error' };
        }
    }
}

// Description truncation functionality
let isDescriptionExpanded = false;
let originalDescription = '';
let truncatedDescription = '';

function initDescriptionTruncation() {
    const descriptionText = document.querySelector('.description-text');
    const showMoreBtn = document.querySelector('.show-more-btn');
    
    if (!descriptionText || !showMoreBtn) return;
    
    originalDescription = descriptionText.innerHTML;
    const maxLength = 300; // Character limit for truncation
    
    if (originalDescription.length > maxLength) {
        // Create truncated version
        truncatedDescription = originalDescription.substring(0, maxLength);
        
        // Find the last complete word within the limit
        const lastSpaceIndex = truncatedDescription.lastIndexOf(' ');
        if (lastSpaceIndex > maxLength * 0.8) { // Only use last space if it's not too far back
            truncatedDescription = truncatedDescription.substring(0, lastSpaceIndex);
        }
        
        truncatedDescription += '...';
        
        // Set initial state
        descriptionText.innerHTML = truncatedDescription;
        showMoreBtn.style.display = 'flex';
    }
}

function toggleDescription() {
    const descriptionText = document.querySelector('.description-text');
    const showMoreBtn = document.querySelector('.show-more-btn');
    const btnText = showMoreBtn.querySelector('.btn-text');
    const btnIcon = showMoreBtn.querySelector('.btn-icon');
    
    if (!descriptionText || !showMoreBtn) return;
    
    if (isDescriptionExpanded) {
        // Collapse
        descriptionText.innerHTML = truncatedDescription;
        btnText.textContent = 'Show more';
        btnIcon.style.transform = 'rotate(0deg)';
        isDescriptionExpanded = false;
    } else {
        // Expand
        descriptionText.innerHTML = originalDescription;
        btnText.textContent = 'Show less';
        btnIcon.style.transform = 'rotate(180deg)';
        isDescriptionExpanded = true;
    }
}

// Review toggle functionality
function toggleReviewFullText(button) {
    const reviewCard = button.closest('.review-card');
    const reviewText = reviewCard.querySelector('.review-text');
    const currentText = reviewText.textContent.trim();
    
    // Get the stored full text from the button's data attribute
    const fullText = button.dataset.fullText || currentText;
    const truncatedText = fullText.substring(0, 200) + '...';
    
    if (currentText.endsWith('...') || currentText === truncatedText) {
        // Show full text
        reviewText.textContent = fullText;
        button.textContent = 'Show less';
    } else {
        // Show truncated text
        reviewText.textContent = truncatedText;
        button.textContent = 'Show more';
    }
}

// Load More Reviews Functionality
<?php if ($total_reviews_count > 3): ?>
const allReviewsData = <?php echo json_encode($reviews); ?>;
const reviewsGrid = document.getElementById('reviews-grid');
const loadMoreBtn = document.getElementById('load-more-reviews');

if (loadMoreBtn) {
    loadMoreBtn.addEventListener('click', function() {
        const loaded = parseInt(this.dataset.loaded);
        const total = parseInt(this.dataset.total);
        const loadCount = 2; // Load 2 more at a time
        
        // Show loading state
        this.classList.add('loading');
        this.disabled = true;
        
        // Simulate loading delay (you can remove this in production)
        setTimeout(() => {
            // Get next batch of reviews
            const nextBatch = allReviewsData.slice(loaded, loaded + loadCount);
            
            // Render new reviews
            nextBatch.forEach(review => {
                const rating = parseInt(review.public?.rating || 5);
                const reviewText = review.public?.review || '';
                const reviewDate = review.reviewed_at || '';
                const platform = review.platform || '';
                
                // Format date
                let formattedDate = '';
                if (reviewDate) {
                    try {
                        const dateObj = new Date(reviewDate);
                        formattedDate = dateObj.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
                    } catch (e) {
                        formattedDate = reviewDate;
                    }
                }
                
                // Extract reviewer name from API - check multiple possible fields and nested objects
                let reviewerName = null;
                
                // Check direct fields first
                const nameFields = ['reviewer_name', 'guest_name', 'author_name', 'name', 'reviewer', 'guest'];
                for (const field of nameFields) {
                    if (review[field] && typeof review[field] === 'string') {
                        reviewerName = review[field];
                        break;
                    }
                    if (review.public && review.public[field] && typeof review.public[field] === 'string') {
                        reviewerName = review.public[field];
                        break;
                    }
                }
                
                // Check nested guest object
                if (!reviewerName && review.guest && typeof review.guest === 'object') {
                    const guestNameFields = ['name', 'full_name', 'display_name', 'first_name', 'username', 'firstname'];
                    for (const field of guestNameFields) {
                        if (review.guest[field] && typeof review.guest[field] === 'string') {
                            reviewerName = review.guest[field];
                            // If we have first_name, try to combine with last_name
                            if (field === 'first_name' && review.guest.last_name) {
                                reviewerName = review.guest.first_name + ' ' + review.guest.last_name;
                            }
                            break;
                        }
                    }
                }
                
                // Check nested reviewer object
                if (!reviewerName && review.reviewer && typeof review.reviewer === 'object') {
                    const reviewerNameFields = ['name', 'full_name', 'display_name', 'first_name', 'username'];
                    for (const field of reviewerNameFields) {
                        if (review.reviewer[field] && typeof review.reviewer[field] === 'string') {
                            reviewerName = review.reviewer[field];
                            if (field === 'first_name' && review.reviewer.last_name) {
                                reviewerName = review.reviewer.first_name + ' ' + review.reviewer.last_name;
                            }
                            break;
                        }
                    }
                }
                
                // Check nested author object
                if (!reviewerName && review.author && typeof review.author === 'object') {
                    const authorNameFields = ['name', 'full_name', 'display_name', 'first_name', 'username'];
                    for (const field of authorNameFields) {
                        if (review.author[field] && typeof review.author[field] === 'string') {
                            reviewerName = review.author[field];
                            if (field === 'first_name' && review.author.last_name) {
                                reviewerName = review.author.first_name + ' ' + review.author.last_name;
                            }
                            break;
                        }
                    }
                }
                
                // Check nested user object
                if (!reviewerName && review.user && typeof review.user === 'object') {
                    const userNameFields = ['name', 'full_name', 'display_name', 'first_name', 'username'];
                    for (const field of userNameFields) {
                        if (review.user[field] && typeof review.user[field] === 'string') {
                            reviewerName = review.user[field];
                            if (field === 'first_name' && review.user.last_name) {
                                reviewerName = review.user.first_name + ' ' + review.user.last_name;
                            }
                            break;
                        }
                    }
                }
                
                // Fallback to platform name if not found
                if (!reviewerName) {
                    reviewerName = platform.charAt(0).toUpperCase() + platform.slice(1);
                }
                
                // Extract reviewer avatar from API - check multiple possible fields and nested objects
                let reviewerAvatar = null;
                
                // Check direct fields first
                const avatarFields = ['avatar', 'avatar_url', 'profile_picture', 'photo', 'profile_photo', 'picture_url', 'image_url', 'thumbnail_url', 'picture'];
                for (const field of avatarFields) {
                    if (review[field] && typeof review[field] === 'string') {
                        reviewerAvatar = review[field];
                        break;
                    }
                    if (review.public && review.public[field] && typeof review.public[field] === 'string') {
                        reviewerAvatar = review.public[field];
                        break;
                    }
                }
                
                // Check nested guest object
                if (!reviewerAvatar && review.guest && typeof review.guest === 'object') {
                    for (const field of avatarFields) {
                        if (review.guest[field] && typeof review.guest[field] === 'string') {
                            reviewerAvatar = review.guest[field];
                            break;
                        }
                    }
                }
                
                // Check nested reviewer object
                if (!reviewerAvatar && review.reviewer && typeof review.reviewer === 'object') {
                    for (const field of avatarFields) {
                        if (review.reviewer[field] && typeof review.reviewer[field] === 'string') {
                            reviewerAvatar = review.reviewer[field];
                            break;
                        }
                    }
                }
                
                // Check nested author object
                if (!reviewerAvatar && review.author && typeof review.author === 'object') {
                    for (const field of avatarFields) {
                        if (review.author[field] && typeof review.author[field] === 'string') {
                            reviewerAvatar = review.author[field];
                            break;
                        }
                    }
                }
                
                // Check nested user object
                if (!reviewerAvatar && review.user && typeof review.user === 'object') {
                    for (const field of avatarFields) {
                        if (review.user[field] && typeof review.user[field] === 'string') {
                            reviewerAvatar = review.user[field];
                            break;
                        }
                    }
                }
                
                // Get initial for fallback avatar
                const reviewerInitial = reviewerName ? reviewerName.charAt(0).toUpperCase() : platform.charAt(0).toUpperCase();
                
                // Truncate review text
                const maxLength = 200;
                let displayText = reviewText;
                let showMoreBtn = false;
                if (reviewText.length > maxLength) {
                    displayText = reviewText.substring(0, maxLength) + '...';
                    showMoreBtn = true;
                }
                
                // Create stars HTML
                let starsHtml = '';
                for (let i = 0; i < 5; i++) {
                    starsHtml += `<span class="star ${i < rating ? 'filled' : ''}">★</span>`;
                }
                
                // Create avatar HTML
                const avatarHtml = reviewerAvatar 
                    ? `<img src="${reviewerAvatar.replace(/"/g, '&quot;')}" alt="${reviewerName.replace(/"/g, '&quot;')}" loading="lazy">`
                    : `<div class="reviewer-initial">${reviewerInitial}</div>`;
                
                // Create review card HTML
                const reviewCardHtml = `
                    <div class="review-card">
                        <div class="review-header">
                            <div class="reviewer-photo">
                                ${avatarHtml}
                            </div>
                            <div class="reviewer-info">
                                <div class="reviewer-name">${reviewerName.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</div>
                                <div class="reviewer-tenure">Guest Breezy</div>
                            </div>
                        </div>
                        <div class="review-rating">
                            ${starsHtml}
                        </div>
                        <div class="review-meta">
                            <span>${formattedDate}</span>
                            <span> • </span>
                            <span>Stayed a few nights</span>
                        </div>
                        <div class="review-text">
                            ${displayText.replace(/</g, '&lt;').replace(/>/g, '&gt;')}
                        </div>
                        ${showMoreBtn ? `<button class="show-more-review" onclick="toggleReviewFullText(this)" data-full-text="${reviewText.replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;')}">Show more</button>` : ''}
                    </div>
                `;
                
                reviewsGrid.insertAdjacentHTML('beforeend', reviewCardHtml);
            });
            
            // Update loaded count
            const newLoaded = loaded + loadCount;
            this.dataset.loaded = newLoaded;
            
            // Update button text or hide if all loaded
            if (newLoaded >= total) {
                this.remove();
            } else {
                const remaining = total - newLoaded;
                this.textContent = `Show ${Math.min(loadCount, remaining)} more reviews`;
                this.classList.remove('loading');
                this.disabled = false;
            }
        }, 300);
    });
}
<?php endif; ?>
</script>

<link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>

<!-- DateRangePicker for date picker -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css">
<script src="https://cdn.jsdelivr.net/npm/moment@2.29.4/moment.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>

<?php get_footer(); ?>