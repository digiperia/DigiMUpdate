jQuery(document).ready(function($) {
    'use strict';

    // Simple UI Builder functionality
    const UIBuilder = {
        previewTimeout: null,
        init: function() {
            this.bindEvents();
        },

        bindEvents: function() {
            // Layout style button selector
            $(document).on('click', '.cb-layout-btn', (event) => {
                const $btn = $(event.target).closest('.cb-layout-btn');
                const layout = $btn.data('layout');
                $('#digim_layout_style').val(layout);
                $('.cb-layout-btn').removeClass('active');
                $btn.addClass('active');
                
                // Show/hide grid columns control
                if (layout === 'list') {
                    $('#grid-columns-control').hide();
                } else {
                    $('#grid-columns-control').show();
                }
                this.debouncedPreview();
            });

            // Grid columns button selector
            $(document).on('click', '.cb-column-btn:not(.cb-layout-btn)', (event) => {
                const $btn = $(event.target).closest('.cb-column-btn');
                if ($btn.hasClass('cb-layout-btn')) return; // Skip if it's a layout button
                const cols = parseInt($btn.data('columns'), 10);
                $('#digim_grid_columns').val(cols);
                $('.cb-column-btn:not(.cb-layout-btn)').removeClass('active');
                $btn.addClass('active');
                this.debouncedPreview();
            });

            // Number input stepper buttons
            $(document).on('click', '.digim-number-increase', (event) => {
                const $input = $(event.target).closest('.digim-number-input-wrapper').find('.digim-number-input');
                const current = parseInt($input.val(), 10) || 1;
                const max = parseInt($input.attr('max'), 10) || 50;
                const newVal = Math.min(current + 1, max);
                $input.val(newVal).trigger('change');
                this.debouncedPreview();
            });

            $(document).on('click', '.digim-number-decrease', (event) => {
                const $input = $(event.target).closest('.digim-number-input-wrapper').find('.digim-number-input');
                const current = parseInt($input.val(), 10) || 1;
                const min = parseInt($input.attr('min'), 10) || 1;
                const newVal = Math.max(current - 1, min);
                $input.val(newVal).trigger('change');
                this.debouncedPreview();
            });

            // Cards per page input change
            $('#digim_cards_per_page').on('input change', () => {
                this.debouncedPreview();
            });

            // Color picker - update color value display
            $('#digim_primary_color').on('change', () => {
                const color = $('#digim_primary_color').val();
                $('.color-value').text(color);
                this.debouncedPreview();
            });

            // Feature checkboxes
            $('#digim_show_map, #digim_show_capacity, #digim_show_capacity_guests, #digim_show_capacity_bedrooms, #digim_show_capacity_beds, #digim_show_capacity_bathrooms').on('change', (event) => {
                if ($(event.target).is('#digim_show_capacity')) {
                    if ($('#digim_show_capacity').is(':checked')) {
                        $('#capacity-options').slideDown(200);
                    } else {
                        $('#capacity-options').slideUp(200);
                    }
                }
                this.debouncedPreview();
            });

            // Refresh preview
            $('#refresh-preview').on('click', () => {
                this.updatePreview();
            });

            // Form submission
            $('#ui-builder-form').on('submit', () => {
                this.showNotification('Saving settings...', 'info');
            });
        },

        debouncedPreview: function() {
            clearTimeout(this.previewTimeout);
            this.previewTimeout = setTimeout(() => {
                this.updatePreview();
            }, 300);
        },

        updatePreview: function() {
            const formData = this.getFormData();
            
            $.ajax({
                url: digim_ui_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'digim_update_preview',
                    nonce: digim_ui_ajax.nonce,
                    ...formData
                },
                success: (response) => {
                    if (response.success) {
                        $('#digim-preview').html(response.data.html);
                        this.showNotification('Preview updated', 'success');
                    } else {
                    }
                },
                error: () => {
                    this.showNotification('', 'error');
                }
            });
        },

        getFormData: function() {
            const formData = {};
            $('#ui-builder-form').find('input, select').each(function() {
                const $this = $(this);
                const name = $this.attr('name');
                const type = $this.attr('type');
                
                if (type === 'checkbox') {
                    formData[name] = $this.is(':checked') ? 1 : 0;
                } else {
                    formData[name] = $this.val();
                }
            });
            return formData;
        },

        showNotification: function(message, type) {
            // Create notification element
            const notification = $('<div class="ui-notification ' + type + '">' + message + '</div>');
            
            // Add to page
            $('body').append(notification);
            
            // Show notification
            setTimeout(() => notification.addClass('show'), 100);
            
            // Remove after 3 seconds
            setTimeout(() => {
                notification.removeClass('show');
                setTimeout(() => notification.remove(), 300);
            }, 3000);
        }
    };

    // Initialize UI Builder
    UIBuilder.init();

    // Add notification styles
    $('<style>')
        .prop('type', 'text/css')
        .html(`
            .ui-notification {
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 12px 20px;
                border-radius: 4px;
                color: white;
                font-weight: 500;
                z-index: 10000;
                transform: translateX(100%);
                transition: transform 0.3s ease;
            }
            
            .ui-notification.show {
                transform: translateX(0);
            }
            
            .ui-notification.success {
                background: #46b450;
            }
            
            .ui-notification.error {
                background: #dc3232;
            }
            
            .ui-notification.info {
                background: #0073aa;
            }
        `)
        .appendTo('head');
});
  