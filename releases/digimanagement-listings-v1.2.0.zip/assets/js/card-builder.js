jQuery(function($){
	'use strict';

	const state = {
		all: [], // all properties
		filtered: [],
		selected: [], // array of uuids
		map: new Map(),
		loading: false,
	};

	const els = {
		available: $('#cb_available'),
		selected: $('#cb_selected'),
		search: $('#cb_search'),
		add: $('#cb_add'),
		remove: $('#cb_remove'),
		save: $('#cb_save'),
		refresh: $('#cb_refresh'),
		title: $('#cb_title'),
		slider: $('#cb_slider'),
		columns: $('#cb_columns'),
		shortcode: $('#cb_shortcode'),
		id: $('#cb_id'),
		preview: $('#cb_preview'),
		selector: $('#cb_set_selector'),
		deleteBtn: $('#cb_delete'),
	};

	function renderAvailable(){
		const term = (els.search.val() || '').toLowerCase();
		els.available.empty();
		state.filtered = state.all.filter(p => {
			if (!term) return true;
			return (p.name||'').toLowerCase().includes(term) || (p.city||'').toLowerCase().includes(term);
		}).filter(p => !state.selected.includes(p.uuid));
		if (state.filtered.length === 0) {
			els.available.append('<li class="cb-empty-state">No properties available</li>');
		} else {
			state.filtered.forEach(p => els.available.append(rowHtml(p)));
		}
	}

	function renderSelected(){
		els.selected.empty();
		if (state.selected.length === 0) {
			els.selected.append('<li class="cb-empty-state">No properties selected</li>');
		} else {
			state.selected.forEach(uuid => {
				const p = state.map.get(uuid);
				if (p) els.selected.append(rowHtml(p));
			});
		}
		wireDnD();
	}

	function rowHtml(p){
		const $li = $('<li draggable="true" data-uuid="'+(p.uuid||'')+'">\
			<div class="thumb">'+(p.picture?('<img src="'+p.picture+'" alt="" />'):'')+'</div>\
			<div class="meta">\
				<span class="name">'+(p.name||'')+'</span>\
				<span class="city">'+(p.city||'')+'</span>\
			</div>\
		</li>');
		$li.on('click', function(){ $(this).toggleClass('selected'); });
		return $li;
	}

	function move(from, to){
		const $src = from.find('li.selected');
		$src.each(function(){
			const uuid = $(this).data('uuid');
			if (from.is(els.available)){
				if (!state.selected.includes(uuid)) state.selected.push(uuid);
			}else{
				state.selected = state.selected.filter(u => u !== uuid);
			}
		});
		renderAvailable();
		renderSelected();
	debouncedPreview();
	}

	function wireDnD(){
		const list = els.selected[0];
		let dragEl = null;
		if (!list) return;
		list.querySelectorAll('li').forEach(li => {
			li.addEventListener('dragstart', e => {
				dragEl = li; li.classList.add('dragging');
				e.dataTransfer.effectAllowed = 'move';
			});
			li.addEventListener('dragend', () => { li.classList.remove('dragging'); dragEl = null; saveOrderFromDOM(); });
		});
		list.addEventListener('dragover', e => {
			e.preventDefault();
			const after = getDragAfterElement(list, e.clientY);
			if (after == null) list.appendChild(dragEl); else list.insertBefore(dragEl, after);
		});
	}

	function getDragAfterElement(container, y){
		const els = [...container.querySelectorAll('li:not(.dragging)')];
		return els.reduce((closest, child) => {
			const box = child.getBoundingClientRect();
			const offset = y - box.top - box.height / 2;
			if (offset < 0 && offset > closest.offset) return { offset, element: child };
			else return closest;
		}, { offset: Number.NEGATIVE_INFINITY }).element;
	}

	function saveOrderFromDOM(){
		const uuids = els.selected.find('li').map(function(){ return $(this).data('uuid'); }).get();
		state.selected = uuids;
	debouncedPreview();
	}

	function fetchAll(){
		state.loading = true;
		$.post(digimCardBuilder.ajax_url, { action: 'digim_fetch_properties', nonce: digimCardBuilder.nonce }, function(resp){
			state.loading = false;
			if (!resp || !resp.success) {
				els.available.empty();
				els.available.append('<li class="cb-error-state">Error loading properties. Please try again.</li>');
				return;
			}
			state.all = resp.data.properties || [];
			state.map = new Map(state.all.map(p => [p.uuid, p]));
			// Load selected from current set if present
			const setId = els.id.val();
			if (setId && digimCardBuilder.sets && digimCardBuilder.sets[setId]){
				state.selected = (digimCardBuilder.sets[setId].selected||[]).filter(u => state.map.has(u));
			}
			renderAvailable();
			renderSelected();
		}).fail(function(){
			state.loading = false;
			els.available.empty();
			els.available.append('<li class="cb-error-state">Error loading properties. Please refresh the page.</li>');
		});
	}

	function saveSet(){
		els.save.prop('disabled', true);
		$.post(digimCardBuilder.ajax_url, {
			action: 'digim_save_card_set',
			nonce: digimCardBuilder.nonce,
			title: els.title.val(),
			selected: state.selected,
			slider: els.slider.is(':checked') ? 1 : 0,
			columns: els.columns.val(),
			id: els.id.val()
		}, function(resp){
			els.save.prop('disabled', false);
			if (!resp || !resp.success) {
				alert('Error saving set. Please try again.');
				return;
			}
			els.id.val(resp.data.id);
			els.shortcode.val(resp.data.shortcode);
			els.deleteBtn.prop('disabled', false);
			// Keep URL with set id for easy editing next time
			const url = new URL(window.location.href);
			url.searchParams.set('set', resp.data.id);
			history.replaceState({}, '', url.toString());
			// Update in-memory registry and dropdown
			if (!window.digimCardBuilder.sets) window.digimCardBuilder.sets = {};
			window.digimCardBuilder.sets[resp.data.id] = {
				id: resp.data.id,
				title: els.title.val(),
				selected: state.selected.slice(),
				slider: els.slider.is(':checked') ? 1 : 0,
				columns: parseInt(els.columns.val()||3, 10)
			};
			if (els.selector.length) {
				const exists = els.selector.find('option[value="'+resp.data.id+'"]').length > 0;
				if (!exists) {
					els.selector.append('<option value="'+resp.data.id+'">'+(els.title.val()||resp.data.id)+'</option>');
				} else {
					els.selector.find('option[value="'+resp.data.id+'"]').text(els.title.val()||resp.data.id);
				}
				els.selector.val(resp.data.id);
			}
			refreshPreview();
		});
	}

	function refreshPreview(){
		els.preview.html('<div class="cb-preview-loading"><span class="spinner is-active"></span> ' + (digimCardBuilder.strings.loading || 'Loading…') + '</div>');
		const payload = {
			action: 'digim_preview_card_set',
			nonce: digimCardBuilder.nonce,
			selected: state.selected,
			slider: els.slider.is(':checked') ? 1 : 0,
			columns: els.columns.val()
		};
		$.post(digimCardBuilder.ajax_url, payload, function(resp){
			if (!resp || !resp.success) {
				els.preview.html('<div class="cb-preview-error">Error loading preview. Please try again.</div>');
				return;
			}
			// Extract and handle script tags separately
			const html = resp.data.html;
			const $temp = $('<div>').html(html);
			const scripts = $temp.find('script');
			const styles = $temp.find('style');
			const content = $temp.clone();
			content.find('script').remove();
			content.find('style').remove();
			
			els.preview.html(content.html());
			
			// Append styles
			styles.each(function(){
				if (!$(this).attr('id') || !$('#cb-preview-' + $(this).attr('id')).length) {
					const $style = $(this).clone();
					if ($(this).attr('id')) {
						$style.attr('id', 'cb-preview-' + $(this).attr('id'));
					}
					$('head').append($style);
				}
			});
			
			// Initialize Swiper if slider is enabled
			setTimeout(function(){
				if (els.slider.is(':checked')) {
					if (window.Swiper) {
						els.preview.find('.swiper').each(function(){
							const $swiper = $(this);
							const swiperId = $swiper.attr('id');
							if (swiperId && !$swiper.data('swiper-initialized')) {
								try {
									// Destroy existing instance if any
									if ($swiper[0].swiper) {
										$swiper[0].swiper.destroy(true, true);
									}
									new Swiper('#' + swiperId, {
										spaceBetween: 16,
										loop: false,
										pagination: { 
											el: '#' + swiperId + ' .swiper-pagination', 
											clickable: true 
										},
										navigation: { 
											nextEl: '#' + swiperId + ' .digim-swiper-next', 
											prevEl: '#' + swiperId + ' .digim-swiper-prev' 
										},
										breakpoints: {
											320: { slidesPerView: 1 },
											640: { slidesPerView: 2 },
											960: { slidesPerView: Math.max(2, Math.min(4, parseInt(els.columns.val() || 3, 10))) },
										}
									});
									$swiper.data('swiper-initialized', true);
								} catch(e) {
									console.error('Swiper initialization error:', e);
								}
							}
						});
					} else {
						console.warn('Swiper library not loaded. Please refresh the page.');
					}
				}
			}, 150);
		}).fail(function(){
			els.preview.html('<div class="cb-preview-error">Failed to load preview. Please refresh the page.</div>');
		});
	}

const debouncedPreview = debounce(refreshPreview, 250);

function debounce(fn, wait){
	let t; return function(){ clearTimeout(t); t = setTimeout(fn, wait); };
}

	// Grid columns button selector
	$(document).on('click', '.cb-column-btn', function(){
		const $btn = $(this);
		const cols = parseInt($btn.data('columns'), 10);
		els.columns.val(cols);
		$('.cb-column-btn').removeClass('active');
		$btn.addClass('active');
		debouncedPreview();
	});

	// Events
	els.add.on('click', () => move(els.available, els.selected));
	els.remove.on('click', () => move(els.selected, els.available));
	els.search.on('input', renderAvailable);
	els.save.on('click', saveSet);
	els.refresh.on('click', refreshPreview);
	els.slider.on('change', debouncedPreview);
els.selector.on('change', function(){
	const val = $(this).val();
	if (!val) return;
	window.location.href = window.location.pathname + '?page=DigiM-cards&set=' + encodeURIComponent(val);
});

// Delete current set
els.deleteBtn.on('click', function(){
	const id = els.id.val();
	if (!id) return;
	if (!confirm('Delete this set? This cannot be undone.')) return;
	$.post(digimCardBuilder.ajax_url, { action:'digim_delete_card_set', nonce: digimCardBuilder.nonce, id }, function(resp){
		if (!resp || !resp.success) return;
		// Remove from dropdown and list
		els.selector.find('option[value="'+id+'"]').remove();
		$('.cb-saved-sets li[data-id="'+id+'"]').remove();
		// Reset page to new set
		window.location.href = window.location.pathname + '?page=DigiM-cards';
	});
});

// Delete from saved sets list
$(document).on('click', '.cb-delete-item', function(){
	const $li = $(this).closest('li[data-id]');
	const id = $li.data('id');
	if (!id) return;
	if (!confirm('Delete this set? This cannot be undone.')) return;
	$.post(digimCardBuilder.ajax_url, { action:'digim_delete_card_set', nonce: digimCardBuilder.nonce, id }, function(resp){
		if (!resp || !resp.success) return;
		els.selector.find('option[value="'+id+'"]').remove();
		$li.remove();
		if (els.id.val() === id) {
			window.location.href = window.location.pathname + '?page=DigiM-cards';
		}
	});
});

	// Copy shortcode functionality
	$(document).on('click', '.cb-copy-shortcode', function(){
		const shortcode = els.shortcode.val();
		if (!shortcode) return;
		const $btn = $(this);
		const original = $btn.html();
		if (navigator.clipboard && navigator.clipboard.writeText) {
			navigator.clipboard.writeText(shortcode).then(function(){
				$btn.html('<span class="dashicons dashicons-yes"></span>');
				$btn.css('background', '#46b450');
				$btn.css('color', '#fff');
				setTimeout(function(){
					$btn.html(original);
					$btn.css('background', '');
					$btn.css('color', '');
				}, 2000);
			}).catch(function(){
				alert('Failed to copy shortcode. Please select and copy manually.');
			});
		} else {
			// Fallback for older browsers
			els.shortcode.select();
			document.execCommand('copy');
			$btn.html('<span class="dashicons dashicons-yes"></span>');
			$btn.css('background', '#46b450');
			$btn.css('color', '#fff');
			setTimeout(function(){
				$btn.html(original);
				$btn.css('background', '');
				$btn.css('color', '');
			}, 2000);
		}
	});

	// Init
	fetchAll();
	const initialId = els.id.val();
	if (initialId) {
		els.shortcode.val('[digim_cards id="'+initialId+'"]');
	}
	refreshPreview();
});


