<?php

/**
 * Plugin Name: DigiM
 * Plugin URI: https://digiperia.com
 * Description: A professional WordPress plugin that integrates with Hospitable API to display property listings with flexible shortcode parameters.
 * Version: 1.2.1
 * Author: Digiperia
 * Author URI: https://digiperia.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wml-hospitable
 * Domain Path: /languages
 * Requires at least: 5.0
 * Tested up to: 6.5.3
 * Requires PHP: 7.4
 * Network: false
 */

// === Plugin Path Constant ===
define('DIGIMANAGEMENT_PLUGIN_PATH', plugin_dir_path(__FILE__));

require_once __DIR__ . '/plugin-update-checker/plugin-update-checker.php';

use YahnisElsts\PluginUpdateChecker\v5p6\PucFactory;

$myUpdateChecker = PucFactory::buildUpdateChecker(
  'https://raw.githubusercontent.com/digiperia/DigiMUpdate/main/digim-plugin-update.json',
  __FILE__,
  'digimanagement-listings'
);



// === Admin-only CSS (load everywhere in admin first; scope later once IDs known) ===
add_action('admin_enqueue_scripts', function () {
  $admin_css_path = plugin_dir_path(__FILE__) . 'assets/css/admin.css';
  if (!file_exists($admin_css_path)) {
    error_log('DigiM admin.css not found at: ' . $admin_css_path);
    return;
  }
  wp_enqueue_style(
    'digim-admin',
    plugin_dir_url(__FILE__) . 'assets/css/admin.css',
    [],
    filemtime($admin_css_path)
  );
});




// === Admin Pages ===
if (is_admin()) {
  require_once DIGIMANAGEMENT_PLUGIN_PATH . 'admin/menu.php';
  require_once DIGIMANAGEMENT_PLUGIN_PATH . 'admin/admin-settings.php';
}

// === Frontend Shortcode ===
require_once DIGIMANAGEMENT_PLUGIN_PATH . 'includes/shortcode.php';


// === Enqueue Plugin Styles & Scripts ===
add_action('wp_enqueue_scripts', function () {
  global $post;
  
  // Check if we should load the styles and scripts
  $should_load = false;
  
  // Check if shortcode exists in post content
  if (isset($post) && has_shortcode($post->post_content, 'digimanagement_listings')) {
    $should_load = true;
  }
  
  // Check if we're on a page that might contain listings (like /listings/)
  if (is_page() && (strpos($_SERVER['REQUEST_URI'], '/listings') !== false || 
                   strpos($_SERVER['REQUEST_URI'], 'listings') !== false)) {
    $should_load = true;
  }
  
  // Check if we're on a property single page
  if (get_query_var('dm_property_uuid')) {
    $should_load = true;
  }
  
  // Check if the current page template or content contains digim classes
  if (isset($post) && (strpos($post->post_content, 'digim-main') !== false || 
                      strpos($post->post_content, 'digimanagement') !== false)) {
    $should_load = true;
  }
  
  // Fallback: Check if we're on any page that might need the plugin styles
  // This can be customized based on your specific needs
  $force_load_pages = ['listings', 'properties', 'search'];
  foreach ($force_load_pages as $page_slug) {
    if (is_page($page_slug) || strpos($_SERVER['REQUEST_URI'], $page_slug) !== false) {
      $should_load = true;
      break;
    }
  }
  
  if (!$should_load) return;

  // ✅ Leaflet CSS & JS
  wp_enqueue_style('leaflet', 'https://unpkg.com/leaflet/dist/leaflet.css');
  wp_enqueue_script('leaflet', 'https://unpkg.com/leaflet/dist/leaflet.js', [], null, true);

  // ✅ Leaflet Marker Cluster
  wp_enqueue_style('leaflet-cluster', 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css');
  wp_enqueue_script('leaflet-cluster', 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js', ['leaflet'], null, true);

  // ✅ Plugin Styles (ensure loaded after Leaflet to override)
  $style_path = plugin_dir_path(__FILE__) . 'assets/css/style.css';
  if (file_exists($style_path)) {
    wp_enqueue_style(
      'digim-style',
      plugin_dir_url(__FILE__) . 'assets/css/style.css',
      [],
      filemtime($style_path)
    );
  }

  // ✅ Plugin Frontend JS (map logic, interactivity)
  $js_path = plugin_dir_path(__FILE__) . 'assets/js/frontend.js';
  if (file_exists($js_path)) {
    wp_enqueue_script(
      'digim-frontend',
      plugin_dir_url(__FILE__) . 'assets/js/frontend.js',
      ['jquery', 'leaflet', 'leaflet-cluster'],
      filemtime($js_path),
      true
    );
  }
});


// === Property Context (for SEO/meta) === //
$GLOBALS['digimanagement_current_property_context'] = null;

function digimanagement_set_current_property_context($property = null, $identifier = null)
{
  if (!$property || !is_array($property)) {
    $GLOBALS['digimanagement_current_property_context'] = null;
    return;
  }

  $GLOBALS['digimanagement_current_property_context'] = [
    'property'    => $property,
    'identifier'  => $identifier,
    'permalink'   => home_url('/property/' . rawurlencode($identifier ?? ($property['uuid'] ?? '')) . '/'),
  ];
}

function digimanagement_get_current_property_context()
{
  return $GLOBALS['digimanagement_current_property_context'] ?? null;
}

if (!function_exists('digim_get_nested_value')) {
  /**
   * Safely get a nested value from an array using an ordered list of keys.
   *
   * @param array<string,mixed> $source
   * @param array<int,string>   $path
   * @return mixed|null
   */
  function digim_get_nested_value($source, $path)
  {
    $value = $source;

    foreach ($path as $segment) {
      if (!is_array($value) || !array_key_exists($segment, $value)) {
        return null;
      }

      $value = $value[$segment];
    }

    return $value;
  }
}

if (!function_exists('digim_normalize_description_text')) {
  /**
   * Normalize description content into a clean, plain-text string.
   */
  function digim_normalize_description_text($text)
  {
    if (!is_string($text)) {
      return '';
    }

    $normalized = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $normalized = preg_replace('/<\s*br\s*\/?>/i', "\n", $normalized);
    $normalized = preg_replace('/<\/\s*p\s*>/i', "\n\n", $normalized);
    $normalized = preg_replace('/<\/\s*li\s*>/i', "\n", $normalized);
    $normalized = preg_replace('/<\s*\/?(ul|ol)\s*>/i', "\n", $normalized);
    $normalized = wp_strip_all_tags($normalized);
    $normalized = preg_replace("/\r\n?/", "\n", $normalized);
    $normalized = preg_replace("/\n{3,}/", "\n\n", $normalized);

    return trim($normalized);
  }
}

if (!function_exists('digim_get_property_description')) {
  /**
   * Extract the best available description text from a property payload.
   *
   * Handles multiple potential field shapes returned by the Hospitable API.
   *
   * @param array<string,mixed>|null $property
   */
  function digim_get_property_description($property)
  {
    if (!is_array($property)) {
      return '';
    }

    $candidates = [];

    $addCandidate = function ($value) use (&$candidates, &$addCandidate) {
      if (is_string($value)) {
        $normalized = digim_normalize_description_text($value);
        if ($normalized !== '' && !in_array($normalized, $candidates, true)) {
          $candidates[] = $normalized;
        }
        return;
      }

      if (!is_array($value)) {
        return;
      }

      $priorityKeys = [
        'plain_text',
        'text',
        'description',
        'summary',
        'content',
        'value',
        'html',
        'markdown',
        'default',
      ];

      foreach ($priorityKeys as $key) {
        if (isset($value[$key])) {
          $addCandidate($value[$key]);
          if (!empty($candidates)) {
            return;
          }
        }
      }

      if (isset($value['translations']) && is_array($value['translations'])) {
        foreach (['en-US', 'en_us', 'en-US', 'en', 'default'] as $localeKey) {
          if (isset($value['translations'][$localeKey])) {
            $addCandidate($value['translations'][$localeKey]);
            if (!empty($candidates)) {
              return;
            }
          }
        }
      }

      foreach ($value as $item) {
        $addCandidate($item);
        if (!empty($candidates)) {
          return;
        }
      }
    };

    $paths = [
      ['description'],
      ['summary'],
      ['public_description'],
      ['description_plain_text'],
      ['description_text'],
      ['description_html'],
      ['summary_html'],
      ['public_summary'],
      ['details', 'description'],
      ['details', 'summary'],
      ['content', 'description'],
      ['content', 'summary'],
      ['content', 'space'],
      ['content', 'the_space'],
      ['body', 'description'],
    ];

    foreach ($paths as $path) {
      $value = digim_get_nested_value($property, $path);
      if ($value !== null) {
        $addCandidate($value);
      }
      if (!empty($candidates)) {
        break;
      }
    }

    if (empty($candidates)) {
      foreach ($property as $key => $value) {
        if (is_string($key) && stripos($key, 'description') !== false) {
          $addCandidate($value);
        }
        if (!empty($candidates)) {
          break;
        }
      }
    }

    return $candidates[0] ?? '';
  }
}

function digimanagement_build_property_seo_title($property)
{
  $name = trim($property['name'] ?? '');
  if (!$name) {
    return null;
  }

  $city    = trim($property['address']['city'] ?? '');
  $state   = trim($property['address']['state'] ?? '');
  $country = trim($property['address']['country'] ?? '');

  $location_parts = array_filter([$city, $state ?: $country]);
  if (!empty($location_parts)) {
    return sprintf('%s | %s', $name, implode(', ', $location_parts));
  }

  return $name;
}

function digimanagement_build_property_seo_description($property)
{
  $description = digim_get_property_description($property);
  $description = preg_replace('/\s+/', ' ', (string) $description);
  $description = trim($description);

  if (!$description) {
    $beds     = $property['bedrooms'] ?? null;
    $baths    = $property['bathrooms'] ?? null;
    $guests   = $property['occupancy'] ?? $property['max_guests'] ?? null;
    $location = trim(($property['address']['city'] ?? '') . ', ' . ($property['address']['state'] ?? ''));

    $parts = [];
    if ($beds) {
      $parts[] = sprintf('%s bedroom%s', $beds, intval($beds) === 1 ? '' : 's');
    }
    if ($baths) {
      $parts[] = sprintf('%s bath%s', $baths, intval($baths) === 1 ? '' : 's');
    }
    if ($guests) {
      $parts[] = sprintf('Sleeps %s', $guests);
    }
    if ($location) {
      $parts[] = $location;
    }

    $description = implode(' • ', array_filter($parts));
  }

  if (!$description) {
    return null;
  }

  return wp_trim_words($description, 35, '…');
}

add_filter('pre_get_document_title', function ($title) {
  $context = digimanagement_get_current_property_context();
  if (!$context) {
    return $title;
  }

  $seo_title = digimanagement_build_property_seo_title($context['property']);
  return $seo_title ?: $title;
}, 20);

add_filter('document_title_parts', function ($parts) {
  $context = digimanagement_get_current_property_context();
  if (!$context) {
    return $parts;
  }

  $seo_title = digimanagement_build_property_seo_title($context['property']);
  if ($seo_title) {
    $parts['title'] = $seo_title;
  }

  return $parts;
}, 20);

add_filter('wpseo_title', function ($title) {
  $context = digimanagement_get_current_property_context();
  if (!$context) {
    return $title;
  }

  $seo_title = digimanagement_build_property_seo_title($context['property']);
  return $seo_title ?: $title;
}, 20, 1);

add_filter('rank_math/frontend/title', function ($title) {
  $context = digimanagement_get_current_property_context();
  if (!$context) {
    return $title;
  }

  $seo_title = digimanagement_build_property_seo_title($context['property']);
  return $seo_title ?: $title;
}, 20, 1);

add_filter('wpseo_metadesc', function ($description) {
  $context = digimanagement_get_current_property_context();
  if (!$context) {
    return $description;
  }

  $seo_description = digimanagement_build_property_seo_description($context['property']);
  return $seo_description ?: $description;
}, 20, 1);

add_filter('rank_math/frontend/description', function ($description) {
  $context = digimanagement_get_current_property_context();
  if (!$context) {
    return $description;
  }

  $seo_description = digimanagement_build_property_seo_description($context['property']);
  return $seo_description ?: $description;
}, 20, 1);

add_filter('wpseo_canonical', function ($canonical) {
  $context = digimanagement_get_current_property_context();
  if (!$context) {
    return $canonical;
  }

  return $context['permalink'] ?? $canonical;
}, 20, 1);

add_filter('rank_math/frontend/canonical', function ($canonical) {
  $context = digimanagement_get_current_property_context();
  if (!$context) {
    return $canonical;
  }

  return $context['permalink'] ?? $canonical;
}, 20, 1);

add_action('wp_head', function () {
  $context = digimanagement_get_current_property_context();
  if (!$context) {
    return;
  }

  global $wp;

  $property = $context['property'];
  $seo_title = digimanagement_build_property_seo_title($property);
  $seo_description = digimanagement_build_property_seo_description($property);
  $permalink = $context['permalink'] ?? home_url(isset($wp) && isset($wp->request) ? $wp->request : '');
  $image = '';

  if (!empty($property['images']) && is_array($property['images'])) {
    $first_image = $property['images'][0];
    if (is_array($first_image)) {
      $image = $first_image['url'] ?? $first_image['original_url'] ?? '';
      if (!$image && isset($first_image[0]) && is_string($first_image[0])) {
        $image = $first_image[0];
      }
    } elseif (is_string($first_image)) {
      $image = $first_image;
    }
  } elseif (!empty($property['image'])) {
    $image = $property['image'];
  }

  if ($seo_description) {
    echo '<meta name="description" content="' . esc_attr($seo_description) . '">' . PHP_EOL;
  }

  if ($seo_title) {
    echo '<meta property="og:title" content="' . esc_attr($seo_title) . '">' . PHP_EOL;
    echo '<meta name="twitter:title" content="' . esc_attr($seo_title) . '">' . PHP_EOL;
  }

  if ($seo_description) {
    echo '<meta property="og:description" content="' . esc_attr($seo_description) . '">' . PHP_EOL;
    echo '<meta name="twitter:description" content="' . esc_attr($seo_description) . '">' . PHP_EOL;
  }

  echo '<meta property="og:type" content="article">' . PHP_EOL;
  echo '<meta property="og:url" content="' . esc_url($permalink) . '">' . PHP_EOL;
  if (!defined('WPSEO_VERSION') && !defined('RANK_MATH_VERSION')) {
    echo '<link rel="canonical" href="' . esc_url($permalink) . '">' . PHP_EOL;
  }

  if ($image) {
    echo '<meta property="og:image" content="' . esc_url($image) . '">' . PHP_EOL;
    echo '<meta name="twitter:card" content="summary_large_image">' . PHP_EOL;
    echo '<meta name="twitter:image" content="' . esc_url($image) . '">' . PHP_EOL;
  }
}, 5);

function digimanagement_get_api_url()
{
  return trim(get_option('digimanagement_api_url', 'https://public.api.hospitable.com/v2'));
}

function digimanagement_get_api_token()
{
  $token = trim(get_option('digimanagement_api_key', ''));
  
  // If no token is stored, use the hardcoded one temporarily
  if (empty($token)) {
    $token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiI5YTYyNGRmMC0xMmYxLTQ0OGUtYjg4NC00MzY3ODBhNWQzY2QiLCJqdGkiOiI1MmI3YmVhOTc1YWExZTViODYzMDAyNjg4ODI3MTM0MTNkNjRmMzhlN2UwZDZiZGFkNGVkMTczYTNmMTExYzllNjZjMTQ4ZTNmODI2YWM4YSIsImlhdCI6MTc1MDI1MDc0Ni4yODAyMTEsIm5iZiI6MTc1MDI1MDc0Ni4yODAyMTMsImV4cCI6MTc4MTc4Njc0Ni4yNzY2Nywic3ViIjoiMTU1NDQ2Iiwic2NvcGVzIjpbInBhdDpyZWFkIiwicGF0OndyaXRlIl19.I5iiT2U-EoxxI3ek9KsLstoYujqZrunlkNjIEdOS2XakLYX5yeL1813wyxYKqK0ad1ZXMGkSe1En9g-tUkjGukRG0yLSxSDpSmo4S-xh8zsZcgNf2MvTwIJn4_Y4aHWV-F6L6-3uwEAGPp6ypjEJyaqiWHE-4vnxUdKfNQTh9HnLTxvsqiHRZpl5fOyvFZFpDu5-oeUQvTK55_8uMyLMVg4jgmjPpwpg1Oqmnpz-0Art01KqdtAe5eShrRQvQzd8D-8E4GHwoXplVuwp-C-P9ZCrfYlkCinCHuRZCw4TiVqfkEF-KwQ8VxmOjnVsuxuA-kzSAEkg9p2J0a97KdqyuWkFqVtbFqn0sa5ZN91rPkvJ-kEvlgjvhfbcVMkDkVDOxV04MdxqkuDYgULKDOkt03V7n7VtXkccQDU3iDEF0H8QvdnPZc2eFO85TMociRVX8TTGdtz-y8tQMDiLCL8IItWCXBzmmEeDfrAwUo7MTmw2fk9_VKVw-tp8KLeBQZlrKQ641X4afOAm0oBWmLh-NyoP9ojU_U5cLkeroek_JAJTDfQ0u7jg22_ZqQZvlmkpJbuawICP0KlqDYaoUFPaRiJOK2CsfOBdHWPlobqtnzpyd82L62h8lnqysMsJLll6_OmDuqGyI8nOxXoa7T-w6N4fBF_L6kdpmDAVEnJhLvY';
    error_log("Using hardcoded token - stored token is empty");
  }
  
  return 'Bearer ' . $token;
}

// Debug function to test API response for a specific property
function digimanagement_debug_property_api($property_uuid) {
    error_log("=== DEBUGGING PROPERTY API FOR UUID: $property_uuid ===");
    
    // Test 1: Get property details
    $property_url = digimanagement_get_api_url() . "/properties/$property_uuid";
    $property_response = wp_remote_get($property_url, [
        'headers' => [
            'Authorization' => digimanagement_get_api_token(),
            'Accept' => 'application/json',
        ],
        'timeout' => 15,
    ]);
    
    if (is_wp_error($property_response)) {
        error_log("Property API Error: " . $property_response->get_error_message());
        return;
    }
    
    $property_data = json_decode(wp_remote_retrieve_body($property_response), true);
    error_log("Property API Response Code: " . wp_remote_retrieve_response_code($property_response));
    error_log("Property API Response: " . wp_remote_retrieve_body($property_response));
    
    if ($property_data && isset($property_data['data'])) {
        $property = $property_data['data'];
        error_log("Property Name: " . ($property['name'] ?? 'N/A'));
        error_log("Property Fields: " . implode(', ', array_keys($property)));
        
        // Check for pricing fields
        if (isset($property['pricing'])) {
            error_log("Pricing Fields: " . implode(', ', array_keys($property['pricing'])));
            error_log("Pricing Data: " . print_r($property['pricing'], true));
        }
    }
    
    // Test 2: Get rates
    $rates_url = digimanagement_get_api_url() . "/properties/$property_uuid/rates";
    $rates_response = wp_remote_get($rates_url, [
        'headers' => [
            'Authorization' => digimanagement_get_api_token(),
            'Accept' => 'application/json',
        ],
        'timeout' => 15,
    ]);
    
    if (!is_wp_error($rates_response)) {
        error_log("Rates API Response Code: " . wp_remote_retrieve_response_code($rates_response));
        error_log("Rates API Response: " . wp_remote_retrieve_body($rates_response));
    }
    
    error_log("=== END DEBUGGING FOR UUID: $property_uuid ===");
}

// Test function to debug API responses
function digimanagement_test_api_ajax() {
    // Skip nonce verification for local testing
    error_log("Test API function called - skipping nonce verification for local testing");
    
    $property_uuid = sanitize_text_field($_POST['property_uuid'] ?? '');
    if (empty($property_uuid)) {
        wp_send_json_error('Property UUID required');
        return;
    }
    
    // Test property API - first test the working listings endpoint
    $listings_url = digimanagement_get_api_url() . "/properties?page=1";
    $listings_response = wp_remote_get($listings_url, [
        'headers' => [
            'Authorization' => digimanagement_get_api_token(),
            'Accept' => 'application/json',
            'Cache-Control' => 'no-cache',
            'Pragma' => 'no-cache',
        ],
        'timeout' => 15,
    ]);
    
    // Test specific property API
    $property_url = digimanagement_get_api_url() . "/properties/$property_uuid";
    $property_response = wp_remote_get($property_url, [
        'headers' => [
            'Authorization' => digimanagement_get_api_token(),
            'Accept' => 'application/json',
        ],
        'timeout' => 15,
    ]);
    
    $property_data = null;
    $property_response_body = '';
    if (!is_wp_error($property_response)) {
        $property_response_body = wp_remote_retrieve_body($property_response);
        $property_data = json_decode($property_response_body, true);
    } else {
        error_log("Property API Error: " . $property_response->get_error_message());
    }
    
    // Test rates API
    $rates_url = digimanagement_get_api_url() . "/properties/$property_uuid/rates";
    $rates_response = wp_remote_get($rates_url, [
        'headers' => [
            'Authorization' => digimanagement_get_api_token(),
            'Accept' => 'application/json',
        ],
        'timeout' => 15,
    ]);
    
    $rates_data = null;
    $rates_response_body = '';
    if (!is_wp_error($rates_response)) {
        $rates_response_body = wp_remote_retrieve_body($rates_response);
        $rates_data = json_decode($rates_response_body, true);
    } else {
        error_log("Rates API Error: " . $rates_response->get_error_message());
    }
    
    // Test quote API
    $quote_url = digimanagement_get_api_url() . "/properties/$property_uuid/quote";
    $quote_data = array(
        'checkin' => '2025-11-09',
        'checkout' => '2025-11-12',
        'adults' => 2,
        'children' => 0,
        'infants' => 0
    );
    
    $quote_response = wp_remote_post($quote_url, array(
        'headers' => array(
            'Authorization' => digimanagement_get_api_token(),
            'Accept' => 'application/json',
            'Content-Type' => 'application/json'
        ),
        'body' => json_encode($quote_data),
        'timeout' => 30
    ));
    
    $quote_data = null;
    $quote_response_body = '';
    if (!is_wp_error($quote_response)) {
        $quote_response_body = wp_remote_retrieve_body($quote_response);
        $quote_data = json_decode($quote_response_body, true);
    } else {
        error_log("Quote API Error: " . $quote_response->get_error_message());
    }
    
    // Test with hardcoded token to see if that works
    $test_token = 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiI5YTYyNGRmMC0xMmYxLTQ0OGUtYjg4NC00MzY3ODBhNWQzY2QiLCJqdGkiOiI1MmI3YmVhOTc1YWExZTViODYzMDAyNjg4ODI3MTM0MTNkNjRmMzhlN2UwZDZiZGFkNGVkMTczYTNmMTExYzllNjZjMTQ4ZTNmODI2YWM4YSIsImlhdCI6MTc1MDI1MDc0Ni4yODAyMTEsIm5iZiI6MTc1MDI1MDc0Ni4yODAyMTMsImV4cCI6MTc4MTc4Njc0Ni4yNzY2Nywic3ViIjoiMTU1NDQ2Iiwic2NvcGVzIjpbInBhdDpyZWFkIiwicGF0OndyaXRlIl19.I5iiT2U-EoxxI3ek9KsLstoYujqZrunlkNjIEdOS2XakLYX5yeL1813wyxYKqK0ad1ZXMGkSe1En9g-tUkjGukRG0yLSxSDpSmo4S-xh8zsZcgNf2MvTwIJn4_Y4aHWV-F6L6-3uwEAGPp6ypjEJyaqiWHE-4vnxUdKfNQTh9HnLTxvsqiHRZpl5fOyvFZFpDu5-oeUQvTK55_8uMyLMVg4jgmjPpwpg1Oqmnpz-0Art01KqdtAe5eShrRQvQzd8D-8E4GHwoXplVuwp-C-P9ZCrfYlkCinCHuRZCw4TiVqfkEF-KwQ8VxmOjnVsuxuA-kzSAEkg9p2J0a97KdqyuWkFqVtbFqn0sa5ZN91rPkvJ-kEvlgjvhfbcVMkDkVDOxV04MdxqkuDYgULKDOkt03V7n7VtXkccQDU3iDEF0H8QvdnPZc2eFO85TMociRVX8TTGdtz-y8tQMDiLCL8IItWCXBzmmEeDfrAwUo7MTmw2fk9_VKVw-tp8KLeBQZlrKQ641X4afOAm0oBWmLh-NyoP9ojU_U5cLkeroek_JAJTDfQ0u7jg22_ZqQZvlmkpJbuawICP0KlqDYaoUFPaRiJOK2CsfOBdHWPlobqtnzpyd82L62h8lnqysMsJLll6_OmDuqGyI8nOxXoa7T-w6N4fBF_L6kdpmDAVEnJhLvY';
    
    $test_response = wp_remote_get($property_url, [
        'headers' => [
            'Authorization' => $test_token,
            'Accept' => 'application/json',
        ],
        'timeout' => 15,
    ]);
    
    $test_response_body = '';
    if (!is_wp_error($test_response)) {
        $test_response_body = wp_remote_retrieve_body($test_response);
    }
    
    $listings_data = null;
    $listings_response_body = '';
    if (!is_wp_error($listings_response)) {
        $listings_response_body = wp_remote_retrieve_body($listings_response);
        $listings_data = json_decode($listings_response_body, true);
    }
    
    wp_send_json_success([
        'listings_test' => [
            'url' => $listings_url,
            'response_code' => wp_remote_retrieve_response_code($listings_response),
            'raw_response' => substr($listings_response_body, 0, 500),
            'is_error' => is_wp_error($listings_response),
            'data_count' => isset($listings_data['data']) ? count($listings_data['data']) : 0
        ],
        'property' => [
            'url' => $property_url,
            'response_code' => wp_remote_retrieve_response_code($property_response),
            'raw_response' => substr($property_response_body, 0, 500), // First 500 chars
            'data' => $property_data
        ],
        'rates' => [
            'url' => $rates_url,
            'response_code' => wp_remote_retrieve_response_code($rates_response),
            'raw_response' => substr($rates_response_body, 0, 500), // First 500 chars
            'data' => $rates_data
        ],
        'quote' => [
            'url' => $quote_url,
            'response_code' => wp_remote_retrieve_response_code($quote_response),
            'raw_response' => substr($quote_response_body, 0, 500), // First 500 chars
            'data' => $quote_data
        ],
        'test_with_hardcoded_token' => [
            'response_code' => wp_remote_retrieve_response_code($test_response),
            'raw_response' => substr($test_response_body, 0, 500),
            'is_error' => is_wp_error($test_response)
        ],
        'api_token' => digimanagement_get_api_token(),
        'api_url' => digimanagement_get_api_url(),
        'stored_token_option' => get_option('digimanagement_api_key', 'NOT_SET')
    ]);
}

// Simple test function
function digimanagement_simple_test_ajax() {
    wp_send_json_success([
        'message' => 'Simple test works!',
        'timestamp' => current_time('mysql'),
        'api_token' => digimanagement_get_api_token(),
        'api_url' => digimanagement_get_api_url()
    ]);
}


// === Slug Functions === //
function digimanagement_create_property_slug($property_name, $address = '') {
  // Create a slug from property name and address
  $slug = $property_name;
  if ($address) {
    $slug .= ' ' . $address;
  }
  
  // Convert to lowercase and replace spaces/special chars with hyphens
  $slug = strtolower($slug);
  $slug = preg_replace('/[^a-z0-9\s-]/', '', $slug);
  $slug = preg_replace('/[\s-]+/', '-', $slug);
  $slug = trim($slug, '-');
  
  // Limit length
  $slug = substr($slug, 0, 100);
  
  return $slug;
}

function digimanagement_get_property_by_slug($slug) {
  // Get all properties and find one with matching slug
  $all_properties = digim_get_all_properties();
  
  foreach ($all_properties as $property) {
    $property_slug = digimanagement_create_property_slug(
      $property['name'] ?? '', 
      $property['address']['city'] ?? ''
    );
    
    if ($property_slug === $slug) {
      return $property;
    }
  }
  
  return null;
}

function digimanagement_get_property_uuid_by_slug($slug) {
  $property = digimanagement_get_property_by_slug($slug);
  return $property ? ($property['uuid'] ?? $property['id'] ?? null) : null;
}

// Ajax UI BUILDER
add_action('wp_ajax_digim_preview_shortcode', function () {
  update_option('digim_layout_style', sanitize_text_field($_POST['layout']));
  update_option('digim_grid_columns', intval($_POST['columns']));

  echo do_shortcode('[digimanagement_listings]');
  wp_die();
});


// === Helper: Parallel Calendar Check === //
if (!function_exists('digim_calendar_day_is_available')) {
  function digim_calendar_day_is_available($day)
  {
    if (!is_array($day)) {
      return false;
    }

    $status = $day['status'] ?? [];

    if (array_key_exists('available', $status)) {
      $flag = $status['available'];
      if (is_bool($flag)) {
        return $flag;
      }
      if (is_string($flag)) {
        $normalized = strtolower($flag);
        if ($normalized === 'true' || $normalized === '1' || $normalized === 'yes') {
          return true;
        }
        if ($normalized === 'false' || $normalized === '0' || $normalized === 'no') {
          return false;
        }
      }
    }

    if (isset($status['state'])) {
      $state = strtolower((string)$status['state']);
      if (in_array($state, ['blocked', 'booked', 'unavailable', 'maintenance'], true)) {
        return false;
      }
    }

    if (isset($status['type'])) {
      $type = strtolower((string)$status['type']);
      if (in_array($type, ['blocked', 'booked', 'unavailable', 'maintenance'], true)) {
        return false;
      }
    }

    return true;
  }
}

function digimanagement_parallel_calendar_check($uuids, $checkin, $checkout)
{
  if (empty($uuids)) {
    return [];
  }

  // Ensure UUIDs are unique, non-empty strings
  $uuids = array_values(array_filter(
    array_unique(array_map(function ($uuid) {
      $uuid = is_null($uuid) ? '' : trim((string) $uuid);
      return $uuid !== '' ? $uuid : null;
    }, $uuids)),
    function ($uuid) {
      return $uuid !== null && $uuid !== '';
    }
  ));

  if (empty($uuids)) {
    return [];
  }

  global $digim_next_available_suggestions;
  global $digim_min_nights_required;
  $digim_next_available_suggestions = [];
  $digim_min_nights_required = [];

  $requested_nights = max(1, (int) floor((strtotime($checkout) - strtotime($checkin)) / DAY_IN_SECONDS));
  $requested_nights = max(1, $requested_nights);

  $search_window_days = max(30, (int) apply_filters('digim_next_available_search_window_days', 90, $checkin, $checkout));
  $search_end_timestamp = max(strtotime($checkout), strtotime('+' . $search_window_days . ' days', strtotime($checkin)));
  $search_end_date = date('Y-m-d', $search_end_timestamp);

  $cached_available = [];
  $pending_uuids = [];
  $cache_ttl = intval(apply_filters('digim_availability_cache_ttl', 5 * MINUTE_IN_SECONDS, $checkin, $checkout));
  $cache_ttl = $cache_ttl > 0 ? $cache_ttl : 300;

  foreach ($uuids as $uuid) {
    $cache_key = 'digim_availability_' . md5($uuid . '|' . $checkin . '|' . $checkout);
    $suggestion_cache_key = 'digim_next_available_' . md5($uuid . '|' . $checkin . '|' . $checkout);
    $min_nights_cache_key = 'digim_min_nights_' . md5($uuid . '|' . $checkin . '|' . $checkout);
    $cached = get_transient($cache_key);
    $cached_suggestion = get_transient($suggestion_cache_key);
    $cached_min_nights = get_transient($min_nights_cache_key);

    if ($cached === 'available') {
      $cached_available[$uuid] = true;
      if ($cached_suggestion === 'none') {
        $digim_next_available_suggestions[$uuid] = null;
      } elseif ($cached_suggestion !== false) {
        $digim_next_available_suggestions[$uuid] = $cached_suggestion;
      }
    } elseif ($cached === 'unavailable') {
      // Check for cached minimum nights requirement
      if ($cached_min_nights !== false && is_numeric($cached_min_nights)) {
        $requested_nights = max(1, (int) floor((strtotime($checkout) - strtotime($checkin)) / DAY_IN_SECONDS));
        if ($requested_nights < (int)$cached_min_nights) {
          $digim_min_nights_required[$uuid] = (int)$cached_min_nights;
        }
      }
      
      if ($cached_suggestion !== false) {
        $digim_next_available_suggestions[$uuid] = $cached_suggestion === 'none' ? null : $cached_suggestion;
      } else {
        // Still need to check this property
        $pending_uuids[] = $uuid;
      }
    } else {
      $pending_uuids[] = $uuid;
    }
  }

  // If every UUID was cached as available and we have no pending calls, return early.
  // But we still need to return minimum nights data if any
  if (empty($pending_uuids)) {
    // Return available UUIDs - minimum nights data is already in global $digim_min_nights_required
    return array_keys($cached_available);
  }

  $query_end_date = $search_end_date;

  $mh = curl_multi_init();
  $handles = [];
  $results = [];

  foreach ($pending_uuids as $uuid) {
    $query_args = http_build_query([
      'start_date' => $checkin,
      'end_date'   => $query_end_date,
    ]);
    $url = digimanagement_get_api_url() . "/properties/$uuid/calendar?$query_args";
    $ch = curl_init();
    curl_setopt_array($ch, [
      CURLOPT_URL => $url,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_HTTPHEADER => [
        'Authorization: ' . digimanagement_get_api_token(),
        'Accept: application/json',
        'Cache-Control: no-cache',
        'Pragma: no-cache',
      ],
      CURLOPT_TIMEOUT => 10,
    ]);
    curl_multi_add_handle($mh, $ch);
    $handles[$uuid] = $ch;
  }

  if (!empty($handles)) {
    do {
      $status = curl_multi_exec($mh, $active);
      if ($active) {
        curl_multi_select($mh, 1.0);
      }
    } while ($active && $status === CURLM_OK);
  }

  $available_map = $cached_available;

  foreach ($handles as $uuid => $ch) {
    $suggestion_cache_key = 'digim_next_available_' . md5($uuid . '|' . $checkin . '|' . $checkout);
    $body = curl_multi_getcontent($ch);
    $calendar = json_decode($body, true);
    $calendar_days = $calendar['data']['days'] ?? [];
    $range_available = true;

    $days_by_date = [];
    if (is_array($calendar_days)) {
      foreach ($calendar_days as $day) {
        if (!empty($day['date'])) {
          $days_by_date[$day['date']] = $day;
        }
      }
    }

    $current = strtotime($checkin);
    $end = strtotime($checkout); // do NOT subtract 1 day

    // Check check-in day restriction (e.g., Saturday-only check-in)
    $checkin_day_of_week = (int) date('w', $current); // 0 = Sunday, 6 = Saturday
    $checkin_day_name = date('l', $current); // Full day name
    
    // Get check-in day from the calendar day data if available
    $checkin_day_data = $days_by_date[date('Y-m-d', $current)] ?? null;
    $allowed_checkin_days = null;
    $min_nights_required = null;
    
    if ($checkin_day_data) {
      // Check for minimum nights requirement in the day data - try multiple possible field names
      $min_nights_required = $checkin_day_data['min_nights'] 
        ?? $checkin_day_data['minimum_nights'] 
        ?? $checkin_day_data['min_stay'] 
        ?? $checkin_day_data['minimum_stay']
        ?? (isset($checkin_day_data['pricing']) && isset($checkin_day_data['pricing']['min_nights']) ? $checkin_day_data['pricing']['min_nights'] : null)
        ?? null;
      
      // Store minimum nights requirement even if property is unavailable (for badge display)
      if ($min_nights_required !== null && $requested_nights < (int)$min_nights_required) {
        if (!isset($digim_min_nights_required[$uuid]) || (int)$min_nights_required > $digim_min_nights_required[$uuid]) {
          $digim_min_nights_required[$uuid] = (int)$min_nights_required;
          // Cache this for future requests
          $min_nights_cache_key = 'digim_min_nights_' . md5($uuid . '|' . $checkin . '|' . $checkout);
          set_transient($min_nights_cache_key, (int)$min_nights_required, $cache_ttl);
        }
      }
      
      // Check for check-in day restrictions
      $allowed_checkin_days = $checkin_day_data['checkin_days'] ?? $checkin_day_data['allowed_checkin_days'] ?? null;
      
      // Also check if this specific day allows check-in
      $allows_checkin = $checkin_day_data['allows_checkin'] ?? $checkin_day_data['checkin_allowed'] ?? true;
      if (isset($checkin_day_data['checkin_allowed']) && $checkin_day_data['checkin_allowed'] === false) {
        $allows_checkin = false;
      }
      
      // If check-in is explicitly not allowed on this day, mark as unavailable
      if ($allows_checkin === false) {
        $range_available = false;
      }
    }
    
    // Check minimum nights requirement
    if ($range_available && $min_nights_required !== null && $requested_nights < (int)$min_nights_required) {
      $range_available = false;
    }
    
    // Check check-in day restrictions (e.g., Saturday-only)
    if ($range_available && $allowed_checkin_days !== null) {
      if (is_array($allowed_checkin_days)) {
        // Array of allowed days (e.g., [6] for Saturday, [0,6] for Sunday and Saturday)
        $day_allowed = in_array($checkin_day_of_week, $allowed_checkin_days);
      } elseif (is_string($allowed_checkin_days)) {
        // String format (e.g., "Saturday", "6", "saturday")
        $day_allowed = (stripos($allowed_checkin_days, strtolower($checkin_day_name)) !== false) ||
                       (stripos($allowed_checkin_days, (string)$checkin_day_of_week) !== false);
      } else {
        $day_allowed = true; // If format is unknown, allow it
      }
      
      if (!$day_allowed) {
        $range_available = false;
      }
    }

    // Loop through each night from checkin to (checkout - 1)
    while ($current < $end && $range_available) {
      $date_str = date('Y-m-d', $current);
      $day_found = $days_by_date[$date_str] ?? null;

      if (!$day_found || !digim_calendar_day_is_available($day_found)) {
        $range_available = false;
        break;
      }
      
      // Check minimum nights from each day (in case it varies) - try multiple field names
      $day_min_nights = $day_found['min_nights'] 
        ?? $day_found['minimum_nights'] 
        ?? $day_found['min_stay'] 
        ?? $day_found['minimum_stay']
        ?? (isset($day_found['pricing']) && isset($day_found['pricing']['min_nights']) ? $day_found['pricing']['min_nights'] : null)
        ?? null;
      if ($day_min_nights !== null && $requested_nights < (int)$day_min_nights) {
        $range_available = false;
        // Store minimum nights requirement for display in search results
        if (!isset($digim_min_nights_required[$uuid]) || (int)$day_min_nights > $digim_min_nights_required[$uuid]) {
          $digim_min_nights_required[$uuid] = (int)$day_min_nights;
          // Cache this for future requests
          $min_nights_cache_key = 'digim_min_nights_' . md5($uuid . '|' . $checkin . '|' . $checkout);
          set_transient($min_nights_cache_key, (int)$day_min_nights, $cache_ttl);
        }
        break;
      }

      $current = strtotime('+1 day', $current);
    }

    if ($range_available) {
      $checkout_day = $days_by_date[$checkout] ?? null;
      if (!$checkout_day || !digim_calendar_day_is_available($checkout_day)) {
        $range_available = false;
      }
    }

    if ($range_available) {
      $results[] = $uuid;
      $available_map[$uuid] = true;
      set_transient('digim_availability_' . md5($uuid . '|' . $checkin . '|' . $checkout), 'available', $cache_ttl);
      $digim_next_available_suggestions[$uuid] = null;
      set_transient($suggestion_cache_key, 'none', $cache_ttl);
    } else {
      set_transient('digim_availability_' . md5($uuid . '|' . $checkin . '|' . $checkout), 'unavailable', $cache_ttl);

      // If we haven't stored minimum nights yet, check all days in the range to find the maximum requirement
      if (!isset($digim_min_nights_required[$uuid])) {
        $max_min_nights = null;
        $check_current = strtotime($checkin);
        $check_end = strtotime($checkout);
        
        while ($check_current < $check_end) {
          $check_date_str = date('Y-m-d', $check_current);
          $check_day = $days_by_date[$check_date_str] ?? null;
          
          if ($check_day) {
            // Try multiple possible field names for minimum nights
            $day_min = $check_day['min_nights'] 
              ?? $check_day['minimum_nights'] 
              ?? $check_day['min_stay'] 
              ?? $check_day['minimum_stay']
              ?? (isset($check_day['pricing']) && isset($check_day['pricing']['min_nights']) ? $check_day['pricing']['min_nights'] : null)
              ?? null;
            if ($day_min !== null) {
              $day_min_int = (int)$day_min;
              if ($max_min_nights === null || $day_min_int > $max_min_nights) {
                $max_min_nights = $day_min_int;
              }
            }
          }
          
          $check_current = strtotime('+1 day', $check_current);
        }
        
        // If we found a minimum nights requirement and requested nights is less, store it
        if ($max_min_nights !== null && $requested_nights < $max_min_nights) {
          $digim_min_nights_required[$uuid] = $max_min_nights;
          // Also cache this for future requests
          $min_nights_cache_key = 'digim_min_nights_' . md5($uuid . '|' . $checkin . '|' . $checkout);
          set_transient($min_nights_cache_key, $max_min_nights, $cache_ttl);
        }
      }

      // Attempt to find the next available window that respects minimum nights and check-in restrictions
      $search_cursor = strtotime($checkin);
      $search_end_ts = strtotime($query_end_date);
      $next_available = null;
      
      // Get minimum nights and check-in restrictions from the original check-in day if available
      $original_checkin_day = $days_by_date[date('Y-m-d', strtotime($checkin))] ?? null;
      $property_min_nights = null;
      $property_allowed_checkin_days = null;
      
      if ($original_checkin_day) {
        $property_min_nights = $original_checkin_day['min_nights'] ?? $original_checkin_day['minimum_nights'] ?? null;
        $property_allowed_checkin_days = $original_checkin_day['checkin_days'] ?? $original_checkin_day['allowed_checkin_days'] ?? null;
      }

      while ($search_cursor <= $search_end_ts) {
        $candidate_start = $search_cursor;
        $candidate_start_date_str = date('Y-m-d', $candidate_start);
        $candidate_start_day = $days_by_date[$candidate_start_date_str] ?? null;
        
        // Check if this day allows check-in
        if ($candidate_start_day) {
          $allows_checkin = $candidate_start_day['allows_checkin'] ?? $candidate_start_day['checkin_allowed'] ?? true;
          if (isset($candidate_start_day['checkin_allowed']) && $candidate_start_day['checkin_allowed'] === false) {
            $allows_checkin = false;
          }
          
          if ($allows_checkin === false) {
            $search_cursor = strtotime('+1 day', $search_cursor);
            continue;
          }
          
          // Check check-in day restrictions
          $candidate_allowed_checkin_days = $candidate_start_day['checkin_days'] ?? $candidate_start_day['allowed_checkin_days'] ?? $property_allowed_checkin_days;
          if ($candidate_allowed_checkin_days !== null) {
            $candidate_day_of_week = (int) date('w', $candidate_start);
            $candidate_day_name = date('l', $candidate_start);
            
            if (is_array($candidate_allowed_checkin_days)) {
              $day_allowed = in_array($candidate_day_of_week, $candidate_allowed_checkin_days);
            } elseif (is_string($candidate_allowed_checkin_days)) {
              $day_allowed = (stripos($candidate_allowed_checkin_days, strtolower($candidate_day_name)) !== false) ||
                             (stripos($candidate_allowed_checkin_days, (string)$candidate_day_of_week) !== false);
            } else {
              $day_allowed = true;
            }
            
            if (!$day_allowed) {
              $search_cursor = strtotime('+1 day', $search_cursor);
              continue;
            }
          }
          
          // Get minimum nights for this candidate start date
          $candidate_min_nights = $candidate_start_day['min_nights'] ?? $candidate_start_day['minimum_nights'] ?? $property_min_nights;
          $required_nights = $candidate_min_nights !== null ? max($requested_nights, (int)$candidate_min_nights) : $requested_nights;
        } else {
          $required_nights = $requested_nights;
        }
        
        $candidate_end = $candidate_start;
        $fits = true;

        // Check availability for the required number of nights
        for ($i = 0; $i < $required_nights; $i++) {
          $candidate_date_str = date('Y-m-d', $candidate_end);
          $candidate_day = $days_by_date[$candidate_date_str] ?? null;
          if (!$candidate_day || !digim_calendar_day_is_available($candidate_day)) {
            $fits = false;
            break;
          }
          $candidate_end = strtotime('+1 day', $candidate_end);
        }

        if ($fits) {
          $candidate_checkout_day = $days_by_date[date('Y-m-d', $candidate_end)] ?? null;
          if (!$candidate_checkout_day || !digim_calendar_day_is_available($candidate_checkout_day)) {
            $fits = false;
          }
        }

        if ($fits) {
          $next_available = date('Y-m-d', $candidate_start);
          // Update suggested nights to match minimum requirement if needed
          if (isset($required_nights) && $required_nights > $requested_nights) {
            $requested_nights = $required_nights;
          }
          break;
        }

        $search_cursor = strtotime('+1 day', $search_cursor);
      }

      if ($next_available) {
        $suggested_checkout = date('Y-m-d', strtotime("+{$requested_nights} days", strtotime($next_available)));
        $suggestion_payload = [
          'start'    => $next_available,
          'checkout' => $suggested_checkout,
          'nights'   => $requested_nights,
        ];
        $digim_next_available_suggestions[$uuid] = $suggestion_payload;
        set_transient($suggestion_cache_key, $suggestion_payload, $cache_ttl);
      } else {
        $digim_next_available_suggestions[$uuid] = null;
        set_transient($suggestion_cache_key, 'none', $cache_ttl);
      }
    }

    curl_multi_remove_handle($mh, $ch);
    curl_close($ch);
  }

  curl_multi_close($mh);
  return array_keys($available_map);
}

// === Shortcode === //
require_once plugin_dir_path(__FILE__) . 'includes/shortcode.php';

// === SINGLE PAGE === //
add_action('init', function () {
  // Support both UUID and slug-based URLs
  add_rewrite_rule('^property/([^/]+)/?', 'index.php?dm_property_identifier=$matches[1]', 'top');
  add_rewrite_tag('%dm_property_identifier%', '([^&]+)');
});
add_filter('template_include', function ($template) {
  if (get_query_var('dm_property_identifier')) {
    return plugin_dir_path(__FILE__) . 'templates/property-single.php';
  }
  return $template;
});

// === Flush === //
register_activation_hook(__FILE__, function () {
  flush_rewrite_rules();
});
register_deactivation_hook(__FILE__, function () {
  flush_rewrite_rules();
});

// === AJAX HANDLER === //
add_action('wp_ajax_digimanagement_get_listings', 'digimanagement_get_listings_ajax');
add_action('wp_ajax_nopriv_digimanagement_get_listings', 'digimanagement_get_listings_ajax');

// Booking submission AJAX handler
add_action('wp_ajax_digim_submit_booking', 'digimanagement_submit_booking_ajax');
add_action('wp_ajax_nopriv_digim_submit_booking', 'digimanagement_submit_booking_ajax');
// Create reservation and return hosted checkout URL
add_action('wp_ajax_digim_create_reservation', 'digimanagement_create_reservation_ajax');
add_action('wp_ajax_nopriv_digim_create_reservation', 'digimanagement_create_reservation_ajax');

// Pricing and availability AJAX handlers
add_action('wp_ajax_digim_get_pricing', 'digimanagement_get_pricing_ajax');
add_action('wp_ajax_nopriv_digim_get_pricing', 'digimanagement_get_pricing_ajax');

add_action('wp_ajax_digim_check_availability', 'digimanagement_check_availability_ajax');
add_action('wp_ajax_nopriv_digim_check_availability', 'digimanagement_check_availability_ajax');

add_action('wp_ajax_digim_get_unavailable_dates', 'digimanagement_get_unavailable_dates_ajax');
add_action('wp_ajax_nopriv_digim_get_unavailable_dates', 'digimanagement_get_unavailable_dates_ajax');

// Test endpoint to debug API responses
add_action('wp_ajax_digim_test_api', 'digimanagement_test_api_ajax');
add_action('wp_ajax_nopriv_digim_test_api', 'digimanagement_test_api_ajax');

// Simple test endpoint
add_action('wp_ajax_digim_simple_test', 'digimanagement_simple_test_ajax');
add_action('wp_ajax_nopriv_digim_simple_test', 'digimanagement_simple_test_ajax');


function digimanagement_get_listings_ajax()
{
  $search = isset($_GET['property_search']) ? $_GET['property_search'] : '';
  // Handle both array (multiple) and string (single) formats
  if (is_array($search)) {
    $search = array_map('sanitize_text_field', array_filter($search));
  } else {
    $search = $search ? [sanitize_text_field($search)] : [];
  }
  $checkin = sanitize_text_field($_GET['checkin'] ?? '');
  $checkout = sanitize_text_field($_GET['checkout'] ?? '');

  $page = 1;
  $all_properties = [];
  do {
    $response = wp_remote_get(digimanagement_get_api_url()
      . "/properties?page=$page", [
      'headers' => [
        'Authorization' => digimanagement_get_api_token(),
        'Accept' => 'application/json',
        'Cache-Control' => 'no-cache',
        'Pragma' => 'no-cache',
      ],
      'timeout' => 15,
    ]);
    if (is_wp_error($response)) wp_send_json_error($response->get_error_message());
    $data = json_decode(wp_remote_retrieve_body($response), true);
    if (!isset($data['data'])) break;
    $all_properties = array_merge($all_properties, $data['data']);
    $page++;
  } while (isset($data['links']['next']) && $data['links']['next']);

  if (!empty($search)) {
    $all_properties = array_filter($all_properties, function ($p) use ($search) {
      $property_name = strtolower($p['public_name'] ?? $p['name'] ?? '');
      $property_city = strtolower($p['address']['city'] ?? '');
      foreach ($search as $search_term) {
        $search_lower = strtolower($search_term);
        if (stripos($property_name, $search_lower) !== false || stripos($property_city, $search_lower) !== false) {
          return true;
        }
      }
      return false;
    });
  }

  if ($checkin && $checkout && count($all_properties) > 0) {
    $uuids = array_map(function ($p) {
      return $p['uuid'] ?? $p['id'] ?? null;
    }, $all_properties);

    $uuids = array_values(array_filter(
      array_unique(array_map(function ($uuid) {
        $uuid = is_null($uuid) ? '' : trim((string) $uuid);
        return $uuid !== '' ? $uuid : null;
      }, $uuids)),
      function ($uuid) {
        return $uuid !== null && $uuid !== '';
      }
    ));

    if (!empty($uuids)) {
      $available_uuids = digimanagement_parallel_calendar_check($uuids, $checkin, $checkout);
      $available_uuid_map = [];
      if (is_array($available_uuids)) {
        foreach ($available_uuids as $uuid) {
          $uuid = trim((string) $uuid);
          if ($uuid !== '') {
            $available_uuid_map[$uuid] = true;
          }
        }
      }

      global $digim_next_available_suggestions;
      $suggestion_map = is_array($digim_next_available_suggestions) ? $digim_next_available_suggestions : [];

      $available_properties = [];
      $suggested_properties = [];

      foreach ($all_properties as $property) {
        $uuid = $property['uuid'] ?? $property['id'] ?? null;
        $uuid = is_null($uuid) ? '' : trim((string) $uuid);
        if ($uuid === '') {
          continue;
        }

        if (isset($available_uuid_map[$uuid])) {
          $property['_digim_is_suggestion'] = false;
          $available_properties[] = $property;
        } elseif (!empty($suggestion_map[$uuid]) && is_array($suggestion_map[$uuid])) {
          $suggestion = $suggestion_map[$uuid];
          $property['_digim_is_suggestion'] = true;
          $property['_digim_suggested_start'] = $suggestion['start'] ?? null;
          $property['_digim_suggested_checkout'] = $suggestion['checkout'] ?? null;
          $property['_digim_suggested_nights'] = $suggestion['nights'] ?? null;
          $suggested_properties[] = $property;
        }
      }

      $all_properties = array_merge($available_properties, $suggested_properties);
    } else {
      $all_properties = [];
    }
  }

  wp_send_json_success(array_values($all_properties));
}

// Booking submission function
function digimanagement_submit_booking_ajax()
{
  // Verify nonce
  if (!wp_verify_nonce($_POST['nonce'], 'digim_booking_nonce')) {
    wp_send_json_error(['message' => 'Invalid nonce']);
    return;
  }

  // Get and sanitize booking data
  $property_uuid = sanitize_text_field($_POST['property_uuid'] ?? '');
  $checkin_date = sanitize_text_field($_POST['checkin_date'] ?? '');
  $checkout_date = sanitize_text_field($_POST['checkout_date'] ?? '');
  $adults = intval($_POST['adults'] ?? 0);
  $children = intval($_POST['children'] ?? 0);
  $infants = intval($_POST['infants'] ?? 0);
  $total_guests = intval($_POST['total_guests'] ?? 0);

  // Validate required fields
  if (empty($property_uuid) || empty($checkin_date) || empty($checkout_date) || $total_guests <= 0) {
    wp_send_json_error(['message' => 'Missing required booking information']);
    return;
  }

  // Validate dates
  $checkin = DateTime::createFromFormat('Y-m-d', $checkin_date);
  $checkout = DateTime::createFromFormat('Y-m-d', $checkout_date);
  
  if (!$checkin || !$checkout || $checkin >= $checkout) {
    wp_send_json_error(['message' => 'Invalid dates']);
    return;
  }

  // Check if check-in is in the future
  if ($checkin < new DateTime('today')) {
    wp_send_json_error(['message' => 'Check-in date must be in the future']);
    return;
  }

  try {
    // Prepare booking data for Hospitable API
    $booking_data = [
      'property_uuid' => $property_uuid,
      'checkin_date' => $checkin_date,
      'checkout_date' => $checkout_date,
      'adults' => $adults,
      'children' => $children,
      'infants' => $infants,
      'total_guests' => $total_guests,
      'status' => 'pending',
      'created_at' => current_time('mysql')
    ];

    // Submit to Hospitable API - using the booking endpoint
    $response = wp_remote_post(digimanagement_get_api_url() . '/bookings', [
      'headers' => [
        'Authorization' => digimanagement_get_api_token(),
        'Accept' => 'application/json',
        'Content-Type' => 'application/json',
      ],
      'body' => json_encode([
        'property_uuid' => $property_uuid,
        'checkin_date' => $checkin_date,
        'checkout_date' => $checkout_date,
        'adults' => $adults,
        'children' => $children,
        'infants' => $infants,
        'total_guests' => $total_guests,
        'status' => 'pending'
      ]),
      'timeout' => 30,
    ]);

    if (is_wp_error($response)) {
      wp_send_json_error(['message' => 'Failed to submit booking: ' . $response->get_error_message()]);
      return;
    }

    $response_code = wp_remote_retrieve_response_code($response);
    $response_body = json_decode(wp_remote_retrieve_body($response), true);

    if ($response_code >= 200 && $response_code < 300) {
      // Store booking locally for tracking
      $booking_id = wp_insert_post([
        'post_type' => 'digim_booking',
        'post_title' => 'Booking for Property ' . $property_uuid,
        'post_status' => 'publish',
        'meta_input' => $booking_data
      ]);

      wp_send_json_success([
        'message' => 'Booking submitted successfully',
        'booking_id' => $booking_id,
        'hospitable_response' => $response_body
      ]);
    } else {
      $error_message = $response_body['message'] ?? 'Unknown error occurred';
      wp_send_json_error(['message' => 'Booking failed: ' . $error_message]);
    }

  } catch (Exception $e) {
    wp_send_json_error(['message' => 'Booking error: ' . $e->getMessage()]);
  }
}

// Create reservation through Hospitable and return a hosted checkout URL
function digimanagement_create_reservation_ajax()
{
  // Verify nonce
  if (!wp_verify_nonce($_POST['nonce'], 'digim_booking_nonce')) {
    wp_send_json_error(['message' => 'Invalid nonce']);
    return;
  }

  $property_uuid = sanitize_text_field($_POST['property_uuid'] ?? '');
  $checkin_date = sanitize_text_field($_POST['checkin_date'] ?? '');
  $checkout_date = sanitize_text_field($_POST['checkout_date'] ?? '');
  $adults = intval($_POST['adults'] ?? 1);
  $children = intval($_POST['children'] ?? 0);
  $infants = intval($_POST['infants'] ?? 0);

  if (empty($property_uuid) || empty($checkin_date) || empty($checkout_date)) {
    wp_send_json_error(['message' => 'Missing required reservation parameters']);
    return;
  }

  try {
    $payload = [
      'property_uuid' => $property_uuid,
      'checkin_date' => $checkin_date,
      'checkout_date' => $checkout_date,
      'guests' => [
        'adults' => $adults,
        'children' => $children,
        'infants' => $infants,
      ],
      'source' => 'website',
      'status' => 'pending',
    ];

    $response = wp_remote_post(digimanagement_get_api_url() . '/reservations', [
      'headers' => [
        'Authorization' => digimanagement_get_api_token(),
        'Accept' => 'application/json',
        'Content-Type' => 'application/json',
      ],
      'body' => json_encode($payload),
      'timeout' => 30,
    ]);

    if (is_wp_error($response)) {
      wp_send_json_error(['message' => 'Reservation request failed: ' . $response->get_error_message()]);
      return;
    }

    $code = wp_remote_retrieve_response_code($response);
    $body_raw = wp_remote_retrieve_body($response);
    $body = json_decode($body_raw, true);

    if ($code >= 200 && $code < 300) {
      // Try common fields where checkout URL might be provided
      $checkout_url = $body['data']['checkout_url']
        ?? $body['data']['public_checkout_url']
        ?? $body['checkout_url']
        ?? $body['public_checkout_url']
        ?? null;
      $reservation_uuid = $body['data']['id'] ?? $body['data']['uuid'] ?? $body['id'] ?? $body['uuid'] ?? null;

      wp_send_json_success([
        'message' => 'Reservation created',
        'reservation_uuid' => $reservation_uuid,
        'checkout_url' => $checkout_url,
        'raw' => $body,
      ]);
    } else {
      $err = $body['message'] ?? $body_raw ?? 'Unknown error';
      wp_send_json_error(['message' => 'Reservation create failed: ' . $err, 'raw' => $body]);
    }
  } catch (Exception $e) {
    wp_send_json_error(['message' => 'Reservation error: ' . $e->getMessage()]);
  }
}

// Function to get quote from Hospitable API
function digimanagement_get_quote($property_uuid, $checkin_date, $checkout_date, $adults = 1, $children = 0, $infants = 0, $pets = 0) {
    $api_url = digimanagement_get_api_url() . "/properties/$property_uuid/quote";
    $api_token = digimanagement_get_api_token();
    
    // Minimal payload for pricing only - no guest details needed
    $request_body = json_encode([
        'checkin_date' => $checkin_date,
        'checkout_date' => $checkout_date,
        'guests' => [
            'adults' => $adults,
            'children' => $children,
            'infants' => $infants,
            'pets' => $pets
        ]
    ]);
    
    error_log("Quote API URL: " . $api_url);
    error_log("Quote API Token: " . substr($api_token, 0, 20) . "...");
    error_log("Quote API Request Body: " . $request_body);
    error_log("Quote API Request Headers: " . json_encode([
        'Authorization' => substr($api_token, 0, 20) . '...',
        'Accept' => 'application/json',
        'Content-Type' => 'application/json'
    ]));
    error_log("Property UUID for quote: " . $property_uuid);
    error_log("Property UUID length: " . strlen($property_uuid));
    
    $response = wp_remote_post($api_url, [
        'headers' => [
            'Authorization' => $api_token,
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
        ],
        'body' => $request_body,
        'timeout' => 30,
    ]);
    
    if (is_wp_error($response)) {
        error_log("Quote API error: " . $response->get_error_message());
        return [ 'error' => $response->get_error_message() ];
    }
    
    $response_code = wp_remote_retrieve_response_code($response);
    $response_body = json_decode(wp_remote_retrieve_body($response), true);
    
    error_log("Quote API response code: " . $response_code);
    error_log("Quote API response body: " . wp_remote_retrieve_body($response));
    error_log("Quote API response parsed: " . print_r($response_body, true));
    
    if ($response_code >= 200 && $response_code < 300) {
        // Some responses wrap data under 'data'
        return isset($response_body['data']) ? $response_body['data'] : $response_body;
    }
    // Return error details for debugging upstream
    return [
        'error' => 'non_2xx',
        'status' => $response_code,
        'body' => $response_body
    ];
}


// Get pricing data from Hospitable API
function digimanagement_get_pricing_ajax()
{
  // Verify nonce
  if (!wp_verify_nonce($_POST['nonce'], 'digim_booking_nonce')) {
    wp_send_json_error(['message' => 'Invalid nonce']);
    return;
  }

  $property_uuid = sanitize_text_field($_POST['property_uuid'] ?? '');
  $checkin_date = sanitize_text_field($_POST['checkin_date'] ?? '');
  $checkout_date = sanitize_text_field($_POST['checkout_date'] ?? '');
  $adults = intval($_POST['adults'] ?? 1);
  $children = intval($_POST['children'] ?? 0);
  $infants = intval($_POST['infants'] ?? 0);
  $pets = intval($_POST['pets'] ?? 0);

  if (empty($property_uuid) || empty($checkin_date) || empty($checkout_date)) {
    wp_send_json_error(['message' => 'Missing required parameters']);
    return;
  }
  
  // Validate UUID format
  if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $property_uuid)) {
    wp_send_json_error(['message' => 'Invalid property UUID format: ' . $property_uuid]);
    return;
  }

  try {
    // Calculate nights
    $checkin = DateTime::createFromFormat('Y-m-d', $checkin_date);
    $checkout = DateTime::createFromFormat('Y-m-d', $checkout_date);
    $nights = $checkin->diff($checkout)->days;
    
    // Debug logging
    error_log("Pricing request - Property: $property_uuid, Checkin: $checkin_date, Checkout: $checkout_date, Nights: $nights");
    error_log("Property UUID type: " . gettype($property_uuid) . ", Length: " . strlen($property_uuid));
    error_log("Property UUID value: " . $property_uuid);

    // Always use Quote API per new logic
    $base_price = 0;
    $cleaning_fee = 0;
    $service_fee = 0;
    $security_deposit = 0;
    $subtotal = 0;
    $total = 0;
    $quote_data = digimanagement_get_quote($property_uuid, $checkin_date, $checkout_date, $adults, $children, $infants, $pets);

    // Handle error returned by helper
    if (isset($quote_data['error'])) {
      $err_message = 'Failed to generate quote';
      if (!empty($quote_data['status'])) {
        $err_message .= ' (HTTP ' . intval($quote_data['status']) . ')';
      }
      if (!empty($quote_data['body']['message'])) {
        $err_message .= ': ' . $quote_data['body']['message'];
      }
      if (!empty($quote_data['body']['errors'])) {
        $err_message .= ' - Errors: ' . json_encode($quote_data['body']['errors']);
      }
      $stored_token = get_option('digimanagement_api_key', '');
      $using_fallback_token = empty(trim($stored_token));
      wp_send_json_error([
        'message' => $err_message,
        'raw' => $quote_data,
        'token_source' => $using_fallback_token ? 'fallback' : 'stored'
      ]);
      return;
    }

    // Parse totals from quote financials (amounts are in cents)
    $currency = $quote_data['currency'] ?? 'USD';
    if (isset($quote_data['financials']['totals'])) {
      $totals = $quote_data['financials']['totals'];
      $sub_cents = null;
      $total_cents = null;
      if (isset($totals['sub_total']['amount'])) { $sub_cents = $totals['sub_total']['amount']; }
      if (isset($totals['sub_total'][0]['amount'])) { $sub_cents = $totals['sub_total'][0]['amount']; }
      if (isset($totals['total']['amount'])) { $total_cents = $totals['total']['amount']; }
      if (isset($totals['total'][0]['amount'])) { $total_cents = $totals['total'][0]['amount']; }

      if ($sub_cents !== null) { $subtotal = floatval($sub_cents) / 100.0; }
      if ($total_cents !== null) { $total = floatval($total_cents) / 100.0; }
    }

    // Derive per-night base price from subtotal
    if ($nights > 0 && $subtotal > 0) {
      $base_price = round($subtotal / $nights, 2);
    }

    // Map fees and taxes from quote
    $fees_cents = 0;
    if (isset($quote_data['financials']['fees']) && is_array($quote_data['financials']['fees'])) {
      foreach ($quote_data['financials']['fees'] as $f) {
        if (isset($f['amount'])) { $fees_cents += intval($f['amount']); }
      }
    }
    
    $taxes_cents = 0;
    if (isset($quote_data['financials']['taxes']) && is_array($quote_data['financials']['taxes'])) {
      foreach ($quote_data['financials']['taxes'] as $t) {
        if (isset($t['amount'])) { $taxes_cents += intval($t['amount']); }
      }
    }
    
    // Separate service fees and taxes
    $service_fee = round($fees_cents / 100.0, 2);
    $taxes_total = round($taxes_cents / 100.0, 2);
    
    // For now, we'll show taxes as a separate line item
    // In the future, we could break down individual taxes
    $cleaning_fee = 0; // Reset cleaning fee since it's not in the API response

    // Compose response
    $pricing_data = [
      'base_price' => $base_price,
      'cleaning_fee' => $cleaning_fee,
      'service_fee' => $service_fee,
      'taxes' => $taxes_total,
      'security_deposit' => $security_deposit,
      'nights' => $nights,
      'subtotal' => $subtotal,
      'total' => $total,
      'currency' => $currency,
      'quote_id' => $quote_data['quote_id'] ?? null,
      'booking_url' => $quote_data['booking_url'] ?? null,
    ];

    wp_send_json_success($pricing_data);

  } catch (Exception $e) {
    wp_send_json_error(['message' => 'Pricing error: ' . $e->getMessage()]);
  }
}

// Check availability from Hospitable API
function digimanagement_check_availability_ajax()
{
  // Verify nonce
  if (!wp_verify_nonce($_POST['nonce'], 'digim_booking_nonce')) {
    wp_send_json_error(['message' => 'Invalid nonce']);
    return;
  }

  $property_uuid = sanitize_text_field($_POST['property_uuid'] ?? '');
  $checkin_date = sanitize_text_field($_POST['checkin_date'] ?? '');
  $checkout_date = sanitize_text_field($_POST['checkout_date'] ?? '');

  if (empty($property_uuid) || empty($checkin_date) || empty($checkout_date)) {
    wp_send_json_error(['message' => 'Missing required parameters']);
    return;
  }

  try {
    // Check availability using Hospitable API
    // First try to get calendar data for the property
    $response = wp_remote_get(digimanagement_get_api_url() . "/properties/$property_uuid/calendar", [
      'headers' => [
        'Authorization' => digimanagement_get_api_token(),
        'Accept' => 'application/json',
      ],
      'timeout' => 15,
    ]);

    if (is_wp_error($response)) {
      wp_send_json_error(['message' => 'Failed to check availability']);
      return;
    }

    $calendar_data = json_decode(wp_remote_retrieve_body($response), true);
    
    // Check if the specific dates are available
    $is_available = true;
    $unavailable_dates = [];

    // For now, assume available if we can't get calendar data
    // In a real implementation, you'd parse the calendar data
    if (isset($calendar_data['data'])) {
      // Parse calendar data to check availability
      // This is a simplified check - you may need to adjust based on actual API response
      $is_available = true; // Default to available
    }

    wp_send_json_success([
      'available' => $is_available,
      'unavailable_dates' => $unavailable_dates,
      'checkin_date' => $checkin_date,
      'checkout_date' => $checkout_date
    ]);

  } catch (Exception $e) {
    wp_send_json_error(['message' => 'Availability check error: ' . $e->getMessage()]);
  }
}

function digimanagement_get_unavailable_dates_ajax()
{
  $property_uuid = sanitize_text_field($_REQUEST['property_uuid'] ?? '');
  $start_date = sanitize_text_field($_REQUEST['start_date'] ?? '');
  $end_date = sanitize_text_field($_REQUEST['end_date'] ?? '');

  if ($property_uuid === '') {
    wp_send_json_error(['message' => 'Missing property UUID']);
    return;
  }

  if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $property_uuid)) {
    wp_send_json_error(['message' => 'Invalid property UUID format']);
    return;
  }

  $today = new DateTimeImmutable('today', wp_timezone());
  if ($start_date === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $start_date)) {
    $start_date = $today->format('Y-m-d');
  }

  $start_obj = DateTimeImmutable::createFromFormat('Y-m-d', $start_date);
  if (!$start_obj) {
    $start_obj = $today;
    $start_date = $start_obj->format('Y-m-d');
  }

  if ($end_date === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $end_date)) {
    $end_obj = $start_obj->modify('+12 months');
    $end_date = $end_obj->format('Y-m-d');
  } else {
    $end_obj = DateTimeImmutable::createFromFormat('Y-m-d', $end_date);
    if (!$end_obj) {
      $end_obj = $start_obj->modify('+12 months');
      $end_date = $end_obj->format('Y-m-d');
    }
  }

  if ($end_obj <= $start_obj) {
    $end_obj = $start_obj->modify('+1 month');
    $end_date = $end_obj->format('Y-m-d');
  }

  $max_range = $start_obj->modify('+18 months');
  if ($end_obj > $max_range) {
    $end_obj = $max_range;
    $end_date = $end_obj->format('Y-m-d');
  }

  $cache_key = 'digim_unavailable_' . md5($property_uuid . '|' . $start_date . '|' . $end_date);
  $cached = get_transient($cache_key);
  if ($cached !== false) {
    wp_send_json_success($cached);
    return;
  }

  $query_args = [
    'start_date' => $start_date,
    'end_date'   => $end_date,
  ];

  $response = wp_remote_get(digimanagement_get_api_url() . "/properties/{$property_uuid}/calendar?" . http_build_query($query_args), [
    'headers' => [
      'Authorization' => digimanagement_get_api_token(),
      'Accept'        => 'application/json',
      'Cache-Control' => 'no-cache',
      'Pragma'        => 'no-cache',
    ],
    'timeout' => 15,
  ]);

  if (is_wp_error($response)) {
    wp_send_json_error(['message' => 'Failed to fetch calendar']);
    return;
  }

  $calendar = json_decode(wp_remote_retrieve_body($response), true);
  if (!is_array($calendar)) {
    wp_send_json_error(['message' => 'Malformed calendar response']);
    return;
  }

  $days = $calendar['data']['days'] ?? [];
  $unavailable = [];
  $min_nights_by_date = []; // Store minimum nights for each date

  if (is_array($days)) {
    foreach ($days as $day) {
      $date = $day['date'] ?? null;
      if (!$date) {
        continue;
      }

      // Extract minimum nights requirement
      $min_nights = $day['min_nights'] ?? $day['minimum_nights'] ?? null;
      if ($min_nights !== null) {
        $min_nights_by_date[$date] = (int)$min_nights;
      }

      $status = $day['status'] ?? [];
      $availableFlag = $status['available'] ?? null;

      $is_available = true;
      if (is_bool($availableFlag)) {
        $is_available = $availableFlag;
      } elseif (is_string($availableFlag)) {
        $is_available = filter_var($availableFlag, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
        if ($is_available === null) {
          $is_available = strtolower($availableFlag) !== 'false';
        }
      } elseif (isset($status['state'])) {
        $state = strtolower((string) $status['state']);
        $is_available = !in_array($state, ['blocked', 'booked', 'unavailable', 'maintenance'], true);
      } elseif (isset($status['type'])) {
        $type = strtolower((string) $status['type']);
        $is_available = !in_array($type, ['blocked', 'booked', 'unavailable', 'maintenance'], true);
      }

      if (!$is_available) {
        $unavailable[] = $date;
      }
    }
  }

  $payload = [
    'dates'       => array_values(array_unique($unavailable)),
    'min_nights'  => $min_nights_by_date, // Minimum nights requirement for each date
    'range_start' => $start_date,
    'range_end'   => $end_date,
  ];

  set_transient($cache_key, $payload, apply_filters('digim_unavailable_dates_cache_ttl', 30 * MINUTE_IN_SECONDS, $property_uuid, $start_date, $end_date));

  wp_send_json_success($payload);
}