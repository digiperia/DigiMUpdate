document.addEventListener("DOMContentLoaded", function () {
  const initDateRangePicker = function() {
    const dateInput = document.querySelector(".flatpickr-range");
    if (!dateInput || (typeof jQuery === 'undefined' || typeof jQuery.fn.daterangepicker === 'undefined')) {
      return;
    }

    // Check if already initialized
    if (dateInput._digimDaterangepickerReady) {
      return;
    }

    const checkinHidden = document.querySelector(".checkin-hidden");
    const checkoutHidden = document.querySelector(".checkout-hidden");
    const dateRangeInput = document.querySelector("input[name='date_range']");

    // Set initial dates if hidden inputs have values
    let startDate = null;
    let endDate = null;
    if (checkinHidden && checkoutHidden && checkinHidden.value && checkoutHidden.value) {
      startDate = moment(checkinHidden.value);
      endDate = moment(checkoutHidden.value);
      if (dateRangeInput) {
        dateRangeInput.value = startDate.format('MMM D, YYYY') + ' to ' + endDate.format('MMM D, YYYY');
      }
    }

    jQuery(dateInput).daterangepicker({
      startDate: startDate || moment(),
      endDate: endDate || null,
      minDate: moment(),
      singleDatePicker: false,
      autoUpdateInput: false,
      locale: {
        format: 'MMM D, YYYY'
      },
      opens: 'left'
    }, function(start, end, label) {
      const checkinStr = start.format('YYYY-MM-DD');
      const checkoutStr = end.format('YYYY-MM-DD');

      if (checkinHidden) checkinHidden.value = checkinStr;
      if (checkoutHidden) checkoutHidden.value = checkoutStr;

      if (dateRangeInput) {
        dateRangeInput.value = start.format('MMM D, YYYY') + ' to ' + end.format('MMM D, YYYY');
      }
    });

    // Set display format (MMM D, YYYY format for search-group datecal - e.g., "Jan 15, 2024")
    if (dateRangeInput && startDate && endDate) {
      dateRangeInput.value = startDate.format('MMM D, YYYY') + ' to ' + endDate.format('MMM D, YYYY');
    }

    dateInput._digimDaterangepickerReady = true;
  };

  // Try to initialize when DOM and libraries are ready
  if (typeof jQuery !== 'undefined' && typeof moment !== 'undefined' && typeof jQuery.fn.daterangepicker !== 'undefined') {
    initDateRangePicker();
  } else {
    // Wait for libraries to load
    let attempts = 0;
    const checkLibraries = setInterval(function() {
      attempts++;
      if ((typeof jQuery !== 'undefined' && typeof moment !== 'undefined' && typeof jQuery.fn.daterangepicker !== 'undefined') || attempts > 50) {
        clearInterval(checkLibraries);
        if (attempts <= 50) {
          initDateRangePicker();
        }
      }
    }, 100);
  }

  // Handle unavailable date clicks with better UX
  function handleUnavailableDateClicks() {
    // Use event delegation to handle clicks on calendar cells
    document.addEventListener('click', function(e) {
      const calendar = document.querySelector('.daterangepicker');
      if (!calendar || !calendar.contains(e.target)) {
        return;
      }

      // Check if clicked element is an unavailable date
      const clickedCell = e.target.closest('td.off');
      if (!clickedCell) {
        return;
      }

      // Prevent default behavior
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();

      // Add visual feedback - shake animation
      clickedCell.classList.add('digim-date-shake');
      
      // Remove shake class after animation
      setTimeout(function() {
        clickedCell.classList.remove('digim-date-shake');
      }, 500);

      // Optional: Show a tooltip or message
      const dateText = clickedCell.textContent.trim();
      if (dateText) {
        // Create a temporary tooltip
        const tooltip = document.createElement('div');
        tooltip.className = 'digim-unavailable-tooltip';
        tooltip.textContent = 'This date is not available';
        tooltip.style.cssText = `
          position: absolute;
          background: rgba(220, 53, 69, 0.95);
          color: white;
          padding: 8px 12px;
          border-radius: 6px;
          font-size: 12px;
          font-weight: 500;
          pointer-events: none;
          z-index: 10000;
          white-space: nowrap;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
        `;

        const rect = clickedCell.getBoundingClientRect();
        tooltip.style.left = rect.left + (rect.width / 2) - 80 + 'px';
        tooltip.style.top = rect.top - 35 + 'px';

        document.body.appendChild(tooltip);

        // Remove tooltip after 2 seconds
        setTimeout(function() {
          if (tooltip.parentNode) {
            tooltip.parentNode.removeChild(tooltip);
          }
        }, 2000);
      }
    }, true); // Use capture phase to intercept before daterangepicker handles it
  }

  // Initialize unavailable date click handler
  handleUnavailableDateClicks();
});

// Mobile: lock body scroll when datepicker is opened
document.addEventListener("DOMContentLoaded", function () {
  const isMobile = () => window.innerWidth <= 991;
  const addLock = () => { if (isMobile()) document.body.classList.add("digim-no-scroll"); };
  const removeLock = () => document.body.classList.remove("digim-no-scroll");

  // Try common selectors for the date input used by daterangepicker
  const dateInputs = [
    document.querySelector("#date-range"),
    document.querySelector(".flatpickr-range"),
    document.querySelector(".airbnb-booking-form .date-input")
  ].filter(Boolean);

  dateInputs.forEach((el) => {
    el.addEventListener("focus", addLock);
    el.addEventListener("click", addLock);
    el.addEventListener("blur", removeLock);
  });

  // If daterangepicker calendar closes (click outside), remove lock
  document.addEventListener("click", function (e) {
    const calendarOpen = document.querySelector(".daterangepicker");
    const clickedInsideCalendar = e.target.closest && e.target.closest(".daterangepicker");
    const clickedDateInput = e.target.closest && e.target.closest("#date-range, .flatpickr-range, .airbnb-booking-form .date-input");
    if (!calendarOpen || (!clickedInsideCalendar && !clickedDateInput)) {
      removeLock();
    }
  });

  // On resize to desktop, ensure unlock
  window.addEventListener("resize", function () {
    if (!isMobile()) removeLock();
  });
});

// Fix daterangepicker calendar positioning to follow the input when scrolling
document.addEventListener("DOMContentLoaded", function () {
  let activeCalendar = null;
  let activeInput = null;

  // Monitor for daterangepicker calendar opening
  const observer = new MutationObserver(function(mutations) {
    mutations.forEach(function(mutation) {
      if (mutation.type === 'childList') {
        const calendar = document.querySelector('.daterangepicker');
        if (calendar && !activeCalendar && calendar.style.display !== 'none') {
          activeCalendar = calendar;
          // Find the associated input
          activeInput = document.querySelector('.flatpickr-range:focus') ||
                       document.querySelector('#date-range:focus');
          
          if (activeInput) {
            // Start tracking scroll to reposition calendar
            window.addEventListener('scroll', repositionCalendar, { passive: true });
            window.addEventListener('resize', repositionCalendar, { passive: true });
          }
        } else if (calendar && (calendar.style.display === 'none' || !document.body.contains(calendar)) && activeCalendar === calendar) {
          // Calendar closed, stop tracking
          activeCalendar = null;
          activeInput = null;
          window.removeEventListener('scroll', repositionCalendar);
          window.removeEventListener('resize', repositionCalendar);
        }
      }
    });
  });

  // Start observing
  observer.observe(document.body, { childList: true, subtree: true });

  function repositionCalendar() {
    if (activeCalendar && activeInput && activeCalendar.style.display !== 'none') {
      const inputRect = activeInput.getBoundingClientRect();
      const calendar = activeCalendar;
      
      // Position calendar relative to input (daterangepicker handles its own positioning, but we can adjust)
      // The library handles most positioning automatically
      if (inputRect) {
        calendar.style.zIndex = '1001';
      }
    }
  }
});

document.addEventListener("DOMContentLoaded", function () {
  const trigger = document.querySelector(
    ".digimanagement-mobile-trigger .mobilesearchdestination"
  );
  const modal = document.querySelector(".digimanagement-mobile-modal");
  const closeBtn = document.querySelector(".digim-close-modal");

  if (trigger && modal && closeBtn) {
    trigger.addEventListener("click", () => {
      modal.classList.add("active");
    });

    closeBtn.addEventListener("click", () => {
      modal.classList.remove("active");
    });

    // Optional: close on outside click
    modal.addEventListener("click", (e) => {
      if (e.target === modal) {
        modal.classList.remove("active");
      }
    });
  }
});

// Mobile booking widget expand/collapse functionality
// Use event delegation so it works even if elements render later
document.addEventListener("click", function (e) {
  const btn = e.target.closest(".mobile-expand-btn");
  if (!btn) return;

  const widget = btn.closest(".booking-widget");
  if (!widget) return;

  const form = widget.querySelector(".booking-form");
  const header = widget.querySelector(".booking-header");
  const rightSidebar = widget.closest(".right-sidebar");
  if (!form || !header) return;

  e.preventDefault();
  const isActive = form.classList.toggle("active");
  header.classList.toggle("active", isActive);
  widget.classList.toggle("active", isActive);
  if (rightSidebar) rightSidebar.classList.toggle("active", isActive);
  
  // Update button text based on active state
  btn.textContent = isActive ? "Collapse" : "Expand";
});

document.addEventListener("DOMContentLoaded", function () {
  const galleryWrappers = document.querySelectorAll("[data-digim-gallery]");
  if (!galleryWrappers.length) {
    return;
  }

  galleryWrappers.forEach((wrapper) => {
    const slides = Array.from(
      wrapper.querySelectorAll("[data-digim-gallery-slide]")
    );
    if (slides.length <= 1) {
      // Nothing to slide – ensure the single slide is visible
      const single = slides[0];
      if (single) {
        single.classList.add("is-active");
      }
      return;
    }

    const prevBtn = wrapper.querySelector("[data-digim-gallery-prev]");
    const nextBtn = wrapper.querySelector("[data-digim-gallery-next]");
    const dots = Array.from(
      wrapper.querySelectorAll("[data-digim-gallery-dot]")
    );
    const counter = wrapper.querySelector(
      ".digim-gallery-counter .current-index"
    );

    let activeIndex = 0;

    const applyState = (newIndex) => {
      const maxIndex = slides.length - 1;
      if (newIndex < 0) {
        newIndex = maxIndex;
      } else if (newIndex > maxIndex) {
        newIndex = 0;
      }

      slides.forEach((slide, idx) =>
        slide.classList.toggle("is-active", idx === newIndex)
      );
      dots.forEach((dot, idx) =>
        dot.classList.toggle("is-active", idx === newIndex)
      );
      if (counter) {
        counter.textContent = newIndex + 1;
      }
      activeIndex = newIndex;
    };

    const goNext = () => applyState(activeIndex + 1);
    const goPrev = () => applyState(activeIndex - 1);

    if (prevBtn) {
      prevBtn.addEventListener("click", (event) => {
        event.preventDefault();
        goPrev();
      });
    }

    if (nextBtn) {
      nextBtn.addEventListener("click", (event) => {
        event.preventDefault();
        goNext();
      });
    }

    dots.forEach((dot, idx) => {
      dot.addEventListener("click", (event) => {
        event.preventDefault();
        applyState(idx);
      });
    });

    // Enable keyboard navigation
    wrapper.setAttribute("tabindex", "0");
    wrapper.addEventListener("keydown", (event) => {
      if (event.key === "ArrowRight") {
        event.preventDefault();
        goNext();
      } else if (event.key === "ArrowLeft") {
        event.preventDefault();
        goPrev();
      }
    });

    // Basic touch support
    let touchStartX = null;
    const onTouchStart = (event) => {
      const touch = event.touches[0];
      touchStartX = touch ? touch.clientX : null;
    };
    const onTouchEnd = (event) => {
      if (touchStartX === null) {
        return;
      }
      const touch = event.changedTouches[0];
      if (!touch) {
        touchStartX = null;
        return;
      }
      const distance = touch.clientX - touchStartX;
      const threshold = 40;
      if (Math.abs(distance) > threshold) {
        if (distance < 0) {
          goNext();
        } else {
          goPrev();
        }
      }
      touchStartX = null;
    };

    wrapper.addEventListener("touchstart", onTouchStart, { passive: true });
    wrapper.addEventListener("touchend", onTouchEnd);

    applyState(0);
  });
});

// Initialize lightgallery for show-all-overlay and modal-image elements
function initLightGallery() {
  if (typeof lightGallery === 'undefined') {
    // Wait for lightgallery to load
    setTimeout(initLightGallery, 100);
    return;
  }
  
  // Helper function to open lightgallery with all images
  function openLightGallery(startIndex) {
    startIndex = startIndex || 0;
    
    // Collect all images from modal gallery (which has all images)
    const modalGallery = document.querySelector('.modal-gallery');
    
    if (!modalGallery) {
      // Fallback: collect from hero gallery if modal gallery doesn't exist
      const heroGallery = document.querySelector('.hero-gallery');
      if (!heroGallery) return;
      
      const allImages = Array.from(heroGallery.querySelectorAll('img'));
      if (allImages.length === 0) return;
      
      const items = allImages.map(function(img, index) {
        return {
          src: img.src,
          thumb: img.src,
          alt: img.alt || 'Photo ' + (index + 1)
        };
      });
      
      const gallery = lightGallery(heroGallery, {
        dynamic: true,
        dynamicEl: items,
        index: startIndex >= 0 ? startIndex : 0,
        plugins: typeof lgThumbnail !== 'undefined' && typeof lgZoom !== 'undefined' ? [lgThumbnail, lgZoom] : [],
        download: false,
        share: false,
        closeOnTap: true,
        enableSwipe: true,
        enableDrag: true
      });
      
      gallery.openGallery(startIndex >= 0 ? startIndex : 0);
      return;
    }
    
    // Get all images from modal gallery
    const allImages = Array.from(modalGallery.querySelectorAll('.modal-image img'));
    if (allImages.length === 0) return;
    
    const items = allImages.map(function(img, index) {
      return {
        src: img.src,
        thumb: img.src,
        alt: img.alt || 'Photo ' + (index + 1)
      };
    });
    
    // Initialize lightgallery with dynamic content
    const gallery = lightGallery(modalGallery, {
      dynamic: true,
      dynamicEl: items,
      index: startIndex >= 0 ? startIndex : 0,
      plugins: typeof lgThumbnail !== 'undefined' && typeof lgZoom !== 'undefined' ? [lgThumbnail, lgZoom] : [],
      download: false,
      share: false,
      closeOnTap: true,
      enableSwipe: true,
      enableDrag: true
    });
    
    gallery.openGallery(startIndex >= 0 ? startIndex : 0);
  }
  
  // Handle main-image click on mobile - opens lightgallery
  const mainImage = document.getElementById('main-image');
  if (mainImage) {
    mainImage.addEventListener('click', function(e) {
      // Only on mobile (screen width <= 768px)
      if (window.innerWidth > 768) return;
      
      e.preventDefault();
      
      // Get all images from modal gallery
      const modalGallery = document.querySelector('.modal-gallery');
      if (!modalGallery) {
        openLightGallery(0);
        return;
      }
      
      const allImages = Array.from(modalGallery.querySelectorAll('.modal-image img'));
      if (allImages.length === 0) {
        openLightGallery(0);
        return;
      }
      
      // Find which image is currently shown in main-image
      const currentSrc = mainImage.src;
      const currentIndex = allImages.findIndex(function(img) {
        return img.src === currentSrc || img.getAttribute('src') === currentSrc;
      });
      
      // Open lightgallery starting from the current image
      openLightGallery(currentIndex >= 0 ? currentIndex : 0);
    });
  }
  
  // Handle show-all-overlay click - opens lightgallery with all images
  const showAllOverlay = document.querySelector(".show-all-overlay");
  if (showAllOverlay) {
    showAllOverlay.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation();
      openLightGallery(0);
    });
  }
  
  // Handle modal-image clicks (if modal is opened)
  const modalImages = document.querySelectorAll(".modal-image");
  
  if (modalImages.length > 0) {
    modalImages.forEach(function(modalImage) {
      modalImage.addEventListener('click', function(e) {
        e.preventDefault();
        
        // Collect all images from modal-gallery
        const modalGallery = document.querySelector('.modal-gallery');
        if (!modalGallery) return;
        
        const allImages = Array.from(modalGallery.querySelectorAll('.modal-image img'));
        const items = allImages.map(function(img, index) {
          return {
            src: img.src,
            thumb: img.src,
            alt: img.alt || 'Photo ' + (index + 1)
          };
        });
        
        // Find clicked image index
        const clickedImg = modalImage.querySelector('img');
        const currentIndex = allImages.findIndex(img => img === clickedImg);
        
        // Initialize lightgallery with dynamic content
        const gallery = lightGallery(modalGallery, {
          dynamic: true,
          dynamicEl: items,
          index: currentIndex >= 0 ? currentIndex : 0,
          plugins: typeof lgThumbnail !== 'undefined' && typeof lgZoom !== 'undefined' ? [lgThumbnail, lgZoom] : [],
          download: false,
          share: false,
          closeOnTap: true,
          enableSwipe: true,
          enableDrag: true
        });
        
        gallery.openGallery(currentIndex >= 0 ? currentIndex : 0);
      });
    });
  }
}

document.addEventListener("DOMContentLoaded", function () {
  initLightGallery();
  
  // Tab switching functionality for property description
  const tabButtons = document.querySelectorAll('.description-tabs .tab-button');
  const tabContents = document.querySelectorAll('.property-description .tab-content');
  
  tabButtons.forEach(button => {
    button.addEventListener('click', function() {
      const targetTab = this.getAttribute('data-tab');
      
      // Remove active class from all buttons and contents
      tabButtons.forEach(btn => btn.classList.remove('active'));
      tabContents.forEach(content => content.classList.remove('active'));
      
      // Add active class to clicked button and corresponding content
      this.classList.add('active');
      const targetContent = document.getElementById('tab-' + targetTab);
      if (targetContent) {
        targetContent.classList.add('active');
      }
    });
  });
});

// Toggle "Search destinations" placeholder based on selected items in Select2
document.addEventListener("DOMContentLoaded", function () {
  function toggleSelect2Placeholder() {
    const renderedElements = document.querySelectorAll('.select2-selection__rendered');
    
    renderedElements.forEach(function(rendered) {
      // Check if there are any <li> elements (selected choices) inside
      const hasSelection = rendered.querySelector('li.select2-selection__choice') !== null;
      
      if (hasSelection) {
        rendered.classList.add('has-selection');
      } else {
        rendered.classList.remove('has-selection');
      }
    });
  }
  
  // Function to setup observers for Select2 elements
  function setupSelect2Observers() {
    const renderedElements = document.querySelectorAll('.select2-selection__rendered');
    
    renderedElements.forEach(function(rendered) {
      // Skip if already observed
      if (rendered._digimObserved) {
        return;
      }
      
      const observer = new MutationObserver(function(mutations) {
        toggleSelect2Placeholder();
      });
      
      observer.observe(rendered, {
        childList: true,
        subtree: true
      });
      
      // Mark as observed
      rendered._digimObserved = true;
    });
  }
  
  // Check on page load
  toggleSelect2Placeholder();
  setupSelect2Observers();
  
  // Check when Select2 changes (using jQuery if available)
  if (typeof jQuery !== 'undefined') {
    // Listen for Select2 change events on any select element
    jQuery(document).on('change', 'select', function() {
      setTimeout(function() {
        toggleSelect2Placeholder();
        setupSelect2Observers();
      }, 10);
    });
    
    // Also listen for Select2 select/unselect events
    jQuery(document).on('select2:select select2:unselect select2:open select2:close', 'select', function() {
      setTimeout(function() {
        toggleSelect2Placeholder();
        setupSelect2Observers();
      }, 10);
    });
  }
  
  // Watch for new Select2 containers being added to the DOM
  const containerObserver = new MutationObserver(function(mutations) {
    let shouldCheck = false;
    mutations.forEach(function(mutation) {
      mutation.addedNodes.forEach(function(node) {
        if (node.nodeType === 1) { // Element node
          if (node.classList && (node.classList.contains('select2-container') || node.querySelector('.select2-selection__rendered'))) {
            shouldCheck = true;
          }
        }
      });
    });
    
    if (shouldCheck) {
      setTimeout(function() {
        toggleSelect2Placeholder();
        setupSelect2Observers();
      }, 50);
    }
  });
  
  containerObserver.observe(document.body, {
    childList: true,
    subtree: true
  });
});
