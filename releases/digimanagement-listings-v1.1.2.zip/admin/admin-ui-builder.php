<?php
add_action('admin_init', function () {
    register_setting('DigiM-style', 'digim_cards_per_page');
    register_setting('DigiM-style', 'digim_layout_style');
    register_setting('DigiM-style', 'digim_show_map');
    register_setting('DigiM-style', 'digim_grid_columns');
    register_setting('DigiM-style', 'digim_card_style');
    register_setting('DigiM-style', 'digim_primary_color'); // <-- this is the key line

});

add_action('admin_enqueue_scripts', 'digim_enqueue_admin_ui_assets');
function digim_enqueue_admin_ui_assets($hook_suffix)
{
    if (isset($_GET['page']) && $_GET['page'] === 'DigiM-style') {
        // CSS
        $css_file = plugin_dir_path(__DIR__) . 'assets/css/style.css';
        $css_url  = plugin_dir_url(__DIR__) . 'assets/css/style.css';

        if (file_exists($css_file)) {
            wp_enqueue_style('digim-admin-ui-style', $css_url, [], filemtime($css_file));
        } else {
            wp_enqueue_style('digim-admin-ui-style', $css_url);
        }

        // JS
        $js_file = plugin_dir_path(__DIR__) . 'assets/js/map-init.js';
        $js_url  = plugin_dir_url(__DIR__) . 'assets/js/map-init.js';

        if (file_exists($js_file)) {
            wp_enqueue_script('digim-admin-map-init', $js_url, ['jquery'], filemtime($js_file), true);
        }
    }
}

// AJAX Handlers for UI Builder
add_action('wp_ajax_digim_update_preview', 'digim_ajax_update_preview');
add_action('wp_ajax_digim_save_ui_settings', 'digim_ajax_save_ui_settings');

function digim_ajax_update_preview() {
    // Verify nonce
    if (!wp_verify_nonce($_POST['nonce'], 'digim_ui_builder_nonce')) {
        wp_die('Security check failed');
    }

    // Update options temporarily for preview
    if (isset($_POST['digim_cards_per_page'])) {
        update_option('digim_cards_per_page', intval($_POST['digim_cards_per_page']));
    }
    if (isset($_POST['digim_layout_style'])) {
        update_option('digim_layout_style', sanitize_text_field($_POST['digim_layout_style']));
    }
    if (isset($_POST['digim_grid_columns'])) {
        update_option('digim_grid_columns', intval($_POST['digim_grid_columns']));
    }
    if (isset($_POST['digim_card_style'])) {
        update_option('digim_card_style', sanitize_text_field($_POST['digim_card_style']));
    }
    if (isset($_POST['digim_primary_color'])) {
        update_option('digim_primary_color', sanitize_hex_color($_POST['digim_primary_color']));
    }
    if (isset($_POST['digim_show_map'])) {
        update_option('digim_show_map', intval($_POST['digim_show_map']));
    }

    // Generate preview HTML
    $preview_html = do_shortcode('[digimanagement_listings]');
    
    wp_send_json_success([
        'html' => $preview_html
    ]);
}

function digim_ajax_save_ui_settings() {
    // Verify nonce
    if (!wp_verify_nonce($_POST['nonce'], 'digim_ui_builder_nonce')) {
        wp_die('Security check failed');
    }

    // Save all settings
    $settings = [
        'digim_cards_per_page' => intval($_POST['digim_cards_per_page']),
        'digim_layout_style' => sanitize_text_field($_POST['digim_layout_style']),
        'digim_grid_columns' => intval($_POST['digim_grid_columns']),
        'digim_card_style' => sanitize_text_field($_POST['digim_card_style']),
        'digim_primary_color' => sanitize_hex_color($_POST['digim_primary_color']),
        'digim_show_map' => intval($_POST['digim_show_map'])
    ];

    foreach ($settings as $key => $value) {
        update_option($key, $value);
    }

    wp_send_json_success([
        'message' => 'Settings saved successfully'
    ]);
}

function digim_render_ui_builder_page()
{
    // Enqueue admin styles and scripts
    wp_enqueue_style('digim-admin-css', plugin_dir_url(__FILE__) . '../assets/css/admin.css', [], '1.0.0');
    wp_enqueue_script('digim-ui-builder-js', plugin_dir_url(__FILE__) . '../assets/js/ui-builder.js', ['jquery'], '1.0.0', true);
    
    // Localize script for AJAX
    wp_localize_script('digim-ui-builder-js', 'digim_ui_ajax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('digim_ui_builder_nonce'),
        'strings' => [
            'updating' => __('Updating preview...', 'DigiM'),
            'saved' => __('Settings saved!', 'DigiM')
        ]
    ]);

    $per_page     = esc_attr(get_option('digim_cards_per_page', 12));
    $layout       = esc_attr(get_option('digim_layout_style', 'grid'));
    $grid_columns = esc_attr(get_option('digim_grid_columns', 3));
    $show_map     = get_option('digim_show_map', false);
    $card_style   = esc_attr(get_option('digim_card_style', 'classic'));
    $primary_color = esc_attr(get_option('digim_primary_color', '#0073aa'));
?>
    <div class="digim-ui-builder">
        <!-- Header -->
        <div class="ui-builder-header">
            <div class="header-content">
                <h1><span class="dashicons dashicons-admin-customizer"></span> UI Builder – Listings Shortcode Settings</h1>
                <p>Design and customize your property listings with real-time preview</p>
            </div>
        </div>

        <!-- Main Builder Interface -->
        <div class="ui-builder-content">
            <!-- Left Sidebar - Controls -->
            <div class="ui-builder-sidebar">
                <form method="post" action="options.php" id="ui-builder-form" class="ui-builder-form">
                    <?php settings_fields('DigiM-style'); ?>
                    
                    <!-- Layout Settings -->
                    <div class="control-group">
                        <h3><span class="dashicons dashicons-layout"></span> Layout Settings</h3>
                        <div class="control-item">
                            <label for="digim_layout_style">Layout Style</label>
                            <div class="cb-columns-selector">
                                <input type="hidden" name="digim_layout_style" id="digim_layout_style" value="<?php echo esc_attr($layout); ?>" />
                                <div class="cb-columns-buttons">
                                    <button type="button" class="cb-column-btn cb-layout-btn <?php echo ($layout == 'grid') ? 'active' : ''; ?>" data-layout="grid" title="Grid Layout">
                                        <div class="cb-column-preview">
                                            <span class="cb-column-box"></span>
                                            <span class="cb-column-box"></span>
                                            <span class="cb-column-box"></span>
                                        </div>
                                        <span class="cb-column-label">Grid</span>
                                    </button>
                                    <button type="button" class="cb-column-btn cb-layout-btn <?php echo ($layout == 'list') ? 'active' : ''; ?>" data-layout="list" title="List Layout">
                                        <div class="cb-column-preview cb-list-preview">
                                            <span class="cb-list-line"></span>
                                            <span class="cb-list-line"></span>
                                            <span class="cb-list-line"></span>
                                        </div>
                                        <span class="cb-column-label">List</span>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div class="control-row">
                            <div class="control-item" id="grid-columns-control" style="<?php echo $layout === 'list' ? 'display: none;' : ''; ?>">
                                <label for="digim_grid_columns">Grid Columns</label>
                                <div class="cb-columns-selector">
                                    <input type="hidden" name="digim_grid_columns" id="digim_grid_columns" value="<?php echo esc_attr($grid_columns); ?>" />
                                    <div class="cb-columns-buttons">
                                        <button type="button" class="cb-column-btn <?php echo ($grid_columns == 2) ? 'active' : ''; ?>" data-columns="2" title="2 columns">
                                            <div class="cb-column-preview">
                                                <span class="cb-column-box"></span>
                                                <span class="cb-column-box"></span>
                                            </div>
                                            <span class="cb-column-label">2</span>
                                        </button>
                                        <button type="button" class="cb-column-btn <?php echo ($grid_columns == 3) ? 'active' : ''; ?>" data-columns="3" title="3 columns">
                                            <div class="cb-column-preview">
                                                <span class="cb-column-box"></span>
                                                <span class="cb-column-box"></span>
                                                <span class="cb-column-box"></span>
                                            </div>
                                            <span class="cb-column-label">3</span>
                                        </button>
                                        <button type="button" class="cb-column-btn <?php echo ($grid_columns == 4) ? 'active' : ''; ?>" data-columns="4" title="4 columns">
                                            <div class="cb-column-preview">
                                                <span class="cb-column-box"></span>
                                                <span class="cb-column-box"></span>
                                                <span class="cb-column-box"></span>
                                                <span class="cb-column-box"></span>
                                            </div>
                                            <span class="cb-column-label">4</span>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div class="control-item">
                                <label for="digim_cards_per_page">Cards per Page</label>
                                <div class="digim-number-input-wrapper">
                                    <button type="button" class="digim-number-btn digim-number-decrease" aria-label="Decrease">
                                        <span class="dashicons dashicons-minus"></span>
                                    </button>
                                    <input type="number" name="digim_cards_per_page" id="digim_cards_per_page" class="digim-input digim-number-input" value="<?php echo esc_attr($per_page); ?>" min="1" max="50" />
                                    <button type="button" class="digim-number-btn digim-number-increase" aria-label="Increase">
                                        <span class="dashicons dashicons-plus"></span>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div class="control-item">
                            <label for="digim_primary_color">Primary Color</label>
                            <div class="color-picker-wrapper">
                                <input type="color" name="digim_primary_color" id="digim_primary_color" value="<?php echo esc_attr($primary_color); ?>" />
                                <span class="color-value"><?php echo esc_attr($primary_color); ?></span>
                            </div>
                        </div>
                    </div>

                    <!-- Features -->
                    <div class="control-group">
                        <h3><span class="dashicons dashicons-admin-tools"></span> Features</h3>
                        <div class="control-item">
                            <label class="checkbox-control">
                                <input type="checkbox" name="digim_show_map" id="digim_show_map" value="1" <?php checked($show_map, 1); ?> />
                                <span class="label-text">Show Map below listings</span>
                                <div class="toggle-switch"></div>
                            </label>
                        </div>
                    </div>

                    <div class="control-group">
                        <div class="control-item">
                            <?php submit_button('Save UI Settings', 'primary', 'submit', false); ?>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Right Side - Live Preview -->
            <div class="ui-builder-preview">
                <div class="preview-header">
                    <h3><span class="dashicons dashicons-visibility"></span> Live Preview</h3>
                    <div class="preview-controls">
                        <button type="button" id="refresh-preview" class="button button-secondary">
                            <span class="dashicons dashicons-update"></span> Refresh
                        </button>
                    </div>
                </div>
                <div class="preview-container">
                    <div id="digim-preview" class="preview-content">
                        <?php echo do_shortcode('[digimanagement_listings]'); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
}
