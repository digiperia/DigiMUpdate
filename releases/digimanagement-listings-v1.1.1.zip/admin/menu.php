<?php
add_action('admin_menu', function () {
    add_menu_page(
        __('DigiManagement', 'DigiM'),
        __('DigiManagement', 'DigiM'),
        'manage_options',
        'DigiM',
        'render_settings_page',
        'dashicons-building',
        58
    );

    add_submenu_page(
        'DigiM',
        __('DigiManagement Settings', 'DigiM'),
        __('Settings', 'DigiM'),
        'manage_options',
        'DigiM',
        'render_settings_page'
    );

    add_submenu_page(
        'DigiM',
        __('DigiManagement Documentation', 'DigiM'),
        __('Documentation', 'DigiM'),
        'manage_options',
        'DigiM-docs',
        'render_documentation_page'
    );
    add_submenu_page(
        'DigiM',
        __('DigiManagement Style', 'DigiM'),
        __('UI Builder', 'DigiM'),
        'manage_options',
        'DigiM-style',
        'digim_render_ui_builder_page'
    );
    add_submenu_page(
        'DigiM',
        __('DigiManagement Cards', 'DigiM'),
        __('Card Builder', 'DigiM'),
        'manage_options',
        'DigiM-cards',
        'digim_render_card_builder_page'
    );
});

// Pages
require_once plugin_dir_path(__FILE__) . '/admin-settings.php';
require_once plugin_dir_path(__DIR__) . '/includes/shortcode.php';


// Callback functions
function render_settings_page()
{
    // Use the enhanced settings page function
    digimanagement_render_settings_page();
}

function render_documentation_page()
{
    echo '<div class="wrap"><h1>Documentation</h1></div>';
}

require_once __DIR__ . '/admin-ui-builder.php';
require_once __DIR__ . '/admin-card-builder.php';
