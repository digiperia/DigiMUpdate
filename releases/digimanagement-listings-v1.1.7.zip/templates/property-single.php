<?php

/**
 * Template: Single Property
 * Called by your plugin when visiting /property/{uuid}
 */

// From inside a file under /plugins/DigiM/templates/...
$plugin_dir = plugin_dir_path(dirname(__FILE__)); // -> /plugins/DigiM/
$plugin_url = plugin_dir_url(dirname(__FILE__));  // -> https://.../plugins/DigiM/

$rel        = 'assets/css/style.css';
$style_path = $plugin_dir . $rel;
$style_url  = $plugin_url . $rel;

if (file_exists($style_path)) {
    wp_enqueue_style('digim-style', $style_url, [], filemtime($style_path));
}

// Ensure frontend JS is loaded on the single property page
$js_rel  = 'assets/js/frontend.js';
$js_path = $plugin_dir . $js_rel;
$js_url  = $plugin_url . $js_rel;
if (file_exists($js_path)) {
    wp_enqueue_script('digim-frontend', $js_url, ['jquery'], filemtime($js_path), true);
}

// Get property identifier (could be UUID or slug)
$identifier = get_query_var('dm_property_identifier');
$uuid = null;
$property = null;

// Debug: Log the identifier
error_log("Property identifier from URL: " . $identifier);

// Check if identifier is a UUID (contains hyphens and is 36 chars long)
if (preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $identifier)) {
    // It's a UUID, use it directly
    $uuid = $identifier;
    error_log("Using UUID directly: " . $uuid);
} else {
    // It's a slug, look up the property to get the UUID
    $property = digimanagement_get_property_by_slug($identifier);
    if ($property) {
        $uuid = $property['uuid'] ?? $property['id'] ?? null;
        error_log("Found UUID from slug lookup: " . $uuid);
        error_log("Property data: " . print_r($property, true));
    } else {
        error_log("No property found for slug: " . $identifier);
    }
}

// If we don't have a property yet (UUID case), fetch it
if (!$property && $uuid) {
    $response = wp_remote_get(digimanagement_get_api_url() . "/properties/$uuid", [
        'headers' => [
            'Authorization' => digimanagement_get_api_token(),
            'Accept' => 'application/json',
            'Cache-Control' => 'no-cache',
        ],
        'timeout' => 15,
    ]);

    if (is_wp_error($response)) {
        echo '<p>Error: ' . esc_html($response->get_error_message()) . '</p>';
        get_footer();
        return;
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);
    $property = $data['data'] ?? null;
}

if (!$property || !$uuid) {
    status_header(404);
    if (function_exists('digimanagement_set_current_property_context')) {
        digimanagement_set_current_property_context(null);
    }

    include get_template_directory() . '/header.php';
    echo '<main class="digim-property-not-found"><p>Property not found.</p></main>';
    get_footer();
    return;
}

// ✅ Fetch reviews from /reviews endpoint
$reviews = [];
$reviews_response = wp_remote_get(digimanagement_get_api_url() . "/properties/$uuid/reviews", [
    'headers' => [
        'Authorization' => digimanagement_get_api_token(),
        'Accept' => 'application/json',
        'Cache-Control' => 'no-cache',
    ],
    'timeout' => 10,
]);

if (!is_wp_error($reviews_response)) {
    $reviews_data = json_decode(wp_remote_retrieve_body($reviews_response), true);
    $reviews = $reviews_data['data'] ?? [];
}

// Calculate average rating
$average_rating = 0;
if (!empty($reviews)) {
    $total_rating = 0;
    $review_count = 0;
    foreach ($reviews as $review) {
        $rating = $review['public']['rating'] ?? null;
        if ($rating !== null) {
            $total_rating += $rating;
            $review_count++;
        }
    }
    if ($review_count > 0) {
        $average_rating = round($total_rating / $review_count, 2);
    }
}

// ✅ Fetch images from dedicated /images endpoint
$images = [];
$images_response = wp_remote_get(digimanagement_get_api_url() . "/properties/$uuid/images", [
    'headers' => [
        'Authorization' => digimanagement_get_api_token(),
        'Accept' => 'application/json',
        'Cache-Control' => 'no-cache',
    ],
    'timeout' => 10,
]);

if (!is_wp_error($images_response)) {
    $images_data = json_decode(wp_remote_retrieve_body($images_response), true);

    $seen = [];
    foreach ($images_data['data'] ?? [] as $img) {
        $url = $img['original_url'] ?? $img['url'] ?? $img['thumbnail_url'] ?? null;
        if ($url && !in_array($url, $seen)) {
            $images[] = $url;
            $seen[] = $url;
        }
    }
}

$context_property = $property;
if (!empty($images)) {
    $context_property['images'] = array_map(function ($url) {
        return ['url' => $url];
    }, $images);
}

if (function_exists('digimanagement_set_current_property_context')) {
    digimanagement_set_current_property_context($context_property, $identifier ?: $uuid);
}

$coords = $property['address']['coordinates'] ?? null;
$amenities = $property['amenities'] ?? [];

wp_enqueue_script('digim-feather-icons', 'https://cdn.jsdelivr.net/npm/feather-icons@4.29.2/dist/feather.min.js', [], '4.29.2', true);

$normalized_amenities = array_map(function ($amenity) {
    return trim(preg_replace('/[^a-z0-9]+/', '_', strtolower($amenity)), '_');
}, $amenities);

$tags = $property['tags'] ?? [];
$normalized_tags = array_map(function ($tag) {
    return trim(preg_replace('/[^a-z0-9]+/', '_', strtolower($tag)), '_');
}, (array) $tags);

$highlight_map = [
    'free_parking' => 'Free Parking',
    'free_parking_on_premises' => 'Free Parking',
    'parking' => 'Free Parking',
    'pets_allowed' => 'Pet Friendly',
    'pet_friendly' => 'Pet Friendly',
    'pet_friendly_room' => 'Pet Friendly',
];

$highlight_badges = [];
foreach ($highlight_map as $key => $label) {
    if (in_array($key, $normalized_amenities, true) || in_array($key, $normalized_tags, true) || !empty($property[$key])) {
        $highlight_badges[] = $label;
    }
}
$highlight_badges = array_values(array_unique($highlight_badges));

$amenity_icons = [
    'ac' => 'wind',
    'alfresco_dining' => 'coffee',
    'alfresco_shower' => 'cloud-rain',
    'arcade_machine' => 'cpu',
    'baking_sheet' => 'grid',
    'barbeque_utensils' => 'tool',
    'bathtub' => 'droplet',
    'bbq_area' => 'sun',
    'beach_essentials' => 'umbrella',
    'bed_linens' => 'layers',
    'blender' => 'aperture',
    'board_games' => 'grid',
    'ceiling_fan' => 'rotate-cw',
    'coffee' => 'coffee',
    'conditioner' => 'droplet',
    'crib' => 'box',
    'dining_table' => 'grid',
    'dishes_and_silverware' => 'tool',
    'dishwasher' => 'droplet',
    'dryer' => 'wind',
    'ev_charger' => 'battery-charging',
    'fire_extinguisher' => 'shield',
    'first_aid_kit' => 'plus-square',
    'free_parking' => 'truck',
    'freezer' => 'thermometer',
    'game_console' => 'cpu',
    'hair_dryer' => 'wind',
    'hangers' => 'feather',
    'high_chair' => 'square',
    'hot_water' => 'thermometer',
    'iron' => 'slash',
    'keurig_coffee_machine' => 'coffee',
    'kitchen' => 'home',
    'laptop_friendly_workspace' => 'monitor',
    'laundromat_nearby' => 'refresh-ccw',
    'microwave' => 'cpu',
    'portable_fans' => 'wind',
    'refrigerator' => 'thermometer',
    'room_darkening_shades' => 'moon',
    'shampoo' => 'droplet',
    'sun_loungers' => 'sun',
    'toaster' => 'grid',
    'tv' => 'tv',
    'washer' => 'refresh-cw',
    'wine_glasses' => 'heart',
];
$default_icon_name = 'check-square';
$image_count = count($images);
$current_path = $_SERVER['REQUEST_URI'] ?? '';
$current_url = esc_url_raw(home_url($current_path));
$encoded_url = rawurlencode($current_url);
$encoded_title = rawurlencode($property['name'] ?? '');
$max_shown = 8;
?>

<?php include get_template_directory() . '/header.php'; ?>

<div class="airbnb-property-page" style="opacity: 0;">
    <style>
        :root {
            --digim-primary-color: <?php echo esc_attr(get_option('digim_primary_color', '#0073aa')); ?>;
            --digim-primary-color-dark: <?php echo esc_attr(get_option('digim_primary_color', '#0073aa')); ?>dd;
            --digim-primary-color-darker: <?php echo esc_attr(get_option('digim_primary_color', '#0073aa')); ?>cc;
        }
    </style>
    <!-- Hero Image Gallery -->
    <?php if (!empty($images)): ?>
        <div class="hero-gallery">
            <!-- Main large image -->
            <div class="main-image">
                <img src="<?php echo esc_url($images[0]); ?>" alt="Main Photo" loading="lazy" id="main-image">
            </div>
            
            <!-- Thumbnail grid (desktop only) -->
            <?php if (count($images) > 1): ?>
                <div class="thumbnail-grid">
                    <!-- Top row -->
                    <div class="thumbnail-item" onclick="changeMainImage('<?php echo esc_url($images[1]); ?>')">
                        <img src="<?php echo esc_url($images[1]); ?>" alt="Photo 2" loading="lazy">
                    </div>
                    <div class="thumbnail-item" onclick="changeMainImage('<?php echo esc_url($images[2]); ?>')">
                        <img src="<?php echo esc_url($images[2]); ?>" alt="Photo 3" loading="lazy">
                    </div>
                    
                    <!-- Bottom row -->
                    <div class="thumbnail-item" onclick="changeMainImage('<?php echo esc_url($images[3]); ?>')">
                        <img src="<?php echo esc_url($images[3]); ?>" alt="Photo 4" loading="lazy">
                    </div>
                    <div class="thumbnail-item show-all" onclick="document.getElementById('photos-modal').style.display='block'">
                        <img src="<?php echo esc_url($images[4] ?? $images[3]); ?>" alt="More photos" loading="lazy">
                        <div class="show-all-overlay">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M3 3h7v7H3V3zm11 0h7v7h-7V3zM3 14h7v7H3v-7zm11 0h7v7h-7v-7z"/>
                            </svg>
                            <span>Show all photos</span>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Mobile slider counter -->
            <div class="slider-counter" id="slider-counter">
                <span id="slider-counter-current">1</span>
                <span class="slider-counter-separator">/</span>
                <span id="slider-counter-total"><?php echo $image_count; ?></span>
            </div>

            <!-- Mobile slider arrows -->
            <button class="slider-arrow prev" onclick="previousSlide()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"/>
                </svg>
            </button>
            <button class="slider-arrow next" onclick="nextSlide()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"/>
                </svg>
            </button>
        </div>
    <?php endif; ?>

    <!-- Main Content Container -->
    <div class="content-container">
        <!-- Left Content -->
        <div class="left-content">
            <!-- Property Header -->
            <div class="property-header">
                <div class="property-title-group">
                    <h1 class="property-title"><?php echo esc_html($property['name'] ?? ''); ?></h1>
                    <div class="property-location">
                        <span class="location-text"><?php echo esc_html($property['address']['display'] ?? ''); ?></span>
                    </div>
                </div>
                <div class="property-share" aria-label="Share this property">
                    <span class="share-label">Share</span>
                    <div class="share-actions">
                        <a class="share-link share-facebook" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $encoded_url; ?>" target="_blank" rel="noopener noreferrer" aria-label="Share on Facebook">
                            <svg viewBox="0 0 320 512" width="18" height="18" aria-hidden="true" focusable="false">
                                <path fill="currentColor" d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z"/>
                            </svg>
                        </a>
                        <a class="share-link share-x" href="https://twitter.com/intent/tweet?url=<?php echo $encoded_url; ?>&text=<?php echo $encoded_title; ?>" target="_blank" rel="noopener noreferrer" aria-label="Share on X">
                            <svg viewBox="0 0 512 512" width="18" height="18" aria-hidden="true" focusable="false">
                                <path fill="currentColor" d="M389.2 48h70.6L322.3 224.2 487.4 464H345L233.4 306.9 106.5 464H35.8L204.2 274.8 47.9 48h146.1l99.7 134.4L389.2 48zm-24.7 373.8h39.1L151.1 86.1h-42z"/>
                            </svg>
                        </a>
                        <a class="share-link share-linkedin" href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo $encoded_url; ?>" target="_blank" rel="noopener noreferrer" aria-label="Share on LinkedIn">
                            <svg viewBox="0 0 448 512" width="18" height="18" aria-hidden="true" focusable="false">
                                <path fill="currentColor" d="M100.28 448H7.4V148.9h92.88zm-46.44-340.7C24 107.3 0 83.3 0 53.7A53.72 53.72 0 0 1 53.7 0a53.72 53.72 0 0 1 53.7 53.7c0 29.6-24 53.6-53.56 53.6zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.25-79.2-48.3 0-55.7 37.7-55.7 76.6V448h-92.7V148.9h88.9v40.8h1.3c12.4-23.5 42.7-48.3 87.9-48.3 94 0 111.3 61.9 111.3 142.3z"/>
                            </svg>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Property Details -->
            <div class="property-details">
                <div class="detail-item">
                    <span><b><?php echo intval($property['capacity']['max'] ?? 0); ?></b> guests</span>
                </div>
                <div class="detail-item">
                    <span><b><?php echo intval($property['capacity']['bedrooms'] ?? 0); ?></b> bedrooms</span>
                </div>
                <div class="detail-item">
                    <span><b><?php echo intval($property['capacity']['beds'] ?? 0); ?></b> beds</span>
                </div>
                <div class="detail-item">
                    <span><b><?php echo intval($property['capacity']['bathrooms'] ?? 0); ?></b> baths</span>
                </div>
            </div>

            <?php if (!empty($highlight_badges)): ?>
                <div class="property-highlights">
                    <?php foreach ($highlight_badges as $badge): ?>
                        <span class="highlight-badge"><?php echo esc_html($badge); ?></span>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <!-- Divider -->
            <div class="divider"></div>

            <!-- Description -->
            <div class="property-description">
                <h2>About this place</h2>
                <div class="description-content">
                    <p class="description-text"><?php echo nl2br(esc_html($property['description'] ?? $property['summary'] ?? '')); ?></p>
                    <button class="show-more-btn" onclick="toggleDescription()" style="display: none;">
                        <span class="btn-text">Show more</span>
                        <svg class="btn-icon" width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6 1.41-1.41z"/>
                        </svg>
                    </button>
                </div>
            </div>

            <!-- Divider -->
            <div class="divider"></div>

            <!-- Amenities -->
            <?php if (!empty($amenities)): ?>
                <div class="amenities-section">
                    <h2>What this place offers</h2>
                    <div class="amenities-grid">
                        <?php foreach (array_slice($amenities, 0, $max_shown) as $a):
                            $normalized_amenity = trim(preg_replace('/[^a-z0-9]+/', '_', strtolower($a)), '_');
                            $label = ucwords(preg_replace('/[_-]+/', ' ', $a));
                            $icon_name = $amenity_icons[$normalized_amenity] ?? $default_icon_name;
                        ?>
                            <div class="amenity-item">
                                <i class="amenity-icon" data-feather="<?php echo esc_attr($icon_name); ?>" aria-hidden="true"></i>
                                <span class="amenity-label"><?php echo esc_html($label); ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <?php if (count($amenities) > $max_shown): ?>
                        <button class="show-all-amenities" onclick="document.getElementById('amenities-modal').style.display='block'">
                            Show all <?php echo count($amenities); ?> amenities
                        </button>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <!-- Divider -->
            <div class="divider"></div>

            <!-- Reviews Section -->
            <?php if (!empty($reviews)): ?>
                <div class="reviews-section">
                    <!-- Overall Rating -->
                    <div class="overall-rating">
                        <div class="rating-number"><?php echo esc_html($average_rating); ?></div>
                    </div>
                    <div class="guest-favorite-label">Guest favorite</div>
                    <p class="guest-favorite-desc">This home is a guest favorite based on ratings, reviews, and reliability</p>

                    <!-- Reviews Grid -->
                    <div class="reviews-grid" id="reviews-grid">
                        <?php foreach (array_slice($reviews, 0, 2) as $index => $review): 
                            // Parse the API response structure
                            $rating = intval($review['public']['rating'] ?? 5);
                            $review_text = $review['public']['review'] ?? '';
                            $review_date = $review['reviewed_at'] ?? '';
                            $platform = $review['platform'] ?? '';
                            
                            // Format dates
                            if ($review_date) {
                                try {
                                    $date_obj = new DateTime($review_date);
                                    $formatted_date = $date_obj->format('F Y');
                                } catch (Exception $e) {
                                    $formatted_date = $review_date;
                                }
                            } else {
                                $formatted_date = '';
                            }
                            
                            // Extract reviewer name from platform if available
                            // For now, use a generic name based on platform
                            $reviewer_name = ucfirst($platform) . ' Guest';
                            $reviewer_initial = strtoupper(substr($platform, 0, 1));
                            
                            // Truncate review text if too long
                            $max_review_length = 200;
                            $display_text = $review_text;
                            $show_more_btn = false;
                            if (strlen($review_text) > $max_review_length) {
                                $display_text = substr($review_text, 0, $max_review_length) . '...';
                                $show_more_btn = true;
                            }
                        ?>
                            <div class="review-card">
                                <div class="review-header">
                                    <div class="reviewer-photo">
                                        <div class="reviewer-initial"><?php echo esc_html($reviewer_initial); ?></div>
                                    </div>
                                    <div class="reviewer-info">
                                        <div class="reviewer-name"><?php echo esc_html($reviewer_name); ?></div>
                                        <div class="reviewer-tenure">Guest on <?php echo esc_html(ucfirst($platform)); ?></div>
                                    </div>
                                </div>
                                <div class="review-rating">
                                    <?php for ($i = 0; $i < 5; $i++): ?>
                                        <span class="star <?php echo $i < $rating ? 'filled' : ''; ?>">★</span>
                                    <?php endfor; ?>
                                </div>
                                <div class="review-meta">
                                    <span><?php echo esc_html($formatted_date); ?></span>
                                    <span> • </span>
                                    <span>Stayed a few nights</span>
                                </div>
                                <div class="review-text">
                                    <?php echo esc_html($display_text); ?>
                                </div>
                                <?php if ($show_more_btn): ?>
                                    <button class="show-more-review" onclick="toggleReviewFullText(this)" data-full-text="<?php echo esc_attr($review_text); ?>">Show more</button>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Load More Button -->
                    <?php if (count($reviews) > 2): ?>
                    <div class="reviews-load-more-wrapper" style="text-align: center; margin-top: 32px;">
                        <button class="load-more-reviews-btn" id="load-more-reviews" data-loaded="2" data-total="<?php echo count($reviews); ?>">
                            Show <?php echo min(2, count($reviews) - 2); ?> more reviews
                        </button>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Divider -->
                <div class="divider"></div>
            <?php endif; ?>

            <!-- Map Section -->
            <?php if ($coords): ?>
                <div class="map-section">
                    <h2>Where you'll be</h2>
                    <div id="map" class="property-map"></div>
                </div>
            <?php endif; ?>
        </div>

        <!-- Right Sidebar - Booking Widget -->
        <div class="right-sidebar">
            <div class="booking-widget">
                <div class="booking-header">
                   <span>Booking Request</span>
                   <button type="button" class="mobile-expand-btn">Expand</button>
                </div>
                
                <!-- Custom Airbnb-style Booking Form -->
                <div class="booking-form">
                    <form id="booking-form" class="airbnb-booking-form">
                        <!-- Date Range Picker -->
                        <div class="booking-field-group single-field">
                            <div class="booking-field date-field">
                                <label class="field-label">DATES</label>
                                <input type="text" id="date-range" class="date-input" placeholder="Add dates" readonly>
                </div>
            </div>

                        <!-- Guest Selector -->
                        <div class="booking-field-group">
                            <div class="booking-field guest-field">
                                <label class="field-label">GUESTS</label>
                                <button type="button" id="guest-selector" class="guest-selector">
                                    <span class="guest-text">Add guests</span>
                                    <svg class="dropdown-arrow" width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                                        <path d="M7 10l5 5 5-5z"/>
                                    </svg>
                                </button>
                                
                                <!-- Guest Dropdown -->
                                <div id="guest-dropdown" class="guest-dropdown">
                                    <div class="guest-row">
                                        <div class="guest-info">
                                            <div class="guest-type">Adults</div>
                                            <div class="guest-age">Ages 13 or above</div>
                                        </div>
                                        <div class="guest-controls">
                                            <button type="button" class="guest-btn minus" data-type="adults" data-action="decrease">−</button>
                                            <span class="guest-count" id="adults-count">1</span>
                                            <button type="button" class="guest-btn plus" data-type="adults" data-action="increase">+</button>
                                        </div>
                                    </div>
                                    <div class="guest-row">
                                        <div class="guest-info">
                                            <div class="guest-type">Children</div>
                                            <div class="guest-age">Ages 2-12</div>
                                        </div>
                                        <div class="guest-controls">
                                            <button type="button" class="guest-btn minus" data-type="children" data-action="decrease">−</button>
                                            <span class="guest-count" id="children-count">0</span>
                                            <button type="button" class="guest-btn plus" data-type="children" data-action="increase">+</button>
                                        </div>
                                    </div>
                                    <div class="guest-row">
                                        <div class="guest-info">
                                            <div class="guest-type">Infants</div>
                                            <div class="guest-age">Under 2</div>
                                        </div>
                                        <div class="guest-controls">
                                            <button type="button" class="guest-btn minus" data-type="infants" data-action="decrease">−</button>
                                            <span class="guest-count" id="infants-count">0</span>
                                            <button type="button" class="guest-btn plus" data-type="infants" data-action="increase">+</button>
                                        </div>
                                    </div>
                                    <div class="guest-row">
                                        <div class="guest-info">
                                            <div class="guest-type">Pets</div>
                                            <div class="guest-age"><a href="#">Bringing a service animal?</a></div>
                                        </div>
                                        <div class="guest-controls">
                                            <button type="button" class="guest-btn minus" data-type="pets" data-action="decrease">−</button>
                                            <span class="guest-count" id="pets-count">0</span>
                                            <button type="button" class="guest-btn plus" data-type="pets" data-action="increase">+</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Reserve Button -->
                        <button type="submit" class="reserve-button">
                            <span class="reserve-text">Reserve</span>
                        </button>

                        <!-- Pricing Breakdown (hidden until dates are selected) -->
                        <div class="pricing-breakdown" id="pricing-breakdown" style="display: none;">
                            <div class="pricing-section">
                                <h4>Price details</h4>
                                <div class="price-line">
                                    <span class="price-label" id="base-price-label">$0.00 × 0 nights</span>
                                    <span class="price-value" id="base-price-total">$0.00</span>
                                </div>
                                <div class="price-line">
                                    <span class="price-label">Cleaning fee</span>
                                    <span class="price-value" id="cleaning-fee">$0.00</span>
                                </div>
                                <div class="price-line">
                                    <span class="price-label">Service fee</span>
                                    <span class="price-value" id="service-fee">$0.00</span>
                                </div>
                                <div class="price-line">
                                    <span class="price-label">Taxes</span>
                                    <span class="price-value" id="taxes">$0.00</span>
                                </div>
                                <div class="price-line total-line">
                                    <span class="price-label">Total</span>
                                    <span class="price-value" id="total-price">$0.00</span>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Photos Modal -->
<div id="photos-modal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="document.getElementById('photos-modal').style.display='none'">&times;</span>
        <div class="modal-gallery">
            <?php foreach ($images as $index => $img): ?>
                <div class="modal-image">
                    <img src="<?php echo esc_url($img); ?>" alt="Photo <?php echo $index + 1; ?>" loading="lazy">
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- Amenities Modal -->
<div id="amenities-modal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="document.getElementById('amenities-modal').style.display='none'">&times;</span>
        <h2>All Amenities</h2>
        <div class="modal-amenities-grid">
            <?php foreach ($amenities as $a):
                $normalized_amenity = trim(preg_replace('/[^a-z0-9]+/', '_', strtolower($a)), '_');
                $label = ucwords(preg_replace('/[_-]+/', ' ', $a));
                $icon_name = $amenity_icons[$normalized_amenity] ?? $default_icon_name;
            ?>
                <div class="modal-amenity-item">
                    <i class="amenity-icon" data-feather="<?php echo esc_attr($icon_name); ?>" aria-hidden="true"></i>
                    <span class="amenity-label"><?php echo esc_html($label); ?></span>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<script>
// Image gallery functionality
let currentSlide = 0;
const images = [
    <?php foreach ($images as $index => $img): ?>
        '<?php echo esc_url($img); ?>'<?php echo $index < count($images) - 1 ? ',' : ''; ?>
    <?php endforeach; ?>
];
const sliderCounterCurrent = document.getElementById('slider-counter-current');
const sliderCounterTotal = document.getElementById('slider-counter-total');

if (sliderCounterTotal) {
    sliderCounterTotal.textContent = images.length;
}

function updateSliderCounter() {
    if (sliderCounterCurrent) {
        sliderCounterCurrent.textContent = currentSlide + 1;
    }
}

function changeMainImage(imageSrc) {
    document.getElementById('main-image').src = imageSrc;
}

// Mobile slider functionality
function goToSlide(slideIndex) {
    currentSlide = slideIndex;
    updateSlider();
}

function nextSlide() {
    currentSlide = (currentSlide + 1) % images.length;
    updateSlider();
}

function previousSlide() {
    currentSlide = (currentSlide - 1 + images.length) % images.length;
    updateSlider();
}

function updateSlider() {
    // Update main image
    document.getElementById('main-image').src = images[currentSlide];
    
    // Update dots
    const dots = document.querySelectorAll('.slider-dot');
    dots.forEach((dot, index) => {
        dot.classList.toggle('active', index === currentSlide);
    });

    updateSliderCounter();
}

// Touch/swipe support for mobile
let startX = 0;
let endX = 0;

document.addEventListener("DOMContentLoaded", function() {
    // Trigger fade-in animation once page is loaded
    const propertyPage = document.querySelector('.airbnb-property-page');
    if (propertyPage) {
        // Small delay to ensure all styles are loaded
        setTimeout(() => {
            propertyPage.style.opacity = '1';
            propertyPage.style.transition = 'opacity 0.6s ease-in-out';
        }, 50);
    }

    if (window.feather) {
        feather.replace();
    }

    updateSliderCounter();
    
    // Initialize description truncation
    initDescriptionTruncation();
    
    const gallery = document.querySelector('.hero-gallery');
    
    if (gallery) {
        gallery.addEventListener('touchstart', function(e) {
            startX = e.touches[0].clientX;
        });
        
        gallery.addEventListener('touchend', function(e) {
            endX = e.changedTouches[0].clientX;
            handleSwipe();
        });
    }
    
    function handleSwipe() {
        const threshold = 50;
        const diff = startX - endX;
        
        if (Math.abs(diff) > threshold) {
            if (diff > 0) {
                nextSlide(); // Swipe left - next slide
            } else {
                previousSlide(); // Swipe right - previous slide
            }
        }
    }
    
    <?php if ($coords): ?>
    var map = L.map('map').setView([<?php echo $coords['latitude']; ?>, <?php echo $coords['longitude']; ?>], 15);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);
    L.marker([<?php echo $coords['latitude']; ?>, <?php echo $coords['longitude']; ?>]).addTo(map);
    <?php endif; ?>
    
    // Initialize booking widget
    initBookingWidget();
});

// Function to prefill booking widget from URL parameters
function prefillBookingFromURL() {
    try {
        const urlParams = new URLSearchParams(window.location.search);
        
        // Get date parameters
        let checkinDate = urlParams.get('checkin');
        let checkoutDate = urlParams.get('checkout');
        const dateRange = urlParams.get('date_range');
        
        // Parse date_range if checkin/checkout not available
        if ((!checkinDate || !checkoutDate) && dateRange) {
            const decoded = decodeURIComponent(dateRange.replace(/\+/g, ' '));
            const parts = decoded.split(/\s+to\s+/i);
            if (parts.length === 2) {
                checkinDate = parts[0].trim();
                checkoutDate = parts[1].trim();
            }
        }
        
        // Set dates if both are available
        if (checkinDate && checkoutDate) {
            const dateInput = document.getElementById('date-range');
            if (dateInput) {
                // Get the existing flatpickr instance
                const picker = dateInput._flatpickr;
                if (picker) {
                    // Set the dates which will trigger onChange and pricing fetch
                    picker.setDate([checkinDate, checkoutDate], true, 'Y-m-d');
                }
            }
        }
        
        // Get guest parameters
        const adults = parseInt(urlParams.get('adults') || '0');
        const children = parseInt(urlParams.get('children') || '0');
        const infants = parseInt(urlParams.get('infants') || '0');
        const pets = parseInt(urlParams.get('pets') || '0');
        const totalGuests = parseInt(urlParams.get('guests') || '0');
        
        // Update guest counts if provided
        if (adults > 0 || children > 0 || infants > 0 || pets >= 0 || totalGuests > 0) {
            // Update the guest state (this will be available in the booking widget scope)
            if (window.guestState) {
                if (adults > 0) window.guestState.adults = adults;
                if (children > 0) window.guestState.children = children;
                if (infants > 0) window.guestState.infants = infants;
                // Always update pets if it's in the URL (even if 0)
                if (urlParams.has('pets')) window.guestState.pets = pets;
                
                // If only total guests provided, assign to adults
                if (adults === 0 && children === 0 && infants === 0 && totalGuests > 0) {
                    window.guestState.adults = totalGuests;
                    window.guestState.children = 0;
                    window.guestState.infants = 0;
                }
                
                // Update the display
                updateGuestDisplayFromURL();
            }
        }
        
    } catch (error) {
        console.warn('Error prefilling from URL:', error);
    }
}

// Helper function to update guest display
function updateGuestDisplayFromURL() {
    if (!window.guestState) return;
    
    // Update guest count displays
    const adultsCount = document.getElementById('adults-count');
    const childrenCount = document.getElementById('children-count');
    const infantsCount = document.getElementById('infants-count');
    const petsCount = document.getElementById('pets-count');
    const guestText = document.querySelector('.guest-text');
    
    if (adultsCount) adultsCount.textContent = window.guestState.adults;
    if (childrenCount) childrenCount.textContent = window.guestState.children;
    if (infantsCount) infantsCount.textContent = window.guestState.infants;
    if (petsCount) petsCount.textContent = window.guestState.pets || 0;
    
    // Update guest text
    if (guestText) {
        const total = window.guestState.adults + window.guestState.children + window.guestState.infants;
        if (total === 0) {
            guestText.textContent = 'Add guests';
            guestText.classList.remove('has-selection');
        } else {
            let text = `${total} guest${total !== 1 ? 's' : ''}`;
            if (window.guestState.infants > 0) {
                text += `, ${window.guestState.infants} infant${window.guestState.infants !== 1 ? 's' : ''}`;
            }
            if (window.guestState.pets > 0) {
                text += `, ${window.guestState.pets} pet${window.guestState.pets !== 1 ? 's' : ''}`;
            }
            guestText.textContent = text;
            guestText.classList.add('has-selection');
        }
    }
}

// Booking Widget Functionality
function initBookingWidget() {
    // Guest selection state (make it globally accessible)
    window.guestState = {
        adults: 1,
        children: 0,
        infants: 0,
        pets: 0
    };
    const guestState = window.guestState;
    
    // Date selection state
    let selectedDates = {
        checkin: null,
        checkout: null
    };
    
    // Don't load initial pricing - wait for user to select dates
    // loadInitialPricing();
    
    // Keep track of the actual selected dates array
    let selectedDatesArray = [];
    
    // Load initial pricing function (disabled - wait for user to select dates)
    async function loadInitialPricing() {
        // This function is disabled - pricing is now loaded when user selects dates
        return;
    }
    
    // Property pricing data (will be updated from API)
    let pricing = {
        basePrice: 0,
        cleaningFee: 0,
        serviceFee: 0,
        securityDeposit: 0,
        currency: 'USD'
    };
    
    // Property data from PHP
    const fullPropertyData = <?php echo json_encode($property ?? []); ?>;
    console.log('Property data:', fullPropertyData);
    
    // Let the API handle minimum stay requirements
    
    // Helper function to format dates for API without timezone issues
    function formatDateForAPI(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
    
    // The Hospitable API doesn't include pricing in the property object
    // We need to get pricing from the quote API, so we'll start with 0
    // and let the API calls populate the real pricing
    
    // Initialize date picker
    initDatePicker();
    
    // Initialize guest selector
    initGuestSelector();
    
    // Prefill from URL parameters after datepicker is ready
    setTimeout(() => {
        prefillBookingFromURL();
    }, 300);
    
    // Debugging removed - pricing is now working!
    
    // Initialize form submission
    initFormSubmission();
    
    function initDatePicker() {
        const dateInput = document.getElementById('date-range');
        
        // Initialize Flatpickr for date range
        flatpickr(dateInput, {
            mode: "range",
            minDate: "today",
            dateFormat: "Y-m-d",
            altInput: true,
            altFormat: "d, M Y",
            allowInput: false,
            onChange: function(selectedDatesArray, dateStr, instance) {
                
                // Update our state object
                if (selectedDatesArray.length === 2) {
                    selectedDates.checkin = selectedDatesArray[0];
                    selectedDates.checkout = selectedDatesArray[1];
                    
                    // Let the API handle minimum stay validation
                    const nights = Math.ceil((selectedDates.checkout - selectedDates.checkin) / (1000 * 60 * 60 * 24));
                    console.log('Selected dates:', selectedDates.checkin, 'to', selectedDates.checkout);
                    console.log('Formatted for API:', formatDateForAPI(selectedDates.checkin), 'to', formatDateForAPI(selectedDates.checkout));
                    console.log('Selected nights:', nights);
                    
                    // Fetch real pricing from API
                    fetchPricingFromAPI();
                } else if (selectedDatesArray.length === 1) {
                    selectedDates.checkin = selectedDatesArray[0];
                    selectedDates.checkout = null;
                    // Hide pricing breakdown
                    const pricingBreakdown = document.getElementById('pricing-breakdown');
                    if (pricingBreakdown) {
                        pricingBreakdown.classList.remove('show');
                        pricingBreakdown.style.display = 'none';
                    }
                } else {
                    selectedDates.checkin = null;
                    selectedDates.checkout = null;
                    // Hide pricing breakdown
                    const pricingBreakdown = document.getElementById('pricing-breakdown');
                    if (pricingBreakdown) {
                        pricingBreakdown.classList.remove('show');
                        pricingBreakdown.style.display = 'none';
                    }
                }
            }
        });
    }
    
    function initGuestSelector() {
        const guestSelector = document.getElementById('guest-selector');
        const guestDropdown = document.getElementById('guest-dropdown');
        const guestText = guestSelector.querySelector('.guest-text');
        const dropdownArrow = guestSelector.querySelector('.dropdown-arrow');
        const rightSidebar = document.querySelector('.airbnb-property-page .right-sidebar');
        const isMobile = () => window.matchMedia('(max-width: 991px)').matches;
        const getWidget = () => rightSidebar ? rightSidebar.querySelector('.booking-widget') : null;
        const shouldApplyBottom = () => {
            const widget = getWidget();
            if (!widget) return true;
            const widgetIsActive = widget.classList.contains('active');
            const widgetHeight = widget.offsetHeight || 0;
            return !(widgetIsActive && widgetHeight > 650);
        };
        const setSidebarBottom = (value) => {
            if (rightSidebar && isMobile() && shouldApplyBottom()) {
                rightSidebar.style.bottom = value;
            }
        };
        
        // Toggle dropdown
        guestSelector.addEventListener('click', function(e) {
            e.stopPropagation();
            const isActive = guestDropdown.classList.contains('active');
            
            if (isActive) {
                guestDropdown.classList.remove('active');
                dropdownArrow.style.transform = 'rotate(0deg)';
                setSidebarBottom('0px');
            } else {
                guestDropdown.classList.add('active');
                dropdownArrow.style.transform = 'rotate(180deg)';
                setSidebarBottom('165px');
            }
        });
        
        // Close dropdown when clicking outside
        document.addEventListener('click', function(e) {
            if (!guestDropdown.contains(e.target) && !guestSelector.contains(e.target)) {
                guestDropdown.classList.remove('active');
                dropdownArrow.style.transform = 'rotate(0deg)';
                setSidebarBottom('0px');
            }
        });

        // Close on Escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                guestDropdown.classList.remove('active');
                dropdownArrow.style.transform = 'rotate(0deg)';
                setSidebarBottom('0px');
            }
        });

        // Ensure correct bottom on resize
        window.addEventListener('resize', function() {
            if (!guestDropdown.classList.contains('active')) {
                setSidebarBottom('0px');
            } else {
                setSidebarBottom('165px');
            }
        });
        
        // Guest control buttons
        const guestButtons = document.querySelectorAll('.guest-btn');
        guestButtons.forEach(button => {
            button.addEventListener('click', function() {
                const type = this.dataset.type;
                const action = this.dataset.action;
                
                if (action === 'increase') {
                    if (type === 'adults' || guestState[type] < 5) {
                        guestState[type]++;
                    }
                } else if (action === 'decrease') {
                    if (guestState[type] > 0 && !(type === 'adults' && guestState[type] === 1)) {
                        guestState[type]--;
                    }
                }
                
                updateGuestDisplay();
                updateGuestText();
            });
        });
        
        updateGuestDisplay();
        updateGuestText();
    }
    
    function updateGuestDisplay() {
        document.getElementById('adults-count').textContent = guestState.adults;
        document.getElementById('children-count').textContent = guestState.children;
        document.getElementById('infants-count').textContent = guestState.infants;
        const petsCountEl = document.getElementById('pets-count');
        if (petsCountEl) petsCountEl.textContent = guestState.pets || 0;
        
        // Update button states
        const minusButtons = document.querySelectorAll('.guest-btn.minus');
        minusButtons.forEach(button => {
            const type = button.dataset.type;
            button.disabled = (type === 'adults' && guestState[type] <= 1) || guestState[type] <= 0;
        });
        
        const plusButtons = document.querySelectorAll('.guest-btn.plus');
        plusButtons.forEach(button => {
            const type = button.dataset.type;
            button.disabled = guestState[type] >= 5;
        });
    }
    
    function updateGuestText() {
        const guestText = document.querySelector('.guest-text');
        const totalGuests = guestState.adults + guestState.children + guestState.infants;
        
        if (totalGuests === 0) {
            guestText.textContent = 'Add guests';
            guestText.classList.remove('has-selection');
        } else {
            let text = `${totalGuests} guest${totalGuests !== 1 ? 's' : ''}`;
            if (guestState.infants > 0) {
                text += `, ${guestState.infants} infant${guestState.infants !== 1 ? 's' : ''}`;
            }
            if (guestState.pets > 0) {
                text += `, ${guestState.pets} pet${guestState.pets !== 1 ? 's' : ''}`;
            }
            guestText.textContent = text;
            guestText.classList.add('has-selection');
        }
    }
    
    // Fetch pricing from Hospitable API
    async function fetchPricingFromAPI() {
        if (!selectedDates.checkin || !selectedDates.checkout) {
            return;
        }
        
        // Fetching pricing for selected dates
        
        const pricingBreakdown = document.getElementById('pricing-breakdown');
        const reserveButton = document.querySelector('.reserve-button');
        
        // Show loading state (do not change base per-night price)
        pricingBreakdown.innerHTML = '<div class="loading-pricing">Loading pricing...</div>';
        pricingBreakdown.style.display = 'block';
        reserveButton.disabled = true;
        
        try {
            // Add timeout to prevent stuck loading
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 second timeout
            
            const response = await fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'digim_get_pricing',
                    nonce: '<?php echo wp_create_nonce('digim_booking_nonce'); ?>',
                    property_uuid: '<?php echo $uuid; ?>',
                    checkin_date: formatDateForAPI(selectedDates.checkin),
                    checkout_date: formatDateForAPI(selectedDates.checkout),
                    adults: guestState.adults,
                    children: guestState.children,
                    infants: guestState.infants,
                    pets: guestState.pets || 0
                }),
                signal: controller.signal
            });
            
            clearTimeout(timeoutId);
            
            const responseText = await response.text();
            
            let data;
            try {
                data = JSON.parse(responseText);
            } catch (parseError) {
                console.error('JSON parse error:', parseError);
                console.error('Response text:', responseText);
                showPricingError('Invalid response from server. Please try again.');
                return;
            }
            
            
            if (data.success) {
                // Store listing_id and account_id from response if available
                if (data.data && data.data.listing_id) {
                    window.listingId = data.data.listing_id;
                }
                if (data.data && data.data.account_id) {
                    window.accountId = data.data.account_id;
                }
                // store quote metadata if present
                if (data.data && (data.data.quote_id || data.data.booking_url)) {
                    if (data.data.quote_id) window.quoteId = data.data.quote_id;
                    if (data.data.booking_url) window.bookingUrl = data.data.booking_url;
                    
                    console.log('Quote ID:', window.quoteId);
                    console.log('Booking URL:', window.bookingUrl);
                }
                
                updatePricingDisplay(data.data);
                // Check availability
                await checkAvailability();
            } else {
                console.error('API error:', data.data);
                
                // Check if it's a minimum stay error
                if (data.data && data.data.message && data.data.message.includes('minimum stay')) {
                    showPricingError('Minimum stay requirement not met. Please select a longer stay.');
                    return;
                }
                
                // Check if it's a 422 error with specific message
                if (data.data && data.data.raw && data.data.raw.body && data.data.raw.body.reason_phrase) {
                    const errorMsg = data.data.raw.body.reason_phrase;
                    if (errorMsg.includes('minimum stay')) {
                        showPricingError('Minimum stay requirement not met. Please select a longer stay or different dates.');
                    } else {
                        showPricingError(errorMsg);
                    }
                    return;
                }
                
                // Fallback to static pricing if API fails
                const nights = Math.ceil((selectedDates.checkout - selectedDates.checkin) / (1000 * 60 * 60 * 24));
                const fallbackPricing = {
                    base_price: pricing.basePrice,
                    cleaning_fee: pricing.cleaningFee,
                    service_fee: pricing.serviceFee,
                    security_deposit: pricing.securityDeposit,
                    currency: pricing.currency,
                    nights: nights,
                    subtotal: pricing.basePrice * nights,
                    total: (pricing.basePrice * nights) + pricing.cleaningFee + pricing.serviceFee
                };
                updatePricingDisplay(fallbackPricing);
            }
        } catch (error) {
            console.error('Pricing fetch error:', error);
            
            if (error.name === 'AbortError') {
            } else {
            }
            
            // Use fallback pricing on error
            const nights = Math.ceil((selectedDates.checkout - selectedDates.checkin) / (1000 * 60 * 60 * 24));
            const fallbackPricing = {
                base_price: pricing.basePrice,
                cleaning_fee: pricing.cleaningFee,
                service_fee: pricing.serviceFee,
                security_deposit: pricing.securityDeposit,
                currency: pricing.currency,
                nights: nights,
                subtotal: pricing.basePrice * nights,
                total: (pricing.basePrice * nights) + pricing.cleaningFee + pricing.serviceFee
            };
            updatePricingDisplay(fallbackPricing);
        } finally {
            reserveButton.disabled = false;
        }
    }
    
    // Update pricing display with API data
    function updatePricingDisplay(pricingData) {
        const pricingBreakdown = document.getElementById('pricing-breakdown');
        if (!pricingBreakdown) return;

        // Update local pricing cache
        pricing.basePrice = pricingData.base_price;
        pricing.cleaningFee = pricingData.cleaning_fee;
        pricing.serviceFee = pricingData.service_fee;
        pricing.taxes = pricingData.taxes || 0;
        pricing.securityDeposit = pricingData.security_deposit;
        pricing.currency = pricingData.currency;

        // Build the card content fresh to avoid missing elements
        pricingBreakdown.classList.add('show');
        pricingBreakdown.style.display = 'block';
        pricingBreakdown.innerHTML = `
            <div class="pricing-section">
                <h4>Price details</h4>
                <div class="price-line">
                    <span class="price-label" id="base-price-label">${pricing.currency}${pricingData.base_price.toFixed(2)} × ${pricingData.nights} nights</span>
                    <span class="price-value" id="base-price-total">${pricing.currency}${pricingData.subtotal.toFixed(2)}</span>
                </div>
                <div class="price-line">
                    <span class="price-label">Cleaning fee</span>
                    <span class="price-value" id="cleaning-fee">${pricing.currency}${pricingData.cleaning_fee.toFixed(2)}</span>
                </div>
                <div class="price-line">
                    <span class="price-label">Service fee</span>
                    <span class="price-value" id="service-fee">${pricing.currency}${pricingData.service_fee.toFixed(2)}</span>
                </div>
                <div class="price-line">
                    <span class="price-label">Taxes</span>
                    <span class="price-value" id="taxes">${pricing.currency}${(pricingData.taxes || 0).toFixed(2)}</span>
                </div>
                <div class="price-line total-line">
                    <span class="price-label">Total</span>
                    <span class="price-value" id="total-price">${pricing.currency}${pricingData.total.toFixed(2)}</span>
                </div>
            </div>
        `;
    }
    
    // Check availability
    async function checkAvailability() {
        if (!selectedDates.checkin || !selectedDates.checkout) return;
        
        try {
            const response = await fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'digim_check_availability',
                    nonce: '<?php echo wp_create_nonce('digim_booking_nonce'); ?>',
                    property_uuid: '<?php echo $uuid; ?>',
                    checkin_date: selectedDates.checkin.toISOString().split('T')[0],
                    checkout_date: selectedDates.checkout.toISOString().split('T')[0]
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                updateAvailabilityStatus(data.data.available);
            }
        } catch (error) {
            console.error('Availability check error:', error);
        }
    }
    
    // Update availability status
    function updateAvailabilityStatus(isAvailable) {
        const reserveButton = document.querySelector('.reserve-button');
        const pricingBreakdown = document.getElementById('pricing-breakdown');
        
        if (!isAvailable) {
            reserveButton.disabled = true;
            reserveButton.innerHTML = '<span class="reserve-text">Not Available</span>';
            
            // Add availability warning
            let warning = pricingBreakdown.querySelector('.availability-warning');
            if (!warning) {
                warning = document.createElement('div');
                warning.className = 'availability-warning';
                warning.style.cssText = 'color: #e31c5f; font-size: 14px; margin-bottom: 12px; text-align: center;';
                pricingBreakdown.insertBefore(warning, pricingBreakdown.firstChild);
            }
            warning.textContent = 'These dates are not available for booking';
        } else {
            reserveButton.disabled = false;
            reserveButton.innerHTML = '<span class="reserve-text">Reserve</span>';
            
            // Remove warning if exists
            const warning = pricingBreakdown.querySelector('.availability-warning');
            if (warning) {
                warning.remove();
            }
        }
    }
    
    // Show pricing error
    function showPricingError(message) {
        const pricingBreakdown = document.getElementById('pricing-breakdown');
        pricingBreakdown.innerHTML = `<div class="pricing-error" style="color: #e31c5f; text-align: center; padding: 20px;">${message}</div>`;
        pricingBreakdown.style.display = 'block';
    }
    
    function initFormSubmission() {
        const form = document.getElementById('booking-form');
        const reserveButton = document.querySelector('.reserve-button');
        
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            
            // Validate form
            if (!selectedDates.checkin || !selectedDates.checkout) {
                alert('Please select check-in and check-out dates');
                return;
            }
            
            if (guestState.adults + guestState.children + guestState.infants === 0) {
                alert('Please select number of guests');
                return;
            }
            
            // Show loading state
            reserveButton.disabled = true;
            reserveButton.innerHTML = '<span class="reserve-text">Processing...</span>';
            
            // Prepare booking data
            const bookingData = {
                property_uuid: '<?php echo $uuid; ?>',
                checkin_date: selectedDates.checkin.toISOString().split('T')[0],
                checkout_date: selectedDates.checkout.toISOString().split('T')[0],
                adults: guestState.adults,
                children: guestState.children,
                infants: guestState.infants,
                total_guests: guestState.adults + guestState.children + guestState.infants
            };
            
            // Use the existing formatDateForAPI function

            // Use booking_url directly from quote if available
            if (window.bookingUrl && window.quoteId) {
                // Construct the correct booking URL format: book/{property_uuid}/{property_id}/{quote_id}
                // Extract property ID from the original booking URL
                const urlParts = window.bookingUrl.split('/');
                const propertyId = urlParts[urlParts.length - 2]; // Get property ID before quote_id
                
                // Get the property UUID from the current page
                const propertyUuid = '<?php echo $uuid; ?>';
                
                // Construct the correct URL format with query parameters
                let finalBookingUrl = `https://booking.hospitable.com/book/${propertyUuid}/${propertyId}/${window.quoteId}`;
                
                // Add query parameters for guests and pets
                const queryParams = new URLSearchParams();
                queryParams.append('adults', guestState.adults);
                queryParams.append('children', guestState.children);
                queryParams.append('infants', guestState.infants);
                if (guestState.pets > 0) {
                    queryParams.append('pets', guestState.pets);
                }
                
                const queryString = queryParams.toString();
                if (queryString) {
                    finalBookingUrl += '?' + queryString;
                }
                
                console.log('Original booking URL:', window.bookingUrl);
                console.log('Property UUID:', propertyUuid);
                console.log('Property ID:', propertyId);
                console.log('Quote ID:', window.quoteId);
                console.log('Final booking URL:', finalBookingUrl);
                
                window.location.href = finalBookingUrl;
                return;
            }
            
            // If no booking_url, show error
            alert('Booking URL not available. Please try selecting dates again.');
            
            // Reset button state
            reserveButton.disabled = false;
            reserveButton.innerHTML = '<span class="reserve-text">Reserve</span>';
        });
    }
    
    // Function to submit booking to Hospitable API
    async function submitBooking(bookingData) {
        try {
            
            const response = await fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'digim_submit_booking',
                    nonce: '<?php echo wp_create_nonce('digim_booking_nonce'); ?>',
                    ...bookingData
                })
            });
            
            const responseText = await response.text();
            
            let data;
            try {
                data = JSON.parse(responseText);
            } catch (parseError) {
                console.error('JSON parse error:', parseError);
                console.error('Response text:', responseText);
                return {
                    success: false,
                    message: 'Invalid response from server',
                    data: { message: responseText }
                };
            }
            
            return data;
        } catch (error) {
            console.error('Booking submission error:', error);
            return {
                success: false,
                message: error.message || 'Network error',
                error: error
            };
        }
    }

    // Create reservation and return checkout URL (server makes API call)
    async function createReservation(bookingData) {
        try {
            const res = await fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'digim_create_reservation',
                    nonce: '<?php echo wp_create_nonce('digim_booking_nonce'); ?>',
                    ...bookingData
                })
            });
            const txt = await res.text();
            try {
                return JSON.parse(txt);
            } catch (e) {
                return { success: false, message: 'Invalid reservation response', raw: txt };
            }
        } catch (e) {
            return { success: false, message: e.message || 'Network error' };
        }
    }
}

// Description truncation functionality
let isDescriptionExpanded = false;
let originalDescription = '';
let truncatedDescription = '';

function initDescriptionTruncation() {
    const descriptionText = document.querySelector('.description-text');
    const showMoreBtn = document.querySelector('.show-more-btn');
    
    if (!descriptionText || !showMoreBtn) return;
    
    originalDescription = descriptionText.innerHTML;
    const maxLength = 300; // Character limit for truncation
    
    if (originalDescription.length > maxLength) {
        // Create truncated version
        truncatedDescription = originalDescription.substring(0, maxLength);
        
        // Find the last complete word within the limit
        const lastSpaceIndex = truncatedDescription.lastIndexOf(' ');
        if (lastSpaceIndex > maxLength * 0.8) { // Only use last space if it's not too far back
            truncatedDescription = truncatedDescription.substring(0, lastSpaceIndex);
        }
        
        truncatedDescription += '...';
        
        // Set initial state
        descriptionText.innerHTML = truncatedDescription;
        showMoreBtn.style.display = 'flex';
    }
}

function toggleDescription() {
    const descriptionText = document.querySelector('.description-text');
    const showMoreBtn = document.querySelector('.show-more-btn');
    const btnText = showMoreBtn.querySelector('.btn-text');
    const btnIcon = showMoreBtn.querySelector('.btn-icon');
    
    if (!descriptionText || !showMoreBtn) return;
    
    if (isDescriptionExpanded) {
        // Collapse
        descriptionText.innerHTML = truncatedDescription;
        btnText.textContent = 'Show more';
        btnIcon.style.transform = 'rotate(0deg)';
        isDescriptionExpanded = false;
    } else {
        // Expand
        descriptionText.innerHTML = originalDescription;
        btnText.textContent = 'Show less';
        btnIcon.style.transform = 'rotate(180deg)';
        isDescriptionExpanded = true;
    }
}

// Review toggle functionality
function toggleReviewFullText(button) {
    const reviewCard = button.closest('.review-card');
    const reviewText = reviewCard.querySelector('.review-text');
    const currentText = reviewText.textContent.trim();
    
    // Get the stored full text from the button's data attribute
    const fullText = button.dataset.fullText || currentText;
    const truncatedText = fullText.substring(0, 200) + '...';
    
    if (currentText.endsWith('...') || currentText === truncatedText) {
        // Show full text
        reviewText.textContent = fullText;
        button.textContent = 'Show less';
    } else {
        // Show truncated text
        reviewText.textContent = truncatedText;
        button.textContent = 'Show more';
    }
}

// Load More Reviews Functionality
<?php if (count($reviews) > 3): ?>
const allReviewsData = <?php echo json_encode($reviews); ?>;
const reviewsGrid = document.getElementById('reviews-grid');
const loadMoreBtn = document.getElementById('load-more-reviews');

if (loadMoreBtn) {
    loadMoreBtn.addEventListener('click', function() {
        const loaded = parseInt(this.dataset.loaded);
        const total = parseInt(this.dataset.total);
        const loadCount = 2; // Load 2 more at a time
        
        // Show loading state
        this.classList.add('loading');
        this.disabled = true;
        
        // Simulate loading delay (you can remove this in production)
        setTimeout(() => {
            // Get next batch of reviews
            const nextBatch = allReviewsData.slice(loaded, loaded + loadCount);
            
            // Render new reviews
            nextBatch.forEach(review => {
                const rating = parseInt(review.public?.rating || 5);
                const reviewText = review.public?.review || '';
                const reviewDate = review.reviewed_at || '';
                const platform = review.platform || '';
                
                // Format date
                let formattedDate = '';
                if (reviewDate) {
                    try {
                        const dateObj = new Date(reviewDate);
                        formattedDate = dateObj.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
                    } catch (e) {
                        formattedDate = reviewDate;
                    }
                }
                
                const reviewerName = (platform.charAt(0).toUpperCase() + platform.slice(1)) + ' Guest';
                const reviewerInitial = platform.charAt(0).toUpperCase();
                
                // Truncate review text
                const maxLength = 200;
                let displayText = reviewText;
                let showMoreBtn = false;
                if (reviewText.length > maxLength) {
                    displayText = reviewText.substring(0, maxLength) + '...';
                    showMoreBtn = true;
                }
                
                // Create stars HTML
                let starsHtml = '';
                for (let i = 0; i < 5; i++) {
                    starsHtml += `<span class="star ${i < rating ? 'filled' : ''}">★</span>`;
                }
                
                // Create review card HTML
                const reviewCardHtml = `
                    <div class="review-card">
                        <div class="review-header">
                            <div class="reviewer-photo">
                                <div class="reviewer-initial">${reviewerInitial}</div>
                            </div>
                            <div class="reviewer-info">
                                <div class="reviewer-name">${reviewerName}</div>
                                <div class="reviewer-tenure">Guest on ${platform.charAt(0).toUpperCase() + platform.slice(1)}</div>
                            </div>
                        </div>
                        <div class="review-rating">
                            ${starsHtml}
                        </div>
                        <div class="review-meta">
                            <span>${formattedDate}</span>
                            <span> • </span>
                            <span>Stayed a few nights</span>
                        </div>
                        <div class="review-text">
                            ${displayText}
                        </div>
                        ${showMoreBtn ? `<button class="show-more-review" onclick="toggleReviewFullText(this)" data-full-text="${reviewText.replace(/"/g, '&quot;')}">Show more</button>` : ''}
                    </div>
                `;
                
                reviewsGrid.insertAdjacentHTML('beforeend', reviewCardHtml);
            });
            
            // Update loaded count
            const newLoaded = loaded + loadCount;
            this.dataset.loaded = newLoaded;
            
            // Update button text or hide if all loaded
            if (newLoaded >= total) {
                this.remove();
            } else {
                const remaining = total - newLoaded;
                this.textContent = `Show ${Math.min(loadCount, remaining)} more reviews`;
                this.classList.remove('loading');
                this.disabled = false;
            }
        }, 300);
    });
}
<?php endif; ?>
</script>

<link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>

<!-- Flatpickr for date picker -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

<?php get_footer(); ?>