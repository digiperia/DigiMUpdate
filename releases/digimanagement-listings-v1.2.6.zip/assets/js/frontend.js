document.addEventListener("DOMContentLoaded", function () {
  const initDateRangePicker = function() {
    const dateInput = document.querySelector(".flatpickr-range");
    if (!dateInput || (typeof jQuery === 'undefined' || typeof jQuery.fn.daterangepicker === 'undefined')) {
      return;
    }

    // Check if already initialized
    if (dateInput._digimDaterangepickerReady) {
      return;
    }

    const checkinHidden = document.querySelector(".checkin-hidden");
    const checkoutHidden = document.querySelector(".checkout-hidden");
    const dateRangeInput = document.querySelector("input[name='date_range']");

    // Ensure moment.js is available and set to English locale for correct date calculations
    if (typeof moment === 'undefined') {
      console.error('Moment.js is required for DateRangePicker');
      return;
    }
    
    // Set locale to English to ensure correct day/month names and date calculations
    moment.locale('en');

    // Set initial dates if hidden inputs have values
    let startDate = null;
    let endDate = null;
    if (checkinHidden && checkoutHidden && checkinHidden.value && checkoutHidden.value) {
      startDate = moment(checkinHidden.value, 'YYYY-MM-DD', true);
      endDate = moment(checkoutHidden.value, 'YYYY-MM-DD', true);
      if (dateRangeInput && startDate.isValid() && endDate.isValid()) {
        dateRangeInput.value = startDate.format('MMM D, YYYY') + ' to ' + endDate.format('MMM D, YYYY');
      }
    }

    jQuery(dateInput).daterangepicker({
      startDate: startDate && startDate.isValid() ? startDate : moment(),
      endDate: endDate && endDate.isValid() ? endDate : null,
      minDate: moment(),
      singleDatePicker: false,
      autoUpdateInput: true,
      autoApply: true, // Automatically apply selection when both dates are chosen
      locale: {
        format: 'MMM D, YYYY',
        separator: ' to ',
        applyLabel: 'Apply',
        cancelLabel: 'Cancel',
        fromLabel: 'From',
        toLabel: 'To',
        customRangeLabel: 'Custom',
        weekLabel: 'W',
        daysOfWeek: moment.weekdaysMin(),
        monthNames: moment.months(),
        firstDay: moment.localeData().firstDayOfWeek()
      },
      opens: 'left'
    }, function(start, end, label) {
      const checkinStr = start.format('YYYY-MM-DD');
      const checkoutStr = end.format('YYYY-MM-DD');

      if (checkinHidden) checkinHidden.value = checkinStr;
      if (checkoutHidden) checkoutHidden.value = checkoutStr;

      if (dateRangeInput) {
        dateRangeInput.value = start.format('MMM D, YYYY') + ' to ' + end.format('MMM D, YYYY');
      }
      
      // Hide calendar after dates are selected (similar to property-single.php)
      if (start && end) {
        setTimeout(function() {
          const calendar = document.querySelector('.daterangepicker');
          if (calendar) {
            calendar.style.display = 'none';
          }
          // Also try jQuery method if available
          if (typeof jQuery !== 'undefined') {
            const $calendar = jQuery('.daterangepicker');
            if ($calendar.length) {
              $calendar.hide();
            }
          }
        }, 100);
      }
    });

    // Set display format (MMM D, YYYY format for search-group datecal - e.g., "Jan 15, 2024")
    if (dateRangeInput && startDate && endDate) {
      dateRangeInput.value = startDate.format('MMM D, YYYY') + ' to ' + endDate.format('MMM D, YYYY');
    }

    dateInput._digimDaterangepickerReady = true;
    
    // Hide apply/cancel buttons since we use autoApply
    jQuery(dateInput).on('show.daterangepicker', function() {
      setTimeout(function() {
        const $calendar = jQuery('.daterangepicker');
        if ($calendar.length) {
          $calendar.find('.drp-buttons, .applyBtn, .cancelBtn').hide();
          $calendar.find('.drp-buttons').css('display', 'none');
        }
      }, 10);
    });
    
    // Also listen for when both dates are selected to ensure calendar closes
    jQuery(dateInput).on('apply.daterangepicker', function() {
      setTimeout(function() {
        const $calendar = jQuery('.daterangepicker');
        if ($calendar.length) {
          $calendar.hide();
        }
        // Also try vanilla JS method
        const calendar = document.querySelector('.daterangepicker');
        if (calendar) {
          calendar.style.display = 'none';
        }
      }, 50);
    });
    
    // Listen for date clicks to hide calendar when both dates are selected
    jQuery(document).on('click', '.daterangepicker td.available', function() {
      setTimeout(function() {
        const $calendar = jQuery('.daterangepicker');
        if ($calendar.length) {
          const hasStartDate = $calendar.find('.start-date').length > 0;
          const hasEndDate = $calendar.find('.end-date').length > 0;
          if (hasStartDate && hasEndDate) {
            // Both dates selected, hide calendar
            setTimeout(function() {
              $calendar.hide();
              const calendar = document.querySelector('.daterangepicker');
              if (calendar) {
                calendar.style.display = 'none';
              }
            }, 100);
          }
        }
      }, 50);
    });
  };

  // Try to initialize when DOM and libraries are ready
  if (typeof jQuery !== 'undefined' && typeof moment !== 'undefined' && typeof jQuery.fn.daterangepicker !== 'undefined') {
    initDateRangePicker();
  } else {
    // Wait for libraries to load
    let attempts = 0;
    const checkLibraries = setInterval(function() {
      attempts++;
      if ((typeof jQuery !== 'undefined' && typeof moment !== 'undefined' && typeof jQuery.fn.daterangepicker !== 'undefined') || attempts > 50) {
        clearInterval(checkLibraries);
        if (attempts <= 50) {
          initDateRangePicker();
        }
      }
    }, 100);
  }

  // Handle unavailable date clicks with better UX
  function handleUnavailableDateClicks() {
    // Use event delegation to handle clicks on calendar cells
    document.addEventListener('click', function(e) {
      const calendar = document.querySelector('.daterangepicker');
      if (!calendar || !calendar.contains(e.target)) {
        return;
      }

      // Check if clicked element is an unavailable date
      const clickedCell = e.target.closest('td.off');
      if (!clickedCell) {
        return;
      }

      // Prevent default behavior
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();

      // Add visual feedback - shake animation
      clickedCell.classList.add('digim-date-shake');
      
      // Remove shake class after animation
      setTimeout(function() {
        clickedCell.classList.remove('digim-date-shake');
      }, 500);

      // Optional: Show a tooltip or message
      const dateText = clickedCell.textContent.trim();
      if (dateText) {
        // Create a temporary tooltip
        const tooltip = document.createElement('div');
        tooltip.className = 'digim-unavailable-tooltip';
        tooltip.textContent = 'This date is not available';
        tooltip.style.cssText = `
          position: absolute;
          background: rgba(220, 53, 69, 0.95);
          color: white;
          padding: 8px 12px;
          border-radius: 6px;
          font-size: 12px;
          font-weight: 500;
          pointer-events: none;
          z-index: 10000;
          white-space: nowrap;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
        `;

        const rect = clickedCell.getBoundingClientRect();
        tooltip.style.left = rect.left + (rect.width / 2) - 80 + 'px';
        tooltip.style.top = rect.top - 35 + 'px';

        document.body.appendChild(tooltip);

        // Remove tooltip after 2 seconds
        setTimeout(function() {
          if (tooltip.parentNode) {
            tooltip.parentNode.removeChild(tooltip);
          }
        }, 2000);
      }
    }, true); // Use capture phase to intercept before daterangepicker handles it
  }

  // Initialize unavailable date click handler
  handleUnavailableDateClicks();
});

// Mobile: lock body scroll when datepicker is opened
document.addEventListener("DOMContentLoaded", function () {
  const isMobile = () => window.innerWidth <= 991;
  const addLock = () => { if (isMobile()) document.body.classList.add("digim-no-scroll"); };
  const removeLock = () => document.body.classList.remove("digim-no-scroll");

  // Try common selectors for the date input used by daterangepicker
  const dateInputs = [
    document.querySelector("#date-range"),
    document.querySelector(".flatpickr-range"),
    document.querySelector(".airbnb-booking-form .date-input")
  ].filter(Boolean);

  dateInputs.forEach((el) => {
    el.addEventListener("focus", addLock);
    el.addEventListener("click", addLock);
    el.addEventListener("blur", removeLock);
  });

  // If daterangepicker calendar closes (click outside), remove lock
  document.addEventListener("click", function (e) {
    const calendarOpen = document.querySelector(".daterangepicker");
    const clickedInsideCalendar = e.target.closest && e.target.closest(".daterangepicker");
    const clickedDateInput = e.target.closest && e.target.closest("#date-range, .flatpickr-range, .airbnb-booking-form .date-input");
    if (!calendarOpen || (!clickedInsideCalendar && !clickedDateInput)) {
      removeLock();
    }
  });

  // On resize to desktop, ensure unlock
  window.addEventListener("resize", function () {
    if (!isMobile()) removeLock();
  });
});

// Fix daterangepicker calendar positioning to follow the input when scrolling
document.addEventListener("DOMContentLoaded", function () {
  let activeCalendar = null;
  let activeInput = null;

  // Monitor for daterangepicker calendar opening
  const observer = new MutationObserver(function(mutations) {
    mutations.forEach(function(mutation) {
      if (mutation.type === 'childList') {
        const calendar = document.querySelector('.daterangepicker');
        if (calendar && !activeCalendar && calendar.style.display !== 'none') {
          activeCalendar = calendar;
          // Find the associated input
          activeInput = document.querySelector('.flatpickr-range:focus') ||
                       document.querySelector('#date-range:focus');
          
          if (activeInput) {
            // Start tracking scroll to reposition calendar
            window.addEventListener('scroll', repositionCalendar, { passive: true });
            window.addEventListener('resize', repositionCalendar, { passive: true });
          }
        } else if (calendar && (calendar.style.display === 'none' || !document.body.contains(calendar)) && activeCalendar === calendar) {
          // Calendar closed, stop tracking
          activeCalendar = null;
          activeInput = null;
          window.removeEventListener('scroll', repositionCalendar);
          window.removeEventListener('resize', repositionCalendar);
        }
      }
    });
  });

  // Start observing
  observer.observe(document.body, { childList: true, subtree: true });

  function repositionCalendar() {
    if (activeCalendar && activeInput && activeCalendar.style.display !== 'none') {
      const inputRect = activeInput.getBoundingClientRect();
      const calendar = activeCalendar;
      
      // Position calendar relative to input (daterangepicker handles its own positioning, but we can adjust)
      // The library handles most positioning automatically
      if (inputRect) {
        calendar.style.zIndex = '1001';
      }
    }
  }
});

document.addEventListener("DOMContentLoaded", function () {
  const trigger = document.querySelector(
    ".digimanagement-mobile-trigger .mobilesearchdestination"
  );
  const modal = document.querySelector(".digimanagement-mobile-modal");
  const closeBtn = document.querySelector(".digim-close-modal");

  if (trigger && modal && closeBtn) {
    trigger.addEventListener("click", () => {
      modal.classList.add("active");
    });

    closeBtn.addEventListener("click", () => {
      modal.classList.remove("active");
    });

    // Optional: close on outside click
    modal.addEventListener("click", (e) => {
      if (e.target === modal) {
        modal.classList.remove("active");
      }
    });
  }
});

// Mobile booking widget expand/collapse functionality
// Use event delegation so it works even if elements render later
document.addEventListener("click", function (e) {
  const btn = e.target.closest(".mobile-expand-btn");
  if (!btn) return;

  const widget = btn.closest(".booking-widget");
  if (!widget) return;

  const form = widget.querySelector(".booking-form");
  const header = widget.querySelector(".booking-header");
  const rightSidebar = widget.closest(".right-sidebar");
  if (!form || !header) return;

  e.preventDefault();
  const isActive = form.classList.toggle("active");
  header.classList.toggle("active", isActive);
  widget.classList.toggle("active", isActive);
  if (rightSidebar) rightSidebar.classList.toggle("active", isActive);
  
  // Update button text based on active state
  btn.textContent = isActive ? "Collapse" : "Expand";
});

// Function to initialize a single gallery
function initDigimGallery(wrapper) {
  // Skip if already initialized
  if (wrapper.dataset.digimGalleryInitialized === 'true') {
    return;
  }
  
  wrapper.dataset.digimGalleryInitialized = 'true';
    const slides = Array.from(
      wrapper.querySelectorAll("[data-digim-gallery-slide]")
    );
    if (slides.length <= 1) {
      // Nothing to slide – ensure the single slide is visible
      const single = slides[0];
      if (single) {
        single.classList.add("is-active");
      }
      return;
    }

    const prevBtn = wrapper.querySelector("[data-digim-gallery-prev]");
    const nextBtn = wrapper.querySelector("[data-digim-gallery-next]");
    const dots = Array.from(
      wrapper.querySelectorAll("[data-digim-gallery-dot]")
    );
    const counter = wrapper.querySelector(
      ".digim-gallery-counter .current-index"
    );

    // Debug: Check if buttons are found
    if (!prevBtn || !nextBtn) {
      console.warn('DigiM Gallery: Navigation buttons not found', { 
        prevBtn, 
        nextBtn, 
        wrapper,
        hasPrev: !!prevBtn,
        hasNext: !!nextBtn,
        allButtons: wrapper.querySelectorAll('button')
      });
    } else {
      console.log('DigiM Gallery: Navigation buttons found', { prevBtn, nextBtn });
    }

    let activeIndex = 0;

    const applyState = (newIndex) => {
      const maxIndex = slides.length - 1;
      if (newIndex < 0) {
        newIndex = maxIndex;
      } else if (newIndex > maxIndex) {
        newIndex = 0;
      }

      slides.forEach((slide, idx) =>
        slide.classList.toggle("is-active", idx === newIndex)
      );
      dots.forEach((dot, idx) =>
        dot.classList.toggle("is-active", idx === newIndex)
      );
      if (counter) {
        counter.textContent = newIndex + 1;
      }
      activeIndex = newIndex;
      
      // Update modal gallery if it exists
      updateModalGallery(newIndex, slides);
    };
    
    // Function to update modal gallery when card gallery changes
    const updateModalGallery = (slideIndex, cardSlides) => {
      if (!cardSlides || cardSlides.length === 0) return;
      
      const activeSlide = cardSlides[slideIndex];
      if (!activeSlide) return;
      
      const activeImage = activeSlide.querySelector('img');
      if (!activeImage) return;
      
      const activeImageSrc = activeImage.src || activeImage.getAttribute('src');
      if (!activeImageSrc) return;
      
      // Helper function to normalize URLs for comparison
      const normalizeUrl = (url) => {
        if (!url) return '';
        try {
          const urlObj = new URL(url, window.location.href);
          // Remove query params and hash for comparison
          return urlObj.pathname;
        } catch {
          // Fallback: remove protocol and domain
          return url.replace(/^https?:\/\/[^\/]+/, '').split('?')[0].split('#')[0];
        }
      };
      
      const normalizedActiveSrc = normalizeUrl(activeImageSrc);
      
      // Update main-image if it exists (property single page)
      const mainImage = document.getElementById('main-image');
      if (mainImage) {
        mainImage.src = activeImageSrc;
        
        // Also update currentSlide if the images array exists (from property-single.php)
        if (typeof images !== 'undefined' && Array.isArray(images) && typeof currentSlide !== 'undefined') {
          const imageIndex = images.findIndex(img => {
            return normalizeUrl(img) === normalizedActiveSrc;
          });
          
          if (imageIndex >= 0) {
            currentSlide = imageIndex;
            if (typeof updateSlider === 'function') {
              updateSlider();
            }
            if (typeof updateSliderCounter === 'function') {
              updateSliderCounter();
            }
          }
        }
      }
      
      // Update modal gallery images visibility
      const modalGallery = document.querySelector('.modal-gallery');
      if (modalGallery) {
        const modalImages = modalGallery.querySelectorAll('.modal-image');
        let foundMatch = false;
        
        modalImages.forEach((modalImg, idx) => {
          const modalImgElement = modalImg.querySelector('img');
          if (modalImgElement) {
            const modalImgSrc = modalImgElement.src || modalImgElement.getAttribute('src');
            const normalizedModalSrc = normalizeUrl(modalImgSrc);
            
            // Check if this modal image matches the active card image
            if (normalizedModalSrc === normalizedActiveSrc) {
              // Make this modal image active/visible
              modalImg.classList.add('is-active');
              modalImg.style.display = 'block';
              foundMatch = true;
              
              // Scroll modal image into view if modal is open
              const photosModal = document.getElementById('photos-modal');
              if (photosModal && (photosModal.style.display === 'block' || photosModal.classList.contains('active'))) {
                setTimeout(() => {
                  modalImg.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
                }, 50);
              }
            } else {
              modalImg.classList.remove('is-active');
            }
          }
        });
        
        // If no exact match found, try to find by index
        if (!foundMatch && modalImages.length > slideIndex) {
          const targetModalImg = modalImages[slideIndex];
          if (targetModalImg) {
            targetModalImg.classList.add('is-active');
            targetModalImg.style.display = 'block';
            
            const photosModal = document.getElementById('photos-modal');
            if (photosModal && (photosModal.style.display === 'block' || photosModal.classList.contains('active'))) {
              setTimeout(() => {
                targetModalImg.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
              }, 50);
            }
          }
        }
      }
      
      // Update lightgallery if it's open
      if (typeof lightGallery !== 'undefined') {
        // Try to find the lightgallery instance and update it
        const lgContainers = document.querySelectorAll('.lg-container');
        lgContainers.forEach(lgContainer => {
          try {
            const lgInstance = lgContainer.lgData || (lgContainer.lgData = {});
            if (lgInstance && lgInstance.items) {
              const lgItems = lgInstance.items || [];
              const lgIndex = lgItems.findIndex(item => {
                const itemSrc = item.src || item.thumb || '';
                return normalizeUrl(itemSrc) === normalizedActiveSrc;
              });
              
              // If found by URL match
              if (lgIndex >= 0) {
                if (lgInstance.index !== lgIndex && lgInstance.slide) {
                  lgInstance.slide(lgIndex, false, false, 'prev');
                }
              } else if (slideIndex < lgItems.length) {
                // Fallback: use index
                if (lgInstance.index !== slideIndex && lgInstance.slide) {
                  lgInstance.slide(slideIndex, false, false, 'prev');
                }
              }
            }
          } catch (e) {
            // Silently fail if lightgallery API is not available
            console.debug('LightGallery update failed:', e);
          }
        });
      }
    };

    const goNext = () => applyState(activeIndex + 1);
    const goPrev = () => applyState(activeIndex - 1);


    // Store button references for later use
    let activePrevBtn = prevBtn;
    let activeNextBtn = nextBtn;

    if (prevBtn) {
      // Ensure button is clickable and on top
      prevBtn.style.pointerEvents = 'auto';
      prevBtn.style.cursor = 'pointer';
      prevBtn.style.zIndex = '1000';
      prevBtn.style.position = 'absolute';
      
      // Create a click handler that definitely works
      const prevClickHandler = function(event) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        goPrev();
        return false;
      };
      
      // Add click handler in capture phase (runs first, highest priority)
      prevBtn.addEventListener("click", prevClickHandler, true);
    }

    if (nextBtn) {
      // Ensure button is clickable and on top
      nextBtn.style.pointerEvents = 'auto';
      nextBtn.style.cursor = 'pointer';
      nextBtn.style.zIndex = '1000';
      nextBtn.style.position = 'absolute';
      
      // Create a click handler that definitely works
      const nextClickHandler = function(event) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        goNext();
        return false;
      };
      
      // Add click handler in capture phase (runs first, highest priority)
      nextBtn.addEventListener("click", nextClickHandler, true);
    }

    dots.forEach((dot, idx) => {
      dot.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        applyState(idx);
      });
    });

    // Enable keyboard navigation
    wrapper.setAttribute("tabindex", "0");
    wrapper.addEventListener("keydown", (event) => {
      if (event.key === "ArrowRight") {
        event.preventDefault();
        goNext();
      } else if (event.key === "ArrowLeft") {
        event.preventDefault();
        goPrev();
      }
    });

    // Basic touch support
    let touchStartX = null;
    const onTouchStart = (event) => {
      const touch = event.touches[0];
      touchStartX = touch ? touch.clientX : null;
    };
    const onTouchEnd = (event) => {
      if (touchStartX === null) {
        return;
      }
      const touch = event.changedTouches[0];
      if (!touch) {
        touchStartX = null;
        return;
      }
      const distance = touch.clientX - touchStartX;
      const threshold = 40;
      if (Math.abs(distance) > threshold) {
        if (distance < 0) {
          goNext();
        } else {
          goPrev();
        }
      }
      touchStartX = null;
    };

    wrapper.addEventListener("touchstart", onTouchStart, { passive: true });
    wrapper.addEventListener("touchend", onTouchEnd);

    // Mouse drag support for desktop
    let mouseStartX = null;
    let isDragging = false;
    const galleryTrack = wrapper.querySelector("[data-digim-gallery-track]");
    const dragTarget = galleryTrack || wrapper;

    const onMouseDown = (event) => {
      // Ignore if clicking on navigation buttons or dots
      if (
        event.target.closest("[data-digim-gallery-prev]") ||
        event.target.closest("[data-digim-gallery-next]") ||
        event.target.closest("[data-digim-gallery-dot]")
      ) {
        return;
      }

      // Prevent image dragging
      event.preventDefault();
      
      mouseStartX = event.clientX;
      isDragging = true;
      
      // Add dragging class for visual feedback
      wrapper.classList.add("is-dragging");
      
      // Prevent text selection while dragging
      wrapper.style.userSelect = "none";
    };

    const onMouseMove = (event) => {
      if (!isDragging || mouseStartX === null) {
        return;
      }

      // Prevent default image dragging
      event.preventDefault();
    };

    const onMouseUp = (event) => {
      if (!isDragging || mouseStartX === null) {
        return;
      }

      const distance = event.clientX - mouseStartX;
      const threshold = 50; // Minimum drag distance to trigger slide change

      if (Math.abs(distance) > threshold) {
        if (distance < 0) {
          // Dragged left - go to next
          goNext();
        } else {
          // Dragged right - go to previous
          goPrev();
        }
      }

      // Reset drag state
      mouseStartX = null;
      isDragging = false;
      wrapper.classList.remove("is-dragging");
      wrapper.style.userSelect = "";
    };

    const onMouseLeave = () => {
      // Reset drag state if mouse leaves the gallery
      if (isDragging) {
        mouseStartX = null;
        isDragging = false;
        wrapper.classList.remove("is-dragging");
        wrapper.style.userSelect = "";
      }
    };

    // Add mouse event listeners
    dragTarget.addEventListener("mousedown", onMouseDown);
    document.addEventListener("mousemove", onMouseMove);
    document.addEventListener("mouseup", onMouseUp);
    wrapper.addEventListener("mouseleave", onMouseLeave);

    // Prevent image drag behavior on images
    const galleryImages = wrapper.querySelectorAll("[data-digim-gallery-slide] img");
    galleryImages.forEach((img) => {
      img.addEventListener("dragstart", (e) => {
        e.preventDefault();
      });
    });

    // Mousepad horizontal scroll support (wheel events) - one slide per scroll, slow and controlled
    let wheelTimeout = null;
    let lastSlideChange = 0;
    let isProcessingWheel = false;
    const WHEEL_COOLDOWN = 800; // Minimum time between slide changes (ms) - much slower
    
    const onWheel = (event) => {
      const now = Date.now();
      const timeSinceLastChange = now - lastSlideChange;
      
      // If we're still in cooldown period, block ALL wheel events
      if (timeSinceLastChange < WHEEL_COOLDOWN || isProcessingWheel) {
        // Check if this is horizontal scroll - if so, prevent page scroll
        const isShiftPressed = event.shiftKey;
        let deltaX = event.deltaX;
        const deltaY = event.deltaY;
        
        if (isShiftPressed && Math.abs(deltaY) > Math.abs(deltaX)) {
          deltaX = deltaY;
        }
        
        const isHorizontalScroll = Math.abs(deltaX) > Math.abs(deltaY) * 0.5;
        
        if (isHorizontalScroll || isShiftPressed) {
          // Block horizontal scroll during cooldown
          event.preventDefault();
          event.stopPropagation();
        }
        // Allow vertical scroll to pass through
        return;
      }
      
      // Check if shift key is pressed (common way to scroll horizontally)
      const isShiftPressed = event.shiftKey;
      
      // Get scroll deltas
      let deltaX = event.deltaX;
      const deltaY = event.deltaY;
      
      // If shift is pressed, treat vertical scroll as horizontal
      if (isShiftPressed && Math.abs(deltaY) > Math.abs(deltaX)) {
        deltaX = deltaY;
      }
      
      // Determine if this is primarily horizontal or vertical scroll
      const isHorizontalScroll = Math.abs(deltaX) > Math.abs(deltaY) * 0.5;
      
      // Only handle horizontal scroll - let vertical scroll pass through to page
      if (!isHorizontalScroll && !isShiftPressed) {
        // This is vertical scroll - allow page to scroll normally
        return;
      }
      
      // This is horizontal scroll - prevent page scroll and handle gallery
      event.preventDefault();
      event.stopPropagation();
      
      // Clear any pending timeout
      if (wheelTimeout) {
        clearTimeout(wheelTimeout);
        wheelTimeout = null;
      }
      
      // Mark as processing immediately to block subsequent events
      isProcessingWheel = true;
      
      // Change slide immediately
      if (deltaX > 0) {
        // Scrolled right - go to next
        goNext();
      } else {
        // Scrolled left - go to previous
        goPrev();
      }
      
      // Update last slide change time
      lastSlideChange = now;
      
      // Reset processing flag after cooldown
      setTimeout(() => {
        isProcessingWheel = false;
      }, WHEEL_COOLDOWN);
    };

    // Add wheel event listener to gallery track and wrapper
    // Use capture phase to catch events before they bubble to page
    const wheelTarget = galleryTrack || wrapper;
    wheelTarget.addEventListener("wheel", onWheel, { passive: false, capture: true });
    
    // Also add to wrapper to catch events on the entire gallery area
    wrapper.addEventListener("wheel", onWheel, { passive: false, capture: true });
    
    // Also add to the card media container to ensure we catch all events
    const cardMedia = wrapper.closest('.digim-card-media');
    if (cardMedia) {
      cardMedia.addEventListener("wheel", onWheel, { passive: false, capture: true });
    }

    // Prevent card link navigation when clicking on gallery controls
    const cardLink = wrapper.closest('.digimanagement-card');
    if (cardLink) {
      // Add click handler to prevent navigation when clicking gallery controls
      // Use bubble phase so button handlers in capture phase run first
      const preventNavigation = (event) => {
        // Check if click is on gallery controls
        const target = event.target;
        const isGalleryControl = 
          target.closest("[data-digim-gallery-prev]") ||
          target.closest("[data-digim-gallery-next]") ||
          target.closest("[data-digim-gallery-dot]") ||
          target.closest(".digim-gallery-nav") ||
          target.closest(".digim-gallery-indicators") ||
          target.matches("[data-digim-gallery-prev]") ||
          target.matches("[data-digim-gallery-next]") ||
          target.matches("[data-digim-gallery-dot]") ||
          target.matches(".digim-gallery-nav") ||
          target.matches(".digim-gallery-indicators");
        
        if (isGalleryControl) {
          // Only prevent default to stop link navigation
          // Don't stop propagation - let button handlers run first
          event.preventDefault();
        }
      };
      
      // Use bubble phase so button handlers in capture phase run first
      cardLink.addEventListener("click", preventNavigation, false);
      
      // For mousedown, also use bubble phase
      cardLink.addEventListener("mousedown", preventNavigation, false);
      
      // Ensure gallery controls are always on top
      if (activePrevBtn) {
        activePrevBtn.style.zIndex = '1000';
        activePrevBtn.style.pointerEvents = 'auto';
      }
      if (activeNextBtn) {
        activeNextBtn.style.zIndex = '1000';
        activeNextBtn.style.pointerEvents = 'auto';
      }
    }

    applyState(0);
}

// Global click handler to prevent navigation on gallery controls (fallback)
// Use bubble phase so button handlers in capture phase run first
document.addEventListener("click", function(event) {
  const target = event.target;
  // Check if click is on gallery controls
  const isGalleryControl = 
    target.closest("[data-digim-gallery-prev]") ||
    target.closest("[data-digim-gallery-next]") ||
    target.closest("[data-digim-gallery-dot]") ||
    target.closest(".digim-gallery-nav") ||
    target.closest(".digim-gallery-indicators") ||
    target.matches("[data-digim-gallery-prev]") ||
    target.matches("[data-digim-gallery-next]") ||
    target.matches("[data-digim-gallery-dot]") ||
    target.matches(".digim-gallery-nav") ||
    target.matches(".digim-gallery-indicators");
  
  if (isGalleryControl) {
    // Find the closest card link
    const cardLink = target.closest('.digimanagement-card');
    if (cardLink && (cardLink.tagName === 'A' || cardLink.closest('a'))) {
      // Prevent navigation but don't stop propagation
      // Button handlers in capture phase will have already run
      event.preventDefault();
    }
  }
}, false); // Use bubble phase so capture phase handlers run first

// Also add mousedown handler to catch events even earlier
// Use bubble phase so button handlers in capture phase run first
document.addEventListener("mousedown", function(event) {
  const target = event.target;
  const isGalleryControl = 
    target.closest("[data-digim-gallery-prev]") ||
    target.closest("[data-digim-gallery-next]") ||
    target.closest(".digim-gallery-nav");
  
  if (isGalleryControl) {
    const cardLink = target.closest('.digimanagement-card');
    if (cardLink && (cardLink.tagName === 'A' || cardLink.closest('a'))) {
      // Only prevent default, don't stop propagation
      event.preventDefault();
    }
  }
}, false); // Use bubble phase so capture phase handlers run first

// Initialize all galleries on page load
document.addEventListener("DOMContentLoaded", function () {
  const galleryWrappers = document.querySelectorAll("[data-digim-gallery]");
  galleryWrappers.forEach((wrapper) => {
    initDigimGallery(wrapper);
  });
  
  // Watch for dynamically added galleries (for shortcode cards added after page load)
  const observer = new MutationObserver(function(mutations) {
    mutations.forEach(function(mutation) {
      mutation.addedNodes.forEach(function(node) {
        if (node.nodeType === 1) { // Element node
          // Check if the added node is a gallery or contains galleries
          if (node.hasAttribute && node.hasAttribute('data-digim-gallery')) {
            // Small delay to ensure DOM is ready
            setTimeout(() => initDigimGallery(node), 10);
          }
          // Check for galleries inside the added node
          const galleries = node.querySelectorAll && node.querySelectorAll('[data-digim-gallery]');
          if (galleries && galleries.length > 0) {
            galleries.forEach(function(gallery) {
              // Small delay to ensure DOM is ready
              setTimeout(() => initDigimGallery(gallery), 10);
            });
          }
        }
      });
    });
  });
  
  // Start observing the document body for changes
  if (document.body) {
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }
  
  // Also check for galleries periodically (fallback for edge cases)
  // This helps catch shortcode cards that might be added in unusual ways
  let checkCount = 0;
  const maxChecks = 10; // Check for 5 seconds (10 * 500ms)
  const checkInterval = setInterval(function() {
    const uninitializedGalleries = document.querySelectorAll('[data-digim-gallery]:not([data-digim-gallery-initialized="true"])');
    if (uninitializedGalleries.length > 0) {
      uninitializedGalleries.forEach(function(gallery) {
        initDigimGallery(gallery);
      });
    }
    
    checkCount++;
    if (checkCount >= maxChecks) {
      clearInterval(checkInterval);
    }
  }, 500); // Check every 500ms
});

// Initialize lightgallery for show-all-overlay and modal-image elements
function initLightGallery() {
  if (typeof lightGallery === 'undefined') {
    // Wait for lightgallery to load
    setTimeout(initLightGallery, 100);
    return;
  }
  
  // Helper function to open lightgallery with all images
  function openLightGallery(startIndex) {
    startIndex = startIndex || 0;
    
    // Collect all images from modal gallery (which has all images)
    const modalGallery = document.querySelector('.modal-gallery');
    
    if (!modalGallery) {
      // Fallback: collect from hero gallery if modal gallery doesn't exist
      const heroGallery = document.querySelector('.hero-gallery');
      if (!heroGallery) return;
      
      const allImages = Array.from(heroGallery.querySelectorAll('img'));
      if (allImages.length === 0) return;
      
      const items = allImages.map(function(img, index) {
        return {
          src: img.src,
          thumb: img.src,
          alt: img.alt || 'Photo ' + (index + 1)
        };
      });
      
      const gallery = lightGallery(heroGallery, {
        dynamic: true,
        dynamicEl: items,
        index: startIndex >= 0 ? startIndex : 0,
        plugins: typeof lgThumbnail !== 'undefined' && typeof lgZoom !== 'undefined' ? [lgThumbnail, lgZoom] : [],
        download: false,
        share: false,
        closeOnTap: true,
        enableSwipe: true,
        enableDrag: true
      });
      
      gallery.openGallery(startIndex >= 0 ? startIndex : 0);
      return;
    }
    
    // Get all images from modal gallery
    const allImages = Array.from(modalGallery.querySelectorAll('.modal-image img'));
    if (allImages.length === 0) return;
    
    const items = allImages.map(function(img, index) {
      return {
        src: img.src,
        thumb: img.src,
        alt: img.alt || 'Photo ' + (index + 1)
      };
    });
    
    // Initialize lightgallery with dynamic content
    const gallery = lightGallery(modalGallery, {
      dynamic: true,
      dynamicEl: items,
      index: startIndex >= 0 ? startIndex : 0,
      plugins: typeof lgThumbnail !== 'undefined' && typeof lgZoom !== 'undefined' ? [lgThumbnail, lgZoom] : [],
      download: false,
      share: false,
      closeOnTap: true,
      enableSwipe: true,
      enableDrag: true
    });
    
    gallery.openGallery(startIndex >= 0 ? startIndex : 0);
  }
  
  // Handle main-image click on mobile - opens lightgallery
  const mainImage = document.getElementById('main-image');
  if (mainImage) {
    mainImage.addEventListener('click', function(e) {
      // Only on mobile (screen width <= 768px)
      if (window.innerWidth > 768) return;
      
      e.preventDefault();
      
      // Get all images from modal gallery
      const modalGallery = document.querySelector('.modal-gallery');
      if (!modalGallery) {
        openLightGallery(0);
        return;
      }
      
      const allImages = Array.from(modalGallery.querySelectorAll('.modal-image img'));
      if (allImages.length === 0) {
        openLightGallery(0);
        return;
      }
      
      // Find which image is currently shown in main-image
      const currentSrc = mainImage.src;
      const currentIndex = allImages.findIndex(function(img) {
        return img.src === currentSrc || img.getAttribute('src') === currentSrc;
      });
      
      // Open lightgallery starting from the current image
      openLightGallery(currentIndex >= 0 ? currentIndex : 0);
    });
  }
  
  // Handle show-all-overlay click - opens lightgallery with all images
  const showAllOverlay = document.querySelector(".show-all-overlay");
  if (showAllOverlay) {
    showAllOverlay.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation();
      openLightGallery(0);
    });
  }
  
  // Handle modal-image clicks (if modal is opened)
  const modalImages = document.querySelectorAll(".modal-image");
  
  if (modalImages.length > 0) {
    modalImages.forEach(function(modalImage) {
      modalImage.addEventListener('click', function(e) {
        e.preventDefault();
        
        // Collect all images from modal-gallery
        const modalGallery = document.querySelector('.modal-gallery');
        if (!modalGallery) return;
        
        const allImages = Array.from(modalGallery.querySelectorAll('.modal-image img'));
        const items = allImages.map(function(img, index) {
          return {
            src: img.src,
            thumb: img.src,
            alt: img.alt || 'Photo ' + (index + 1)
          };
        });
        
        // Find clicked image index
        const clickedImg = modalImage.querySelector('img');
        const currentIndex = allImages.findIndex(img => img === clickedImg);
        
        // Initialize lightgallery with dynamic content
        const gallery = lightGallery(modalGallery, {
          dynamic: true,
          dynamicEl: items,
          index: currentIndex >= 0 ? currentIndex : 0,
          plugins: typeof lgThumbnail !== 'undefined' && typeof lgZoom !== 'undefined' ? [lgThumbnail, lgZoom] : [],
          download: false,
          share: false,
          closeOnTap: true,
          enableSwipe: true,
          enableDrag: true
        });
        
        gallery.openGallery(currentIndex >= 0 ? currentIndex : 0);
      });
    });
  }
}

document.addEventListener("DOMContentLoaded", function () {
  initLightGallery();
  
  // Tab switching functionality for property description
  const tabButtons = document.querySelectorAll('.description-tabs .tab-button');
  const tabContents = document.querySelectorAll('.property-description .tab-content');
  
  tabButtons.forEach(button => {
    button.addEventListener('click', function() {
      const targetTab = this.getAttribute('data-tab');
      
      // Remove active class from all buttons and contents
      tabButtons.forEach(btn => btn.classList.remove('active'));
      tabContents.forEach(content => content.classList.remove('active'));
      
      // Add active class to clicked button and corresponding content
      this.classList.add('active');
      const targetContent = document.getElementById('tab-' + targetTab);
      if (targetContent) {
        targetContent.classList.add('active');
      }
    });
  });
});

// Toggle "Search destinations" placeholder based on selected items in Select2
document.addEventListener("DOMContentLoaded", function () {
  function toggleSelect2Placeholder() {
    const renderedElements = document.querySelectorAll('.select2-selection__rendered');
    
    renderedElements.forEach(function(rendered) {
      // Check if there are any <li> elements (selected choices) inside
      const hasSelection = rendered.querySelector('li.select2-selection__choice') !== null;
      
      if (hasSelection) {
        rendered.classList.add('has-selection');
      } else {
        rendered.classList.remove('has-selection');
      }
    });
  }
  
  // Function to setup observers for Select2 elements
  function setupSelect2Observers() {
    const renderedElements = document.querySelectorAll('.select2-selection__rendered');
    
    renderedElements.forEach(function(rendered) {
      // Skip if already observed
      if (rendered._digimObserved) {
        return;
      }
      
      const observer = new MutationObserver(function(mutations) {
        toggleSelect2Placeholder();
      });
      
      observer.observe(rendered, {
        childList: true,
        subtree: true
      });
      
      // Mark as observed
      rendered._digimObserved = true;
    });
  }
  
  // Check on page load
  toggleSelect2Placeholder();
  setupSelect2Observers();
  
  // Check when Select2 changes (using jQuery if available)
  if (typeof jQuery !== 'undefined') {
    // Listen for Select2 change events on any select element
    jQuery(document).on('change', 'select', function() {
      setTimeout(function() {
        toggleSelect2Placeholder();
        setupSelect2Observers();
      }, 10);
    });
    
    // Also listen for Select2 select/unselect events
    jQuery(document).on('select2:select select2:unselect select2:open select2:close', 'select', function() {
      setTimeout(function() {
        toggleSelect2Placeholder();
        setupSelect2Observers();
      }, 10);
    });
  }
  
  // Watch for new Select2 containers being added to the DOM
  const containerObserver = new MutationObserver(function(mutations) {
    let shouldCheck = false;
    mutations.forEach(function(mutation) {
      mutation.addedNodes.forEach(function(node) {
        if (node.nodeType === 1) { // Element node
          if (node.classList && (node.classList.contains('select2-container') || node.querySelector('.select2-selection__rendered'))) {
            shouldCheck = true;
          }
        }
      });
    });
    
    if (shouldCheck) {
      setTimeout(function() {
        toggleSelect2Placeholder();
        setupSelect2Observers();
      }, 50);
    }
  });
  
  containerObserver.observe(document.body, {
    childList: true,
    subtree: true
  });
});
