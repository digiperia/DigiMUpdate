<?php
// Global flag to track if shortcode was rendered
global $digim_shortcode_rendered;
$digim_shortcode_rendered = false;

// Early detection: Hook into the_content to detect shortcodes before rendering
add_filter('the_content', function($content) {
    global $digim_shortcode_rendered;
    
    // Check if content contains our shortcodes
    if (has_shortcode($content, 'digimanagement_listings') || 
        has_shortcode($content, 'digim_cards') ||
        strpos($content, '[digimanagement_listings') !== false ||
        strpos($content, '[digim_cards') !== false) {
        $digim_shortcode_rendered = true;
        
        // Enqueue styles early if not already done (uses .min when built)
        if (!did_action('wp_head')) {
            $style_asset = digim_asset('assets/css/style.css');
            if (file_exists($style_asset['path']) && !wp_style_is('digim-style', 'enqueued')) {
                wp_enqueue_style('digim-style', $style_asset['url'], [], filemtime($style_asset['path']));
            }
            
            // Enqueue dependencies
            $deps = [
                'leaflet' => 'https://unpkg.com/leaflet/dist/leaflet.css',
                'leaflet-cluster' => 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.css',
                'leaflet-cluster-default' => 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css',
                'select2' => 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css',
                'daterangepicker-css' => 'https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css',
                'digim-fontawesome' => 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css',
            ];
            
            foreach ($deps as $handle => $url) {
                if (!wp_style_is($handle, 'enqueued')) {
                    wp_enqueue_style($handle, $url);
                }
            }
        }
    }
    
    return $content;
}, 1); // Priority 1 to run early

add_action('wp_enqueue_scripts', function () {
    global $post;
    
    // Check if we should load the styles and scripts
    $should_load = false;
    
    // Check if shortcode exists in post content
    if (is_singular() && isset($post) && (has_shortcode($post->post_content, 'digimanagement_listings') || has_shortcode($post->post_content, 'digim_cards'))) {
        $should_load = true;
    }
    
    // Check ALL posts/pages in query (for archive pages, etc.)
    if (have_posts()) {
        while (have_posts()) {
            the_post();
            if (has_shortcode(get_the_content(), 'digimanagement_listings') || has_shortcode(get_the_content(), 'digim_cards')) {
                $should_load = true;
                break;
            }
        }
        wp_reset_postdata();
    }
    
    // Check widgets (text widgets can contain shortcodes)
    if (is_active_sidebar('sidebar-1') || is_active_sidebar('footer-1') || is_active_sidebar('footer-2') || is_active_sidebar('footer-3')) {
        $sidebars = wp_get_sidebars_widgets();
        foreach ($sidebars as $sidebar => $widgets) {
            if (is_array($widgets)) {
                foreach ($widgets as $widget_id) {
                    $widget_data = get_option('widget_text');
                    if ($widget_data) {
                        foreach ($widget_data as $widget) {
                            if (isset($widget['text']) && (has_shortcode($widget['text'], 'digimanagement_listings') || has_shortcode($widget['text'], 'digim_cards'))) {
                                $should_load = true;
                                break 3;
                            }
                        }
                    }
                }
            }
        }
    }
    
    // Check if we're on a page that might contain listings (like /listings/)
    if (is_page() && (strpos($_SERVER['REQUEST_URI'], '/listings') !== false || 
                     strpos($_SERVER['REQUEST_URI'], 'listings') !== false)) {
        $should_load = true;
    }
    
    // Check if we're on a property single page
    if (get_query_var('dm_property_uuid') || get_query_var('dm_property_identifier')) {
        $should_load = true;
    }
    
    // Check if the current page template or content contains digim classes
    if (isset($post) && (strpos($post->post_content, 'digim-main') !== false || 
                        strpos($post->post_content, 'digimanagement') !== false ||
                        strpos($post->post_content, '[digimanagement_listings') !== false ||
                        strpos($post->post_content, '[digim_cards') !== false)) {
        $should_load = true;
    }
    
    // Fallback: Check if we're on any page that might need the plugin styles
    // This can be customized based on your specific needs
    $force_load_pages = ['listings', 'properties', 'search'];
    foreach ($force_load_pages as $page_slug) {
        if (is_page($page_slug) || strpos($_SERVER['REQUEST_URI'], $page_slug) !== false) {
            $should_load = true;
            break;
        }
    }
    
    // Check if shortcode was rendered earlier (for page builders)
    global $digim_shortcode_rendered;
    if ($digim_shortcode_rendered) {
        $should_load = true;
    }
    
    // More permissive fallback: Load on singular pages/posts that might have shortcodes
    // This ensures styles are available even if detection fails (e.g., page builders)
    // Only applies to pages that could potentially contain shortcodes
    if (!$should_load && (is_singular() || is_page())) {
        // Check if we're NOT on admin or special pages
        if (!is_admin() && !is_feed() && !is_robots()) {
            // Only load as last resort fallback for pages that could have shortcodes
            // This is safer than loading on all pages but ensures compatibility with page builders
            $should_load = true;
        }
    }
    
    if (!$should_load) return;
    
    wp_enqueue_style('leaflet', 'https://unpkg.com/leaflet/dist/leaflet.css');
    wp_enqueue_style('leaflet-cluster', 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.css');
    wp_enqueue_style('leaflet-cluster-default', 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css');
    wp_enqueue_style('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css');
    wp_enqueue_style('daterangepicker-css', 'https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css');
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css');

    wp_enqueue_script('leaflet', 'https://unpkg.com/leaflet/dist/leaflet.js', [], null, true);
    wp_enqueue_script('leaflet-cluster', 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js', ['leaflet'], null, true);
    wp_enqueue_script('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js', ['jquery'], null, true);
    wp_enqueue_script('moment-js', 'https://cdn.jsdelivr.net/npm/moment@2.29.4/moment.min.js', [], null, true);
    wp_enqueue_script('daterangepicker-js', 'https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js', ['moment-js', 'jquery'], null, true);

    // Load plugin stylesheet for digim-main layout (uses .min when built)
    $style_asset = digim_asset('assets/css/style.css');
    if (file_exists($style_asset['path'])) {
        wp_enqueue_style('digim-style', $style_asset['url'], [], filemtime($style_asset['path']));
    }
    $map_asset = digim_asset('assets/js/map-init.js');
    if (file_exists($map_asset['path'])) {
        wp_enqueue_script('digim-map-init', $map_asset['url'], ['leaflet', 'leaflet-cluster'], filemtime($map_asset['path']), true);
    }

    // Inline Select2 init
    add_action('wp_footer', function () {
?>
        <script>
            jQuery(document).ready(function($) {
                // Hide dropdowns immediately before Select2 initializes
                $('.select2-dropdown').css({
                    'opacity': '0',
                    'visibility': 'hidden',
                    'display': 'none'
                });
                
                // Only init Select2 when not using custom city dropdown (no .city-select-hidden)
                $('select[name="property_search[]"]:not(.city-select-hidden)').select2({
                    placeholder: "Search destinations",
                    allowClear: true,
                    width: '100%',
                    multiple: true,
                    minimumResultsForSearch: Infinity,
                    closeOnSelect: false
                }).on('select2:open', function() {
                    // Show dropdown smoothly when opened
                    var $dropdown = $(this).next('.select2-container').find('.select2-dropdown');
                    $dropdown.css({
                        'opacity': '1',
                        'visibility': 'visible',
                        'display': 'block'
                    });
                }).on('select2:close', function() {
                    // Hide dropdown when closed
                    var $dropdown = $(this).next('.select2-container').find('.select2-dropdown');
                    $dropdown.css({
                        'opacity': '0',
                        'visibility': 'hidden',
                        'display': 'none'
                    });
                });
                
                // Ensure dropdown is hidden after initialization
                setTimeout(function() {
                    $('.select2-dropdown').not('.select2-container--open .select2-dropdown').css({
                        'opacity': '0',
                        'visibility': 'hidden',
                        'display': 'none'
                    });
                }, 100);
            });
        </script>
<?php
    }, 100);
}, 100);

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('digim-fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css', [], '6.5.2');
}, 100);

add_shortcode('digimanagement_listings', 'digimanagement_hospitable_listings_shortcode');

// ✅ Load all properties (with pagination + caching)
// Optimized: per_page + parallel page fetch (curl_multi) for ~2s cold load.
// Uses transient first, then WordPress option fallback (persistent), then API.
// Saves to both transient and option so date-range and filter searches stay fast.
function digim_get_all_properties()
{
    $cache_key = 'digim_all_properties';
    $option_key = 'digim_properties_stored';
    $all_properties = get_transient($cache_key);

    // Fallback: load from persistent option if transient empty (e.g. after cache cleanup)
    if (!is_array($all_properties) || empty($all_properties)) {
        $stored = get_option($option_key, null);
        $max_age = (int) apply_filters('digim_properties_option_max_age', 24 * HOUR_IN_SECONDS);
        if (is_array($stored) && !empty($stored['properties']) && isset($stored['updated'])) {
            $age = time() - (int) $stored['updated'];
            if ($age <= $max_age) {
                $all_properties = $stored['properties'];
                $cache_ttl = (int) apply_filters('digim_properties_cache_ttl', 30 * MINUTE_IN_SECONDS);
                set_transient($cache_key, $all_properties, $cache_ttl > 0 ? $cache_ttl : 1800);
                return $all_properties;
            }
        }
        $all_properties = [];
    } else {
        return $all_properties;
    }

    // Fetch from API
    $per_page = (int) apply_filters('digim_properties_per_page', 100);
    $per_page = $per_page > 0 ? min($per_page, 100) : 100;
    $cache_ttl = (int) apply_filters('digim_properties_cache_ttl', 30 * MINUTE_IN_SECONDS);
    $cache_ttl = $cache_ttl > 0 ? $cache_ttl : 30 * MINUTE_IN_SECONDS;
    $base_url = digimanagement_get_api_url() . '/properties?per_page=' . $per_page . '&page=';
    $token = digimanagement_get_api_token();
    $batch_size = (int) apply_filters('digim_properties_parallel_batch_size', 6);
    $batch_size = $batch_size > 0 ? min($batch_size, 10) : 6;

    // First page (single request)
    $url = $base_url . '1';
    $response = wp_remote_get($url, [
        'headers' => [
            'Authorization' => $token,
            'Accept' => 'application/json',
        ],
        'timeout' => (int) apply_filters('digim_properties_first_page_timeout', 8),
    ]);

    if (is_wp_error($response)) {
        set_transient($cache_key, [], min(60, $cache_ttl));
        return [];
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);
    if (!isset($data['data']) || !is_array($data['data'])) {
        set_transient($cache_key, [], min(60, $cache_ttl));
        return [];
    }

    $all_properties = $data['data'];
    $next_page = 2;
    $has_more = !empty($data['links']['next']);
    // Some API responses omit links.next; if the first page is full, keep paginating until a short page.
    $first_batch_count = count($all_properties);
    if (!$has_more && $first_batch_count >= $per_page) {
        $has_more = true;
    }

    // Remaining pages in parallel batches (curl_multi)
    while ($has_more && function_exists('curl_multi_init')) {
        $mh = curl_multi_init();
        $handles = [];
        $pages_in_batch = min($batch_size, 10);

        for ($i = 0; $i < $pages_in_batch; $i++) {
            $p = $next_page + $i;
            $page_url = $base_url . $p;
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => $page_url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HTTPHEADER => [
                    'Authorization: ' . $token,
                    'Accept: application/json',
                ],
                CURLOPT_TIMEOUT => (int) apply_filters('digim_properties_batch_timeout', 6),
                CURLOPT_CONNECTTIMEOUT => 2,
            ]);
            curl_multi_add_handle($mh, $ch);
            $handles[(int) $p] = $ch;
        }

        do {
            $status = curl_multi_exec($mh, $active);
            if ($active) {
                curl_multi_select($mh, 0.1);
            }
        } while ($active && $status === CURLM_OK);

        $last_has_next = false;
        ksort($handles);
        foreach ($handles as $p => $ch) {
            $body = curl_multi_getcontent($ch);
            $page_data = json_decode($body, true);
            curl_multi_remove_handle($mh, $ch);
            curl_close($ch);
            if (isset($page_data['data']) && is_array($page_data['data'])) {
                $page_count = count($page_data['data']);
                $all_properties = array_merge($all_properties, $page_data['data']);
                $last_has_next = !empty($page_data['links']['next']);
                if (!$last_has_next && $page_count >= $per_page) {
                    $last_has_next = true;
                }
            } else {
                $last_has_next = false;
                $has_more = false;
                break;
            }
        }
        curl_multi_close($mh);

        $next_page += $pages_in_batch;
        $has_more = $last_has_next;
    }

    // Fallback: sequential when curl_multi not available (e.g. PHP without curl)
    if ($has_more) {
        while ($has_more) {
            $url = $base_url . $next_page;
            $response = wp_remote_get($url, [
                'headers' => [
                    'Authorization' => $token,
                    'Accept' => 'application/json',
                ],
                'timeout' => (int) apply_filters('digim_properties_batch_timeout', 6),
            ]);
            if (is_wp_error($response)) break;
            $data = json_decode(wp_remote_retrieve_body($response), true);
            if (!isset($data['data'])) break;
            $page_count = count($data['data']);
            $all_properties = array_merge($all_properties, $data['data']);
            $has_more = !empty($data['links']['next']);
            if (!$has_more && $page_count >= $per_page) {
                $has_more = true;
            }
            $next_page++;
        }
    }

    $final_count = count($all_properties);
    error_log("DigiM: Fetched {$final_count} properties from API (per_page={$per_page}, pages fetched)");
    
    set_transient($cache_key, $all_properties, $cache_ttl);
    // Persist to WordPress option so properties survive transient cleanup; speeds up date-range filter.
    update_option($option_key, [
        'updated' => time(),
        'properties' => $all_properties,
    ], false);

    return $all_properties;
}

/**
 * Clear properties cache (transient + optional stored option). Call before refetch to force sync.
 *
 * @param bool $clear_option If true, also delete the persistent option (default true).
 */
function digim_clear_properties_cache($clear_option = true)
{
    delete_transient('digim_all_properties');
    if ($clear_option) {
        delete_option('digim_properties_stored');
    }
}

/**
 * Get a map of property_uuid → booking count for the last 30 days.
 * Uses a short-lived transient to avoid repeated DB queries per page load.
 */
function digim_get_recent_bookings_map()
{
    $cache_key = 'digim_recent_bookings_map';
    $cached = get_transient($cache_key);
    if (is_array($cached)) {
        return $cached;
    }

    $thirty_days_ago = date('Y-m-d', strtotime('-30 days'));
    $bookings = get_posts([
        'post_type'      => 'digim_booking',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'date_query'     => [['after' => $thirty_days_ago]],
        'fields'         => 'ids',
    ]);

    $map = [];
    $cancelled_map = [];
    $total_map = [];
    foreach ($bookings as $booking_id) {
        $uuid = strtolower(trim((string) get_post_meta($booking_id, 'property_uuid', true)));
        if ($uuid === '') {
            continue;
        }
        $status = strtolower(trim((string) get_post_meta($booking_id, 'status', true)));
        $total_map[$uuid] = ($total_map[$uuid] ?? 0) + 1;
        if ($status === 'cancelled' || $status === 'canceled') {
            $cancelled_map[$uuid] = ($cancelled_map[$uuid] ?? 0) + 1;
        } else {
            $map[$uuid] = ($map[$uuid] ?? 0) + 1;
        }
    }

    $result = [
        'bookings'      => $map,
        'cancellations' => $cancelled_map,
        'totals'        => $total_map,
    ];
    set_transient($cache_key, $result, 5 * MINUTE_IN_SECONDS);
    return $result;
}

/**
 * Sort properties by a dynamic SearchScore for fair, fresh results.
 *
 * Formula (adapted from Airbnb-style marketplace ranking):
 *   SearchScore =
 *     0.40 × normalizedRating         (rating / 5, default 0.5 if unknown)
 *   + 0.25 × normalizedReviewCount    (log₁₀(reviews+1) / log₁₀(101))
 *   + 0.25 × recentBookingsScore      (normalized against max in set)
 *   + 0.10 × listingFreshnessScore    (newer = higher)
 *
 *   FinalScore = SearchScore
 *     + newListingBoost   (+0.05 if listing < 30 days old)
 *     − cancellationPenalty (−0.10 if cancellation rate > 5%)
 *     + randomFactor      (0 to 0.05 for rotation)
 *
 * Price competitiveness is handled downstream by the badge system
 * (Great Value badge) when quote data is available.
 */
function digim_sort_by_search_score(&$properties)
{
    if (empty($properties) || count($properties) <= 1) {
        return;
    }

    $bookings_data   = digim_get_recent_bookings_map();
    $bookings_map    = $bookings_data['bookings'] ?? [];
    $cancel_map      = $bookings_data['cancellations'] ?? [];
    $totals_map      = $bookings_data['totals'] ?? [];
    $max_recent      = !empty($bookings_map) ? max(array_values($bookings_map)) : 0;

    $scored = [];
    foreach ($properties as $p) {
        $uuid = strtolower(trim((string) ($p['uuid'] ?? $p['id'] ?? '')));

        // --- Rating (normalized 0–1) ---
        $rating = null;
        foreach (['average_rating', 'rating', 'overall_rating', 'review_rating'] as $rk) {
            if (isset($p[$rk]) && is_numeric($p[$rk])) { $rating = (float) $p[$rk]; break; }
            if (isset($p['reviews'][$rk]) && is_numeric($p['reviews'][$rk])) { $rating = (float) $p['reviews'][$rk]; break; }
        }
        $norm_rating = $rating !== null ? min($rating / 5.0, 1.0) : 0.5;

        // --- Review count (log scale, normalized 0–1) ---
        $reviews = 0;
        foreach (['reviews_count', 'review_count', 'total_reviews', 'count'] as $ck) {
            if (isset($p[$ck]) && is_numeric($p[$ck])) { $reviews = (int) $p[$ck]; break; }
            if (isset($p['reviews'][$ck]) && is_numeric($p['reviews'][$ck])) { $reviews = (int) $p['reviews'][$ck]; break; }
        }
        $norm_reviews = $reviews > 0 ? min(log10($reviews + 1) / log10(101), 1.0) : 0.0;

        // --- Recent bookings (normalized 0–1) ---
        $recent = $uuid !== '' ? ($bookings_map[$uuid] ?? 0) : 0;
        $norm_bookings = $max_recent > 0 ? min($recent / $max_recent, 1.0) : 0.0;

        // --- Listing freshness (newer = higher, 0–1 over 1 year) ---
        $listing_age_days = null;
        foreach (['created_at', 'listed_at', 'activated_at'] as $dk) {
            if (!empty($p[$dk]) && strtotime($p[$dk]) !== false) {
                $listing_age_days = max(0, (time() - strtotime($p[$dk])) / DAY_IN_SECONDS);
                break;
            }
        }
        $freshness = $listing_age_days !== null
            ? max(0, 1 - $listing_age_days / 365)
            : 0.5;

        // --- Core search score ---
        $search_score = (0.40 * $norm_rating)
                      + (0.25 * $norm_reviews)
                      + (0.25 * $norm_bookings)
                      + (0.10 * $freshness);

        // --- New listing boost (+0.05 if < 30 days old) ---
        $new_boost = 0.0;
        if ($listing_age_days !== null && $listing_age_days < 30) {
            $new_boost = 0.05;
        }

        // --- Cancellation penalty (−0.10 if cancellation rate > 5%) ---
        $cancel_penalty = 0.0;
        if ($uuid !== '') {
            $total_bookings = $totals_map[$uuid] ?? 0;
            $cancellations  = $cancel_map[$uuid] ?? 0;
            if ($total_bookings >= 3 && ($cancellations / $total_bookings) > 0.05) {
                $cancel_penalty = 0.10;
            }
        }

        // --- Random factor for rotation (0 to 0.025) ---
        $random_factor = mt_rand(0, 250) / 10000;

        $final_score = $search_score + $new_boost - $cancel_penalty + $random_factor;

        $scored[] = [
            'property' => $p,
            'score'    => $final_score,
        ];
    }

    usort($scored, static function ($a, $b) {
        return $b['score'] <=> $a['score'];
    });

    $properties = array_values(array_column($scored, 'property'));
}

// ✅ Main shortcode logic
function digimanagement_hospitable_listings_shortcode()
{
    // Set global flag that shortcode is being rendered
    global $digim_shortcode_rendered;
    global $digim_from_ui_builder;
    
    $digim_shortcode_rendered = true;
    
    // Check if we're in admin UI builder context (not AJAX, but direct page load)
    if (is_admin() && isset($_GET['page']) && $_GET['page'] === 'DigiM-style') {
        $digim_from_ui_builder = true;
    }
    
    // Ensure core stylesheet is enqueued even when builders (e.g. Bricks) don't put shortcodes in post_content (uses .min when built)
    $style_asset = digim_asset('assets/css/style.css');
    if (file_exists($style_asset['path'])) {
        if (!wp_style_is('digim-style', 'enqueued')) {
            wp_enqueue_style('digim-style', $style_asset['url'], [], filemtime($style_asset['path']));
        }
    }
    if (!wp_style_is('digim-style', 'enqueued') && !wp_style_is('digim-style', 'done')) {
        if (!did_action('wp_head')) {
            wp_enqueue_style('digim-style', $style_asset['url'], [], filemtime($style_asset['path']));
        } else {
            add_action('wp_footer', function() use ($style_asset) {
                if (file_exists($style_asset['path']) && !wp_style_is('digim-style', 'done')) {
                    echo '<link rel="stylesheet" href="' . esc_url($style_asset['url']) . '?v=' . filemtime($style_asset['path']) . '" />';
                }
            }, 1);
        }
    }
    
    // Also ensure all required dependencies are loaded
    $required_styles = [
        'leaflet' => 'https://unpkg.com/leaflet/dist/leaflet.css',
        'leaflet-cluster' => 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.css',
        'leaflet-cluster-default' => 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css',
        'select2' => 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css',
        'daterangepicker-css' => 'https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css',
        'digim-fontawesome' => 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css',
    ];
    
    foreach ($required_styles as $handle => $url) {
        if (!wp_style_is($handle, 'enqueued') && !wp_style_is($handle, 'done')) {
            if (!did_action('wp_head')) {
                wp_enqueue_style($handle, $url);
            } else {
                // Fallback: inject in footer if wp_head already fired
                add_action('wp_footer', function() use ($handle, $url) {
                    if (!wp_style_is($handle, 'done')) {
                        echo '<link rel="stylesheet" href="' . esc_url($url) . '" />';
                    }
                }, 1);
            }
        }
    }
    
    // Enqueue scripts if needed (these can be added later)
    $required_scripts = [
        'leaflet' => ['url' => 'https://unpkg.com/leaflet/dist/leaflet.js', 'deps' => []],
        'leaflet-cluster' => ['url' => 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js', 'deps' => ['leaflet']],
        'select2' => ['url' => 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js', 'deps' => ['jquery']],
        'moment-js' => ['url' => 'https://cdn.jsdelivr.net/npm/moment@2.29.4/moment.min.js', 'deps' => []],
        'daterangepicker-js' => ['url' => 'https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js', 'deps' => ['moment-js', 'jquery']],
    ];
    
    foreach ($required_scripts as $handle => $script) {
        if (!wp_script_is($handle, 'enqueued') && !wp_script_is($handle, 'done')) {
            wp_enqueue_script($handle, $script['url'], $script['deps'], null, true);
        }
    }
    
    // Map init script (uses .min when built)
    $map_asset = digim_asset('assets/js/map-init.js');
    if (file_exists($map_asset['path']) && !wp_script_is('digim-map-init', 'enqueued')) {
        wp_enqueue_script('digim-map-init', $map_asset['url'], ['leaflet', 'leaflet-cluster'], filemtime($map_asset['path']), true);
    }

    $layout_style = get_option('digim_layout_style', 'grid');
    $per_page = intval(get_option('digim_cards_per_page', 9));
    if ($per_page <= 0) {
        $per_page = 9;
    }
    $per_page = (int) apply_filters('digim_listings_cards_per_page', $per_page);
    if ($per_page <= 0) {
        $per_page = 9;
    }
    $grid_columns = intval(get_option('digim_grid_columns', 3));
    $card_style = get_option('digim_card_style', 'classic');
    $primary_color = get_option('digim_primary_color', '#0073aa');
    error_log("Primary color from database: " . $primary_color);
    $show_map = get_option('digim_show_map', false);

    $search = isset($_GET['property_search']) ? $_GET['property_search'] : '';
    // Handle both array (multiple) and string (single) formats
    if (is_array($search)) {
        $search = array_map('sanitize_text_field', array_filter($search));
    } else {
        $search = $search ? [sanitize_text_field($search)] : [];
    }
    $checkin = sanitize_text_field($_GET['checkin'] ?? '');
    $checkout = sanitize_text_field($_GET['checkout'] ?? '');
    // Flexible search parameters (e.g. "Weekend in March")
    $flex_mode  = isset($_GET['flex_mode']) ? sanitize_text_field($_GET['flex_mode']) : '';
    $flex_month = isset($_GET['flex_month']) ? (int) $_GET['flex_month'] : 0;
    $flex_year  = isset($_GET['flex_year']) ? (int) $_GET['flex_year'] : 0;

    // When user chose "Weekend in <Month>", do NOT derive a single weekend — we want to
    // check all weekend dates in that month for all properties. Leave checkin/checkout
    // empty so the flexible-weekend branch (all weekends in month) runs. No date picker needed.
    $is_flexible_weekend_in_month = (
        $flex_mode === 'weekend'
        && $flex_month >= 1 && $flex_month <= 12
        && $flex_year >= 1970
    );
    if (!$is_flexible_weekend_in_month && function_exists('digim_derive_flexible_weekend_dates')) {
        list($checkin, $checkout, $flex_weekend_derived) = digim_derive_flexible_weekend_dates($checkin, $checkout, $flex_mode, $flex_month, $flex_year);
        if ($flex_weekend_derived) {
            $_GET['checkin']  = $checkin;
            $_GET['checkout'] = $checkout;
            $GLOBALS['digim_flexible_weekend_next_available'] = true;
        }
    }
    // When "Weekend in [Month]" is selected, ignore any checkin/checkout from URL so we only
    // use all Fri–Sun weekends in that month. Keeps form and links clean (no stale date).
    if ($is_flexible_weekend_in_month) {
        $checkin  = '';
        $checkout = '';
        $_GET['checkin']  = '';
        $_GET['checkout'] = '';
    }
    // When "Week in [Month]" is selected, do NOT derive a single 7-day range — we want to
    // check all 7-day windows starting in that month (e.g. March 1–8, 2–9, 7–14, etc.).
    $is_flexible_week_in_month = (
        $flex_mode === 'week'
        && $flex_month >= 1 && $flex_month <= 12
        && $flex_year >= 1970
    );
    if ($is_flexible_week_in_month) {
        $checkin  = '';
        $checkout = '';
        $_GET['checkin']  = '';
        $_GET['checkout'] = '';
    }
    $is_flexible_month_in_month = (
        $flex_mode === 'month'
        && $flex_month >= 1 && $flex_month <= 12
        && $flex_year >= 1970
    );
    if ($is_flexible_month_in_month) {
        $checkin  = '';
        $checkout = '';
        $_GET['checkin']  = '';
        $_GET['checkout'] = '';
    }
    if (!$is_flexible_week_in_month && !$is_flexible_month_in_month && function_exists('digim_derive_flexible_week_dates')) {
        list($checkin, $checkout, $flex_week_derived) = digim_derive_flexible_week_dates($checkin, $checkout, $flex_mode, $flex_month, $flex_year);
        if ($flex_week_derived) {
            $_GET['checkin']  = $checkin;
            $_GET['checkout'] = $checkout;
            $GLOBALS['digim_flexible_week_next_available'] = true;
        }
    }
    $current_page = max(1, intval($_GET['property_page'] ?? 1));

    // 🔄 Fetch all properties
    $all_properties = digim_get_all_properties();
    $total_from_api = count($all_properties);

    // Hide listings that are marked "hidden on frontend" in DigiM → Listings (Hospitable unchanged)
    $hidden_uuids = function_exists('digim_get_hidden_listing_uuids') ? digim_get_hidden_listing_uuids() : [];
    if (!empty($hidden_uuids)) {
        $all_properties = array_filter($all_properties, function ($p) use ($hidden_uuids) {
            $uuid = $p['uuid'] ?? $p['id'] ?? null;
            $uuid = $uuid !== null ? trim((string) $uuid) : '';
            return $uuid === '' || !in_array($uuid, $hidden_uuids, true);
        });
        $all_properties = array_values($all_properties);
        $after_hidden = count($all_properties);
        error_log("DigiM Shortcode: API returned {$total_from_api} properties, {$after_hidden} after removing " . count($hidden_uuids) . " hidden");
    }

    // 🧭 Get ALL destinations from unfiltered properties (for dropdown)
    // This ensures dropdown always shows all destinations, even when filtered
    $all_destination_names = array_unique(array_filter(array_map(
        fn($p) => $p['address']['city'] ?? '',
        $all_properties
    )));
    sort($all_destination_names);

    // 🔎 Filter: City (multiple selection support)
    if (!empty($search)) {
        $before_city = count($all_properties);
        $all_properties = array_filter(
            $all_properties,
            fn($p) => in_array(
                strtolower($p['address']['city'] ?? ''),
                array_map('strtolower', $search)
            )
        );
        $after_city = count($all_properties);
        error_log("DigiM: City filter applied. Before: {$before_city}, After: {$after_city}");
    }

    // 👥 Guests (adults + children + infants) — default at least 1 guest
    $adults = max(1, intval($_GET['adults'] ?? 0));
    $children = intval($_GET['children'] ?? 0);
    $infants = intval($_GET['infants'] ?? 0);
    $total_guests = $adults + $children + $infants;

    // Only apply guest filter when user explicitly sets guests > 1 (not default browse)
    if ($total_guests > 1) {
        $before_guests = count($all_properties);
        $all_properties = array_filter(
            $all_properties,
            fn($p) => ($p['capacity']['max'] ?? 0) >= $total_guests
        );
        $after_guests = count($all_properties);
        if ($before_guests !== $after_guests) {
            error_log("DigiM: Guest filter ({$total_guests} guests) applied. Before: {$before_guests}, After: {$after_guests}");
        }
    }
    
    // 🛏️ Bedrooms filter
    $filter_bedrooms = isset($_GET['filter_bedrooms']) ? sanitize_text_field($_GET['filter_bedrooms']) : '';
    if ($filter_bedrooms !== '') {
        $bedrooms_value = intval($filter_bedrooms);
        if ($bedrooms_value > 0) {
            $all_properties = array_filter(
                $all_properties,
                fn($p) => isset($p['capacity']['bedrooms']) && intval($p['capacity']['bedrooms']) === $bedrooms_value
            );
        }
    }
    
    // 🛏️ Beds filter
    $filter_beds = isset($_GET['filter_beds']) ? sanitize_text_field($_GET['filter_beds']) : '';
    if ($filter_beds !== '') {
        $beds_value = intval($filter_beds);
        if ($beds_value > 0) {
            $all_properties = array_filter(
                $all_properties,
                fn($p) => isset($p['capacity']['beds']) && intval($p['capacity']['beds']) === $beds_value
            );
        }
    }

    // 🏷️ Build unique amenities list for filter UI (before applying amenities filter)
    $amenity_labels_overrides = get_option('digim_amenities_labels', []);
    $digim_all_amenities_for_filter = [];
    foreach ($all_properties as $p) {
        $amenities = $p['amenities'] ?? [];
        if (!is_array($amenities)) {
            continue;
        }
        foreach ($amenities as $a) {
            $slug = digim_normalize_amenity($a);
            if ($slug === '') {
                continue;
            }
            $label_source = is_array($a) ? ($a['name'] ?? $a['slug'] ?? $slug) : (string) $a;
            $label = $amenity_labels_overrides[$slug] ?? ucwords(preg_replace('/[_-]+/', ' ', $slug));
            $digim_all_amenities_for_filter[$slug] = $label;
        }
    }
    ksort($digim_all_amenities_for_filter);

    // 🏷️ Amenities filter (property must have all selected amenities)
    $filter_amenities_raw = isset($_GET['filter_amenities']) ? $_GET['filter_amenities'] : '';
    $filter_amenities_slugs = [];
    if (is_array($filter_amenities_raw)) {
        $filter_amenities_slugs = array_values(array_unique(array_filter(array_map(function ($v) {
            return digim_normalize_amenity(sanitize_text_field($v));
        }, $filter_amenities_raw))));
    } elseif (is_string($filter_amenities_raw) && $filter_amenities_raw !== '') {
        $filter_amenities_slugs = array_values(array_unique(array_filter(array_map(function ($v) {
            return digim_normalize_amenity(sanitize_text_field(trim($v)));
        }, explode(',', $filter_amenities_raw)))));
    }
    if (!empty($filter_amenities_slugs)) {
        $all_properties = array_filter($all_properties, function ($p) use ($filter_amenities_slugs) {
            $prop_amenities = $p['amenities'] ?? [];
            $prop_slugs = array_map('digim_normalize_amenity', is_array($prop_amenities) ? $prop_amenities : []);
            foreach ($filter_amenities_slugs as $slug) {
                if (!in_array($slug, $prop_slugs, true)) {
                    return false;
                }
            }
            return true;
        });
    }

    // 🐾 Pets filter: when user is adding pets, only show properties that allow pets (exclude "Not including service animals" etc.)
    $pets = max(0, (int) ($_GET['pets'] ?? 0));
    if ($pets > 0 && function_exists('digim_property_allows_pets')) {
        $all_properties = array_filter($all_properties, function ($p) {
            return digim_property_allows_pets($p);
        });
    }

    // Re-index after filters and sort by dynamic SearchScore for fair, fresh results.
    $all_properties = array_values($all_properties);
    $before_sort = count($all_properties);
    digim_sort_by_search_score($all_properties);
    $after_sort = count($all_properties);
    
    if ($before_sort !== $after_sort) {
        error_log("DigiM: WARNING - Sort changed count! Before: {$before_sort}, After: {$after_sort}");
    }

    // Default pagination for non-date browsing. Date search blocks override these with filtered counts.
    // $per_page comes from UI Builder → Cards per page (digim_cards_per_page).
    $total = count($all_properties);
    error_log("DigiM: Final property count before pagination: {$total} (per_page: {$per_page})");
    $total_pages = $per_page > 0 ? max(1, (int) ceil($total / $per_page)) : 1;
    $current_page = max(1, min($current_page, $total_pages));
    $offset = ($current_page - 1) * $per_page;
    $properties_for_page = array_slice($all_properties, $offset, $per_page);

    // 📅 Availability (calendar check) — ONLY for current page UUIDs (never all properties).
    $properties_to_show = $properties_for_page;
    $has_standard_dates = ($checkin && $checkout);
    $has_flexible_weekend = (
        $flex_mode === 'weekend'
        && $flex_month >= 1 && $flex_month <= 12
        && $flex_year >= 1970
    );
    $has_flexible_week = (
        $flex_mode === 'week'
        && $flex_month >= 1 && $flex_month <= 12
        && $flex_year >= 1970
    );
    $has_flexible_month = (
        $flex_mode === 'month'
        && $flex_month >= 1 && $flex_month <= 12
        && $flex_year >= 1970
    );

    if ($has_standard_dates && !empty($all_properties)) {
        // Check ALL properties for availability (fast with pre-warmed calendar cache — transient reads only).
        // Then paginate the filtered list so we always fill per_page and show correct pagination.
        $all_uuids = array_values(array_filter(
            array_unique(array_map(function ($p) {
                $uuid = $p['uuid'] ?? $p['id'] ?? null;
                return is_null($uuid) ? null : trim((string) $uuid);
            }, $all_properties)),
            function ($uuid) {
                return $uuid !== null && $uuid !== '';
            }
        ));

        if (!empty($all_uuids)) {
            $available_uuids = digimanagement_parallel_calendar_check($all_uuids, $checkin, $checkout);
            if (!is_array($available_uuids)) {
                $available_uuids = [];
            }

            $available_uuid_map = [];
            foreach ($available_uuids as $uuid) {
                $uuid = trim((string) $uuid);
                if ($uuid !== '') {
                    $available_uuid_map[$uuid] = true;
                }
            }

            global $digim_next_available_suggestions;
            global $digim_min_nights_required;
            global $digim_checkin_blocked;
            $suggestion_map = is_array($digim_next_available_suggestions) ? $digim_next_available_suggestions : [];
            $min_nights_map = is_array($digim_min_nights_required) ? $digim_min_nights_required : [];
            $checkin_blocked_map = is_array($digim_checkin_blocked) ? $digim_checkin_blocked : [];

            $available_properties = [];
            $suggested_properties = [];
            $min_nights_properties = [];

            foreach ($all_properties as $property) {
                $uuid = $property['uuid'] ?? $property['id'] ?? null;
                $uuid = is_null($uuid) ? '' : trim((string) $uuid);
                if ($uuid === '') {
                    continue;
                }

                $property_min_nights = $property['minimum_nights']
                    ?? $property['min_nights']
                    ?? $property['min_stay']
                    ?? $property['minimum_stay']
                    ?? (isset($property['pricing']['minimum_nights']) ? $property['pricing']['minimum_nights'] : null)
                    ?? (isset($property['pricing']['min_nights']) ? $property['pricing']['min_nights'] : null)
                    ?? null;
                $calendar_min_nights = isset($min_nights_map[$uuid]) ? $min_nights_map[$uuid] : null;
                $final_min_nights = null;
                if ($calendar_min_nights !== null && $property_min_nights !== null) {
                    $final_min_nights = max((int) $calendar_min_nights, (int) $property_min_nights);
                } elseif ($calendar_min_nights !== null) {
                    $final_min_nights = (int) $calendar_min_nights;
                } elseif ($property_min_nights !== null) {
                    $final_min_nights = (int) $property_min_nights;
                }

                $requested_nights = max(1, (int) floor((strtotime($checkout) - strtotime($checkin)) / DAY_IN_SECONDS));
                $has_min_nights_issue = $final_min_nights !== null && $requested_nights < (int) $final_min_nights;
                $is_checkin_blocked = isset($checkin_blocked_map[$uuid]) && $checkin_blocked_map[$uuid] === true;
                if ($is_checkin_blocked) {
                    continue;
                }

                if (isset($available_uuid_map[$uuid])) {
                    $property['_digim_is_suggestion'] = false;
                    $property['_digim_suggested_start'] = null;
                    $property['_digim_suggested_checkout'] = null;
                    $property['_digim_suggested_nights'] = null;
                    $property['_digim_min_nights_required'] = null;
                    $available_properties[] = $property;
                } elseif ($has_min_nights_issue) {
                    $property['_digim_is_suggestion'] = false;
                    $property['_digim_suggested_start'] = null;
                    $property['_digim_suggested_checkout'] = null;
                    $property['_digim_suggested_nights'] = null;
                    $property['_digim_min_nights_required'] = (int) $final_min_nights;
                    $min_nights_properties[] = $property;
                } elseif (!empty($suggestion_map[$uuid]) && is_array($suggestion_map[$uuid])) {
                    $suggestion = $suggestion_map[$uuid];
                    $property['_digim_is_suggestion'] = true;
                    $property['_digim_suggested_start'] = $suggestion['start'] ?? null;
                    $property['_digim_suggested_checkout'] = $suggestion['checkout'] ?? null;
                    $property['_digim_suggested_nights'] = $suggestion['nights'] ?? null;
                    $property['_digim_min_nights_required'] = null;
                    $suggested_properties[] = $property;
                } else {
                    continue;
                }
            }

            $filtered_full = array_merge($available_properties, $suggested_properties, $min_nights_properties);

            // Paginate the filtered results — accurate page count based on actual availability
            $total_filtered = count($filtered_full);
            $total_pages = $per_page > 0 ? max(1, (int) ceil($total_filtered / $per_page)) : 1;
            $current_page = max(1, min($current_page, $total_pages));
            $offset = ($current_page - 1) * $per_page;
            $properties_to_show = array_slice($filtered_full, $offset, $per_page);
        }
    } elseif ($has_flexible_weekend && !empty($all_properties)) {
        // OPTIMIZED: Flexible "Weekend in <Month>" - Check only properties for current page (12 cards)
        // to avoid 1-minute load times. Pagination-first approach for better performance.
        
        // Check all properties (fast with cached calendars), paginate filtered results
        $all_uuids_flex = array_values(array_filter(
            array_unique(array_map(function ($p) {
                $uuid = $p['uuid'] ?? $p['id'] ?? null;
                return is_null($uuid) ? null : trim((string) $uuid);
            }, $all_properties)),
            function ($uuid) {
                return $uuid !== null && $uuid !== '';
            }
        ));

        if (!empty($all_uuids_flex)) {
            
            // All Fridays in month → 2-night weekend ranges (e.g. May: 1–3, 8–10, 15–17, 22–24, 29–31).
            $weekend_ranges = function_exists('digim_get_weekend_ranges_for_month')
                ? digim_get_weekend_ranges_for_month($flex_year, $flex_month)
                : [];

            // Check EVERY weekend in the month; property is included if available for any of them.
            $weekend_available_map = [];
            foreach ($weekend_ranges as $range) {
                list($weekend_checkin, $weekend_checkout) = $range;
                $available_for_weekend = digimanagement_parallel_calendar_check($all_uuids_flex, $weekend_checkin, $weekend_checkout);
                if (!is_array($available_for_weekend)) {
                    continue;
                }
                foreach ($available_for_weekend as $uuid) {
                    $uuid = trim((string) $uuid);
                    if ($uuid === '' || isset($weekend_available_map[$uuid])) {
                        continue;
                    }
                    $weekend_available_map[$uuid] = [[
                        'checkin'  => $weekend_checkin,
                        'checkout' => $weekend_checkout,
                    ]];
                }
            }

            $filtered_full = [];
            foreach ($all_properties as $property) {
                $uuid = $property['uuid'] ?? $property['id'] ?? null;
                $uuid = is_null($uuid) ? '' : trim((string) $uuid);
                if ($uuid === '') {
                    continue;
                }
                if (!empty($weekend_available_map[$uuid])) {
                    $first_weekend = $weekend_available_map[$uuid][0];
                    $property['_digim_is_suggestion'] = false;
                    $property['_digim_suggested_start'] = null;
                    $property['_digim_suggested_checkout'] = null;
                    $property['_digim_suggested_nights'] = null;
                    $property['_digim_min_nights_required'] = null;
                    $property['_digim_flexible_weekend_dates'] = [ $first_weekend ];
                    $filtered_full[] = $property;
                }
            }

            $total_filtered = count($filtered_full);
            $total_pages = $per_page > 0 ? max(1, (int) ceil($total_filtered / $per_page)) : 1;
            $current_page = max(1, min($current_page, $total_pages));
            $offset = ($current_page - 1) * $per_page;
            $properties_to_show = array_slice($filtered_full, $offset, $per_page);

            // Quotes deferred to frontend hydration (quote-hydration.js) for fast response.
        }
    } elseif ($has_flexible_week && !empty($all_properties)) {
        // OPTIMIZED: Flexible "Week in <Month>" - Check only properties for current page (12 cards)
        // to avoid slow load times. Pagination-first approach for better performance.
        
        // Calculate pagination FIRST - only check properties we'll actually show
        // Check all properties, paginate filtered results
        $all_uuids_flex = array_values(array_filter(
            array_unique(array_map(function ($p) {
                $uuid = $p['uuid'] ?? $p['id'] ?? null;
                return is_null($uuid) ? null : trim((string) $uuid);
            }, $all_properties)),
            function ($uuid) {
                return $uuid !== null && $uuid !== '';
            }
        ));

        if (!empty($all_uuids_flex)) {
            
            try {
                $tz = wp_timezone();
            } catch (Exception $e) {
                $tz = new DateTimeZone('UTC');
            }

            // 7 nights for flexible week; sample every N days to reduce API calls (~6 ranges vs 31)
            $flex_nights = (int) apply_filters('digim_flexible_week_nights', 7);
            $flex_nights = max(3, min(14, $flex_nights));
            $range_step = (int) apply_filters('digim_flexible_week_range_step', 1);
            $range_step = max(1, min(7, $range_step));
            $week_ranges = [];
            try {
                $first_of_month = new DateTimeImmutable(sprintf('%04d-%02d-01', $flex_year, $flex_month), $tz);
                $last_of_month = $first_of_month->modify('last day of this month');
                $current = $first_of_month;
                while ($current <= $last_of_month) {
                    $range_checkin = $current->format('Y-m-d');
                    $range_checkout = $current->modify('+' . $flex_nights . ' days')->format('Y-m-d');
                    $week_ranges[] = [ $range_checkin, $range_checkout ];
                    $current = $current->modify('+' . $range_step . ' days');
                }
            } catch (Exception $e) {
                $week_ranges = [];
            }

            $week_available_map = [];
            if (function_exists('digimanagement_parallel_calendar_check_multi_ranges')) {
                $multi_result = digimanagement_parallel_calendar_check_multi_ranges($all_uuids_flex, $week_ranges);
                foreach ($multi_result as $uuid => $available_ranges) {
                    if (!empty($available_ranges)) {
                        $week_available_map[$uuid] = $available_ranges[0];
                    }
                }
            } else {
                foreach ($week_ranges as $range) {
                    list($range_checkin, $range_checkout) = $range;
                    $available_for_week = digimanagement_parallel_calendar_check($all_uuids_flex, $range_checkin, $range_checkout);
                    if (!is_array($available_for_week)) {
                        continue;
                    }
                    foreach ($available_for_week as $uuid) {
                        $uuid = trim((string) $uuid);
                        if ($uuid === '') {
                            continue;
                        }
                        if (isset($week_available_map[$uuid])) {
                            continue;
                        }
                        $week_available_map[$uuid] = [
                            'checkin'  => $range_checkin,
                            'checkout' => $range_checkout,
                        ];
                    }
                }
            }

            $filtered_full = [];
            foreach ($all_properties as $property) {
                $uuid = $property['uuid'] ?? $property['id'] ?? null;
                $uuid = is_null($uuid) ? '' : trim((string) $uuid);
                if ($uuid === '') {
                    continue;
                }
                if (!isset($week_available_map[$uuid])) {
                    continue;
                }
                $first_week = $week_available_map[$uuid];
                $property['_digim_is_suggestion'] = false;
                $property['_digim_suggested_start'] = null;
                $property['_digim_suggested_checkout'] = null;
                $property['_digim_suggested_nights'] = null;
                $property['_digim_min_nights_required'] = null;
                $property['_digim_flexible_week_dates'] = [ $first_week ];
                $filtered_full[] = $property;
            }

            $total_filtered = count($filtered_full);
            $total_pages = $per_page > 0 ? max(1, (int) ceil($total_filtered / $per_page)) : 1;
            $current_page = max(1, min($current_page, $total_pages));
            $offset = ($current_page - 1) * $per_page;
            $properties_to_show = array_slice($filtered_full, $offset, $per_page);

            // Quotes deferred to frontend hydration (quote-hydration.js) for fast response.
        }
    } elseif ($has_flexible_month && !empty($all_properties)) {
        // Flexible "Month in <Month>" — check all properties, paginate filtered results.
        $all_uuids_flex = array_values(array_filter(
            array_unique(array_map(function ($p) {
                $uuid = $p['uuid'] ?? $p['id'] ?? null;
                return is_null($uuid) ? null : trim((string) $uuid);
            }, $all_properties)),
            function ($uuid) { return $uuid !== null && $uuid !== ''; }
        ));

        if (!empty($all_uuids_flex)) {
            try {
                $tz = wp_timezone();
            } catch (Exception $e) {
                $tz = new DateTimeZone('UTC');
            }

            $range_step = (int) apply_filters('digim_flexible_month_range_step', 1);
            $range_step = max(1, min(15, $range_step));
            $month_ranges = [];
            try {
                $first_of_month = new DateTimeImmutable(sprintf('%04d-%02d-01', $flex_year, $flex_month), $tz);
                $last_of_month = $first_of_month->modify('last day of this month');
                $current = $first_of_month;
                while ($current <= $last_of_month) {
                    $range_checkin = $current->format('Y-m-d');
                    $range_checkout = $current->modify('+1 month')->format('Y-m-d');
                    $month_ranges[] = [ $range_checkin, $range_checkout ];
                    $current = $current->modify('+' . $range_step . ' days');
                }
            } catch (Exception $e) {
                $month_ranges = [];
            }

            $month_available_map = [];
            if (function_exists('digimanagement_parallel_calendar_check_multi_ranges')) {
                $multi_result = digimanagement_parallel_calendar_check_multi_ranges($all_uuids_flex, $month_ranges);
                foreach ($multi_result as $uuid => $available_ranges) {
                    if (!empty($available_ranges)) {
                        $month_available_map[$uuid] = $available_ranges[0];
                    }
                }
            } else {
                foreach ($month_ranges as $range) {
                    list($range_checkin, $range_checkout) = $range;
                    $available = digimanagement_parallel_calendar_check($all_uuids_flex, $range_checkin, $range_checkout);
                    if (!is_array($available)) {
                        continue;
                    }
                    foreach ($available as $uuid) {
                        $uuid = trim((string) $uuid);
                        if ($uuid !== '' && !isset($month_available_map[$uuid])) {
                            $month_available_map[$uuid] = [ 'checkin' => $range_checkin, 'checkout' => $range_checkout ];
                        }
                    }
                }
            }

            $filtered_full = [];
            foreach ($all_properties as $property) {
                $uuid = $property['uuid'] ?? $property['id'] ?? null;
                $uuid = is_null($uuid) ? '' : trim((string) $uuid);
                if ($uuid === '' || !isset($month_available_map[$uuid])) {
                    continue;
                }
                $first_month = $month_available_map[$uuid];
                $property['_digim_is_suggestion'] = false;
                $property['_digim_suggested_start'] = null;
                $property['_digim_suggested_checkout'] = null;
                $property['_digim_suggested_nights'] = null;
                $property['_digim_min_nights_required'] = null;
                $property['_digim_flexible_month_dates'] = [ $first_month ];
                $filtered_full[] = $property;
            }

            $total_filtered = count($filtered_full);
            $total_pages = $per_page > 0 ? max(1, (int) ceil($total_filtered / $per_page)) : 1;
            $current_page = max(1, min($current_page, $total_pages));
            $offset = ($current_page - 1) * $per_page;
            $properties_to_show = array_slice($filtered_full, $offset, $per_page);
            // Quotes deferred to frontend hydration (quote-hydration.js) for fast response.
        }
    }

    // Apply price filter to $properties_to_show when we have quote data (flexible date or standard dates with quote map)
    $filter_price_min = isset($_GET['filter_price_min']) ? sanitize_text_field($_GET['filter_price_min']) : '';
    $filter_price_max = isset($_GET['filter_price_max']) ? sanitize_text_field($_GET['filter_price_max']) : '';
    $price_min_val = ($filter_price_min !== '' && is_numeric($filter_price_min)) ? (float) $filter_price_min : null;
    $price_max_val = ($filter_price_max !== '' && is_numeric($filter_price_max)) ? (float) $filter_price_max : null;
    // Treat max=10000 as "no max" so that "500–10000" is a valid filter (user intent: up to 10000)
    $has_price_filter = ($price_min_val !== null && $price_min_val > 0) || ($price_max_val !== null && $price_max_val > 0);

    // When flexible weekend + price filter but no quote map yet (e.g. no property had weekend), fetch quotes for first weekend of month so we can filter by price
    if ($has_flexible_weekend && $has_price_filter && !empty($properties_to_show) && function_exists('digimanagement_parallel_quote_fetch')) {
        $existing_map = isset($GLOBALS['digim_quote_map']) && is_array($GLOBALS['digim_quote_map']) ? $GLOBALS['digim_quote_map'] : [];
        $need_quotes = empty($existing_map);
        if (!$need_quotes) {
            $uuids_with_quote = array_keys($existing_map);
            $uuids_to_show = array_values(array_filter(array_map(function ($p) {
                $u = $p['uuid'] ?? $p['id'] ?? '';
                return $u !== '' ? trim((string) $u) : null;
            }, $properties_to_show)));
            foreach ($uuids_to_show as $u) {
                if (!in_array($u, $uuids_with_quote, true)) {
                    $need_quotes = true;
                    break;
                }
            }
        }
        if ($need_quotes) {
            try {
                $tz = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC');
                $first_of_month = new DateTimeImmutable(sprintf('%04d-%02d-01', $flex_year, $flex_month), $tz);
                $first_friday = $first_of_month->modify('first friday of this month');
                if ((int) $first_friday->format('n') === (int) $flex_month) {
                    $first_weekend_ci = $first_friday->format('Y-m-d');
                    $first_weekend_co = $first_friday->modify('+2 days')->format('Y-m-d');
                    $price_quote_uuids = array_values(array_filter(array_unique(array_map(function ($p) {
                        $u = $p['uuid'] ?? $p['id'] ?? null;
                        return $u !== null && trim((string) $u) !== '' ? trim((string) $u) : null;
                    }, $properties_to_show))));
                    if (!empty($price_quote_uuids)) {
                        $adults_q = max(1, (int) ($_GET['adults'] ?? 1));
                        $quotes_fallback = digimanagement_parallel_quote_fetch(
                            $price_quote_uuids,
                            $first_weekend_ci,
                            $first_weekend_co,
                            $adults_q,
                            (int) ($_GET['children'] ?? 0),
                            (int) ($_GET['infants'] ?? 0),
                            (int) ($_GET['pets'] ?? 0)
                        );
                        if (is_array($quotes_fallback) && !empty($quotes_fallback)) {
                            $normalized = [];
                            foreach ($quotes_fallback as $uid => $q) {
                                if ($q !== null && is_array($q)) {
                                    $normalized[trim((string) $uid)] = $q;
                                }
                            }
                            $GLOBALS['digim_quote_map'] = array_merge($existing_map, $normalized);
                        }
                    }
                }
            } catch (Exception $e) {
                // ignore
            }
        }
    }
    // When flexible week + price filter but no quote map yet, fetch quotes for first 7 nights of month (matches digim_flexible_week_nights)
    if ($has_flexible_week && $has_price_filter && !empty($properties_to_show) && function_exists('digimanagement_parallel_quote_fetch')) {
        $existing_map = isset($GLOBALS['digim_quote_map']) && is_array($GLOBALS['digim_quote_map']) ? $GLOBALS['digim_quote_map'] : [];
        $need_quotes = empty($existing_map);
        if (!$need_quotes) {
            $uuids_with_quote = array_keys($existing_map);
            $uuids_to_show = array_values(array_filter(array_map(function ($p) {
                $u = $p['uuid'] ?? $p['id'] ?? '';
                return $u !== '' ? trim((string) $u) : null;
            }, $properties_to_show)));
            foreach ($uuids_to_show as $u) {
                if (!in_array($u, $uuids_with_quote, true)) {
                    $need_quotes = true;
                    break;
                }
            }
        }
        if ($need_quotes) {
            try {
                $flex_nights = (int) apply_filters('digim_flexible_week_nights', 7);
                $flex_nights = max(3, min(14, $flex_nights));
                // Prefer dates from first property's _digim_flexible_week_dates so quote matches displayed availability
                $fallback_ci = null;
                $fallback_co = null;
                foreach ($properties_to_show as $p) {
                    $fd = $p['_digim_flexible_week_dates'][0] ?? null;
                    if ($fd && !empty($fd['checkin']) && !empty($fd['checkout'])) {
                        $fallback_ci = $fd['checkin'];
                        $fallback_co = $fd['checkout'];
                        break;
                    }
                }
                if (!$fallback_ci || !$fallback_co) {
                    $tz = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC');
                    $first_of_month = new DateTimeImmutable(sprintf('%04d-%02d-01', $flex_year, $flex_month), $tz);
                    $fallback_ci = $first_of_month->format('Y-m-d');
                    $fallback_co = $first_of_month->modify('+' . $flex_nights . ' days')->format('Y-m-d');
                }
                $first_week_ci = $fallback_ci;
                $first_week_co = $fallback_co;
                $price_quote_uuids = array_values(array_filter(array_unique(array_map(function ($p) {
                    $u = $p['uuid'] ?? $p['id'] ?? null;
                    return $u !== null && trim((string) $u) !== '' ? trim((string) $u) : null;
                }, $properties_to_show))));
                if (!empty($price_quote_uuids)) {
                    $adults_q = max(1, (int) ($_GET['adults'] ?? 1));
                    $quotes_fallback = digimanagement_parallel_quote_fetch(
                        $price_quote_uuids,
                        $first_week_ci,
                        $first_week_co,
                        $adults_q,
                        (int) ($_GET['children'] ?? 0),
                        (int) ($_GET['infants'] ?? 0),
                        (int) ($_GET['pets'] ?? 0)
                    );
                    if (is_array($quotes_fallback) && !empty($quotes_fallback)) {
                        $normalized = [];
                        foreach ($quotes_fallback as $uid => $q) {
                            if ($q !== null && is_array($q)) {
                                $normalized[trim((string) $uid)] = $q;
                            }
                        }
                        $GLOBALS['digim_quote_map'] = array_merge($existing_map, $normalized);
                    }
                }
            } catch (Exception $e) {
                // ignore
            }
        }
    }
    // When flexible month + price filter but no quote map yet
    if ($has_flexible_month && $has_price_filter && !empty($properties_to_show) && function_exists('digimanagement_parallel_quote_fetch')) {
        $existing_map = isset($GLOBALS['digim_quote_map']) && is_array($GLOBALS['digim_quote_map']) ? $GLOBALS['digim_quote_map'] : [];
        $need_quotes = empty($existing_map);
        if (!$need_quotes) {
            $uuids_with_quote = array_keys($existing_map);
            $uuids_to_show = array_values(array_filter(array_map(function ($p) {
                $u = $p['uuid'] ?? $p['id'] ?? '';
                return $u !== '' ? trim((string) $u) : null;
            }, $properties_to_show)));
            foreach ($uuids_to_show as $u) {
                if (!in_array($u, $uuids_with_quote, true)) { $need_quotes = true; break; }
            }
        }
        if ($need_quotes) {
            try {
                $fallback_ci = null;
                $fallback_co = null;
                foreach ($properties_to_show as $p) {
                    $fd = $p['_digim_flexible_month_dates'][0] ?? null;
                    if ($fd && !empty($fd['checkin']) && !empty($fd['checkout'])) {
                        $fallback_ci = $fd['checkin'];
                        $fallback_co = $fd['checkout'];
                        break;
                    }
                }
                if (!$fallback_ci || !$fallback_co) {
                    $tz = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC');
                    $first_of_month = new DateTimeImmutable(sprintf('%04d-%02d-01', $flex_year, $flex_month), $tz);
                    $fallback_ci = $first_of_month->format('Y-m-d');
                    $fallback_co = $first_of_month->modify('+1 month')->format('Y-m-d');
                }
                $price_quote_uuids = array_values(array_filter(array_unique(array_map(function ($p) {
                    $u = $p['uuid'] ?? $p['id'] ?? null;
                    return $u !== null && trim((string) $u) !== '' ? trim((string) $u) : null;
                }, $properties_to_show))));
                if (!empty($price_quote_uuids)) {
                    $adults_q = max(1, (int) ($_GET['adults'] ?? 1));
                    $quotes_fallback = digimanagement_parallel_quote_fetch(
                        $price_quote_uuids, $fallback_ci, $fallback_co,
                        $adults_q, (int) ($_GET['children'] ?? 0), (int) ($_GET['infants'] ?? 0), (int) ($_GET['pets'] ?? 0)
                    );
                    if (is_array($quotes_fallback) && !empty($quotes_fallback)) {
                        $normalized = [];
                        foreach ($quotes_fallback as $uid => $q) {
                            if ($q !== null && is_array($q)) { $normalized[trim((string) $uid)] = $q; }
                        }
                        $GLOBALS['digim_quote_map'] = array_merge($existing_map, $normalized);
                    }
                }
            } catch (Exception $e) { /* ignore */ }
        }
    }

    if ($has_price_filter && !empty($properties_to_show) && isset($GLOBALS['digim_quote_map']) && is_array($GLOBALS['digim_quote_map']) && !empty($GLOBALS['digim_quote_map'])) {
        $quote_map = $GLOBALS['digim_quote_map'];
        $properties_to_show = array_values(array_filter($properties_to_show, function ($p) use ($quote_map, $price_min_val, $price_max_val) {
            $uuid = isset($p['uuid']) ? trim((string) $p['uuid']) : (isset($p['id']) ? trim((string) $p['id']) : '');
            if ($uuid === '') {
                return false; // exclude when price filter is active and we can't get a price
            }
            // Lookup quote (match template: exact then case-insensitive/trim fallback)
            $quote = $quote_map[$uuid] ?? null;
            if ((!$quote || !is_array($quote)) && !empty($quote_map)) {
                foreach ($quote_map as $map_uuid => $map_quote) {
                    $mu = trim((string) $map_uuid);
                    if ($mu === $uuid || strcasecmp($mu, $uuid) === 0) {
                        $quote = $map_quote;
                        break;
                    }
                }
            }
            if (!$quote || !is_array($quote)) {
                return false; // when price filter is active, only show properties we have a price for
            }
            // Use the same price the user sees (after discounts), not pre-discount total
            $total = isset($quote['total_before_tax']) && (float) $quote['total_before_tax'] > 0
                ? (float) $quote['total_before_tax']
                : 0;
            if ($total <= 0 && (isset($quote['subtotal']) || isset($quote['discounts']))) {
                $st = (float) ($quote['subtotal'] ?? 0);
                $discount_sum = 0.0;
                if (isset($quote['discounts']) && is_array($quote['discounts'])) {
                    foreach ($quote['discounts'] as $d) {
                        $discount_sum += (float) (isset($d['amount']) ? $d['amount'] : 0);
                    }
                }
                $total = $st - $discount_sum + (float) ($quote['cleaning_fee'] ?? 0) + (float) ($quote['service_fee'] ?? 0);
                $total = max(0.0, round($total, 2));
            }
            if ($total <= 0 && isset($quote['total'])) {
                $total = (float) $quote['total'];
            }
            if ($price_min_val !== null && $total < $price_min_val) {
                return false;
            }
            if ($price_max_val !== null && $price_max_val > 0 && $total > $price_max_val) {
                return false;
            }
            return true;
        }));
    }

    // When price filter is active, only hide pagination on page 1 (so 3 cards = no pagination).
    // On page 2+ leave pagination so the user can click back to page 1.
    if ($has_price_filter && $current_page <= 1) {
        $total_pages = 1;
    }

    $show_available_only = isset($_GET['show_available_only']) && $_GET['show_available_only'] === '1';
    global $digim_all_properties_for_filter, $digim_per_page, $digim_checkin_date, $digim_checkout_date;
    $digim_all_properties_for_filter = $all_properties;
    $digim_per_page = $per_page;
    $digim_checkin_date = $checkin;
    $digim_checkout_date = $checkout;

    // 🧭 Dropdown values - use ALL destinations (unfiltered) so users can always see and select all options
    $destination_names = $all_destination_names;

    // 🗺️ Map markers
    $marker_data = array_map(function ($p) {
        $property_slug = digimanagement_create_property_slug(
            $p['name'] ?? '', 
            $p['address']['city'] ?? ''
        );
        return [
            'lat' => $p['address']['coordinates']['latitude'] ?? $p['address']['latitude'] ?? null,
            'lng' => $p['address']['coordinates']['longitude'] ?? $p['address']['longitude'] ?? null,
            'name' => $p['name'] ?? 'No Name',
            'address' => $p['address']['display'] ?? '',
            'img' => $p['picture'] ?? '',
            'url' => site_url('/property/' . $property_slug . '/'),
        ];
    }, array_filter(
        $properties_to_show,
        fn($p) =>
        !empty($p['address']['coordinates']['latitude'] ?? $p['address']['latitude'] ?? null)
    ));

    if ($show_map) {
        wp_localize_script('digim-map-init', 'digimMapData', ['markers' => $marker_data]);
        // Expose for AJAX filter response so map can be updated with filtered markers
        $GLOBALS['digim_marker_data_for_response'] = $marker_data;
    }

    // 🔄 Render listings
    // Ensure primary color CSS applies to search bar/buttons across themes
    if (!function_exists('digim_darken_color')) {
        function digim_darken_color($hex, $percent = 20) {
            $hex = (string) $hex;
            if ($hex === '') { $hex = '#000000'; }
            $hex = str_replace('#', '', $hex);
            if (strlen($hex) !== 6) { return '#000000'; }
            $r = hexdec(substr($hex, 0, 2));
            $g = hexdec(substr($hex, 2, 2));
            $b = hexdec(substr($hex, 4, 2));
            $r = max(0, min(255, (int) round($r - ($r * $percent / 100))));
            $g = max(0, min(255, (int) round($g - ($g * $percent / 100))));
            $b = max(0, min(255, (int) round($b - ($b * $percent / 100))));
            return '#' . str_pad(dechex($r), 2, '0', STR_PAD_LEFT)
                       . str_pad(dechex($g), 2, '0', STR_PAD_LEFT)
                       . str_pad(dechex($b), 2, '0', STR_PAD_LEFT);
        }
    }

    $primary_color = is_string($primary_color) && $primary_color ? $primary_color : '#0073aa';
    $primary_color_hover = digim_darken_color($primary_color, 10);
    $primary_color_active = digim_darken_color($primary_color, 20);

    // Only add digim-shortcode CSS class if from UI builder
    $dynamic_css = "";
    if (!empty($digim_from_ui_builder)) {
        $dynamic_css = ".digim-main.digim-shortcode{padding:0 !important;margin:0 !important;}\n";
    }
    $dynamic_css .= ".digim-main .digimanagement-search .search-buttons button.search-button{background: {$primary_color} !important; background-color: {$primary_color} !important; color:#fff !important;}\n"
        . ".digim-main .digimanagement-search .search-buttons button.search-button:hover, .digim-main .digimanagement-search .search-buttons button.search-button:focus{background: {$primary_color_hover} !important; background-color: {$primary_color_hover} !important; color:#fff !important;}\n"
        . ".digim-main .digimanagement-search .search-buttons button.search-button:active{background: {$primary_color_active} !important; background-color: {$primary_color_active} !important; color:#fff !important;}\n";
    if (wp_style_is('digim-style', 'enqueued') || wp_style_is('digim-style', 'queue')) {
        wp_add_inline_style('digim-style', $dynamic_css);
    } else {
        // Fallback: print inline if style isn't registered yet
        add_action('wp_head', function() use ($dynamic_css) {
            echo '<style>' . $dynamic_css . '</style>';
        }, 101);
    }
    ob_start();
    include plugin_dir_path(__FILE__) . '/listings-template.php';
    
    // Reset flag after rendering
    $digim_from_ui_builder = false;
    
    return ob_get_clean();
}

// === SEARCH-ONLY SHORTCODE: [digim_search_form] ==============================

// Enqueue only what the form needs when the shortcode is present (no map libs)
add_action('wp_enqueue_scripts', function () {
    global $post;
    
    // Check if we should load the styles and scripts
    $should_load = false;
    
    // Check if shortcode exists in post content
    if (is_singular() && has_shortcode(get_post()->post_content, 'digim_search_form')) {
        $should_load = true;
    }
    
    // Check if we're on a page that might contain listings (like /listings/)
    if (is_page() && (strpos($_SERVER['REQUEST_URI'], '/listings') !== false || 
                     strpos($_SERVER['REQUEST_URI'], 'listings') !== false)) {
        $should_load = true;
    }
    
    // Check if we're on a property single page
    if (get_query_var('dm_property_uuid')) {
        $should_load = true;
    }
    
    // Check if the current page template or content contains digim classes
    if (isset($post) && (strpos($post->post_content, 'digim-main') !== false || 
                        strpos($post->post_content, 'digimanagement') !== false)) {
        $should_load = true;
    }
    
    // Fallback: Check if we're on any page that might need the plugin styles
    // This can be customized based on your specific needs
    $force_load_pages = ['listings', 'properties', 'search'];
    foreach ($force_load_pages as $page_slug) {
        if (is_page($page_slug) || strpos($_SERVER['REQUEST_URI'], $page_slug) !== false) {
            $should_load = true;
            break;
        }
    }
    
    if (!$should_load) return;

    // Styles
    wp_enqueue_style('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css', [], null);
    wp_enqueue_style('daterangepicker-css', 'https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css', [], null);
    wp_enqueue_style('digim-fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css', [], '6.5.2');

    // From inside a file under /plugins/DigiM/templates/... (uses .min when built)
    $style_asset = digim_asset('assets/css/style.css');
    if (file_exists($style_asset['path'])) {
        wp_enqueue_style('digim-style', $style_asset['url'], [], filemtime($style_asset['path']));
    }

    // Scripts
    wp_enqueue_script('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js', ['jquery'], null, true);
    wp_enqueue_script('moment-js', 'https://cdn.jsdelivr.net/npm/moment@2.29.4/moment.min.js', [], null, true);
    wp_enqueue_script('daterangepicker-js', 'https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js', ['moment-js', 'jquery'], null, true);
}, 5);

// [digim_search_form listingsurl="/listings"]
add_shortcode('digim_search_form', function ($atts = []) {
    // Ensure styles load when rendered via builders (e.g., Bricks); uses .min when built
    $style_asset = digim_asset('assets/css/style.css');
    if (file_exists($style_asset['path']) && !wp_style_is('digim-style', 'enqueued')) {
        wp_enqueue_style('digim-style', $style_asset['url'], [], filemtime($style_asset['path']));
    }
    // Ensure third-party CSS is present when rendered via builders
    if (!wp_style_is('select2', 'enqueued')) {
        wp_enqueue_style('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css', [], null);
    }
    if (!wp_style_is('daterangepicker-css', 'enqueued')) {
        wp_enqueue_style('daterangepicker-css', 'https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css', [], null);
    }

    // Ensure required JS deps are present when rendered via builders
    if (!wp_script_is('select2', 'enqueued')) {
        wp_enqueue_script('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js', ['jquery'], null, true);
    }
    if (!wp_script_is('moment-js', 'enqueued')) {
        wp_enqueue_script('moment-js', 'https://cdn.jsdelivr.net/npm/moment@2.29.4/moment.min.js', [], null, true);
    }
    if (!wp_script_is('daterangepicker-js', 'enqueued')) {
        wp_enqueue_script('daterangepicker-js', 'https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js', ['moment-js', 'jquery'], null, true);
    }

    // Accept optional redirection target
    $atts = shortcode_atts([
        'listingsurl' => '', // e.g. "/listings" (relative) or full URL
    ], $atts, 'digim_search_form');

    $listings_url = trim($atts['listingsurl']);
    // Allow relative paths; esc_url handles both
    $form_action = $listings_url ? esc_url($listings_url) : '';

    // Current filters from URL
    $search = isset($_GET['property_search']) ? $_GET['property_search'] : '';
    // Handle both array (multiple) and string (single) formats
    if (is_array($search)) {
        $search = array_map('sanitize_text_field', array_filter($search));
    } else {
        $search = $search ? [sanitize_text_field($search)] : [];
    }
    $checkin  = sanitize_text_field($_GET['checkin'] ?? '');
    $checkout = sanitize_text_field($_GET['checkout'] ?? '');

    // Initial label for flatpickr-range: "Weekend in March" when flexible, or date range when checkin+checkout (same as listings)
    $date_input_label = '';
    if (!empty($_GET['flex_mode']) && isset($_GET['flex_month']) && isset($_GET['flex_year'])) {
        $fm = (int) $_GET['flex_month'];
        if ($fm >= 1 && $fm <= 12) {
            $month_name = date('F', mktime(0, 0, 0, $fm, 1, 2000));
            $duration = (isset($_GET['flex_mode']) ? sanitize_text_field($_GET['flex_mode']) : '') === 'week' ? 'Week' : ((isset($_GET['flex_mode']) ? sanitize_text_field($_GET['flex_mode']) : '') === 'month' ? 'Month' : 'Weekend');
            $date_input_label = $duration . ' in ' . $month_name;
        }
    } elseif (!empty($checkin) && !empty($checkout)) {
        $date_input_label = date('M j, Y', strtotime($checkin)) . ' to ' . date('M j, Y', strtotime($checkout));
    }

    $adults   = max(1, intval($_GET['adults'] ?? 0));
    $children = intval($_GET['children'] ?? 0);
    $infants  = intval($_GET['infants'] ?? 0);
    $pets     = intval($_GET['pets'] ?? 0);
    $guest_count = max(1, $adults + $children + $infants); // default +1 guest always

    // Build destination dropdown values from cached properties
    if (!function_exists('digim_get_all_properties')) {
        return '<p style="color:#c00">digim_get_all_properties() not found.</p>';
    }
    $all_properties = digim_get_all_properties();
    $hidden_uuids = function_exists('digim_get_hidden_listing_uuids') ? digim_get_hidden_listing_uuids() : [];
    if (!empty($hidden_uuids)) {
        $all_properties = array_filter($all_properties, function ($p) use ($hidden_uuids) {
            $uuid = $p['uuid'] ?? $p['id'] ?? null;
            $uuid = $uuid !== null ? trim((string) $uuid) : '';
            return $uuid === '' || !in_array($uuid, $hidden_uuids, true);
        });
    }
    $destination_names = array_unique(array_filter(array_map(
        fn($p) => $p['address']['city'] ?? '',
        $all_properties
    )));
    sort($destination_names);

    ob_start();
    ?>
    <div class="digim-main digim-shortcode onlysearch">
        <form class="digimanagement-search" method="get" action="<?php echo $form_action; ?>" data-listings-url="<?php echo esc_attr($listings_url); ?>">
            <div class="search-grid">
                <!-- WHERE (same style as guest dropdown) -->
                <?php
                $search_array = is_array($search) ? $search : ($search ? [$search] : []);
                ?>
                <div class="search-group">
                    <label>Where</label>
                    <div class="city-dropdown-wrapper">
                        <button type="button" class="city-toggle">
                            <span class="city-placeholder">Search destinations</span>
                            <div class="city-chips" aria-hidden="true"></div>
                        </button>
                        <div class="city-dropdown guest-dropdown">
                            <?php foreach ($destination_names as $city): ?>
                                <div class="city-row guest-row<?php echo in_array($city, $search_array) ? ' selected' : ''; ?>" data-value="<?php echo esc_attr($city); ?>">
                                    <span class="city-name"><?php echo esc_html($city); ?></span>
                                    <span class="city-check" aria-hidden="true">✓</span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <select name="property_search[]" class="city-select city-select-hidden" multiple aria-hidden="true" tabindex="-1">
                            <?php foreach ($destination_names as $city): ?>
                                <option value="<?php echo esc_attr($city); ?>" <?php selected(true, in_array($city, $search_array)); ?>><?php echo esc_html($city); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <!-- CHECKIN / CHECKOUT -->
                <div class="search-group datecal">
                    <label>Check in / Check out</label>
                    <input
                        type="text"
                        class="flatpickr-range"
                        placeholder="Add dates"
                        autocomplete="off"
                        readonly
                        inputmode="none"
                        value="<?php echo esc_attr($date_input_label); ?>">
                    <input type="hidden" name="checkin" class="checkin-hidden" value="<?php echo esc_attr($checkin); ?>">
                    <input type="hidden" name="checkout" class="checkout-hidden" value="<?php echo esc_attr($checkout); ?>">
                    <?php $has_flex = !empty($_GET['flex_mode']) && isset($_GET['flex_month']) && isset($_GET['flex_year']); ?>
                    <input type="hidden" <?php echo $has_flex ? 'name="flex_mode"' : ''; ?> class="digim-flex-mode" value="<?php echo isset($_GET['flex_mode']) ? esc_attr(sanitize_text_field($_GET['flex_mode'])) : ''; ?>">
                    <input type="hidden" <?php echo $has_flex ? 'name="flex_month"' : ''; ?> class="digim-flex-month" value="<?php echo isset($_GET['flex_month']) ? intval($_GET['flex_month']) : ''; ?>">
                    <input type="hidden" <?php echo $has_flex ? 'name="flex_year"' : ''; ?> class="digim-flex-year" value="<?php echo isset($_GET['flex_year']) ? intval($_GET['flex_year']) : ''; ?>">
                </div>

                <!-- WHO -->
                <div class="search-group">
                    <label>Who</label>
                    <div class="guest-dropdown-wrapper">
                        <button type="button" class="guest-toggle">
                            <?php
                            $btn = 'Add guests';
                            $g   = $adults + $children;
                            if ($g > 0) {
                                $btn = $g . ' guest' . ($g > 1 ? 's' : '');
                                if ($infants > 0) $btn .= ", $infants infant" . ($infants > 1 ? 's' : '');
                                if ($pets    > 0) $btn .= ", $pets pet" . ($pets > 1 ? 's' : '');
                            }
                            echo esc_html($btn);
                            ?>
                        </button>
                        <div class="guest-dropdown">
                            <?php
                            $guest_types = [
                                'adults'   => ['label' => 'Adults',   'desc' => 'Ages 13 or above',         'val' => $adults],
                                'children' => ['label' => 'Children', 'desc' => 'Ages 2–12',                'val' => $children],
                                'infants'  => ['label' => 'Infants',  'desc' => 'Under 2',                 'val' => $infants],
                                'pets'     => ['label' => 'Pets',     'desc' => '<a href="/accessibility-policy" target="_blank" style="text-decoration: underline;">Bringing a service animal?</a>', 'val' => $pets],
                            ];
                            foreach ($guest_types as $type => $meta): ?>
                                <div class="guest-row">
                                    <div class="guest-labels">
                                        <span><?php echo esc_html($meta['label']); ?></span>
                                        <span><?php echo $meta['desc']; // may contain link 
                                                ?></span>
                                    </div>
                                    <div class="guest-controls">
                                        <button type="button" class="minus" aria-label="Decrease <?php echo esc_attr($type); ?>">−</button>
                                        <span class="guest-count"><?php echo intval($meta['val']); ?></span>
                                        <button type="button" class="plus" aria-label="Increase <?php echo esc_attr($type); ?>">+</button>
                                        <input type="hidden" name="<?php echo esc_attr($type); ?>" value="<?php echo intval($meta['val']); ?>">
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <input type="hidden" name="guests" value="<?php echo esc_attr($guest_count); ?>">
                    </div>
                </div>

                <!-- BUTTONS -->
                <div class="search-buttons">
                    <button type="button" class="reset-button" title="Reset"><i class="fas fa-undo"></i></button>
                    <button type="submit" class="search-button" title="Search"><i class="fas fa-search"></i></button>
                </div>
            </div>
        </form>

        <script>
            document.addEventListener("DOMContentLoaded", function() {
                if (document.querySelector('.digim-main.onlysearch')) document.body.classList.add('digim-has-onlysearch');
                function initDigimSearchOnce() {
                    // City dropdown uses custom UI (same style as guest dropdown), no Select2

                    // DateRangePicker range -> hidden fields
                    var rangeInput = document.querySelector('.digimanagement-search .flatpickr-range');
                    if (rangeInput && typeof jQuery !== 'undefined' && typeof moment !== 'undefined' && typeof jQuery.fn.daterangepicker !== 'undefined' && !rangeInput._digimDaterangepickerReady) {
                        var checkinHidden = document.querySelector('.digimanagement-search .checkin-hidden');
                        var checkoutHidden = document.querySelector('.digimanagement-search .checkout-hidden');

                        // Ensure moment.js is available and set to English locale for correct date calculations
                        if (typeof moment === 'undefined') {
                            console.error('Moment.js is required for DateRangePicker');
                            return;
                        }
                        
                        // Set locale to English to ensure correct day/month names and date calculations
                        moment.locale('en');

                        // Set initial dates if hidden inputs have values
                        var startDate = null;
                        var endDate = null;
                        if (checkinHidden && checkoutHidden && checkinHidden.value && checkoutHidden.value) {
                            startDate = moment(checkinHidden.value, 'YYYY-MM-DD', true);
                            endDate = moment(checkoutHidden.value, 'YYYY-MM-DD', true);
                        }

                        jQuery(rangeInput).daterangepicker({
                            startDate: (startDate && startDate.isValid()) ? startDate : moment(),
                            endDate: (endDate && endDate.isValid()) ? endDate : null,
                            minDate: moment(),
                            singleDatePicker: false,
                            autoUpdateInput: false,
                            autoApply: true, // Automatically apply selection when both dates are chosen
                            locale: {
                                format: 'MMM D, YYYY',
                                separator: ' to ',
                                applyLabel: 'Apply',
                                cancelLabel: 'Cancel',
                                fromLabel: 'From',
                                toLabel: 'To',
                                customRangeLabel: 'Custom',
                                weekLabel: 'W',
                                daysOfWeek: moment.weekdaysMin(),
                                monthNames: moment.months(),
                                firstDay: moment.localeData().firstDayOfWeek()
                            },
                            opens: 'left'
                        }, function(start, end, label) {
                            // Check if we're in flexible mode - if so, don't update the input here
                            var calendarEl = document.querySelector('.daterangepicker');
                            var isFlexibleActive = calendarEl && calendarEl.classList.contains('is-flexible');
                            
                            if (isFlexibleActive) {
                                // In flexible mode - don't update the input, flexible pane handles it
                                return;
                            }
                            
                            // Only proceed if start date is valid
                            if (!start || !start.isValid()) {
                                return;
                            }

                            // Check if both dates are valid and end is after start (at least 1 day difference)
                            if (end && end.isValid() && end.isAfter(start)) {
                                // Both dates are valid and end is at least 1 day after start
                                var checkinStr = start.format('YYYY-MM-DD');
                                var checkoutStr = end.format('YYYY-MM-DD');
                                
                                if (checkinHidden) checkinHidden.value = checkinStr;
                                if (checkoutHidden) checkoutHidden.value = checkoutStr;
                                
                                rangeInput.value = start.format('MMM D, YYYY') + ' to ' + end.format('MMM D, YYYY');
                                
                                // Clear flexible mode data when selecting actual dates
                                if (rangeInput.dataset) {
                                    delete rangeInput.dataset.digimFlexMode;
                                    delete rangeInput.dataset.digimFlexMonth;
                                    delete rangeInput.dataset.digimFlexYear;
                                }
                                
                                // Hide calendar after dates are selected (similar to property-single.php)
                                setTimeout(function() {
                                    var $calendar = jQuery('.daterangepicker');
                                    if ($calendar.length) {
                                        $calendar.hide();
                                    }
                                }, 100);
                            } else {
                                // Only start date is selected or end date is invalid
                                // Not in flexible mode - show "(Add other date)"
                                if (checkinHidden) checkinHidden.value = start.format('YYYY-MM-DD');
                                if (checkoutHidden) checkoutHidden.value = "";
                                rangeInput.value = start.format('MMM D, YYYY') + ' (Add other date)';
                            }
                        });

                        // Set display format (MMM D, YYYY format for search-group datecal - e.g., "Jan 15, 2024")
                        if (startDate && endDate) {
                            rangeInput.value = startDate.format('MMM D, YYYY') + ' to ' + endDate.format('MMM D, YYYY');
                        }

                        rangeInput._digimDaterangepickerReady = true;
                        
                        // Hide apply/cancel buttons since we use autoApply
                        jQuery(rangeInput).on('show.daterangepicker', function() {
                            setTimeout(function() {
                                var $calendar = jQuery('.daterangepicker');
                                if ($calendar.length) {
                                    // Dates/Flexible tabs are added by global handler in frontend.js (single .digim-tabs wrapper)
                                    // Add close button if it doesn't exist
                                    if ($calendar.find('.digim-close-button').length === 0) {
                                        var $closeButton = jQuery('<button type="button" class="digim-close-button">Close</button>');
                                        $closeButton.on('click', function() {
                                            var picker = jQuery(rangeInput).data('daterangepicker');
                                            if (picker) {
                                                picker.hide();
                                            }
                                        });
                                        $calendar.append($closeButton);
                                    }
                                    
                                    // Add prev/next navigation arrows for mobile only
                                    if ($calendar.find('.digim-calendar-prev').length === 0) {
                                        var $prevButton = jQuery('<button type="button" class="digim-calendar-prev" aria-label="Previous month"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15 18L9 12L15 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>');
                                        var $nextButton = jQuery('<button type="button" class="digim-calendar-next" aria-label="Next month"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9 18L15 12L9 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>');
                                        
                                        $prevButton.on('click', function(e) {
                                            e.preventDefault();
                                            e.stopPropagation();
                                            // Click the daterangepicker's prev button
                                            var $prevBtn = $calendar.find('.prev');
                                            if ($prevBtn.length) {
                                                $prevBtn.trigger('click');
                                            }
                                        });
                                        
                                        $nextButton.on('click', function(e) {
                                            e.preventDefault();
                                            e.stopPropagation();
                                            // Click the daterangepicker's next button
                                            var $nextBtn = $calendar.find('.next');
                                            if ($nextBtn.length) {
                                                $nextBtn.trigger('click');
                                            }
                                        });
                                        
                                        $calendar.append($prevButton);
                                        $calendar.append($nextButton);
                                    }
                                }
                            }, 10);
                        });
                        
                        // Remove class and close button when date picker closes
                        jQuery(rangeInput).on('hide.daterangepicker', function() {
                            var $calendar = jQuery('.daterangepicker');
                            
                            // Before cleaning up, check if we're in flexible mode and preserve the selection
                            var wasFlexible = false;
                            var flexibleData = null;
                            if ($calendar.length && $calendar.hasClass('is-flexible')) {
                                wasFlexible = true;
                                var storedInput = $calendar.data('digim-active-input') || rangeInput;
                                if (storedInput && storedInput.dataset) {
                                    flexibleData = {
                                        mode: storedInput.dataset.digimFlexMode,
                                        month: storedInput.dataset.digimFlexMonth,
                                        year: storedInput.dataset.digimFlexYear
                                    };
                                }
                            }
                            
                            if ($calendar.length) {
                                $calendar.removeClass('Digi-input-date-open is-flexible');
                                $calendar.find('.digim-close-button, .digim-calendar-prev, .digim-calendar-next, .digim-tabs').remove();
                            }
                            
                            // If we were in flexible mode with data, ensure it persists
                            if (wasFlexible && flexibleData && flexibleData.mode && flexibleData.month && flexibleData.year) {
                                // Immediately update all inputs
                                document.querySelectorAll('.digimanagement-search .flatpickr-range').forEach(function(input) {
                                    if (input.dataset) {
                                        input.dataset.digimFlexMode = flexibleData.mode;
                                        input.dataset.digimFlexMonth = flexibleData.month;
                                        input.dataset.digimFlexYear = flexibleData.year;
                                    }
                                });
                                
                                // Apply the label immediately
                                if (typeof window.applyFlatpickrRangeLabel === 'function') {
                                    window.applyFlatpickrRangeLabel();
                                }
                                
                                // Also apply again after a short delay to override any other handlers
                                setTimeout(function() {
                                    if (typeof window.applyFlatpickrRangeLabel === 'function') {
                                        window.applyFlatpickrRangeLabel();
                                    }
                                }, 50);
                            }
                        });
                        
                        // Also listen for when both dates are selected to ensure calendar closes
                        jQuery(rangeInput).on('apply.daterangepicker', function() {
                            setTimeout(function() {
                                var $calendar = jQuery('.daterangepicker');
                                if ($calendar.length) {
                                    $calendar.hide();
                                }
                            }, 50);
                        });
                        
                        // Listen for date clicks to hide calendar when both dates are selected
                        jQuery(document).on('click', '.daterangepicker td.available', function() {
                            setTimeout(function() {
                                var $calendar = jQuery('.daterangepicker');
                                if ($calendar.length) {
                                    var hasStartDate = $calendar.find('.start-date').length > 0;
                                    var hasEndDate = $calendar.find('.end-date').length > 0;
                                    if (hasStartDate && hasEndDate) {
                                        // Both dates selected, hide calendar
                                        setTimeout(function() {
                                            $calendar.hide();
                                        }, 100);
                                    }
                                }
                            }, 50);
                        });
                    }
                }

                // Try now
                initDigimSearchOnce();

                // Retry when daterangepicker loads late
                var tries = 0;
                var t = setInterval(function() {
                    if (typeof jQuery !== 'undefined' && typeof moment !== 'undefined' && typeof jQuery.fn.daterangepicker !== 'undefined') {
                        initDigimSearchOnce();
                        clearInterval(t);
                    } else if (++tries > 50) {
                        clearInterval(t);
                    }
                }, 150);

                // Observe DOM changes (builders injecting after DOMContentLoaded)
                var observer = new MutationObserver(function(mutations) {
                    for (var i = 0; i < mutations.length; i++) {
                        if (document.querySelector('.digimanagement-search .flatpickr-range')) {
                            initDigimSearchOnce();
                            break;
                        }
                    }
                });
                if (document.body) {
                    observer.observe(document.body, { childList: true, subtree: true });
                }

                // Guests dropdown + summary
                (function() {
                    var wrapper = document.querySelector(".digimanagement-search .guest-dropdown-wrapper");
                    if (!wrapper) return;

                    var toggleBtn = wrapper.querySelector(".guest-toggle");
                    var dropdown = wrapper.querySelector(".guest-dropdown");
                    var guestRows = wrapper.querySelectorAll(".guest-row");
                    var totalGuestsInput = wrapper.querySelector('input[name="guests"]');

                    function updateGuestSummary() {
                        var guests = 0,
                            infants = 0,
                            pets = 0;

                        guestRows.forEach(function(row) {
                            var input = row.querySelector('input[type="hidden"]');
                            var count = parseInt(input.value) || 0;
                            var type = input.name;

                            if (type === "adults" || type === "children") guests += count;
                            else if (type === "infants") infants = count;
                            else if (type === "pets") pets = count;

                            var label = row.querySelector(".guest-count");
                            if (label) label.textContent = count;
                        });

                        // Default +1 guest always: enforce at least 1 adult
                        if (guests < 1) {
                            guestRows.forEach(function(row) {
                                var input = row.querySelector('input[type="hidden"]');
                                if (input && input.name === "adults") {
                                    input.value = "1";
                                    var label = row.querySelector(".guest-count");
                                    if (label) label.textContent = "1";
                                }
                            });
                            guests = 1;
                        }

                        var text = guests > 0 ? (guests + " guest" + (guests > 1 ? "s" : "")) : "Add guests";
                        if (infants > 0) text += ", " + infants + " infant" + (infants > 1 ? "s" : "");
                        if (pets > 0) text += ", " + pets + " pet" + (pets > 1 ? "s" : "");

                        toggleBtn.textContent = text;
                        if (totalGuestsInput) totalGuestsInput.value = Math.max(1, guests + infants);
                    }

                    guestRows.forEach(function(row) {
                        var input = row.querySelector('input[type="hidden"]');
                        var minus = row.querySelector(".minus");
                        var plus = row.querySelector(".plus");

                        minus.addEventListener("click", function() {
                            var minVal = (input.name === "adults") ? 1 : 0;
                            input.value = Math.max(minVal, (parseInt(input.value) || 0) - 1);
                            updateGuestSummary();
                        });
                        plus.addEventListener("click", function() {
                            input.value = (parseInt(input.value) || 0) + 1;
                            updateGuestSummary();
                        });
                    });

                    toggleBtn.addEventListener("click", function() {
                        document.querySelectorAll(".digimanagement-search .city-dropdown-wrapper .city-dropdown").forEach(function(d) { d.classList.remove("active"); });
                        dropdown.classList.toggle("active");
                    });

                    document.addEventListener("click", function(e) {
                        if (!wrapper.contains(e.target)) dropdown.classList.remove("active");
                    });

                    // Reset form without reload
                    var formEl = document.querySelector('.digimanagement-search');
                    var resetBtn = document.querySelector('.digimanagement-search .reset-button');
                    if (resetBtn && formEl) {
                        resetBtn.addEventListener("click", function() {
                            // Reset city dropdown (custom UI + hidden select)
                            var citySelect = document.querySelector('.digimanagement-search select.city-select-hidden');
                            if (citySelect) {
                                Array.from(citySelect.options).forEach(function(o) { o.selected = false; });
                                var cityWrap = citySelect.closest('.city-dropdown-wrapper');
                                if (cityWrap) {
                                    cityWrap.querySelectorAll('.city-row').forEach(function(r) { r.classList.remove('selected'); });
                                    var updateUi = cityWrap._digimUpdateCityUI;
                                    if (typeof updateUi === 'function') updateUi();
                                }
                            }

                            // Reset date range (DateRangePicker)
                            var dateRangeInput = document.querySelector('.digimanagement-search .flatpickr-range');
                            if (dateRangeInput && typeof jQuery !== 'undefined' && jQuery(dateRangeInput).data('daterangepicker')) {
                                var picker = jQuery(dateRangeInput).data('daterangepicker');
                                picker.setStartDate(moment());
                                picker.setEndDate(null);
                                jQuery(dateRangeInput).val('');
                            } else if (dateRangeInput) {
                                dateRangeInput.value = '';
                            }
                            
                            // Reset hidden date inputs
                            var checkinHidden = document.querySelector('.digimanagement-search .checkin-hidden');
                            var checkoutHidden = document.querySelector('.digimanagement-search .checkout-hidden');
                            if (checkinHidden) checkinHidden.value = '';
                            if (checkoutHidden) checkoutHidden.value = '';

                            // Reset guest inputs (default +1 guest: adults = 1, rest = 0)
                            guestRows.forEach(function(row) {
                                var input = row.querySelector('input[type="hidden"]');
                                if (input) {
                                    input.value = (input.name === 'adults') ? '1' : '0';
                                }
                            });

                            // Update guest summary
                            updateGuestSummary();

                            // Clear URL parameters - reload only if URL has parameters
                            if (window.location.search) {
                                // URL has parameters, reload with clean URL
                                window.location.href = window.location.pathname;
                            }
                            // If no URL parameters, just reset inputs (already done above, no reload)
                        });
                    }

                    updateGuestSummary();
                })();

                // City dropdown (chips UI + only one dropdown active at a time)
                (function() {
                    var form = document.querySelector(".digimanagement-search");
                    if (!form) return;
                    var cityWrappers = form.querySelectorAll(".city-dropdown-wrapper");
                    cityWrappers.forEach(function(wrapper) {
                        var toggleBtn = wrapper.querySelector(".city-toggle");
                        var dropdown = wrapper.querySelector(".city-dropdown");
                        var placeholder = wrapper.querySelector(".city-placeholder");
                        var chipsContainer = wrapper.querySelector(".city-chips");
                        var rows = wrapper.querySelectorAll(".city-row");
                        var selectEl = wrapper.querySelector("select.city-select-hidden");
                        if (!toggleBtn || !dropdown || !selectEl) return;

                        function updateCityToggleUI() {
                            var selected = Array.from(selectEl.selectedOptions).map(function(o) { return o.value; });
                            if (!chipsContainer) return;
                            chipsContainer.innerHTML = "";
                            selected.forEach(function(value) {
                                var chip = document.createElement("span");
                                chip.className = "city-chip";
                                chip.setAttribute("data-value", value);
                                chip.innerHTML = value + ' <button type="button" class="city-chip-remove" aria-label="Remove ' + value + '">&times;</button>';
                                var removeBtn = chip.querySelector(".city-chip-remove");
                                removeBtn.addEventListener("click", function(e) {
                                    e.preventDefault();
                                    e.stopPropagation();
                                    var opt = Array.from(selectEl.options).filter(function(o) { return o.value === value; })[0];
                                    if (opt) { opt.selected = false; }
                                    var row = wrapper.querySelector('.city-row[data-value="' + value + '"]');
                                    if (row) row.classList.remove("selected");
                                    updateCityToggleUI();
                                });
                                chipsContainer.appendChild(chip);
                            });
                            toggleBtn.classList.toggle("has-chips", selected.length > 0);
                            if (placeholder) placeholder.style.display = selected.length ? "none" : "";
                        }

                        wrapper._digimUpdateCityUI = updateCityToggleUI;

                        toggleBtn.addEventListener("click", function(e) {
                            e.stopPropagation();
                            form.querySelectorAll(".guest-dropdown-wrapper .guest-dropdown").forEach(function(d) { d.classList.remove("active"); });
                            dropdown.classList.toggle("active");
                        });

                        rows.forEach(function(row) {
                            row.addEventListener("click", function() {
                                var val = row.getAttribute("data-value");
                                var opt = Array.from(selectEl.options).filter(function(o) { return o.value === val; })[0];
                                if (!opt) return;
                                opt.selected = !opt.selected;
                                row.classList.toggle("selected", opt.selected);
                                updateCityToggleUI();
                            });
                        });

                        document.addEventListener("click", function(e) {
                            if (!wrapper.contains(e.target)) dropdown.classList.remove("active");
                        });

                        updateCityToggleUI();
                    });
                })();
            });
        </script>
        <?php 
        // Ensure primary color is defined for search-only shortcode
        $primary_color = get_option('digim_primary_color', '#0073aa');
        if (empty($primary_color) || !is_string($primary_color)) {
            $primary_color = '#0073aa';
        }

        // Helper function to darken hex color (robust to null/invalid)
        if (!function_exists('digim_darken_color')) {
            function digim_darken_color($hex, $percent = 20) {
                $hex = (string) $hex;
                if ($hex === '') {
                    $hex = '#000000';
                }
                $hex = str_replace('#', '', $hex);
                if (strlen($hex) !== 6) {
                    return '#000000';
                }

                $r = hexdec(substr($hex, 0, 2));
                $g = hexdec(substr($hex, 2, 2));
                $b = hexdec(substr($hex, 4, 2));

                $r = max(0, min(255, (int) round($r - ($r * $percent / 100)))) ;
                $g = max(0, min(255, (int) round($g - ($g * $percent / 100)))) ;
                $b = max(0, min(255, (int) round($b - ($b * $percent / 100)))) ;

                return '#' . str_pad(dechex($r), 2, '0', STR_PAD_LEFT)
                           . str_pad(dechex($g), 2, '0', STR_PAD_LEFT)
                           . str_pad(dechex($b), 2, '0', STR_PAD_LEFT);
            }
        }

        $primary_color_hover = digim_darken_color($primary_color, 10);
        $primary_color_active = digim_darken_color($primary_color, 20);
        ?>

        <style>
            :root {
                --digim-primary-color: <?php echo $primary_color; ?>;
                --digim-primary-color-hover: <?php echo $primary_color_hover; ?>;
                --digim-primary-color-active: <?php echo $primary_color_active; ?>;
                --digim-primary-color-dark: <?php echo $primary_color; ?>dd;
                --digim-primary-color-darker: <?php echo $primary_color; ?>cc;
            }
            
            .digim-main .digimanagement-search .search-buttons button.search-button {
                background: <?php echo $primary_color; ?> !important;
                background-color: <?php echo $primary_color; ?> !important;
                color: #fff !important;
            }
            
            .digim-main .digimanagement-search .search-buttons button.search-button:hover,
            .digim-main .digimanagement-search .search-buttons button.search-button:focus {
                background: <?php echo $primary_color_hover; ?> !important;
                background-color: <?php echo $primary_color_hover; ?> !important;
                color: #fff !important;
            }
            
            .digim-main .digimanagement-search .search-buttons button.search-button:active {
                background: <?php echo $primary_color_active; ?> !important;
                background-color: <?php echo $primary_color_active; ?> !important;
                color: #fff !important;
            }
            
            .digim-main .digimanagement-pagination a.active {
                background: <?php echo $primary_color; ?> !important;
                border-color: <?php echo $primary_color; ?> !important;
            }

            .digimanagement-card.highlight {
                outline: 2px solid <?php echo $primary_color; ?> !important;
                box-shadow: 0 0 5px <?php echo $primary_color; ?> !important;
            }

            /* Minimal safety styles; keeps your structure intact */
            .guest-dropdown-wrapper {
                position: relative;
            }

            .guest-toggle {
                display: inline-flex;
                align-items: center;
                gap: .5rem;
                padding: .5rem .75rem;
                border: 1px solid #ddd;
                border-radius: 8px;
                background: #fff;
                cursor: pointer;
            }

            .guest-dropdown {
                position: absolute;
                top: 100%;
                left: 0;
                z-index: 50;
                width: 320px;
                max-width: 90vw;
                background: #fff;
                border: 1px solid #e5e7eb;
                border-radius: 12px;
                padding: .75rem;
                margin-top: .5rem;
                box-shadow: 0 10px 20px rgba(0, 0, 0, .08);
                display: none;
            }

            .guest-dropdown.active {
                display: block;
            }

            .guest-row {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 1rem;
                padding: .5rem 0;
            }

            .guest-labels {
                display: flex;
                flex-direction: column;
                gap: .15rem;
            }

            .guest-labels span:first-child {
                font-weight: 600;
            }

            .guest-labels span:last-child {
                font-size: .85rem;
                color: #6b7280;
            }

            .guest-controls {
                display: flex;
                align-items: center;
                gap: .75rem;
            }

            .guest-controls .minus,
            .guest-controls .plus {
                width: 32px;
                height: 32px;
                border-radius: 50%;
                border: 1px solid #ddd;
                background: #fff;
                line-height: 30px;
                text-align: center;
                font-size: 18px;
                cursor: pointer;
            }

            .search-grid {
                display: grid;
                grid-template-columns: repeat(4, minmax(0, 1fr));
                gap: 12px;
            }

            @media (max-width:768px) {
                .search-grid {
                    grid-template-columns: 1fr;
                }
            }

            .search-buttons {
                display: flex;
                align-items: center;
                gap: .5rem;
                justify-content: flex-end;
            }

            .search-button {
                padding: .6rem .9rem;
                border-radius: 10px;
                color: #fff;
                border: 1px solid transparent;
            }

            .reset-button {
                padding: .6rem .9rem;
                border-radius: 10px;
                border: 1px solid #ddd;
                background: #fff;
            }
        </style>
    </div>
<?php
    return ob_get_clean();
});

// === CARD SET SHORTCODE: [digim_cards id="dmcs_xxx"] ========================
add_shortcode('digim_cards', function ($atts = []) {
	// Set global flag that shortcode is being rendered
	global $digim_shortcode_rendered;
	$digim_shortcode_rendered = true;
	
	// Ensure styles are loaded (uses .min when built)
	$style_asset = digim_asset('assets/css/style.css');
	if (file_exists($style_asset['path']) && !wp_style_is('digim-style', 'enqueued')) {
		wp_enqueue_style('digim-style', $style_asset['url'], [], filemtime($style_asset['path']));
	}
	if (!wp_style_is('digim-fontawesome', 'enqueued')) {
		wp_enqueue_style('digim-fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css', [], '6.5.2');
	}
	$js_asset = digim_asset('assets/js/frontend.js');
	if (file_exists($js_asset['path']) && !wp_script_is('digim-frontend', 'enqueued')) {
		wp_enqueue_script('digim-frontend', $js_asset['url'], ['jquery'], filemtime($js_asset['path']), true);
	}
	
	$atts = shortcode_atts([
		'id' => '',
	], $atts, 'digim_cards');

	$set_id = sanitize_text_field($atts['id']);
	if (!$set_id) return '<p style="color:#c00">Missing card set id.</p>';

	$sets = get_option('digim_card_sets', []);
	if (!isset($sets[$set_id])) return '<p style="color:#c00">Card set not found.</p>';
	$set = $sets[$set_id];
	$uuids = $set['selected'] ?? [];
	$slider = !empty($set['slider']);
	$columns = intval($set['columns'] ?? 3);
	$random_value = $set['random'] ?? 0;
	$random = !empty($random_value);

	$primary_color = get_option('digim_primary_color', '#0073aa');

    $props = digim_build_props_from_uuids($uuids);
    if ($random == 1) {
        shuffle($props);
    }
    return digim_render_cards_block($props, $slider, $columns, $primary_color);
});

if (!function_exists('digim_build_props_from_uuids')) {
    function digim_build_props_from_uuids($uuids) {
        $all = digim_get_all_properties();
        // Exclude hidden listings (DigiM → Listings) so they never show in digim-main / digim-shortcode
        $hidden_uuids = function_exists('digim_get_hidden_listing_uuids') ? digim_get_hidden_listing_uuids() : [];
        if (!empty($hidden_uuids)) {
            $all = array_filter($all, function ($p) use ($hidden_uuids) {
                $uuid = $p['uuid'] ?? $p['id'] ?? null;
                $uuid = $uuid !== null ? trim((string) $uuid) : '';
                return $uuid === '' || !in_array($uuid, $hidden_uuids, true);
            });
        }
        $map = [];
        foreach ($all as $p) {
            $map[$p['uuid'] ?? ($p['id'] ?? '')] = $p;
        }
        $props = [];
        foreach ($uuids as $u) {
            if (isset($map[$u])) $props[] = $map[$u];
        }
        return $props;
    }
}

if (!function_exists('digim_render_cards_block')) {
    function digim_render_cards_block($props, $slider, $columns, $primary_color) {
        // Batch fetch images for all properties that need them (parallel API calls)
        $uuids_needing_images = [];
        foreach ($props as $property) {
            $uuid = $property['uuid'] ?? $property['id'] ?? '';
            // Only fetch if property doesn't have images in payload
            if (!empty($uuid) && (empty($property['images']) || !is_array($property['images']) || count($property['images']) === 0)) {
                $uuids_needing_images[] = $uuid;
            }
        }
        
        // Fetch all images in parallel
        if (!empty($uuids_needing_images) && function_exists('digimanagement_parallel_fetch_images')) {
            digimanagement_parallel_fetch_images($uuids_needing_images);
        }
        
        ob_start();
        if ($slider) {
            wp_enqueue_style('swiper-css', 'https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css', [], '10');
            wp_enqueue_script('swiper-js', 'https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js', [], '10', true);
            $container_id = 'digim-swiper-' . wp_generate_uuid4();
            ?>
            <div class="digim-main digim-shortcode" id="digim-wrapper-<?php echo esc_attr($container_id); ?>">
                <div class="swiper" id="<?php echo esc_attr($container_id); ?>">
                    <div class="swiper-wrapper">
                        <?php foreach ($props as $property): ?>
                            <div class="swiper-slide">
                                <?php echo digim_render_property_card($property); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="swiper-pagination"></div>
                </div>
                <button type="button" class="digim-swiper-prev" aria-label="Previous">
                    <svg width="47" height="47" viewBox="0 0 47 47" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <rect x="47" y="47" width="47" height="47" rx="23.5" transform="rotate(-180 47 47)" fill="#274D55"/>
                        <path d="M27 28.9376L25.9589 30L20.2884 24.2096C20.197 24.1169 20.1245 24.0065 20.075 23.885C20.0255 23.7635 20 23.6331 20 23.5015C20 23.3699 20.0255 23.2395 20.075 23.118C20.1245 22.9965 20.197 22.8862 20.2884 22.7934L25.9589 17L26.999 18.0625L21.6769 23.5L27 28.9376Z" fill="white"/>
                    </svg>
                </button>
                <button type="button" class="digim-swiper-next" aria-label="Next">
                    <svg width="47" height="47" viewBox="0 0 47 47" fill="none" xmlns="http://www.w3.org/2000/svg" style="transform: rotate(180deg);">
                        <rect x="47" y="47" width="47" height="47" rx="23.5" transform="rotate(-180 47 47)" fill="#274D55"/>
                        <path d="M27 28.9376L25.9589 30L20.2884 24.2096C20.197 24.1169 20.1245 24.0065 20.075 23.885C20.0255 23.7635 20 23.6331 20 23.5015C20 23.3699 20.0255 23.2395 20.075 23.118C20.1245 22.9965 20.197 22.8862 20.2884 22.7934L25.9589 17L26.999 18.0625L21.6769 23.5L27 28.9376Z" fill="white"/>
                    </svg>
                </button>
            </div>
            <script>
                (function() {
                    function initSwiper() {
                        var containerId = '<?php echo esc_js($container_id); ?>';
                        var wrapperId = 'digim-wrapper-<?php echo esc_js($container_id); ?>';
                        var swiperEl = document.getElementById(containerId);
                        var nextBtn = document.querySelector('#' + wrapperId + ' .digim-swiper-next');
                        var prevBtn = document.querySelector('#' + wrapperId + ' .digim-swiper-prev');
                        
                        if (!swiperEl) {
                            // Retry if element not found yet
                            setTimeout(initSwiper, 100);
                            return;
                        }
                        
                        if (window.Swiper) {
                            var swiper = new Swiper('#' + containerId, {
                                spaceBetween: 16,
                                loop: false,
                                pagination: { 
                                    el: '#' + containerId + ' .swiper-pagination', 
                                    clickable: true 
                                },
                                navigation: { 
                                    nextEl: '#' + wrapperId + ' .digim-swiper-next', 
                                    prevEl: '#' + wrapperId + ' .digim-swiper-prev' 
                                },
                                breakpoints: {
                                    320: { slidesPerView: 1 },
                                    640: { slidesPerView: 2 },
                                    960: { slidesPerView: Math.max(2, Math.min(4, <?php echo intval($columns); ?>)) },
                                }
                            });
                            
                            // Ensure buttons work even if Swiper navigation fails
                            if (nextBtn && !nextBtn._digimListener) {
                                nextBtn.addEventListener('click', function(e) {
                                    e.preventDefault();
                                    e.stopPropagation();
                                    if (swiper && swiper.slideNext) {
                                        swiper.slideNext();
                                    }
                                });
                                nextBtn._digimListener = true;
                            }
                            
                            if (prevBtn && !prevBtn._digimListener) {
                                prevBtn.addEventListener('click', function(e) {
                                    e.preventDefault();
                                    e.stopPropagation();
                                    if (swiper && swiper.slidePrev) {
                                        swiper.slidePrev();
                                    }
                                });
                                prevBtn._digimListener = true;
                            }
                        } else {
                            // Wait for Swiper to load
                            setTimeout(initSwiper, 100);
                        }
                    }
                    
                    if (document.readyState === 'loading') {
                        document.addEventListener('DOMContentLoaded', initSwiper);
                    } else {
                        initSwiper();
                    }
                })();
            </script>
            <style>
                :root { --digim-primary-color: <?php echo esc_html($primary_color); ?>; }
                .swiper-pagination-bullet-active { background: var(--digim-primary-color); }
                /* Custom arrow buttons */
                #digim-wrapper-<?php echo esc_html($container_id); ?> {
                    position: relative;
                    overflow: visible !important;
                }
                #<?php echo esc_html($container_id); ?> {
                    overflow: hidden !important;
                }
                #digim-wrapper-<?php echo esc_html($container_id); ?> .digim-swiper-prev,
                #digim-wrapper-<?php echo esc_html($container_id); ?> .digim-swiper-next { 
                    position: absolute; 
                    top: 50%; 
                    transform: translateY(-50%); 
                    z-index: 10; 
                    background: transparent; 
                    border: 0; 
                    padding: 0; 
                    cursor: pointer; 
                    width: 47px; 
                    height: 47px;
                }
                #digim-wrapper-<?php echo esc_html($container_id); ?> .digim-swiper-prev { left: -25px; }
                #digim-wrapper-<?php echo esc_html($container_id); ?> .digim-swiper-next { right: -25px; }
                #digim-wrapper-<?php echo esc_html($container_id); ?> .digim-swiper-prev svg,
                #digim-wrapper-<?php echo esc_html($container_id); ?> .digim-swiper-next svg { 
                    display: block; 
                    width: 47px; 
                    height: 47px; 
                }
                @media screen and (max-width: 1160px) {
                    #digim-wrapper-<?php echo esc_html($container_id); ?> .digim-swiper-prev {         left: auto;
                        position: relative;
                        left: -32px;
                        top: 24px;
                        transform: none;
                        margin: 0 auto;
                        display: flex; 
                    }
                    #digim-wrapper-<?php echo esc_html($container_id); ?> .digim-swiper-next { 
                        position: relative;
                        right: -32px;
                        top: -23px;
                        transform: none;
                        margin: 0 auto;
                        display: flex;  
                    }
                }
                @media screen and (max-width: 576px) {
                    #digim-wrapper-<?php echo esc_html($container_id); ?> .digim-swiper-prev {         left: auto;
                        position: relative;
                        left: -32px;
                        top: 0;
                        transform: none;
                        margin: 0 auto;
                        display: flex; 
                    }
                    #digim-wrapper-<?php echo esc_html($container_id); ?> .digim-swiper-next { 
                        position: relative;
                        right: -32px;
                        top: -47px;
                        transform: none;
                        margin: 0 auto;
                        display: flex;  
                    }
                }
            </style>
            <?php
        } else {
            $grid_class = "digimanagement-grid grid-cols-{$columns}";
            ?>
            <div class="digim-main digim-shortcode">
                <div class="dm-grid">
                    <div class="dm-property">
                        <div class="<?php echo esc_attr($grid_class); ?>">
                            <?php if (empty($props)): ?>
                                <p class="no-results" style="margin-top: 1rem;">No listings selected.</p>
                            <?php else: ?>
                                <?php foreach ($props as $property): ?>
                                    <?php echo digim_render_property_card($property); ?>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <style>
                :root { --digim-primary-color: <?php echo esc_html($primary_color); ?>; }
            </style>
            <?php
        }
        return ob_get_clean();
    }
}

if (!function_exists('digim_render_property_card')) {
	function digim_render_property_card($property) {
		$original_picture = $property['picture'] ?? '';
		$high_res_picture = preg_replace('/\?.*/', '', $original_picture);
		$uuid = $property['uuid'] ?? ($property['id'] ?? '');
		$property_slug = digimanagement_create_property_slug(
			$property['name'] ?? '',
			$property['address']['city'] ?? ''
		);
		$property_url = site_url('/property/' . esc_attr($property_slug) . '/');

        static $settings_cache = null;
        if ($settings_cache === null) {
            $settings_cache = [
                'row'        => intval(get_option('digim_show_capacity', 1)),
                'guests'     => intval(get_option('digim_show_capacity_guests', 1)),
                'bedrooms'   => intval(get_option('digim_show_capacity_bedrooms', 1)),
                'beds'       => intval(get_option('digim_show_capacity_beds', 1)),
                'bathrooms'  => intval(get_option('digim_show_capacity_bathrooms', 1)),
            ];
        }
        $show_capacity = apply_filters('digim_show_capacity_grid', $settings_cache['row'], $property);
        $show_capacity_guests = apply_filters('digim_show_capacity_guests', $settings_cache['guests'], $property);
        $show_capacity_bedrooms = apply_filters('digim_show_capacity_bedrooms', $settings_cache['bedrooms'], $property);
        $show_capacity_beds = apply_filters('digim_show_capacity_beds', $settings_cache['beds'], $property);
        $show_capacity_bathrooms = apply_filters('digim_show_capacity_bathrooms', $settings_cache['bathrooms'], $property);

        // Fetch gallery images (optimized: use cache first, then property payload, then API)
        $gallery_images = [];
        $seen_urls = [];
        
        // Priority 1: Use images already present on the property payload (no extra requests)
        if (!empty($property['images']) && is_array($property['images'])) {
            foreach ($property['images'] as $img) {
                $url = '';
                if (is_array($img)) {
                    // Prefer url (medium-res) for crisp card gallery
                    $url = $img['url'] ?? $img['original_url'] ?? $img['thumbnail_url'] ?? '';
                    if (!$url && isset($img[0]) && is_string($img[0])) {
                        $url = $img[0];
                    }
                } elseif (is_string($img)) {
                    $url = $img;
                }
                if ($url && !in_array($url, $seen_urls, true)) {
                    $gallery_images[] = $url;
                    $seen_urls[] = $url;
                    if (count($gallery_images) >= 4) {
                        break;
                    }
                }
            }
        }
        
        // Priority 2: Check cache for images (from parallel fetch or previous requests)
        if (empty($gallery_images) && !empty($uuid)) {
            $cache_key = 'digim_images_v2_' . md5($uuid);
            $cached_images = get_transient($cache_key);
            if ($cached_images !== false && is_array($cached_images)) {
                foreach ($cached_images as $url) {
                    if ($url && !in_array($url, $seen_urls, true)) {
                        $gallery_images[] = $url;
                        $seen_urls[] = $url;
                        if (count($gallery_images) >= 4) {
                            break;
                        }
                    }
                }
            }
        }
        
        // Priority 3: Only make API call if cache miss and no images in payload (fallback)
        if (empty($gallery_images) && !empty($uuid) && function_exists('digimanagement_get_api_url') && function_exists('digimanagement_get_api_token')) {
            $images_response = wp_remote_get(digimanagement_get_api_url() . "/properties/$uuid/images", [
                'headers' => [
                    'Authorization' => digimanagement_get_api_token(),
                    'Accept' => 'application/json',
                ],
                'timeout' => 8, // Shorter timeout
            ]);

            if (!is_wp_error($images_response)) {
                $images_data = json_decode(wp_remote_retrieve_body($images_response), true);
                
                foreach ($images_data['data'] ?? [] as $img) {
                    $url = $img['url'] ?? $img['original_url'] ?? $img['thumbnail_url'] ?? null;
                    if ($url && !in_array($url, $seen_urls, true)) {
                        $gallery_images[] = $url;
                        $seen_urls[] = $url;
                        if (count($gallery_images) >= 4) {
                            break;
                        }
                    }
                }
                
                // Cache the results
                if (!empty($gallery_images)) {
                    $cache_key = 'digim_images_v2_' . md5($uuid);
                    set_transient($cache_key, $gallery_images, 60 * 30); // 30 minutes
                }
            }
        }
        
        // Priority 4: Fallback to property data images if we still don't have enough
        if (count($gallery_images) < 3 && !empty($property['images']) && is_array($property['images'])) {
            foreach ($property['images'] as $img) {
                $url = '';
                if (is_array($img)) {
                    $url = $img['url'] ?? $img['original_url'] ?? '';
                    if (!$url && isset($img[0]) && is_string($img[0])) {
                        $url = $img[0];
                    }
                } elseif (is_string($img)) {
                    $url = $img;
                }
                if ($url && !in_array($url, $seen_urls)) {
                    $gallery_images[] = $url;
                    $seen_urls[] = $url;
                    if (count($gallery_images) >= 4) {
                        break;
                    }
                }
            }
        }
        
        // Priority 3: Fallback to high_res_picture if no images found
        if (empty($gallery_images) && !empty($high_res_picture)) {
            $gallery_images[] = $high_res_picture;
        }
        $gallery_count = count($gallery_images);

		ob_start();
		?>
		<a href="<?php echo esc_url($property_url); ?>" class="digimanagement-card" target="_blank" rel="noopener">
			<?php if ($gallery_count > 0): ?>
				<div class="digim-card-media" data-digim-gallery>
					<?php if (!empty($property['_digim_almost_fully_booked'])): ?>
						<span class="digim-almost-fully-booked-badge">
							<span class="almost-fully-booked-dot" aria-hidden="true"></span>
							<?php echo esc_html(__('Almost Fully Booked', 'digim')); ?>
						</span>
					<?php endif; ?>
					<?php if (!empty($property['_digim_best_value'])): ?>
						<span class="digim-best-value-badge">
							<span class="best-value-dot" aria-hidden="true"></span>
							<?php echo esc_html(__('Breezy Choice', 'digim')); ?>
						</span>
					<?php endif; ?>
					<div class="digim-card-gallery" data-digim-gallery-track>
						<?php foreach ($gallery_images as $index => $image_url): ?>
							<div class="digim-card-slide <?php echo $index === 0 ? 'is-active' : ''; ?>" data-digim-gallery-slide="<?php echo esc_attr($index); ?>">
								<img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($property['name'] ?? 'Property image'); ?>" loading="lazy" decoding="async" />
							</div>
						<?php endforeach; ?>
					</div>
					<?php if ($gallery_count > 1): ?>
						<button class="digim-gallery-nav previous" type="button" aria-label="<?php echo esc_attr__('View previous image', 'digim'); ?>" data-digim-gallery-prev>
							<span aria-hidden="true">&lsaquo;</span>
						</button>
						<button class="digim-gallery-nav next" type="button" aria-label="<?php echo esc_attr__('View next image', 'digim'); ?>" data-digim-gallery-next>
							<span aria-hidden="true">&rsaquo;</span>
						</button>
						<div class="digim-gallery-indicators" role="tablist">
							<?php foreach ($gallery_images as $index => $image_url): ?>
								<button type="button" class="digim-gallery-dot <?php echo $index === 0 ? 'is-active' : ''; ?>" aria-label="<?php echo esc_attr(sprintf(__('Show image %d', 'digim'), $index + 1)); ?>" data-digim-gallery-dot="<?php echo esc_attr($index); ?>"></button>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>
				</div>
			<?php endif; ?>
			<div class="digim-card-content">
				<h3 class="digim-title"><?php echo esc_html($property['name'] ?? 'Untitled'); ?></h3>
				<?php
				$city = trim((string) ($property['address']['city'] ?? ''));
				$state = trim((string) ($property['address']['state'] ?? $property['address']['state_name'] ?? ''));
				$country = trim((string) ($property['address']['country'] ?? ''));
				$country_code = trim((string) ($property['address']['country_code'] ?? ''));
				$short_address_parts = array_filter([
					$city,
					$state,
					$country ?: $country_code,
				], static function ($part) {
					return $part !== '';
				});
				$short_address_parts = array_values(array_unique($short_address_parts));
				$short_address = implode(', ', $short_address_parts);
				if ($short_address === '' && !empty($property['address']['display'])) {
					$short_address = $property['address']['display'];
				}
				?>
				<?php if ($short_address !== ''): ?>
					<p class="digim-address"><?php echo esc_html($short_address); ?></p>
				<?php endif; ?>
                <?php if ($show_capacity): ?>
                    <?php
                    $capacity_parts = [];
                    if ($show_capacity_bedrooms && ($property['capacity']['bedrooms'] ?? '')) {
                        $n = intval($property['capacity']['bedrooms']);
                        $capacity_parts[] = $n . ' ' . ($n === 1 ? 'bedroom' : 'bedrooms');
                    }
                    if ($show_capacity_beds && ($property['capacity']['beds'] ?? '')) {
                        $n = intval($property['capacity']['beds']);
                        $capacity_parts[] = $n . ' ' . ($n === 1 ? 'bed' : 'beds');
                    }
                    if ($show_capacity_bathrooms && ($property['capacity']['bathrooms'] ?? '')) {
                        $n = intval($property['capacity']['bathrooms']);
                        $capacity_parts[] = $n . ' ' . ($n === 1 ? 'bath' : 'baths');
                    }
                    $capacity_text = implode(' · ', $capacity_parts);
                    if ($capacity_text !== ''):
                    ?>
                    <p class="digim-capacity-inline"><?php echo esc_html($capacity_text); ?></p>
                    <?php endif; ?>
                <?php endif; ?>
                <?php
                global $digim_quote_map, $digim_checkin_date, $digim_checkout_date;
                $quote = (isset($digim_quote_map) && is_array($digim_quote_map) && !empty($uuid)) ? ($digim_quote_map[$uuid] ?? null) : null;
                $total_bt = $quote && isset($quote['total_before_tax']) ? (float) $quote['total_before_tax'] : (float) ($quote['total'] ?? 0);
                $show_pricing = $quote && $total_bt > 0;
                $has_dates_no_quote = !empty($digim_checkin_date) && !empty($digim_checkout_date) && !$show_pricing;
                $is_suggestion = !empty($property['_digim_is_suggestion']);
                $show_price_fallback = $has_dates_no_quote && !$is_suggestion;
                if ($show_pricing):
                    $symbol = $quote['symbol'] ?? '$';
                    $nights = (int) ($quote['nights'] ?? 1);
                    $checkin_fmt = '';
                    $checkout_fmt = '';
                    if (!empty($quote['checkin']) && !empty($quote['checkout'])) {
                        $ci = DateTimeImmutable::createFromFormat('Y-m-d', $quote['checkin'], wp_timezone());
                        $co = DateTimeImmutable::createFromFormat('Y-m-d', $quote['checkout'], wp_timezone());
                        if ($ci && $co) {
                            $checkin_fmt = $ci->format('M j');
                            $checkout_fmt = $co->format('M j');
                        }
                    }
                    $date_range = ($checkin_fmt && $checkout_fmt) ? $checkin_fmt . ' – ' . $checkout_fmt : '';
                    $discounts = isset($quote['discounts']) && is_array($quote['discounts']) ? $quote['discounts'] : [];
                    $discount_sum = 0.0;
                    foreach ($discounts as $d) {
                        $discount_sum += (float) (isset($d['amount']) ? $d['amount'] : 0);
                    }
                    $has_discount = $discount_sum > 0;
                    $original_price = $has_discount ? $total_bt + $discount_sum : $total_bt;
                ?>
                    <div class="digim-pricing-section">
                        <?php if ($date_range !== ''): ?>
                            <p class="digim-price-date-range"><?php echo esc_html($date_range); ?></p>
                        <?php endif; ?>
                        <p class="digim-price-display">
                            <?php if ($has_discount): ?>
                                <span class="digim-price-original"><?php echo esc_html($symbol . number_format($original_price, 0)); ?></span>
                            <?php endif; ?>
                            <span class="digim-price-total"><?php echo esc_html($symbol . number_format($total_bt, 0)); ?></span> <span class="digim-price-for-nights"><?php echo esc_html(sprintf(__('for %d night%s', 'digim'), $nights, $nights !== 1 ? 's' : '')); ?></span>
                        </p>
                        <?php foreach ($discounts as $d): ?>
                            <?php
                            $d_name = isset($d['name']) ? (string) $d['name'] : '';
                            $d_amt = isset($d['amount']) ? (float) $d['amount'] : 0;
                            if ($d_name === '') { continue; }
                            ?>
                            <p class="digim-price-discount-line"><?php echo esc_html($d_name . ' -' . $symbol . number_format($d_amt, 2)); ?></p>
                        <?php endforeach; ?>
                    </div>
                <?php elseif ($show_price_fallback): ?>
                    <div class="digim-pricing-section">
                        <p class="digim-price-display digim-price-fallback"><?php echo esc_html__('Price on request', 'digim'); ?></p>
                    </div>
                <?php endif; ?>
			</div>
		</a>
		<?php
		return ob_get_clean();
	}
}
