<?php
add_action('wp_enqueue_scripts', function () {
    if (is_singular() && has_shortcode(get_post()->post_content, 'digimanagement_listings')) {
        wp_enqueue_style('leaflet', 'https://unpkg.com/leaflet/dist/leaflet.css');
        wp_enqueue_style('leaflet-cluster', 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.css');
        wp_enqueue_style('leaflet-cluster-default', 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css');
        wp_enqueue_style('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css');
        wp_enqueue_style('flatpickr-css', 'https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css');
        wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css');

        wp_enqueue_script('leaflet', 'https://unpkg.com/leaflet/dist/leaflet.js', [], null, true);
        wp_enqueue_script('leaflet-cluster', 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js', ['leaflet'], null, true);
        wp_enqueue_script('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js', ['jquery'], null, true);
        wp_enqueue_script('flatpickr-js', 'https://cdn.jsdelivr.net/npm/flatpickr', [], null, true);

        $map_init_path = plugin_dir_path(__FILE__) . '../assets/js/map-init.js';
        if (file_exists($map_init_path)) {
            wp_enqueue_script('digim-map-init', plugin_dir_url(__FILE__) . '../assets/js/map-init.js', ['leaflet', 'leaflet-cluster'], filemtime($map_init_path), true);
        }

        // Inline Select2 init
        add_action('wp_footer', function () {
?>
            <script>
                jQuery(document).ready(function($) {
                    $('select[name="property_search"]').select2({
                        placeholder: "Search destination",
                        allowClear: true,
                        width: '100%'
                    });
                });
            </script>
<?php
        }, 100);
    }
});

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('digim-fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css', [], '6.5.2');
}, 5);

add_shortcode('digimanagement_listings', 'digimanagement_hospitable_listings_shortcode');

// ✅ Load all properties (with pagination + caching)
function digim_get_all_properties()
{
    $cache_key = 'digim_all_properties';
    $all_properties = get_transient($cache_key);

    if (!$all_properties) {
        $all_properties = [];
        $page = 1;

        do {
            $response = wp_remote_get(digimanagement_get_api_url() . "/properties?page=$page", [
                'headers' => [
                    'Authorization' => digimanagement_get_api_token(),
                    'Accept' => 'application/json',
                ],
                'timeout' => 15,
            ]);

            if (is_wp_error($response)) break;

            $data = json_decode(wp_remote_retrieve_body($response), true);
            if (!isset($data['data'])) break;

            $all_properties = array_merge($all_properties, $data['data']);
            $has_more = isset($data['links']['next']) && $data['links']['next'];
            $page++;
        } while ($has_more);

        set_transient($cache_key, $all_properties, 60 * 10); // cache for 10 mins
    }

    return $all_properties;
}

// ✅ Main shortcode logic
function digimanagement_hospitable_listings_shortcode()
{
    $layout_style = get_option('digim_layout_style', 'grid');
    $per_page = intval(get_option('digim_cards_per_page', 12));
    $grid_columns = intval(get_option('digim_grid_columns', 3));
    $card_style = get_option('digim_card_style', 'classic');
    $primary_color = get_option('digim_primary_color', '#0073aa');
    $show_map = get_option('digim_show_map', false);

    $search = sanitize_text_field($_GET['property_search'] ?? '');
    $checkin = sanitize_text_field($_GET['checkin'] ?? '');
    $checkout = sanitize_text_field($_GET['checkout'] ?? '');
    $current_page = max(1, intval($_GET['property_page'] ?? 1));

    // 🔄 Fetch all properties
    $all_properties = digim_get_all_properties();

    // 🔎 Filter: City
    if ($search) {
        $all_properties = array_filter(
            $all_properties,
            fn($p) =>
            stripos($p['address']['city'] ?? '', $search) !== false
        );
    }

    // 👥 Guests (adults + children + infants)
    $adults = intval($_GET['adults'] ?? 0);
    $children = intval($_GET['children'] ?? 0);
    $infants = intval($_GET['infants'] ?? 0);
    $total_guests = $adults + $children + $infants;

    if ($total_guests > 0) {
        $all_properties = array_filter(
            $all_properties,
            fn($p) => ($p['capacity']['max'] ?? 0) >= $total_guests
        );
    }

    // 📅 Availability (calendar check)
    if ($checkin && $checkout) {
        $uuids = array_map(fn($p) => $p['uuid'] ?? $p['id'], $all_properties);
        $available_uuids = digimanagement_parallel_calendar_check($uuids, $checkin, $checkout);
        $all_properties = array_filter(
            $all_properties,
            fn($p) =>
            in_array($p['uuid'] ?? $p['id'], $available_uuids)
        );
    }

    // 📦 Pagination
    $total = count($all_properties);
    $total_pages = ceil($total / $per_page);
    $properties_to_show = array_slice($all_properties, ($current_page - 1) * $per_page, $per_page);

    // 🧭 Dropdown values
    $destination_names = array_unique(array_filter(array_map(
        fn($p) =>
        $p['address']['city'] ?? '',
        $all_properties
    )));
    sort($destination_names);

    // 🗺️ Map markers
    $marker_data = array_map(function ($p) {
        return [
            'lat' => $p['address']['coordinates']['latitude'] ?? $p['address']['latitude'] ?? null,
            'lng' => $p['address']['coordinates']['longitude'] ?? $p['address']['longitude'] ?? null,
            'name' => $p['name'] ?? 'No Name',
            'address' => $p['address']['display'] ?? '',
            'img' => $p['picture'] ?? '',
            'url' => site_url('/property/' . ($p['uuid'] ?? $p['id']) . '/'),
        ];
    }, array_filter(
        $properties_to_show,
        fn($p) =>
        !empty($p['address']['coordinates']['latitude'] ?? $p['address']['latitude'] ?? null)
    ));

    if ($show_map) {
        wp_localize_script('digim-map-init', 'digimMapData', ['markers' => $marker_data]);
    }

    // 🔄 Render listings
    ob_start();
    include plugin_dir_path(__FILE__) . '/listings-template.php';
    return ob_get_clean();
}
