document.addEventListener("DOMContentLoaded", function () {
  flatpickr(".flatpickr-range", {
    mode: "range",
    minDate: "today",
    dateFormat: "Y-m-d",
    altInput: true,
    allowInput: false,

    onChange: function (selectedDates, dateStr, instance) {
      const [checkin, checkout] = selectedDates;

      const pad = (n) => String(n).padStart(2, "0");
      const formatDate = (d) =>
        `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

      const checkinStr = checkin ? formatDate(checkin) : "";
      const checkoutStr = checkout ? formatDate(checkout) : "";

      document.querySelector(".checkin-hidden").value = checkinStr;
      document.querySelector(".checkout-hidden").value = checkoutStr;

      if (checkinStr && checkoutStr) {
        document.querySelector(
          "input[name='date_range']"
        ).value = `${checkinStr} to ${checkoutStr}`;
      } else {
        document.querySelector("input[name='date_range']").value = "";
      }
    },
    onReady: function (selectedDates, dateStr, instance) {
      const checkinInput = document.querySelector(".checkin-hidden").value;
      const checkoutInput = document.querySelector(".checkout-hidden").value;

      if (checkinInput && checkoutInput) {
        const checkinDate = new Date(checkinInput + "T00:00:00");
        const checkoutDate = new Date(checkoutInput + "T00:00:00");

        instance.setDate([checkinDate, checkoutDate], true);

        document.querySelector(
          "input[name='date_range']"
        ).value = `${checkinInput} to ${checkoutInput}`;
      }
    },
  });
});

document.addEventListener("DOMContentLoaded", function () {
  const trigger = document.querySelector(
    ".digimanagement-mobile-trigger .mobilesearchdestination"
  );
  const modal = document.querySelector(".digimanagement-mobile-modal");
  const closeBtn = document.querySelector(".digim-close-modal");

  if (trigger && modal && closeBtn) {
    trigger.addEventListener("click", () => {
      modal.classList.add("active");
    });

    closeBtn.addEventListener("click", () => {
      modal.classList.remove("active");
    });

    // Optional: close on outside click
    modal.addEventListener("click", (e) => {
      if (e.target === modal) {
        modal.classList.remove("active");
      }
    });
  }
});
