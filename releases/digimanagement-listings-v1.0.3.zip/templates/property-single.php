<?php

/**
 * Template: Single Property
 * Called by your plugin when visiting /property/{uuid}
 */

include get_template_directory() . '/header.php';

// Get UUID
$uuid = get_query_var('dm_property_uuid');

// Fetch property details
$response = wp_remote_get(digimanagement_get_api_url() . "/properties/$uuid", [
    'headers' => [
        'Authorization' => digimanagement_get_api_token(),
        'Accept' => 'application/json',
        'Cache-Control' => 'no-cache',
    ],
    'timeout' => 15,
]);

if (is_wp_error($response)) {
    echo '<p>Error: ' . esc_html($response->get_error_message()) . '</p>';
    get_footer();
    return;
}

$data = json_decode(wp_remote_retrieve_body($response), true);
$property = $data['data'] ?? null;

if (!$property) {
    echo '<p>Property not found.</p>';
    get_footer();
    return;
}

// ✅ Fetch images from dedicated /images endpoint
$images = [];
$images_response = wp_remote_get(digimanagement_get_api_url() . "/properties/$uuid/images", [
    'headers' => [
        'Authorization' => digimanagement_get_api_token(),
        'Accept' => 'application/json',
        'Cache-Control' => 'no-cache',
    ],
    'timeout' => 10,
]);

if (!is_wp_error($images_response)) {
    $images_data = json_decode(wp_remote_retrieve_body($images_response), true);

    $seen = [];
    foreach ($images_data['data'] ?? [] as $img) {
        $url = $img['original_url'] ?? $img['url'] ?? $img['thumbnail_url'] ?? null;
        if ($url && !in_array($url, $seen)) {
            $images[] = $url;
            $seen[] = $url;
        }
    }
}

$coords = $property['address']['coordinates'] ?? null;
$amenities = $property['amenities'] ?? [];
$amenity_icons = [
    'wifi' => '📶',
    'ac' => '❄️',
    'tv' => '📺',
    'kitchen' => '🍳',
    'washer' => '🧺',
    'dryer' => '🧺',
    'parking' => '🅿️',
    'bbq_area' => '🍖',
    'fire_pit' => '🔥',
    'bathtub' => '🛁',
    'pets_allowed' => '🐾',
];
$max_shown = 8;
?>

<div class="property-page">

    <!-- ✅ HERO + GRID GALLERY -->
    <?php if (!empty($images)): ?>
        <div class="gallery-grid">
            <div class="hero-photo">
                <img src="<?php echo esc_url($images[0]); ?>" alt="Main Photo" loading="lazy">
            </div>
            <?php if (count($images) > 1): ?>
                <div class="grid-photos">
                    <?php foreach (array_slice($images, 1, 4) as $index => $img): ?>
                        <div class="grid-item">
                            <img src="<?php echo esc_url($img); ?>" alt="Photo <?php echo $index + 2; ?>" loading="lazy">
                            <?php if ($index === 3 && count($images) > 5): ?>
                                <button class="view-all-btn" onclick="document.getElementById('photos-modal').style.display='block'">
                                    Show all photos
                                </button>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <!-- ✅ MAIN GRID -->
    <div class="property-main">
        <div class="property-left">
            <h1><?php echo esc_html($property['name'] ?? ''); ?></h1>
            <p class="address"><?php echo esc_html($property['address']['display'] ?? ''); ?></p>

            <div class="meta">
                <?php echo intval($property['capacity']['max'] ?? 0); ?> guests ·
                <?php echo intval($property['capacity']['bedrooms'] ?? 0); ?> bedrooms ·
                <?php echo intval($property['capacity']['beds'] ?? 0); ?> beds ·
                <?php echo intval($property['capacity']['bathrooms'] ?? 0); ?> baths
            </div>

            <div class="description">
                <?php echo nl2br(esc_html($property['description'] ?? $property['summary'] ?? '')); ?>
            </div>

            <!-- ✅ Amenities -->
            <?php if (!empty($amenities)): ?>
                <div class="property-amenities">
                    <h2>What this place offers</h2>
                    <div class="amenities-list">
                        <?php foreach (array_slice($amenities, 0, $max_shown) as $a):
                            $label = ucwords(str_replace('_', ' ', $a));
                            $icon = $amenity_icons[$a] ?? '✔️';
                            echo '<span class="amenity-item">' . $icon . ' ' . esc_html($label) . '</span>';
                        endforeach; ?>
                    </div>
                    <?php if (count($amenities) > $max_shown): ?>
                        <button class="show-all-btn" onclick="document.getElementById('amenities-modal').style.display='block'">
                            Show all <?php echo count($amenities); ?> amenities
                        </button>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <!-- ✅ Map -->
            <?php if ($coords): ?>
                <div class="property-map">
                    <h2>Where you’ll be</h2>
                    <div id="map" style="height:400px;border-radius:12px;"></div>
                </div>
                <script>
                    document.addEventListener("DOMContentLoaded", function() {
                        var map = L.map('map').setView([<?php echo $coords['latitude']; ?>, <?php echo $coords['longitude']; ?>], 15);
                        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);
                        L.marker([<?php echo $coords['latitude']; ?>, <?php echo $coords['longitude']; ?>]).addTo(map);
                    });
                </script>
                <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
                <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
            <?php endif; ?>
        </div>

        <!-- ✅ Booking -->
        <div class="property-right">
            <div class="booking-box">
                <?php
                $account_username = 'digimaccount';
                $property_id = $property['id'] ?? '';
                $uuid = $property['uuid'] ?? '';
                $checkin = $_GET['checkin'] ?? '';
                $checkout = $_GET['checkout'] ?? '';
                $guests = max(1, intval($_GET['guests'] ?? $_GET['adults'] ?? 1));

                $iframe_url = "https://booking.hospitable.com/book/" .
                    rawurlencode($account_username) . "/" .
                    rawurlencode($property_id) . "/" .
                    rawurlencode($uuid) . "?theme=default";

                if ($checkin)   $iframe_url .= "&checkin=" . urlencode($checkin);
                if ($checkout)  $iframe_url .= "&checkout=" . urlencode($checkout);
                if ($guests)    $iframe_url .= "&adults=" . intval($guests); // ✅ change from guests to adults

                ?>

                <iframe
                    src="<?php echo esc_url($iframe_url); ?>"
                    width="100%"
                    height="850"
                    style="border: none; border-radius: 10px;"
                    allow="payment; fullscreen">
                </iframe>
            </div>
        </div>

    </div>
</div>

<!-- ✅ PHOTOS MODAL -->
<div id="photos-modal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="document.getElementById('photos-modal').style.display='none'">&times;</span>
        <?php foreach ($images as $img): ?>
            <img src="<?php echo esc_url($img); ?>" style="width:100%;margin-bottom:20px;" alt="Modal Photo" loading="lazy">
        <?php endforeach; ?>
    </div>
</div>

<!-- ✅ AMENITIES MODAL -->
<div id="amenities-modal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="document.getElementById('amenities-modal').style.display='none'">&times;</span>
        <h2>All Amenities</h2>
        <div class="amenity-items">
            <?php foreach ($amenities as $a):
                $label = ucwords(str_replace('_', ' ', $a));
                $icon = $amenity_icons[$a] ?? '✔️';
            ?>
                <div class="amenity-item">
                    <?php echo $icon . ' ' . esc_html($label); ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php get_footer(); ?>



<style>
    .property-page {
        max-width: 1200px;
        margin: 40px auto;
        font-family: "DM Sans", sans-serif !important;
    }

    .property-page h1,
    .property-page h2,
    .property-page h3,
    .property-page h4,
    .property-page h5,
    .property-page h6,
    .property-page p,
    .property-page span,
    .property-page a {
        font-family: "DM Sans", sans-serif !important;
    }


    .gallery-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 8px;
        border-radius: 12px;
        overflow: hidden;
    }

    .hero-photo img {
        width: 100%;
        height: auto;
        max-height: 400px;
        /* ✅ limit hero image height */
        object-fit: cover;
        border-radius: 12px;
    }

    .grid-photos {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 8px;
    }

    .grid-photos .grid-item {
        position: relative;
    }

    .grid-photos img {
        width: 100%;
        height: auto;
        max-height: 400px;
        /* ✅ limit grid image height too */
        object-fit: cover;
        border-radius: 12px;
    }

    .view-all-btn {
        position: absolute;
        bottom: 12px;
        right: 12px;
        background: rgba(0, 0, 0, 0.7);
        color: #fff;
        border: none;
        padding: 10px 16px;
        border-radius: 30px;
        cursor: pointer;
        font-size: 14px;
    }

    @media (max-width: 768px) {
        .gallery-grid {
            grid-template-columns: 1fr;
        }

        .grid-photos {
            grid-template-columns: 1fr 1fr;
        }
    }



    .property-main {
        display: grid;
        grid-template-columns: 2fr 1fr;
        gap: 40px;
        margin-top: 40px;
    }

    .property-left h1 {
        font-size: 32px;
        margin-bottom: 10px;
    }

    .property-left .address {
        color: #555;
        margin-bottom: 10px;
    }

    .property-left .meta {
        font-size: 16px;
        margin-bottom: 20px;
        color: #444;
        border-bottom: 1px solid #d9d9d9;
        padding-bottom: 12px;
    }

    .description {
        font-size: 18px;
        line-height: 1.6;
        margin-bottom: 40px;
    }

    .property-amenities h2,
    .property-map h2 {
        font-size: 24px;
        margin: 40px 0 20px;
    }

    .amenities-list {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
    }

    .amenity-items {
        display: grid;
        grid-template-columns: 1fr 1fr 1fr;
        gap: 4px;
    }

    .amenity-item {
        background: #ffffff;
        border-radius: 4px;
        padding: 8px 16px;
        border: 1px solid #ddd;
        font-size: 12px;
    }

    .show-all-btn {
        margin-top: 20px;
        background: #222;
        color: #fff;
        padding: 12px 18px;
        border: none;
        border-radius: 30px;
        cursor: pointer;
    }

    .property-right .booking-box {
        padding: 20px;
        border-radius: 12px;
        position: sticky;
        top: 80px;
    }

    .property-right h2 {
        font-size: 22px;
        margin-bottom: 20px;
    }

    .property-right iframe {
        width: 100%;
        height: 700px;
        border: none;
        border-radius: 12px;
    }

    .modal {
        display: none;
        position: fixed;
        z-index: 9999;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.8);
        overflow: auto;
        padding: 40px;
    }

    .modal-content {
        background: #fff;
        padding: 20px;
        border-radius: 12px;
        max-width: 800px;
        margin: auto;
        font-family: "DM Sans", sans-serif !important;
    }

    .modal .close {
        float: right;
        font-size: 28px;
        cursor: pointer;
    }
</style>