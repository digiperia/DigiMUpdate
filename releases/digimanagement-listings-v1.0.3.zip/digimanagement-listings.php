<?php

/**
 * Plugin Name: DigiM
 * Plugin URI: https://digiperia.com
 * Description: A professional WordPress plugin that integrates with Hospitable API to display property listings with flexible shortcode parameters.
 * Version: 1.0.3
 * Author: Altin Beqiri & Barlet Hamzai
 * Author URI: https://digiperia.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wml-hospitable
 * Domain Path: /languages
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.4
 * Network: false
 */

// === Plugin Path Constant ===
define('DIGIMANAGEMENT_PLUGIN_PATH', plugin_dir_path(__FILE__));

require_once __DIR__ . '/plugin-update-checker/plugin-update-checker.php';

use YahnisElsts\PluginUpdateChecker\v5p6\PucFactory;

$myUpdateChecker = PucFactory::buildUpdateChecker(
  'https://raw.githubusercontent.com/digiperia/DigiMUpdate/main/digim-plugin-update.json',
  __FILE__,
  'digimanagement-listings'
);





// === Admin Pages ===
if (is_admin()) {
  require_once DIGIMANAGEMENT_PLUGIN_PATH . 'admin/menu.php';
  require_once DIGIMANAGEMENT_PLUGIN_PATH . 'admin/admin-settings.php';
}

// === Frontend Shortcode ===
require_once DIGIMANAGEMENT_PLUGIN_PATH . 'includes/shortcode.php';


// === Enqueue Plugin Styles & Scripts ===
add_action('wp_enqueue_scripts', function () {
  global $post;

  // Only load if the shortcode exists on the page
  if (!isset($post) || !has_shortcode($post->post_content, 'digimanagement_listings')) return;

  // ✅ Leaflet CSS & JS
  wp_enqueue_style('leaflet', 'https://unpkg.com/leaflet/dist/leaflet.css');
  wp_enqueue_script('leaflet', 'https://unpkg.com/leaflet/dist/leaflet.js', [], null, true);

  // ✅ Leaflet Marker Cluster
  wp_enqueue_style('leaflet-cluster', 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css');
  wp_enqueue_script('leaflet-cluster', 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js', ['leaflet'], null, true);

  // ✅ Plugin Styles (ensure loaded after Leaflet to override)
  $style_path = plugin_dir_path(__FILE__) . 'assets/css/style.css';
  if (file_exists($style_path)) {
    wp_enqueue_style(
      'digim-style',
      plugin_dir_url(__FILE__) . 'assets/css/style.css',
      [],
      filemtime($style_path)
    );
  }

  // ✅ Plugin Frontend JS (map logic, interactivity)
  $js_path = plugin_dir_path(__FILE__) . 'assets/js/frontend.js';
  if (file_exists($js_path)) {
    wp_enqueue_script(
      'digim-frontend',
      plugin_dir_url(__FILE__) . 'assets/js/frontend.js',
      ['jquery', 'leaflet', 'leaflet-cluster'],
      filemtime($js_path),
      true
    );
  }
});


function digimanagement_get_api_url()
{
  return trim(get_option('digimanagement_api_url', 'https://public.api.hospitable.com/v2'));
}

function digimanagement_get_api_token()
{
  $token = trim(get_option('digimanagement_api_key', ''));
  return 'Bearer ' . $token;
}

// Ajax UI BUILDER
add_action('wp_ajax_digim_preview_shortcode', function () {
  update_option('digim_layout_style', sanitize_text_field($_POST['layout']));
  update_option('digim_grid_columns', intval($_POST['columns']));

  echo do_shortcode('[digimanagement_listings]');
  wp_die();
});


// === Helper: Parallel Calendar Check === //
function digimanagement_parallel_calendar_check($uuids, $checkin, $checkout)
{
  $mh = curl_multi_init();
  $handles = [];
  $results = [];

  foreach ($uuids as $uuid) {
    $url = digimanagement_get_api_url() . "/properties/$uuid/calendar";
    $ch = curl_init();
    curl_setopt_array($ch, [
      CURLOPT_URL => $url,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_HTTPHEADER => [
        'Authorization: ' . digimanagement_get_api_token(),
        'Accept: application/json',
        'Cache-Control: no-cache',
        'Pragma: no-cache',
      ],
      CURLOPT_TIMEOUT => 10,
    ]);
    curl_multi_add_handle($mh, $ch);
    $handles[$uuid] = $ch;
  }

  do {
    $status = curl_multi_exec($mh, $active);
    curl_multi_select($mh);
  } while ($active && $status === CURLM_OK);

  foreach ($handles as $uuid => $ch) {
    $body = curl_multi_getcontent($ch);
    $calendar = json_decode($body, true);
    $calendar_days = $calendar['data']['days'] ?? [];
    $range_available = true;

    $current = strtotime($checkin);
    $end = strtotime($checkout); // do NOT subtract 1 day

    // Loop through each night from checkin to (checkout - 1)
    while ($current < $end) {
      $date_str = date('Y-m-d', $current);
      $day_found = null;

      foreach ($calendar_days as $d) {
        if ($d['date'] === $date_str) {
          $day_found = $d;
          break;
        }
      }

      if (!$day_found || empty($day_found['status']['available'])) {
        $range_available = false;
        break;
      }

      $current = strtotime('+1 day', $current);
    }

    if ($range_available) {
      $results[] = $uuid;
    }

    curl_multi_remove_handle($mh, $ch);
    curl_close($ch);
  }

  curl_multi_close($mh);
  return $results;
}

// === Shortcode === //
require_once plugin_dir_path(__FILE__) . 'includes/shortcode.php';

// === SINGLE PAGE === //
add_action('init', function () {
  add_rewrite_rule('^property/([^/]+)/?', 'index.php?dm_property_uuid=$matches[1]', 'top');
  add_rewrite_tag('%dm_property_uuid%', '([^&]+)');
});
add_filter('template_include', function ($template) {
  if (get_query_var('dm_property_uuid')) {
    return plugin_dir_path(__FILE__) . 'templates/property-single.php';
  }
  return $template;
});

// === Flush === //
register_activation_hook(__FILE__, function () {
  flush_rewrite_rules();
});
register_deactivation_hook(__FILE__, function () {
  flush_rewrite_rules();
});

// === AJAX HANDLER === //
add_action('wp_ajax_digimanagement_get_listings', 'digimanagement_get_listings_ajax');
add_action('wp_ajax_nopriv_digimanagement_get_listings', 'digimanagement_get_listings_ajax');

function digimanagement_get_listings_ajax()
{
  $search = sanitize_text_field($_GET['property_search'] ?? '');
  $checkin = sanitize_text_field($_GET['checkin'] ?? '');
  $checkout = sanitize_text_field($_GET['checkout'] ?? '');

  $page = 1;
  $all_properties = [];
  do {
    $response = wp_remote_get(digimanagement_get_api_url()
      . "/properties?page=$page", [
      'headers' => [
        'Authorization' => digimanagement_get_api_token(),
        'Accept' => 'application/json',
        'Cache-Control' => 'no-cache',
        'Pragma' => 'no-cache',
      ],
      'timeout' => 15,
    ]);
    if (is_wp_error($response)) wp_send_json_error($response->get_error_message());
    $data = json_decode(wp_remote_retrieve_body($response), true);
    if (!isset($data['data'])) break;
    $all_properties = array_merge($all_properties, $data['data']);
    $page++;
  } while (isset($data['links']['next']) && $data['links']['next']);

  if ($search) {
    $all_properties = array_filter($all_properties, function ($p) use ($search) {
      return stripos($p['public_name'] ?? $p['name'] ?? '', $search) !== false;
    });
  }

  if ($checkin && $checkout && count($all_properties) > 0) {
    $uuids = [];
    foreach ($all_properties as $p) {
      $uuids[] = $p['uuid'] ?? $p['id'];
    }
    $available_uuids = digimanagement_parallel_calendar_check($uuids, $checkin, $checkout);
    $all_properties = array_filter($all_properties, function ($p) use ($available_uuids) {
      return in_array($p['uuid'] ?? $p['id'], $available_uuids);
    });
  }

  wp_send_json_success(array_values($all_properties));
}
