<?php
// Card Builder admin page and AJAX

add_action('admin_enqueue_scripts', function ($hook) {
	if (!isset($_GET['page']) || $_GET['page'] !== 'DigiM-cards') return;

	// CSS
	wp_enqueue_style('digim-admin-css', plugin_dir_url(__FILE__) . '../assets/css/admin.css', [], '1.0.0');

	// Frontend styles for preview (digim-main)
	$style_rel = '../assets/css/style.css';
	$style_abs = plugin_dir_path(__FILE__) . $style_rel;
	if (file_exists($style_abs)) {
		wp_enqueue_style('digim-style', plugin_dir_url(__FILE__) . $style_rel, [], filemtime($style_abs));
	}

	// JS
	$js_rel = '../assets/js/card-builder.js';
	$js_abs = plugin_dir_path(__FILE__) . $js_rel;
	wp_enqueue_script(
		'digim-card-builder-js',
		plugin_dir_url(__FILE__) . $js_rel,
		['jquery'],
		file_exists($js_abs) ? filemtime($js_abs) : '1.0.0',
		true
	);

	// Pass data
	$sets = get_option('digim_card_sets', []);
	wp_localize_script('digim-card-builder-js', 'digimCardBuilder', [
		'ajax_url' => admin_url('admin-ajax.php'),
		'nonce' => wp_create_nonce('digim_card_builder_nonce'),
		'sets' => $sets,
		'strings' => [
			'loading' => __('Loading properties…', 'DigiM'),
			'saving' => __('Saving…', 'DigiM'),
			'saved' => __('Saved!', 'DigiM'),
			'error' => __('Something went wrong', 'DigiM'),
		],
	]);
});

// AJAX: Fetch all properties for selector
add_action('wp_ajax_digim_fetch_properties', function () {
	if (!wp_verify_nonce($_POST['nonce'] ?? '', 'digim_card_builder_nonce')) wp_send_json_error('nonce');
	if (!current_user_can('manage_options')) wp_send_json_error('cap');

	if (!function_exists('digim_get_all_properties')) wp_send_json_error('missing');
	$props = digim_get_all_properties();

	// Minify payload
	$list = array_map(function ($p) {
		return [
			'uuid' => $p['uuid'] ?? ($p['id'] ?? ''),
			'name' => $p['name'] ?? '',
			'city' => $p['address']['city'] ?? '',
			'picture' => $p['picture'] ?? '',
		];
	}, $props);

	wp_send_json_success(['properties' => $list]);
});

// AJAX: Save card set
add_action('wp_ajax_digim_save_card_set', function () {
	if (!wp_verify_nonce($_POST['nonce'] ?? '', 'digim_card_builder_nonce')) wp_send_json_error('nonce');
	if (!current_user_can('manage_options')) wp_send_json_error('cap');

	$title = sanitize_text_field($_POST['title'] ?? 'Untitled Set');
	$selected = array_values(array_filter(array_map('sanitize_text_field', (array)($_POST['selected'] ?? []))));
	$slider = intval($_POST['slider'] ?? 0) ? 1 : 0;
	$columns = max(1, min(6, intval($_POST['columns'] ?? 3)));
	$id = sanitize_text_field($_POST['id'] ?? '');

	$sets = get_option('digim_card_sets', []);
	if (!$id) {
		// If no id provided, but a set with the same title exists, update that set instead of creating a new one
		foreach ($sets as $existingId => $existing) {
			if (!empty($existing['title']) && strtolower($existing['title']) === strtolower($title)) {
				$id = $existingId;
				break;
			}
		}
		if (!$id) {
			$id = uniqid('dmcs_', true);
		}
	}
	$sets[$id] = [
		'id' => $id,
		'title' => $title,
		'selected' => $selected,
		'slider' => $slider,
		'columns' => $columns,
		'updated_at' => current_time('mysql'),
	];
	update_option('digim_card_sets', $sets);

	$shortcode = '[digim_cards id="' . esc_attr($id) . '"]';
	wp_send_json_success(['id' => $id, 'shortcode' => $shortcode]);
});

// AJAX: Render preview HTML in admin
add_action('wp_ajax_digim_render_card_preview', function () {
	if (!wp_verify_nonce($_POST['nonce'] ?? '', 'digim_card_builder_nonce')) wp_send_json_error('nonce');
	if (!current_user_can('manage_options')) wp_send_json_error('cap');

	$id = sanitize_text_field($_POST['id'] ?? '');
	if (!$id) wp_send_json_error('missing id');

	$html = do_shortcode('[digim_cards id="' . $id . '"]');
	wp_send_json_success(['html' => $html]);
});

// AJAX: Preview from current unsaved selection
add_action('wp_ajax_digim_preview_card_set', function(){
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'digim_card_builder_nonce')) wp_send_json_error('nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('cap');

    $selected = array_values(array_filter(array_map('sanitize_text_field', (array)($_POST['selected'] ?? []))));
    $slider = intval($_POST['slider'] ?? 0) ? 1 : 0;
    $columns = max(1, min(6, intval($_POST['columns'] ?? 3)));
    $primary_color = get_option('digim_primary_color', '#0073aa');

    if (!function_exists('digim_build_props_from_uuids') || !function_exists('digim_render_cards_block')) wp_send_json_error('missing helpers');
    $props = digim_build_props_from_uuids($selected);
    $html = digim_render_cards_block($props, $slider, $columns, $primary_color);
    wp_send_json_success(['html' => $html]);
});

// AJAX: Delete card set
add_action('wp_ajax_digim_delete_card_set', function(){
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'digim_card_builder_nonce')) wp_send_json_error('nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('cap');

    $id = sanitize_text_field($_POST['id'] ?? '');
    if (!$id) wp_send_json_error('missing id');

    $sets = get_option('digim_card_sets', []);
    if (!isset($sets[$id])) wp_send_json_error('not found');
    unset($sets[$id]);
    update_option('digim_card_sets', $sets);
    wp_send_json_success(['deleted' => $id]);
});

function digim_render_card_builder_page() {
	$sets = get_option('digim_card_sets', []);
	$current_id = isset($_GET['set']) ? sanitize_text_field($_GET['set']) : '';
	$current = $current_id && isset($sets[$current_id]) ? $sets[$current_id] : null;
	$title = $current['title'] ?? '';
	$slider = isset($current['slider']) ? intval($current['slider']) : 0;
	$columns = isset($current['columns']) ? intval($current['columns']) : 3;
	$selected = $current['selected'] ?? [];
	?>
	<div class="digim-ui-builder digim-card-builder">
		<div class="ui-builder-header">
			<div class="header-content">
				<h1><span class="dashicons dashicons-screenoptions"></span> Card Builder</h1>
				<p>Create curated sets of listings and embed via shortcode.</p>
			</div>
			<div class="header-actions">
				<select id="cb_set_selector">
					<option value="">Load set…</option>
					<?php foreach ($sets as $sid => $s): ?>
						<option value="<?php echo esc_attr($sid); ?>" <?php selected($sid, $current_id); ?>><?php echo esc_html($s['title'] ?: $sid); ?></option>
					<?php endforeach; ?>
				</select>
				<a class="button" href="<?php echo esc_url(admin_url('admin.php?page=DigiM-cards')); ?>"><span class="dashicons dashicons-plus"></span> New Set</a>
			</div>
		</div>

		<div class="ui-builder-content">
			<div class="ui-builder-sidebar">
				<form id="card-builder-form" class="ui-builder-form" onsubmit="return false;">
					<div class="control-group">
						<h3><span class="dashicons dashicons-admin-generic"></span> Settings</h3>
						<div class="control-item">
							<label for="cb_title">Title</label>
							<input type="text" id="cb_title" value="<?php echo esc_attr($title); ?>" placeholder="e.g. Featured Villas" />
						</div>
						<div class="control-row">
							<div class="control-item">
								<label for="cb_slider">Display as slider</label>
								<label class="checkbox-control">
									<input type="checkbox" id="cb_slider" value="1" <?php checked($slider, 1); ?> />
									<span class="label-text">Enable slider</span>
									<div class="toggle-switch"></div>
								</label>
							</div>
							<div class="control-item">
								<label for="cb_columns">Grid Columns</label>
								<select id="cb_columns">
									<?php for ($i=2;$i<=6;$i++): ?>
										<option value="<?php echo $i; ?>" <?php selected($columns, $i); ?>><?php echo $i; ?></option>
									<?php endfor; ?>
								</select>
							</div>
						</div>

						<div class="control-group">
							<h3><span class="dashicons dashicons-randomize"></span> Listings</h3>
							<div class="control-item">
								<input type="search" id="cb_search" placeholder="Search properties…" />
							</div>
							<div class="control-item" style="display:flex; gap:12px;">
								<div style="flex:1; min-width:0;">
									<label>Available</label>
									<ul id="cb_available" class="digim-card-list" aria-label="Available properties"></ul>
								</div>
								<div style="flex:.2; display:flex; align-items:center; justify-content:center; gap:8px; flex-direction:column;">
									<button type="button" class="button" id="cb_add">&rarr;</button>
									<button type="button" class="button" id="cb_remove">&larr;</button>
								</div>
								<div style="flex:1; min-width:0;">
									<label>Selected (drag to reorder)</label>
									<ul id="cb_selected" class="digim-card-list" aria-label="Selected properties"></ul>
								</div>
							</div>
						</div>

						<div class="control-group">
							<div class="control-item">
								<button type="button" class="button button-primary" id="cb_save">Save Set</button>
								<button type="button" class="button button-secondary" id="cb_delete" <?php echo $current_id ? '' : 'disabled'; ?>>Delete</button>
								<span id="cb_shortcode" style="margin-left:10px; font-family:monospace;"></span>
								<input type="hidden" id="cb_id" value="<?php echo esc_attr($current_id); ?>" />
							</div>
						</div>

						<div class="control-group">
							<h3><span class="dashicons dashicons-media-code"></span> Saved Sets</h3>
							<div class="control-item">
								<ul class="cb-saved-sets">
									<?php foreach ($sets as $sid => $s): $sc = '[digim_cards id="' . $sid . '"]'; ?>
									<li data-id="<?php echo esc_attr($sid); ?>">
										<a href="<?php echo esc_url(admin_url('admin.php?page=DigiM-cards&set='.$sid)); ?>" class="button button-secondary">Edit</a>
										<button type="button" class="button cb-delete-item">Delete</button>
										<strong><?php echo esc_html($s['title'] ?: $sid); ?></strong>
										<code><?php echo esc_html($sc); ?></code>
									</li>
									<?php endforeach; ?>
								</ul>
							</div>
						</div>
					</form>
			</div>

			<div class="ui-builder-preview">
				<div class="preview-header">
					<h3><span class="dashicons dashicons-visibility"></span> Preview</h3>
					<div class="preview-controls">
						<button type="button" class="button" id="cb_refresh"><span class="dashicons dashicons-update"></span> Refresh</button>
					</div>
				</div>
				<div class="preview-container">
					<div id="cb_preview" class="preview-content"></div>
				</div>
			</div>
		</div>
	</div>
	<style>
		/* Card Builder specific overrides */
		.digim-card-builder .ui-builder-sidebar { width: 100%; }
		.digim-card-list { list-style:none; margin:0; padding:0; min-height:220px; max-height:380px; overflow:auto; border:1px solid #e1e8ed; border-radius:8px; }
		.digim-card-list li { display:flex; align-items:center; gap:10px; padding:10px; border-bottom:1px solid #f1f1f1; background:#fff; cursor:grab; }
		.digim-card-list li:last-child { border-bottom:0; }
		.digim-card-list li .thumb { width:42px; height:42px; border-radius:6px; background:#f3f4f6; overflow:hidden; flex-shrink:0; }
		.digim-card-list li .thumb img { width:100%; height:100%; object-fit:cover; display:block; }
		.digim-card-list li .meta { display:flex; flex-direction:column; min-width:0; }
		.digim-card-list li .meta .name { font-weight:600; font-size:13px; color:#111827; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
		.digim-card-list li .meta .city { font-size:12px; color:#6b7280; }
		.digim-card-list li.selected { background:#f8fafc; }
	</style>
	<?php
}


