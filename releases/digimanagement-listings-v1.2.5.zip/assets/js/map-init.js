document.addEventListener("DOMContentLoaded", function () {
  if (!window.digimMapData || !digimMapData.markers || !L) return;

  const mapContainer = document.getElementById("digim-map");
  if (!mapContainer) return;

  const map = L.map("digim-map", {
    scrollWheelZoom: false, // Disable scroll initially
    zoomAnimationDuration: 800, // Moderate zoom animation (default is 250ms)
  }).setView([46.8182, 8.2275], 8); // Slight zoom

  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "&copy; OpenStreetMap contributors",
  }).addTo(map);

  // 🖱️ Click-to-enable scroll zoom
  mapContainer.addEventListener("click", () => {
    map.scrollWheelZoom.enable();
    setTimeout(() => {
      map.scrollWheelZoom.disable(); // Disable again after 10s for UX
    }, 5000);
  });

  const markerCluster = L.markerClusterGroup();
  const markerRefs = {};
  let currentAnimation = null; // Track current animation to cancel if needed
  let isAnimating = false; // Track if we're currently animating

  function normalizeUrl(url) {
    try {
      const u = new URL(url, window.location.origin);
      return (u.origin + u.pathname).replace(/\/$/, "");
    } catch (e) {
      return url.replace(/\?.*$/, "").replace(/\/$/, "");
    }
  }

  digimMapData.markers.forEach((marker) => {
    const m = L.marker([marker.lat, marker.lng])
      .bindPopup(
        `
          <div class="popup-card">
            <a href="${marker.url}" target="_blank" style="text-decoration: none;">
              <img src="${marker.img}" class="popup-image" alt="${marker.name}" />
              <div class="popup-info">
                <strong class="popup-title">${marker.name}</strong><br/>
                <small class="popup-address">${marker.address}</small>
              </div>
            </a>
          </div>
        `
      )
      .on("click", function () {
        highlightCard(marker.url);
        m.openPopup();
      });

    markerCluster.addLayer(m);
    markerRefs[normalizeUrl(marker.url)] = m;
  });

  map.addLayer(markerCluster);

  if (digimMapData.markers.length > 0) {
    const bounds = L.latLngBounds(
      digimMapData.markers.map((m) => [m.lat, m.lng])
    );
    map.fitBounds(bounds, { padding: [30, 30] });
  }

  // Function to expand cluster and show popup (no map animation on hover)
  function recenterMapToMarker(marker) {
    // Validate marker exists
    if (!marker || !marker.getLatLng) {
      return;
    }
    
    // Cancel any ongoing animation
    if (isAnimating) {
      map.stop();
      isAnimating = false;
    }
    
    // Set flag to prevent multiple simultaneous operations
    isAnimating = true;
    
    // Use zoomToShowLayer which handles both cases:
    // - If marker is in a cluster, it expands the cluster and zooms to show it
    // - If marker is already visible, it just zooms to it
    // No additional map animation - just expand cluster and show popup
    try {
      markerCluster.zoomToShowLayer(marker, function() {
        // Validate marker is still valid after cluster operation
        if (!marker || !marker.getLatLng) {
          isAnimating = false;
          return;
        }
        
        // Small delay to ensure marker is visible after cluster expansion
        setTimeout(() => {
          // Ensure marker is still valid before opening popup
          if (marker && marker.openPopup) {
            try {
              marker.openPopup();
            } catch (e) {
              console.debug('Could not open popup:', e);
            }
          }
          isAnimating = false;
        }, 300);
      });
    } catch (e) {
      console.debug('Error in zoomToShowLayer:', e);
      isAnimating = false;
      
      // Fallback: just open popup if cluster operation fails
      if (marker && marker.openPopup) {
        try {
          marker.openPopup();
        } catch (e) {
          console.debug('Could not open popup:', e);
        }
      }
    }
  }

  document.querySelectorAll(".digimanagement-card").forEach((card) => {
    const href = card.href;
    const marker = markerRefs[normalizeUrl(href)];
    if (!marker) return;

    card.addEventListener("mouseenter", () => {
      recenterMapToMarker(marker);
      card.classList.add("hover-glow");
    });

    card.addEventListener("mouseleave", () => {
      marker.closePopup();
      card.classList.remove("hover-glow");
    });
  });

  const highlightUrl = new URLSearchParams(window.location.search).get(
    "highlight_url"
  );
  if (highlightUrl) {
    highlightCard(highlightUrl);
  }

  function highlightCard(url) {
    const target = normalizeUrl(url);
    const card = [...document.querySelectorAll(".digimanagement-card")].find(
      (el) => normalizeUrl(el.getAttribute("href")) === target
    );

    if (card) {
      card.scrollIntoView({ behavior: "smooth", block: "center" });
      card.classList.add("highlight");
      setTimeout(() => card.classList.remove("highlight"), 3500);
    }
  }
});
