<?php
// Global flag to track if shortcode was rendered
global $digim_shortcode_rendered;
$digim_shortcode_rendered = false;

// Early detection: Hook into the_content to detect shortcodes before rendering
add_filter('the_content', function($content) {
    global $digim_shortcode_rendered;
    
    // Check if content contains our shortcodes
    if (has_shortcode($content, 'digimanagement_listings') || 
        has_shortcode($content, 'digim_cards') ||
        strpos($content, '[digimanagement_listings') !== false ||
        strpos($content, '[digim_cards') !== false) {
        $digim_shortcode_rendered = true;
        
        // Enqueue styles early if not already done
        if (!did_action('wp_head')) {
            $plugin_dir = plugin_dir_path(dirname(__FILE__));
            $plugin_url = plugin_dir_url(dirname(__FILE__));
            $rel_style  = 'assets/css/style.css';
            $style_path = $plugin_dir . $rel_style;
            $style_url  = $plugin_url . $rel_style;
            
            if (file_exists($style_path) && !wp_style_is('digim-style', 'enqueued')) {
                wp_enqueue_style('digim-style', $style_url, [], filemtime($style_path));
            }
            
            // Enqueue dependencies
            $deps = [
                'leaflet' => 'https://unpkg.com/leaflet/dist/leaflet.css',
                'leaflet-cluster' => 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.css',
                'leaflet-cluster-default' => 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css',
                'select2' => 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css',
                'daterangepicker-css' => 'https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css',
                'digim-fontawesome' => 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css',
            ];
            
            foreach ($deps as $handle => $url) {
                if (!wp_style_is($handle, 'enqueued')) {
                    wp_enqueue_style($handle, $url);
                }
            }
        }
    }
    
    return $content;
}, 1); // Priority 1 to run early

add_action('wp_enqueue_scripts', function () {
    global $post;
    
    // Check if we should load the styles and scripts
    $should_load = false;
    
    // Check if shortcode exists in post content
    if (is_singular() && isset($post) && (has_shortcode($post->post_content, 'digimanagement_listings') || has_shortcode($post->post_content, 'digim_cards'))) {
        $should_load = true;
    }
    
    // Check ALL posts/pages in query (for archive pages, etc.)
    if (have_posts()) {
        while (have_posts()) {
            the_post();
            if (has_shortcode(get_the_content(), 'digimanagement_listings') || has_shortcode(get_the_content(), 'digim_cards')) {
                $should_load = true;
                break;
            }
        }
        wp_reset_postdata();
    }
    
    // Check widgets (text widgets can contain shortcodes)
    if (is_active_sidebar('sidebar-1') || is_active_sidebar('footer-1') || is_active_sidebar('footer-2') || is_active_sidebar('footer-3')) {
        $sidebars = wp_get_sidebars_widgets();
        foreach ($sidebars as $sidebar => $widgets) {
            if (is_array($widgets)) {
                foreach ($widgets as $widget_id) {
                    $widget_data = get_option('widget_text');
                    if ($widget_data) {
                        foreach ($widget_data as $widget) {
                            if (isset($widget['text']) && (has_shortcode($widget['text'], 'digimanagement_listings') || has_shortcode($widget['text'], 'digim_cards'))) {
                                $should_load = true;
                                break 3;
                            }
                        }
                    }
                }
            }
        }
    }
    
    // Check if we're on a page that might contain listings (like /listings/)
    if (is_page() && (strpos($_SERVER['REQUEST_URI'], '/listings') !== false || 
                     strpos($_SERVER['REQUEST_URI'], 'listings') !== false)) {
        $should_load = true;
    }
    
    // Check if we're on a property single page
    if (get_query_var('dm_property_uuid') || get_query_var('dm_property_identifier')) {
        $should_load = true;
    }
    
    // Check if the current page template or content contains digim classes
    if (isset($post) && (strpos($post->post_content, 'digim-main') !== false || 
                        strpos($post->post_content, 'digimanagement') !== false ||
                        strpos($post->post_content, '[digimanagement_listings') !== false ||
                        strpos($post->post_content, '[digim_cards') !== false)) {
        $should_load = true;
    }
    
    // Fallback: Check if we're on any page that might need the plugin styles
    // This can be customized based on your specific needs
    $force_load_pages = ['listings', 'properties', 'search'];
    foreach ($force_load_pages as $page_slug) {
        if (is_page($page_slug) || strpos($_SERVER['REQUEST_URI'], $page_slug) !== false) {
            $should_load = true;
            break;
        }
    }
    
    // Check if shortcode was rendered earlier (for page builders)
    global $digim_shortcode_rendered;
    if ($digim_shortcode_rendered) {
        $should_load = true;
    }
    
    // More permissive fallback: Load on singular pages/posts that might have shortcodes
    // This ensures styles are available even if detection fails (e.g., page builders)
    // Only applies to pages that could potentially contain shortcodes
    if (!$should_load && (is_singular() || is_page())) {
        // Check if we're NOT on admin or special pages
        if (!is_admin() && !is_feed() && !is_robots()) {
            // Only load as last resort fallback for pages that could have shortcodes
            // This is safer than loading on all pages but ensures compatibility with page builders
            $should_load = true;
        }
    }
    
    if (!$should_load) return;
    
    wp_enqueue_style('leaflet', 'https://unpkg.com/leaflet/dist/leaflet.css');
    wp_enqueue_style('leaflet-cluster', 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.css');
    wp_enqueue_style('leaflet-cluster-default', 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css');
    wp_enqueue_style('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css');
    wp_enqueue_style('daterangepicker-css', 'https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css');
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css');

    wp_enqueue_script('leaflet', 'https://unpkg.com/leaflet/dist/leaflet.js', [], null, true);
    wp_enqueue_script('leaflet-cluster', 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js', ['leaflet'], null, true);
    wp_enqueue_script('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js', ['jquery'], null, true);
    wp_enqueue_script('moment-js', 'https://cdn.jsdelivr.net/npm/moment@2.29.4/moment.min.js', [], null, true);
    wp_enqueue_script('daterangepicker-js', 'https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js', ['moment-js', 'jquery'], null, true);

    // Load plugin stylesheet for digim-main layout
    $plugin_dir = plugin_dir_path(dirname(__FILE__));
    $plugin_url = plugin_dir_url(dirname(__FILE__));
    $rel_style  = 'assets/css/style.css';
    $style_path = $plugin_dir . $rel_style;
    $style_url  = $plugin_url . $rel_style;
    if (file_exists($style_path)) {
        wp_enqueue_style('digim-style', $style_url, [], filemtime($style_path));
    }

    $map_init_path = plugin_dir_path(__FILE__) . '../assets/js/map-init.js';
    if (file_exists($map_init_path)) {
        wp_enqueue_script('digim-map-init', plugin_dir_url(__FILE__) . '../assets/js/map-init.js', ['leaflet', 'leaflet-cluster'], filemtime($map_init_path), true);
    }

    // Inline Select2 init
    add_action('wp_footer', function () {
?>
        <script>
            jQuery(document).ready(function($) {
                $('select[name="property_search[]"]').select2({
                    placeholder: "Search destinations",
                    allowClear: true,
                    width: '100%',
                    multiple: true,
                    minimumResultsForSearch: Infinity,
                    closeOnSelect: false
                });
            });
        </script>
<?php
    }, 100);
}, 100);

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('digim-fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css', [], '6.5.2');
}, 100);

add_shortcode('digimanagement_listings', 'digimanagement_hospitable_listings_shortcode');

// ✅ Load all properties (with pagination + caching)
function digim_get_all_properties()
{
    $cache_key = 'digim_all_properties';
    $all_properties = get_transient($cache_key);

    if (!$all_properties) {
        $all_properties = [];
        $page = 1;

        do {
            $response = wp_remote_get(digimanagement_get_api_url() . "/properties?page=$page", [
                'headers' => [
                    'Authorization' => digimanagement_get_api_token(),
                    'Accept' => 'application/json',
                ],
                'timeout' => 15,
            ]);

            if (is_wp_error($response)) break;

            $data = json_decode(wp_remote_retrieve_body($response), true);
            if (!isset($data['data'])) break;

            $all_properties = array_merge($all_properties, $data['data']);
            $has_more = isset($data['links']['next']) && $data['links']['next'];
            $page++;
        } while ($has_more);

        set_transient($cache_key, $all_properties, 60 * 10); // cache for 10 mins
    }

    return $all_properties;
}

// ✅ Main shortcode logic
function digimanagement_hospitable_listings_shortcode()
{
    // Set global flag that shortcode is being rendered
    global $digim_shortcode_rendered;
    global $digim_from_ui_builder;
    
    $digim_shortcode_rendered = true;
    
    // Check if we're in admin UI builder context (not AJAX, but direct page load)
    if (is_admin() && isset($_GET['page']) && $_GET['page'] === 'DigiM-style') {
        $digim_from_ui_builder = true;
    }
    
    // Ensure core stylesheet is enqueued even when builders (e.g. Bricks) don't put shortcodes in post_content
    $plugin_dir = plugin_dir_path(dirname(__FILE__));
    $plugin_url = plugin_dir_url(dirname(__FILE__));
    $rel_style  = 'assets/css/style.css';
    $style_path = $plugin_dir . $rel_style;
    $style_url  = $plugin_url . $rel_style;
    
    // Try to enqueue styles (may not work if called after wp_head, so we'll add fallback)
    if (file_exists($style_path)) {
        if (!wp_style_is('digim-style', 'enqueued')) {
            wp_enqueue_style('digim-style', $style_url, [], filemtime($style_path));
        }
    }
    
    // Fallback: If styles weren't enqueued properly (e.g., page builder), inject them
    if (!wp_style_is('digim-style', 'enqueued') && !wp_style_is('digim-style', 'done')) {
        // If wp_head hasn't fired yet, we can still enqueue
        if (!did_action('wp_head')) {
            wp_enqueue_style('digim-style', $style_url, [], filemtime($style_path));
        } else {
            // wp_head already fired, inject directly into output
            add_action('wp_footer', function() use ($style_url, $style_path) {
                if (file_exists($style_path) && !wp_style_is('digim-style', 'done')) {
                    echo '<link rel="stylesheet" href="' . esc_url($style_url) . '?v=' . filemtime($style_path) . '" />';
                }
            }, 1);
        }
    }
    
    // Also ensure all required dependencies are loaded
    $required_styles = [
        'leaflet' => 'https://unpkg.com/leaflet/dist/leaflet.css',
        'leaflet-cluster' => 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.css',
        'leaflet-cluster-default' => 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css',
        'select2' => 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css',
        'daterangepicker-css' => 'https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css',
        'digim-fontawesome' => 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css',
    ];
    
    foreach ($required_styles as $handle => $url) {
        if (!wp_style_is($handle, 'enqueued') && !wp_style_is($handle, 'done')) {
            if (!did_action('wp_head')) {
                wp_enqueue_style($handle, $url);
            } else {
                // Fallback: inject in footer if wp_head already fired
                add_action('wp_footer', function() use ($handle, $url) {
                    if (!wp_style_is($handle, 'done')) {
                        echo '<link rel="stylesheet" href="' . esc_url($url) . '" />';
                    }
                }, 1);
            }
        }
    }
    
    // Enqueue scripts if needed (these can be added later)
    $required_scripts = [
        'leaflet' => ['url' => 'https://unpkg.com/leaflet/dist/leaflet.js', 'deps' => []],
        'leaflet-cluster' => ['url' => 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js', 'deps' => ['leaflet']],
        'select2' => ['url' => 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js', 'deps' => ['jquery']],
        'moment-js' => ['url' => 'https://cdn.jsdelivr.net/npm/moment@2.29.4/moment.min.js', 'deps' => []],
        'daterangepicker-js' => ['url' => 'https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js', 'deps' => ['moment-js', 'jquery']],
    ];
    
    foreach ($required_scripts as $handle => $script) {
        if (!wp_script_is($handle, 'enqueued') && !wp_script_is($handle, 'done')) {
            wp_enqueue_script($handle, $script['url'], $script['deps'], null, true);
        }
    }
    
    // Map init script
    $map_init_path = plugin_dir_path(__FILE__) . '../assets/js/map-init.js';
    if (file_exists($map_init_path) && !wp_script_is('digim-map-init', 'enqueued')) {
        wp_enqueue_script('digim-map-init', plugin_dir_url(__FILE__) . '../assets/js/map-init.js', ['leaflet', 'leaflet-cluster'], filemtime($map_init_path), true);
    }

    $layout_style = get_option('digim_layout_style', 'grid');
    $per_page = intval(get_option('digim_cards_per_page', 12));
    $grid_columns = intval(get_option('digim_grid_columns', 3));
    $card_style = get_option('digim_card_style', 'classic');
    $primary_color = get_option('digim_primary_color', '#0073aa');
    error_log("Primary color from database: " . $primary_color);
    $show_map = get_option('digim_show_map', false);

    $search = isset($_GET['property_search']) ? $_GET['property_search'] : '';
    // Handle both array (multiple) and string (single) formats
    if (is_array($search)) {
        $search = array_map('sanitize_text_field', array_filter($search));
    } else {
        $search = $search ? [sanitize_text_field($search)] : [];
    }
    $checkin = sanitize_text_field($_GET['checkin'] ?? '');
    $checkout = sanitize_text_field($_GET['checkout'] ?? '');
    $current_page = max(1, intval($_GET['property_page'] ?? 1));

    // 🔄 Fetch all properties
    $all_properties = digim_get_all_properties();

    // 🧭 Get ALL destinations from unfiltered properties (for dropdown)
    // This ensures dropdown always shows all destinations, even when filtered
    $all_destination_names = array_unique(array_filter(array_map(
        fn($p) => $p['address']['city'] ?? '',
        $all_properties
    )));
    sort($all_destination_names);

    // 🔎 Filter: City (multiple selection support)
    if (!empty($search)) {
        $all_properties = array_filter(
            $all_properties,
            fn($p) => in_array(
                strtolower($p['address']['city'] ?? ''),
                array_map('strtolower', $search)
            )
        );
    }

    // 👥 Guests (adults + children + infants)
    $adults = intval($_GET['adults'] ?? 0);
    $children = intval($_GET['children'] ?? 0);
    $infants = intval($_GET['infants'] ?? 0);
    $total_guests = $adults + $children + $infants;

    if ($total_guests > 0) {
        $all_properties = array_filter(
            $all_properties,
            fn($p) => ($p['capacity']['max'] ?? 0) >= $total_guests
        );
    }

    // 📅 Availability (calendar check)
    $available_uuids = [];
    $available_uuid_map = [];
    if ($checkin && $checkout) {
        $uuids = array_map(fn($p) => $p['uuid'] ?? $p['id'] ?? null, $all_properties);
        $uuids = array_values(array_filter(
            array_unique(array_map(function ($uuid) {
                $uuid = is_null($uuid) ? '' : trim((string) $uuid);
                return $uuid !== '' ? $uuid : null;
            }, $uuids)),
            function ($uuid) {
                return $uuid !== null && $uuid !== '';
            }
        ));

        if (!empty($uuids)) {
            $available_uuids = digimanagement_parallel_calendar_check($uuids, $checkin, $checkout);
            if (!is_array($available_uuids)) {
                $available_uuids = [];
            }

            foreach ($available_uuids as $uuid) {
                $uuid = trim((string) $uuid);
                if ($uuid !== '') {
                    $available_uuid_map[$uuid] = true;
                }
            }

            global $digim_next_available_suggestions;
            global $digim_min_nights_required;
            $suggestion_map = is_array($digim_next_available_suggestions) ? $digim_next_available_suggestions : [];
            $min_nights_map = is_array($digim_min_nights_required) ? $digim_min_nights_required : [];

            $available_properties = [];
            $suggested_properties = [];
            $min_nights_properties = [];

            foreach ($all_properties as $property) {
                $uuid = $property['uuid'] ?? $property['id'] ?? null;
                $uuid = is_null($uuid) ? '' : trim((string) $uuid);
                if ($uuid === '') {
                    continue;
                }

                // Check property-level minimum nights from property data
                $property_min_nights = $property['minimum_nights'] 
                    ?? $property['min_nights'] 
                    ?? $property['min_stay'] 
                    ?? $property['minimum_stay']
                    ?? (isset($property['pricing']) && isset($property['pricing']['minimum_nights']) ? $property['pricing']['minimum_nights'] : null)
                    ?? (isset($property['pricing']) && isset($property['pricing']['min_nights']) ? $property['pricing']['min_nights'] : null)
                    ?? null;
                
                // Get minimum nights from calendar check (may be more specific to the date)
                $calendar_min_nights = isset($min_nights_map[$uuid]) ? $min_nights_map[$uuid] : null;
                
                // Use the maximum of calendar and property minimum nights (calendar is date-specific, property is general)
                $final_min_nights = null;
                if ($calendar_min_nights !== null && $property_min_nights !== null) {
                    $final_min_nights = max((int)$calendar_min_nights, (int)$property_min_nights);
                } elseif ($calendar_min_nights !== null) {
                    $final_min_nights = (int)$calendar_min_nights;
                } elseif ($property_min_nights !== null) {
                    $final_min_nights = (int)$property_min_nights;
                }
                
                // Check if requested nights meet minimum requirement
                $requested_nights = max(1, (int) floor((strtotime($checkout) - strtotime($checkin)) / DAY_IN_SECONDS));
                $has_min_nights_issue = $final_min_nights !== null && $requested_nights < (int)$final_min_nights;

                if (isset($available_uuid_map[$uuid])) {
                    // Property is available for the selected dates
                    $property['_digim_is_suggestion'] = false;
                    $property['_digim_suggested_start'] = null;
                    $property['_digim_suggested_checkout'] = null;
                    $property['_digim_suggested_nights'] = null;
                    $property['_digim_min_nights_required'] = null;
                    $available_properties[] = $property;
                } elseif ($has_min_nights_issue) {
                    // Property doesn't meet minimum nights requirement - prioritize this over suggestions
                    $property['_digim_is_suggestion'] = false;
                    $property['_digim_suggested_start'] = null;
                    $property['_digim_suggested_checkout'] = null;
                    $property['_digim_suggested_nights'] = null;
                    $property['_digim_min_nights_required'] = (int)$final_min_nights;
                    $min_nights_properties[] = $property;
                } elseif (!empty($suggestion_map[$uuid]) && is_array($suggestion_map[$uuid])) {
                    // Property has suggested dates (but no minimum nights issue)
                    $suggestion = $suggestion_map[$uuid];
                    $property['_digim_is_suggestion'] = true;
                    $property['_digim_suggested_start'] = $suggestion['start'] ?? null;
                    $property['_digim_suggested_checkout'] = $suggestion['checkout'] ?? null;
                    $property['_digim_suggested_nights'] = $suggestion['nights'] ?? null;
                    $property['_digim_min_nights_required'] = null;
                    $suggested_properties[] = $property;
                } else {
                    // Property is unavailable for other reasons (not minimum nights, no suggestions)
                    // Still include it but without any special flags
                    $property['_digim_is_suggestion'] = false;
                    $property['_digim_suggested_start'] = null;
                    $property['_digim_suggested_checkout'] = null;
                    $property['_digim_suggested_nights'] = null;
                    $property['_digim_min_nights_required'] = null;
                    // Don't add to any special array - these won't show in results
                }
            }

            // Include properties that don't meet minimum nights (they'll show with a badge)
            $all_properties = array_merge($available_properties, $suggested_properties, $min_nights_properties);
        } else {
            $all_properties = [];
        }
    }

    // 📦 Pagination
    $total = count($all_properties);
    $total_pages = ceil($total / $per_page);
    $properties_to_show = array_slice($all_properties, ($current_page - 1) * $per_page, $per_page);

    // 🧭 Dropdown values - use ALL destinations (unfiltered) so users can always see and select all options
    $destination_names = $all_destination_names;

    // 🗺️ Map markers
    $marker_data = array_map(function ($p) {
        $property_slug = digimanagement_create_property_slug(
            $p['name'] ?? '', 
            $p['address']['city'] ?? ''
        );
        return [
            'lat' => $p['address']['coordinates']['latitude'] ?? $p['address']['latitude'] ?? null,
            'lng' => $p['address']['coordinates']['longitude'] ?? $p['address']['longitude'] ?? null,
            'name' => $p['name'] ?? 'No Name',
            'address' => $p['address']['display'] ?? '',
            'img' => $p['picture'] ?? '',
            'url' => site_url('/property/' . $property_slug . '/'),
        ];
    }, array_filter(
        $properties_to_show,
        fn($p) =>
        !empty($p['address']['coordinates']['latitude'] ?? $p['address']['latitude'] ?? null)
    ));

    if ($show_map) {
        wp_localize_script('digim-map-init', 'digimMapData', ['markers' => $marker_data]);
    }

    // 🔄 Render listings
    // Ensure primary color CSS applies to search bar/buttons across themes
    if (!function_exists('digim_darken_color')) {
        function digim_darken_color($hex, $percent = 20) {
            $hex = (string) $hex;
            if ($hex === '') { $hex = '#000000'; }
            $hex = str_replace('#', '', $hex);
            if (strlen($hex) !== 6) { return '#000000'; }
            $r = hexdec(substr($hex, 0, 2));
            $g = hexdec(substr($hex, 2, 2));
            $b = hexdec(substr($hex, 4, 2));
            $r = max(0, min(255, (int) round($r - ($r * $percent / 100))));
            $g = max(0, min(255, (int) round($g - ($g * $percent / 100))));
            $b = max(0, min(255, (int) round($b - ($b * $percent / 100))));
            return '#' . str_pad(dechex($r), 2, '0', STR_PAD_LEFT)
                       . str_pad(dechex($g), 2, '0', STR_PAD_LEFT)
                       . str_pad(dechex($b), 2, '0', STR_PAD_LEFT);
        }
    }

    $primary_color = is_string($primary_color) && $primary_color ? $primary_color : '#0073aa';
    $primary_color_hover = digim_darken_color($primary_color, 10);
    $primary_color_active = digim_darken_color($primary_color, 20);

    // Only add digim-shortcode CSS class if from UI builder
    $dynamic_css = "";
    if (!empty($digim_from_ui_builder)) {
        $dynamic_css = ".digim-main.digim-shortcode{padding:0 !important;margin:0 !important;}\n";
    }
    $dynamic_css .= ".digim-main .digimanagement-search .search-buttons button.search-button{background: {$primary_color} !important; background-color: {$primary_color} !important; color:#fff !important;}\n"
        . ".digim-main .digimanagement-search .search-buttons button.search-button:hover, .digim-main .digimanagement-search .search-buttons button.search-button:focus{background: {$primary_color_hover} !important; background-color: {$primary_color_hover} !important; color:#fff !important;}\n"
        . ".digim-main .digimanagement-search .search-buttons button.search-button:active{background: {$primary_color_active} !important; background-color: {$primary_color_active} !important; color:#fff !important;}\n";
    if (wp_style_is('digim-style', 'enqueued') || wp_style_is('digim-style', 'queue')) {
        wp_add_inline_style('digim-style', $dynamic_css);
    } else {
        // Fallback: print inline if style isn't registered yet
        add_action('wp_head', function() use ($dynamic_css) {
            echo '<style>' . $dynamic_css . '</style>';
        }, 101);
    }
    ob_start();
    include plugin_dir_path(__FILE__) . '/listings-template.php';
    
    // Reset flag after rendering
    $digim_from_ui_builder = false;
    
    return ob_get_clean();
}

// === SEARCH-ONLY SHORTCODE: [digim_search_form] ==============================

// Enqueue only what the form needs when the shortcode is present (no map libs)
add_action('wp_enqueue_scripts', function () {
    global $post;
    
    // Check if we should load the styles and scripts
    $should_load = false;
    
    // Check if shortcode exists in post content
    if (is_singular() && has_shortcode(get_post()->post_content, 'digim_search_form')) {
        $should_load = true;
    }
    
    // Check if we're on a page that might contain listings (like /listings/)
    if (is_page() && (strpos($_SERVER['REQUEST_URI'], '/listings') !== false || 
                     strpos($_SERVER['REQUEST_URI'], 'listings') !== false)) {
        $should_load = true;
    }
    
    // Check if we're on a property single page
    if (get_query_var('dm_property_uuid')) {
        $should_load = true;
    }
    
    // Check if the current page template or content contains digim classes
    if (isset($post) && (strpos($post->post_content, 'digim-main') !== false || 
                        strpos($post->post_content, 'digimanagement') !== false)) {
        $should_load = true;
    }
    
    // Fallback: Check if we're on any page that might need the plugin styles
    // This can be customized based on your specific needs
    $force_load_pages = ['listings', 'properties', 'search'];
    foreach ($force_load_pages as $page_slug) {
        if (is_page($page_slug) || strpos($_SERVER['REQUEST_URI'], $page_slug) !== false) {
            $should_load = true;
            break;
        }
    }
    
    if (!$should_load) return;

    // Styles
    wp_enqueue_style('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css', [], null);
    wp_enqueue_style('daterangepicker-css', 'https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css', [], null);
    wp_enqueue_style('digim-fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css', [], '6.5.2');

    // From inside a file under /plugins/DigiM/templates/...
    $plugin_dir = plugin_dir_path(dirname(__FILE__)); // -> /wp-content/plugins/DigiM/
    $plugin_url = plugin_dir_url(dirname(__FILE__));  // -> https://.../wp-content/plugins/DigiM/
    $rel        = 'assets/css/style.css';
    $style_path = $plugin_dir . $rel;
    $style_url  = $plugin_url . $rel;
    if (file_exists($style_path)) {
        wp_enqueue_style('digim-style', $style_url, [], filemtime($style_path));
    }

    // Scripts
    wp_enqueue_script('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js', ['jquery'], null, true);
    wp_enqueue_script('moment-js', 'https://cdn.jsdelivr.net/npm/moment@2.29.4/moment.min.js', [], null, true);
    wp_enqueue_script('daterangepicker-js', 'https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js', ['moment-js', 'jquery'], null, true);
}, 5);

// [digim_search_form listingsurl="/listings"]
add_shortcode('digim_search_form', function ($atts = []) {
    // Ensure styles load when rendered via builders (e.g., Bricks), regardless of earlier conditional hooks
    $plugin_dir = plugin_dir_path(dirname(__FILE__));
    $plugin_url = plugin_dir_url(dirname(__FILE__));
    $rel_style  = 'assets/css/style.css';
    $style_path = $plugin_dir . $rel_style;
    $style_url  = $plugin_url . $rel_style;
    if (file_exists($style_path)) {
        if (!wp_style_is('digim-style', 'enqueued')) {
            wp_enqueue_style('digim-style', $style_url, [], filemtime($style_path));
        }
    }
    // Ensure third-party CSS is present when rendered via builders
    if (!wp_style_is('select2', 'enqueued')) {
        wp_enqueue_style('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css', [], null);
    }
    if (!wp_style_is('daterangepicker-css', 'enqueued')) {
        wp_enqueue_style('daterangepicker-css', 'https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css', [], null);
    }

    // Ensure required JS deps are present when rendered via builders
    if (!wp_script_is('select2', 'enqueued')) {
        wp_enqueue_script('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js', ['jquery'], null, true);
    }
    if (!wp_script_is('moment-js', 'enqueued')) {
        wp_enqueue_script('moment-js', 'https://cdn.jsdelivr.net/npm/moment@2.29.4/moment.min.js', [], null, true);
    }
    if (!wp_script_is('daterangepicker-js', 'enqueued')) {
        wp_enqueue_script('daterangepicker-js', 'https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js', ['moment-js', 'jquery'], null, true);
    }

    // Accept optional redirection target
    $atts = shortcode_atts([
        'listingsurl' => '', // e.g. "/listings" (relative) or full URL
    ], $atts, 'digim_search_form');

    $listings_url = trim($atts['listingsurl']);
    // Allow relative paths; esc_url handles both
    $form_action = $listings_url ? esc_url($listings_url) : '';

    // Current filters from URL
    $search = isset($_GET['property_search']) ? $_GET['property_search'] : '';
    // Handle both array (multiple) and string (single) formats
    if (is_array($search)) {
        $search = array_map('sanitize_text_field', array_filter($search));
    } else {
        $search = $search ? [sanitize_text_field($search)] : [];
    }
    $checkin  = sanitize_text_field($_GET['checkin'] ?? '');
    $checkout = sanitize_text_field($_GET['checkout'] ?? '');

    $adults   = intval($_GET['adults'] ?? 0);
    $children = intval($_GET['children'] ?? 0);
    $infants  = intval($_GET['infants'] ?? 0);
    $pets     = intval($_GET['pets'] ?? 0);
    $guest_count = max(0, $adults + $children + $infants); // matches listings calc

    // Build destination dropdown values from cached properties
    if (!function_exists('digim_get_all_properties')) {
        return '<p style="color:#c00">digim_get_all_properties() not found.</p>';
    }
    $all_properties = digim_get_all_properties();
    $destination_names = array_unique(array_filter(array_map(
        fn($p) => $p['address']['city'] ?? '',
        $all_properties
    )));
    sort($destination_names);

    ob_start();
    ?>
    <div class="digim-main digim-shortcode onlysearch">
        <form class="digimanagement-search" method="get" action="<?php echo $form_action; ?>" data-listings-url="<?php echo esc_attr($listings_url); ?>">
            <div class="search-grid">
                <!-- WHERE -->
                <div class="search-group">
                    <label>Where</label>
                    <select name="property_search[]" class="city-select" multiple>
                        <?php foreach ($destination_names as $city): ?>
                            <option value="<?php echo esc_attr($city); ?>" <?php 
                                $search_array = is_array($search) ? $search : ($search ? [$search] : []);
                                selected(true, in_array($city, $search_array)); 
                            ?>>
                                <?php echo esc_html($city); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- CHECKIN / CHECKOUT -->
                <div class="search-group datecal">
                    <label>Check in / Check out</label>
                    <input
                        type="text"
                        name="date_range"
                        class="flatpickr-range"
                        placeholder="Add dates"
                        autocomplete="off"
                        value="<?php
                                echo ($checkin && $checkout)
                                    ? esc_attr(date('M j, Y', strtotime($checkin)) . ' to ' . date('M j, Y', strtotime($checkout)))
                                    : '';
                                ?>">
                    <input type="hidden" name="checkin" class="checkin-hidden" value="<?php echo esc_attr($checkin); ?>">
                    <input type="hidden" name="checkout" class="checkout-hidden" value="<?php echo esc_attr($checkout); ?>">
                </div>

                <!-- WHO -->
                <div class="search-group">
                    <label>Who</label>
                    <div class="guest-dropdown-wrapper">
                        <button type="button" class="guest-toggle">
                            <?php
                            $btn = 'Add guests';
                            $g   = $adults + $children;
                            if ($g > 0) {
                                $btn = $g . ' guest' . ($g > 1 ? 's' : '');
                                if ($infants > 0) $btn .= ", $infants infant" . ($infants > 1 ? 's' : '');
                                if ($pets    > 0) $btn .= ", $pets pet" . ($pets > 1 ? 's' : '');
                            }
                            echo esc_html($btn);
                            ?>
                        </button>
                        <div class="guest-dropdown">
                            <?php
                            $guest_types = [
                                'adults'   => ['label' => 'Adults',   'desc' => 'Ages 13 or above',         'val' => $adults],
                                'children' => ['label' => 'Children', 'desc' => 'Ages 2–12',                'val' => $children],
                                'infants'  => ['label' => 'Infants',  'desc' => 'Under 2',                 'val' => $infants],
                                'pets'     => ['label' => 'Pets',     'desc' => '<a href="#">Bringing a service animal?</a>', 'val' => $pets],
                            ];
                            foreach ($guest_types as $type => $meta): ?>
                                <div class="guest-row">
                                    <div class="guest-labels">
                                        <span><?php echo esc_html($meta['label']); ?></span>
                                        <span><?php echo $meta['desc']; // may contain link 
                                                ?></span>
                                    </div>
                                    <div class="guest-controls">
                                        <button type="button" class="minus" aria-label="Decrease <?php echo esc_attr($type); ?>">−</button>
                                        <span class="guest-count"><?php echo intval($meta['val']); ?></span>
                                        <button type="button" class="plus" aria-label="Increase <?php echo esc_attr($type); ?>">+</button>
                                        <input type="hidden" name="<?php echo esc_attr($type); ?>" value="<?php echo intval($meta['val']); ?>">
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <input type="hidden" name="guests" value="<?php echo esc_attr($guest_count); ?>">
                    </div>
                </div>

                <!-- BUTTONS -->
                <div class="search-buttons">
                    <button type="button" class="reset-button" title="Reset"><i class="fas fa-undo"></i></button>
                    <button type="submit" class="search-button" title="Search"><i class="fas fa-search"></i></button>
                </div>
            </div>
        </form>

        <script>
            document.addEventListener("DOMContentLoaded", function() {
                function initDigimSearchOnce() {
                    // Select2 for city
                    if (window.jQuery && document.querySelector('select[name="property_search[]"]')) {
                        jQuery(function($) {
                            var $el = $('select[name="property_search[]"]');
                            if (!$el.data('select2')) {
                                $el.select2({
                                    placeholder: "Search destinations",
                                    allowClear: true,
                                    width: '100%',
                                    multiple: true,
                                    minimumResultsForSearch: Infinity,
                                    closeOnSelect: false
                                });
                            }
                        });
                    }

                    // DateRangePicker range -> hidden fields
                    var rangeInput = document.querySelector('.digimanagement-search .flatpickr-range');
                    if (rangeInput && typeof jQuery !== 'undefined' && typeof moment !== 'undefined' && typeof jQuery.fn.daterangepicker !== 'undefined' && !rangeInput._digimDaterangepickerReady) {
                        var checkinHidden = document.querySelector('.digimanagement-search .checkin-hidden');
                        var checkoutHidden = document.querySelector('.digimanagement-search .checkout-hidden');

                        // Ensure moment.js is available and set to English locale for correct date calculations
                        if (typeof moment === 'undefined') {
                            console.error('Moment.js is required for DateRangePicker');
                            return;
                        }
                        
                        // Set locale to English to ensure correct day/month names and date calculations
                        moment.locale('en');

                        // Set initial dates if hidden inputs have values
                        var startDate = null;
                        var endDate = null;
                        if (checkinHidden && checkoutHidden && checkinHidden.value && checkoutHidden.value) {
                            startDate = moment(checkinHidden.value, 'YYYY-MM-DD', true);
                            endDate = moment(checkoutHidden.value, 'YYYY-MM-DD', true);
                        }

                        jQuery(rangeInput).daterangepicker({
                            startDate: (startDate && startDate.isValid()) ? startDate : moment(),
                            endDate: (endDate && endDate.isValid()) ? endDate : null,
                            minDate: moment(),
                            singleDatePicker: false,
                            autoUpdateInput: false,
                            autoApply: true, // Automatically apply selection when both dates are chosen
                            locale: {
                                format: 'MMM D, YYYY',
                                separator: ' to ',
                                applyLabel: 'Apply',
                                cancelLabel: 'Cancel',
                                fromLabel: 'From',
                                toLabel: 'To',
                                customRangeLabel: 'Custom',
                                weekLabel: 'W',
                                daysOfWeek: moment.weekdaysMin(),
                                monthNames: moment.months(),
                                firstDay: moment.localeData().firstDayOfWeek()
                            },
                            opens: 'left'
                        }, function(start, end, label) {
                            if (start && end) {
                                var checkinStr = start.format('YYYY-MM-DD');
                                var checkoutStr = end.format('YYYY-MM-DD');
                                
                                if (checkinHidden) checkinHidden.value = checkinStr;
                                if (checkoutHidden) checkoutHidden.value = checkoutStr;
                                
                                rangeInput.value = start.format('MMM D, YYYY') + ' to ' + end.format('MMM D, YYYY');
                                
                                // Hide calendar after dates are selected (similar to property-single.php)
                                setTimeout(function() {
                                    var $calendar = jQuery('.daterangepicker');
                                    if ($calendar.length) {
                                        $calendar.hide();
                                    }
                                }, 100);
                            } else if (start) {
                                if (checkinHidden) checkinHidden.value = start.format('YYYY-MM-DD');
                                if (checkoutHidden) checkoutHidden.value = "";
                                rangeInput.value = start.format('MMM D, YYYY');
                            } else {
                                if (checkinHidden) checkinHidden.value = "";
                                if (checkoutHidden) checkoutHidden.value = "";
                                rangeInput.value = "";
                            }
                        });

                        // Set display format (MMM D, YYYY format for search-group datecal - e.g., "Jan 15, 2024")
                        if (startDate && endDate) {
                            rangeInput.value = startDate.format('MMM D, YYYY') + ' to ' + endDate.format('MMM D, YYYY');
                        }

                        rangeInput._digimDaterangepickerReady = true;
                        
                        // Hide apply/cancel buttons since we use autoApply
                        jQuery(rangeInput).on('show.daterangepicker', function() {
                            setTimeout(function() {
                                var $calendar = jQuery('.daterangepicker');
                                if ($calendar.length) {
                                    $calendar.find('.drp-buttons, .applyBtn, .cancelBtn').hide();
                                    $calendar.find('.drp-buttons').css('display', 'none');
                                }
                            }, 10);
                        });
                        
                        // Also listen for when both dates are selected to ensure calendar closes
                        jQuery(rangeInput).on('apply.daterangepicker', function() {
                            setTimeout(function() {
                                var $calendar = jQuery('.daterangepicker');
                                if ($calendar.length) {
                                    $calendar.hide();
                                }
                            }, 50);
                        });
                        
                        // Listen for date clicks to hide calendar when both dates are selected
                        jQuery(document).on('click', '.daterangepicker td.available', function() {
                            setTimeout(function() {
                                var $calendar = jQuery('.daterangepicker');
                                if ($calendar.length) {
                                    var hasStartDate = $calendar.find('.start-date').length > 0;
                                    var hasEndDate = $calendar.find('.end-date').length > 0;
                                    if (hasStartDate && hasEndDate) {
                                        // Both dates selected, hide calendar
                                        setTimeout(function() {
                                            $calendar.hide();
                                        }, 100);
                                    }
                                }
                            }, 50);
                        });
                    }
                }

                // Try now
                initDigimSearchOnce();

                // Retry when daterangepicker loads late
                var tries = 0;
                var t = setInterval(function() {
                    if (typeof jQuery !== 'undefined' && typeof moment !== 'undefined' && typeof jQuery.fn.daterangepicker !== 'undefined') {
                        initDigimSearchOnce();
                        clearInterval(t);
                    } else if (++tries > 50) {
                        clearInterval(t);
                    }
                }, 150);

                // Observe DOM changes (builders injecting after DOMContentLoaded)
                var observer = new MutationObserver(function(mutations) {
                    for (var i = 0; i < mutations.length; i++) {
                        if (document.querySelector('.digimanagement-search .flatpickr-range')) {
                            initDigimSearchOnce();
                            break;
                        }
                    }
                });
                if (document.body) {
                    observer.observe(document.body, { childList: true, subtree: true });
                }

                // Guests dropdown + summary
                (function() {
                    var wrapper = document.querySelector(".digimanagement-search .guest-dropdown-wrapper");
                    if (!wrapper) return;

                    var toggleBtn = wrapper.querySelector(".guest-toggle");
                    var dropdown = wrapper.querySelector(".guest-dropdown");
                    var guestRows = wrapper.querySelectorAll(".guest-row");
                    var totalGuestsInput = wrapper.querySelector('input[name="guests"]');

                    function updateGuestSummary() {
                        var guests = 0,
                            infants = 0,
                            pets = 0;

                        guestRows.forEach(function(row) {
                            var input = row.querySelector('input[type="hidden"]');
                            var count = parseInt(input.value) || 0;
                            var type = input.name;

                            if (type === "adults" || type === "children") guests += count;
                            else if (type === "infants") infants = count;
                            else if (type === "pets") pets = count;

                            var label = row.querySelector(".guest-count");
                            if (label) label.textContent = count;
                        });

                        var text = guests > 0 ? (guests + " guest" + (guests > 1 ? "s" : "")) : "Add guests";
                        if (infants > 0) text += ", " + infants + " infant" + (infants > 1 ? "s" : "");
                        if (pets > 0) text += ", " + pets + " pet" + (pets > 1 ? "s" : "");

                        toggleBtn.textContent = text;
                        if (totalGuestsInput) totalGuestsInput.value = Math.max(0, guests + infants); // keep parity with server
                    }

                    guestRows.forEach(function(row) {
                        var input = row.querySelector('input[type="hidden"]');
                        var minus = row.querySelector(".minus");
                        var plus = row.querySelector(".plus");

                        minus.addEventListener("click", function() {
                            input.value = Math.max(0, (parseInt(input.value) || 0) - 1);
                            updateGuestSummary();
                        });
                        plus.addEventListener("click", function() {
                            input.value = (parseInt(input.value) || 0) + 1;
                            updateGuestSummary();
                        });
                    });

                    toggleBtn.addEventListener("click", function() {
                        dropdown.classList.toggle("active");
                    });

                    document.addEventListener("click", function(e) {
                        if (!wrapper.contains(e.target)) dropdown.classList.remove("active");
                    });

                    // Reset form without reload
                    var formEl = document.querySelector('.digimanagement-search');
                    var resetBtn = document.querySelector('.digimanagement-search .reset-button');
                    if (resetBtn && formEl) {
                        resetBtn.addEventListener("click", function() {
                            // Reset city select dropdown (Select2)
                            var citySelect = document.querySelector('.digimanagement-search select[name="property_search[]"]');
                            if (citySelect && window.jQuery) {
                                window.jQuery(citySelect).val(null).trigger('change');
                            } else if (citySelect) {
                                citySelect.value = '';
                            }

                            // Reset date range (DateRangePicker)
                            var dateRangeInput = document.querySelector('.digimanagement-search .flatpickr-range');
                            if (dateRangeInput && typeof jQuery !== 'undefined' && jQuery(dateRangeInput).data('daterangepicker')) {
                                var picker = jQuery(dateRangeInput).data('daterangepicker');
                                picker.setStartDate(moment());
                                picker.setEndDate(null);
                                jQuery(dateRangeInput).val('');
                            } else if (dateRangeInput) {
                                dateRangeInput.value = '';
                            }
                            
                            // Reset hidden date inputs
                            var checkinHidden = document.querySelector('.digimanagement-search .checkin-hidden');
                            var checkoutHidden = document.querySelector('.digimanagement-search .checkout-hidden');
                            if (checkinHidden) checkinHidden.value = '';
                            if (checkoutHidden) checkoutHidden.value = '';

                            // Reset guest inputs
                            guestRows.forEach(function(row) {
                                var input = row.querySelector('input[type="hidden"]');
                                if (input) {
                                    input.value = '0';
                                }
                            });

                            // Update guest summary
                            updateGuestSummary();

                            // Clear URL parameters - reload only if URL has parameters
                            if (window.location.search) {
                                // URL has parameters, reload with clean URL
                                window.location.href = window.location.pathname;
                            }
                            // If no URL parameters, just reset inputs (already done above, no reload)
                        });
                    }

                    updateGuestSummary();
                })();
            });
        </script>
        <?php 
        // Ensure primary color is defined for search-only shortcode
        $primary_color = get_option('digim_primary_color', '#0073aa');
        if (empty($primary_color) || !is_string($primary_color)) {
            $primary_color = '#0073aa';
        }

        // Helper function to darken hex color (robust to null/invalid)
        if (!function_exists('digim_darken_color')) {
            function digim_darken_color($hex, $percent = 20) {
                $hex = (string) $hex;
                if ($hex === '') {
                    $hex = '#000000';
                }
                $hex = str_replace('#', '', $hex);
                if (strlen($hex) !== 6) {
                    return '#000000';
                }

                $r = hexdec(substr($hex, 0, 2));
                $g = hexdec(substr($hex, 2, 2));
                $b = hexdec(substr($hex, 4, 2));

                $r = max(0, min(255, (int) round($r - ($r * $percent / 100)))) ;
                $g = max(0, min(255, (int) round($g - ($g * $percent / 100)))) ;
                $b = max(0, min(255, (int) round($b - ($b * $percent / 100)))) ;

                return '#' . str_pad(dechex($r), 2, '0', STR_PAD_LEFT)
                           . str_pad(dechex($g), 2, '0', STR_PAD_LEFT)
                           . str_pad(dechex($b), 2, '0', STR_PAD_LEFT);
            }
        }

        $primary_color_hover = digim_darken_color($primary_color, 10);
        $primary_color_active = digim_darken_color($primary_color, 20);
        ?>

        <style>
            :root {
                --digim-primary-color: <?php echo $primary_color; ?>;
                --digim-primary-color-hover: <?php echo $primary_color_hover; ?>;
                --digim-primary-color-active: <?php echo $primary_color_active; ?>;
                --digim-primary-color-dark: <?php echo $primary_color; ?>dd;
                --digim-primary-color-darker: <?php echo $primary_color; ?>cc;
            }
            
            .digim-main .digimanagement-search .search-buttons button.search-button {
                background: <?php echo $primary_color; ?> !important;
                background-color: <?php echo $primary_color; ?> !important;
                color: #fff !important;
            }
            
            .digim-main .digimanagement-search .search-buttons button.search-button:hover,
            .digim-main .digimanagement-search .search-buttons button.search-button:focus {
                background: <?php echo $primary_color_hover; ?> !important;
                background-color: <?php echo $primary_color_hover; ?> !important;
                color: #fff !important;
            }
            
            .digim-main .digimanagement-search .search-buttons button.search-button:active {
                background: <?php echo $primary_color_active; ?> !important;
                background-color: <?php echo $primary_color_active; ?> !important;
                color: #fff !important;
            }
            
            .digim-main .digimanagement-pagination a.active {
                background: <?php echo $primary_color; ?> !important;
                border-color: <?php echo $primary_color; ?> !important;
            }

            .digimanagement-card.highlight {
                outline: 2px solid <?php echo $primary_color; ?> !important;
                box-shadow: 0 0 5px <?php echo $primary_color; ?> !important;
            }

            /* Minimal safety styles; keeps your structure intact */
            .guest-dropdown-wrapper {
                position: relative;
            }

            .guest-toggle {
                display: inline-flex;
                align-items: center;
                gap: .5rem;
                padding: .5rem .75rem;
                border: 1px solid #ddd;
                border-radius: 8px;
                background: #fff;
                cursor: pointer;
            }

            .guest-dropdown {
                position: absolute;
                top: 100%;
                left: 0;
                z-index: 50;
                width: 320px;
                max-width: 90vw;
                background: #fff;
                border: 1px solid #e5e7eb;
                border-radius: 12px;
                padding: .75rem;
                margin-top: .5rem;
                box-shadow: 0 10px 20px rgba(0, 0, 0, .08);
                display: none;
            }

            .guest-dropdown.active {
                display: block;
            }

            .guest-row {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 1rem;
                padding: .5rem 0;
            }

            .guest-labels {
                display: flex;
                flex-direction: column;
                gap: .15rem;
            }

            .guest-labels span:first-child {
                font-weight: 600;
            }

            .guest-labels span:last-child {
                font-size: .85rem;
                color: #6b7280;
            }

            .guest-controls {
                display: flex;
                align-items: center;
                gap: .75rem;
            }

            .guest-controls .minus,
            .guest-controls .plus {
                width: 32px;
                height: 32px;
                border-radius: 50%;
                border: 1px solid #ddd;
                background: #fff;
                line-height: 30px;
                text-align: center;
                font-size: 18px;
                cursor: pointer;
            }

            .search-grid {
                display: grid;
                grid-template-columns: repeat(4, minmax(0, 1fr));
                gap: 12px;
            }

            @media (max-width:768px) {
                .search-grid {
                    grid-template-columns: 1fr;
                }
            }

            .search-buttons {
                display: flex;
                align-items: center;
                gap: .5rem;
                justify-content: flex-end;
            }

            .search-button {
                padding: .6rem .9rem;
                border-radius: 10px;
                color: #fff;
                border: 1px solid transparent;
            }

            .reset-button {
                padding: .6rem .9rem;
                border-radius: 10px;
                border: 1px solid #ddd;
                background: #fff;
            }
        </style>
    </div>
<?php
    return ob_get_clean();
});

// === CARD SET SHORTCODE: [digim_cards id="dmcs_xxx"] ========================
add_shortcode('digim_cards', function ($atts = []) {
	// Set global flag that shortcode is being rendered
	global $digim_shortcode_rendered;
	$digim_shortcode_rendered = true;
	
	// Ensure styles are loaded
	$plugin_dir = plugin_dir_path(dirname(__FILE__));
	$plugin_url = plugin_dir_url(dirname(__FILE__));
	$rel_style  = 'assets/css/style.css';
	$style_path = $plugin_dir . $rel_style;
	$style_url  = $plugin_url . $rel_style;
	if (file_exists($style_path) && !wp_style_is('digim-style', 'enqueued')) {
		wp_enqueue_style('digim-style', $style_url, [], filemtime($style_path));
	}
	if (!wp_style_is('digim-fontawesome', 'enqueued')) {
		wp_enqueue_style('digim-fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css', [], '6.5.2');
	}
	
	// Ensure frontend.js is loaded for gallery functionality
	$js_path = $plugin_dir . 'assets/js/frontend.js';
	if (file_exists($js_path) && !wp_script_is('digim-frontend', 'enqueued')) {
		wp_enqueue_script('digim-frontend', $plugin_url . 'assets/js/frontend.js', ['jquery'], filemtime($js_path), true);
	}
	
	$atts = shortcode_atts([
		'id' => '',
	], $atts, 'digim_cards');

	$set_id = sanitize_text_field($atts['id']);
	if (!$set_id) return '<p style="color:#c00">Missing card set id.</p>';

	$sets = get_option('digim_card_sets', []);
	if (!isset($sets[$set_id])) return '<p style="color:#c00">Card set not found.</p>';
	$set = $sets[$set_id];
	$uuids = $set['selected'] ?? [];
	$slider = !empty($set['slider']);
	$columns = intval($set['columns'] ?? 3);
	$random_value = $set['random'] ?? 0;
	$random = !empty($random_value);

	$primary_color = get_option('digim_primary_color', '#0073aa');

    $props = digim_build_props_from_uuids($uuids);
    if ($random == 1) {
        shuffle($props);
    }
    return digim_render_cards_block($props, $slider, $columns, $primary_color);
});

if (!function_exists('digim_build_props_from_uuids')) {
    function digim_build_props_from_uuids($uuids) {
        $all = digim_get_all_properties();
        $map = [];
        foreach ($all as $p) {
            $map[$p['uuid'] ?? ($p['id'] ?? '')] = $p;
        }
        $props = [];
        foreach ($uuids as $u) {
            if (isset($map[$u])) $props[] = $map[$u];
        }
        return $props;
    }
}

if (!function_exists('digim_render_cards_block')) {
    function digim_render_cards_block($props, $slider, $columns, $primary_color) {
        ob_start();
        if ($slider) {
            wp_enqueue_style('swiper-css', 'https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css', [], '10');
            wp_enqueue_script('swiper-js', 'https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js', [], '10', true);
            $container_id = 'digim-swiper-' . wp_generate_uuid4();
            ?>
            <div class="digim-main digim-shortcode" id="digim-wrapper-<?php echo esc_attr($container_id); ?>">
                <div class="swiper" id="<?php echo esc_attr($container_id); ?>">
                    <div class="swiper-wrapper">
                        <?php foreach ($props as $property): ?>
                            <div class="swiper-slide">
                                <?php echo digim_render_property_card($property); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="swiper-pagination"></div>
                </div>
                <button type="button" class="digim-swiper-prev" aria-label="Previous">
                    <svg width="47" height="47" viewBox="0 0 47 47" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <rect x="47" y="47" width="47" height="47" rx="23.5" transform="rotate(-180 47 47)" fill="#274D55"/>
                        <path d="M27 28.9376L25.9589 30L20.2884 24.2096C20.197 24.1169 20.1245 24.0065 20.075 23.885C20.0255 23.7635 20 23.6331 20 23.5015C20 23.3699 20.0255 23.2395 20.075 23.118C20.1245 22.9965 20.197 22.8862 20.2884 22.7934L25.9589 17L26.999 18.0625L21.6769 23.5L27 28.9376Z" fill="white"/>
                    </svg>
                </button>
                <button type="button" class="digim-swiper-next" aria-label="Next">
                    <svg width="47" height="47" viewBox="0 0 47 47" fill="none" xmlns="http://www.w3.org/2000/svg" style="transform: rotate(180deg);">
                        <rect x="47" y="47" width="47" height="47" rx="23.5" transform="rotate(-180 47 47)" fill="#274D55"/>
                        <path d="M27 28.9376L25.9589 30L20.2884 24.2096C20.197 24.1169 20.1245 24.0065 20.075 23.885C20.0255 23.7635 20 23.6331 20 23.5015C20 23.3699 20.0255 23.2395 20.075 23.118C20.1245 22.9965 20.197 22.8862 20.2884 22.7934L25.9589 17L26.999 18.0625L21.6769 23.5L27 28.9376Z" fill="white"/>
                    </svg>
                </button>
            </div>
            <script>
                (function() {
                    function initSwiper() {
                        var containerId = '<?php echo esc_js($container_id); ?>';
                        var wrapperId = 'digim-wrapper-<?php echo esc_js($container_id); ?>';
                        var swiperEl = document.getElementById(containerId);
                        var nextBtn = document.querySelector('#' + wrapperId + ' .digim-swiper-next');
                        var prevBtn = document.querySelector('#' + wrapperId + ' .digim-swiper-prev');
                        
                        if (!swiperEl) {
                            // Retry if element not found yet
                            setTimeout(initSwiper, 100);
                            return;
                        }
                        
                        if (window.Swiper) {
                            var swiper = new Swiper('#' + containerId, {
                                spaceBetween: 16,
                                loop: false,
                                pagination: { 
                                    el: '#' + containerId + ' .swiper-pagination', 
                                    clickable: true 
                                },
                                navigation: { 
                                    nextEl: '#' + wrapperId + ' .digim-swiper-next', 
                                    prevEl: '#' + wrapperId + ' .digim-swiper-prev' 
                                },
                                breakpoints: {
                                    320: { slidesPerView: 1 },
                                    640: { slidesPerView: 2 },
                                    960: { slidesPerView: Math.max(2, Math.min(4, <?php echo intval($columns); ?>)) },
                                }
                            });
                            
                            // Ensure buttons work even if Swiper navigation fails
                            if (nextBtn && !nextBtn._digimListener) {
                                nextBtn.addEventListener('click', function(e) {
                                    e.preventDefault();
                                    e.stopPropagation();
                                    if (swiper && swiper.slideNext) {
                                        swiper.slideNext();
                                    }
                                });
                                nextBtn._digimListener = true;
                            }
                            
                            if (prevBtn && !prevBtn._digimListener) {
                                prevBtn.addEventListener('click', function(e) {
                                    e.preventDefault();
                                    e.stopPropagation();
                                    if (swiper && swiper.slidePrev) {
                                        swiper.slidePrev();
                                    }
                                });
                                prevBtn._digimListener = true;
                            }
                        } else {
                            // Wait for Swiper to load
                            setTimeout(initSwiper, 100);
                        }
                    }
                    
                    if (document.readyState === 'loading') {
                        document.addEventListener('DOMContentLoaded', initSwiper);
                    } else {
                        initSwiper();
                    }
                })();
            </script>
            <style>
                :root { --digim-primary-color: <?php echo esc_html($primary_color); ?>; }
                .swiper-pagination-bullet-active { background: var(--digim-primary-color); }
                /* Custom arrow buttons */
                #digim-wrapper-<?php echo esc_html($container_id); ?> {
                    position: relative;
                    overflow: visible !important;
                }
                #<?php echo esc_html($container_id); ?> {
                    overflow: hidden !important;
                }
                #digim-wrapper-<?php echo esc_html($container_id); ?> .digim-swiper-prev,
                #digim-wrapper-<?php echo esc_html($container_id); ?> .digim-swiper-next { 
                    position: absolute; 
                    top: 50%; 
                    transform: translateY(-50%); 
                    z-index: 10; 
                    background: transparent; 
                    border: 0; 
                    padding: 0; 
                    cursor: pointer; 
                    width: 47px; 
                    height: 47px;
                }
                #digim-wrapper-<?php echo esc_html($container_id); ?> .digim-swiper-prev { left: -25px; }
                #digim-wrapper-<?php echo esc_html($container_id); ?> .digim-swiper-next { right: -25px; }
                #digim-wrapper-<?php echo esc_html($container_id); ?> .digim-swiper-prev svg,
                #digim-wrapper-<?php echo esc_html($container_id); ?> .digim-swiper-next svg { 
                    display: block; 
                    width: 47px; 
                    height: 47px; 
                }
                @media screen and (max-width: 1160px) {
                    #digim-wrapper-<?php echo esc_html($container_id); ?> .digim-swiper-prev {         left: auto;
                        position: relative;
                        left: -32px;
                        top: 24px;
                        transform: none;
                        margin: 0 auto;
                        display: flex; 
                    }
                    #digim-wrapper-<?php echo esc_html($container_id); ?> .digim-swiper-next { 
                        position: relative;
                        right: -32px;
                        top: -23px;
                        transform: none;
                        margin: 0 auto;
                        display: flex;  
                    }
                }
                @media screen and (max-width: 576px) {
                    #digim-wrapper-<?php echo esc_html($container_id); ?> .digim-swiper-prev {         left: auto;
                        position: relative;
                        left: -32px;
                        top: 0;
                        transform: none;
                        margin: 0 auto;
                        display: flex; 
                    }
                    #digim-wrapper-<?php echo esc_html($container_id); ?> .digim-swiper-next { 
                        position: relative;
                        right: -32px;
                        top: -47px;
                        transform: none;
                        margin: 0 auto;
                        display: flex;  
                    }
                }
            </style>
            <?php
        } else {
            $grid_class = "digimanagement-grid grid-cols-{$columns}";
            ?>
            <div class="digim-main digim-shortcode">
                <div class="dm-grid">
                    <div class="dm-property">
                        <div class="<?php echo esc_attr($grid_class); ?>">
                            <?php if (empty($props)): ?>
                                <p class="no-results" style="margin-top: 1rem;">No listings selected.</p>
                            <?php else: ?>
                                <?php foreach ($props as $property): ?>
                                    <?php echo digim_render_property_card($property); ?>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <style>
                :root { --digim-primary-color: <?php echo esc_html($primary_color); ?>; }
            </style>
            <?php
        }
        return ob_get_clean();
    }
}

if (!function_exists('digim_render_property_card')) {
	function digim_render_property_card($property) {
		$original_picture = $property['picture'] ?? '';
		$high_res_picture = preg_replace('/\?.*/', '', $original_picture);
		$uuid = $property['uuid'] ?? ($property['id'] ?? '');
		$property_slug = digimanagement_create_property_slug(
			$property['name'] ?? '',
			$property['address']['city'] ?? ''
		);
		$property_url = site_url('/property/' . esc_attr($property_slug) . '/');

        static $settings_cache = null;
        if ($settings_cache === null) {
            $settings_cache = [
                'row'        => intval(get_option('digim_show_capacity', 1)),
                'guests'     => intval(get_option('digim_show_capacity_guests', 1)),
                'bedrooms'   => intval(get_option('digim_show_capacity_bedrooms', 1)),
                'beds'       => intval(get_option('digim_show_capacity_beds', 1)),
                'bathrooms'  => intval(get_option('digim_show_capacity_bathrooms', 1)),
            ];
        }
        $show_capacity = apply_filters('digim_show_capacity_grid', $settings_cache['row'], $property);
        $show_capacity_guests = apply_filters('digim_show_capacity_guests', $settings_cache['guests'], $property);
        $show_capacity_bedrooms = apply_filters('digim_show_capacity_bedrooms', $settings_cache['bedrooms'], $property);
        $show_capacity_beds = apply_filters('digim_show_capacity_beds', $settings_cache['beds'], $property);
        $show_capacity_bathrooms = apply_filters('digim_show_capacity_bathrooms', $settings_cache['bathrooms'], $property);

        // Fetch gallery images (same logic as listings-template.php)
        $gallery_images = [];
        $seen_urls = [];
        
        // Priority 1: Fetch from Hospitable API using property UUID
        if (!empty($uuid) && function_exists('digimanagement_get_api_url') && function_exists('digimanagement_get_api_token')) {
            $images_response = wp_remote_get(digimanagement_get_api_url() . "/properties/$uuid/images", [
                'headers' => [
                    'Authorization' => digimanagement_get_api_token(),
                    'Accept' => 'application/json',
                    'Cache-Control' => 'no-cache',
                ],
                'timeout' => 10,
            ]);

            if (!is_wp_error($images_response)) {
                $images_data = json_decode(wp_remote_retrieve_body($images_response), true);
                
                foreach ($images_data['data'] ?? [] as $img) {
                    $url = $img['original_url'] ?? $img['url'] ?? $img['thumbnail_url'] ?? null;
                    if ($url && !in_array($url, $seen_urls)) {
                        $gallery_images[] = $url;
                        $seen_urls[] = $url;
                        if (count($gallery_images) >= 4) {
                            break;
                        }
                    }
                }
            }
        }
        
        // Priority 2: Fallback to property data images if we don't have enough (3-4 images)
        if (count($gallery_images) < 3 && !empty($property['images']) && is_array($property['images'])) {
            foreach ($property['images'] as $img) {
                $url = '';
                if (is_array($img)) {
                    $url = $img['url'] ?? $img['original_url'] ?? '';
                    if (!$url && isset($img[0]) && is_string($img[0])) {
                        $url = $img[0];
                    }
                } elseif (is_string($img)) {
                    $url = $img;
                }
                if ($url && !in_array($url, $seen_urls)) {
                    $gallery_images[] = $url;
                    $seen_urls[] = $url;
                    if (count($gallery_images) >= 4) {
                        break;
                    }
                }
            }
        }
        
        // Priority 3: Fallback to high_res_picture if no images found
        if (empty($gallery_images) && !empty($high_res_picture)) {
            $gallery_images[] = $high_res_picture;
        }
        $gallery_count = count($gallery_images);

		ob_start();
		?>
        <a href="<?php echo esc_url($property_url); ?>" class="digimanagement-card">
			<?php if ($gallery_count > 0): ?>
				<div class="digim-card-media" data-digim-gallery>
					<div class="digim-card-gallery" data-digim-gallery-track>
						<?php foreach ($gallery_images as $index => $image_url): ?>
							<div class="digim-card-slide <?php echo $index === 0 ? 'is-active' : ''; ?>" data-digim-gallery-slide="<?php echo esc_attr($index); ?>">
								<img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($property['name'] ?? 'Property image'); ?>" loading="lazy" decoding="async" />
							</div>
						<?php endforeach; ?>
					</div>
					<?php if ($gallery_count > 1): ?>
						<button class="digim-gallery-nav previous" type="button" aria-label="<?php echo esc_attr__('View previous image', 'digim'); ?>" data-digim-gallery-prev>
							<span aria-hidden="true">&lsaquo;</span>
						</button>
						<button class="digim-gallery-nav next" type="button" aria-label="<?php echo esc_attr__('View next image', 'digim'); ?>" data-digim-gallery-next>
							<span aria-hidden="true">&rsaquo;</span>
						</button>
						<div class="digim-gallery-indicators" role="tablist">
							<?php foreach ($gallery_images as $index => $image_url): ?>
								<button type="button" class="digim-gallery-dot <?php echo $index === 0 ? 'is-active' : ''; ?>" aria-label="<?php echo esc_attr(sprintf(__('Show image %d', 'digim'), $index + 1)); ?>" data-digim-gallery-dot="<?php echo esc_attr($index); ?>"></button>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>
				</div>
			<?php endif; ?>
			<div class="digim-card-content">
				<h3 class="digim-title"><?php echo esc_html($property['name'] ?? 'Untitled'); ?></h3>
				<?php if (!empty($property['address']['display'])): ?>
                    <p class="digim-address">
                        <span class="location-icon" aria-hidden="true">
                            <svg width="11" height="13" viewBox="0 0 11 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1.78795 1.75234C2.73221 0.826967 4.00352 0.311624 5.3256 0.318301C6.64769 0.324979 7.91372 0.853137 8.84859 1.78801C9.78346 2.72287 10.3116 3.98891 10.3183 5.31099C10.325 6.63308 9.80963 7.90439 8.88425 8.84865L6.23201 11.5009C5.99437 11.7385 5.67211 11.8719 5.3361 11.8719C5.00008 11.8719 4.67783 11.7385 4.44019 11.5009L1.78795 8.84865C0.846981 7.90759 0.318359 6.63129 0.318359 5.3005C0.318359 3.9697 0.846981 2.69341 1.78795 1.75234Z" stroke="#5E5E5E" stroke-width="0.636364" stroke-linejoin="round"/>
                                <path d="M5.33537 7.20137C6.38515 7.20137 7.23616 6.35036 7.23616 5.30058C7.23616 4.2508 6.38515 3.39978 5.33537 3.39978C4.28559 3.39978 3.43457 4.2508 3.43457 5.30058C3.43457 6.35036 4.28559 7.20137 5.33537 7.20137Z" stroke="#5E5E5E" stroke-width="0.636364" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </span>
                        <?php echo esc_html($property['address']['display']); ?>
                    </p>
				<?php endif; ?>
                <?php if ($show_capacity): ?>
    				<div class="capacity-grid">
                        <!-- <?php if ($show_capacity_guests && ($property['capacity']['max'] ?? '')): ?>
                            <div class="capacity-item">
                                <span class="icon-svg" aria-hidden="true">
                                    <svg width="19" height="14" viewBox="0 0 19 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M13.0667 12.1334V14H0V12.1334C0 12.1334 0 8.40004 6.53333 8.40004C13.0667 8.40004 13.0667 12.1334 13.0667 12.1334ZM9.8 3.2667C9.8 2.62062 9.60842 1.98904 9.24947 1.45184C8.89052 0.914638 8.38034 0.495941 7.78343 0.248695C7.18653 0.00144844 6.52971 -0.0632425 5.89604 0.0628026C5.26237 0.188848 4.6803 0.499968 4.22345 0.956819C3.7666 1.41367 3.45548 1.99574 3.32944 2.62941C3.20339 3.26308 3.26808 3.9199 3.51533 4.5168C3.76257 5.11371 4.18127 5.62389 4.71847 5.98284C5.25567 6.34178 5.88725 6.53337 6.53333 6.53337C7.39971 6.53337 8.2306 6.1892 8.84322 5.57658C9.45584 4.96396 9.8 4.13308 9.8 3.2667ZM13.0107 8.40004C13.5844 8.84407 14.0539 9.40844 14.3861 10.0534C14.7183 10.6984 14.9051 11.4084 14.9333 12.1334V14H18.6667V12.1334C18.6667 12.1334 18.6667 8.74537 13.0107 8.40004ZM12.1333 3.43434e-05C11.491 -0.00295339 10.8629 0.189063 10.332 0.550701C10.8989 1.34286 11.2038 2.29257 11.2038 3.2667C11.2038 4.24083 10.8989 5.19055 10.332 5.9827C10.8629 6.34434 11.491 6.53636 12.1333 6.53337C12.9997 6.53337 13.8306 6.1892 14.4432 5.57658C15.0558 4.96396 15.4 4.13308 15.4 3.2667C15.4 2.40033 15.0558 1.56944 14.4432 0.956819C13.8306 0.3442 12.9997 3.43434e-05 12.1333 3.43434e-05Z" fill="#274D55"/>
                                    </svg>
                                </span>
                                <span class="capacity-text"><?php echo intval($property['capacity']['max']); ?> Guests</span>
                            </div>
                        <?php endif; ?> -->
                        <?php if ($show_capacity_bedrooms && ($property['capacity']['bedrooms'] ?? '')): ?>
                            <div class="capacity-item">
                                <span class="icon-svg" aria-hidden="true">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M9.77778 2.66667V16H0V14.2222H1.77778V0H9.77778V0.888889H14.2222V14.2222H16V16H12.4444V2.66667H9.77778ZM6.22222 7.11111V8.88889H8V7.11111H6.22222Z" fill="#274D55"/>
                                    </svg>
                                </span>
                                <span class="capacity-text"><?php echo intval($property['capacity']['bedrooms']); ?> bedrooms</span>
                            </div>
                        <?php endif; ?>
                        <?php if ($show_capacity_beds && ($property['capacity']['beds'] ?? '')): ?>
                            <div class="capacity-item">
                                <span class="icon-svg" aria-hidden="true">
                                    <svg width="20" height="14" viewBox="0 0 20 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M16.3636 1.81818H9.09091V8.18182H1.81818V0H0V13.6364H1.81818V10.9091H18.1818V13.6364H20V5.45455C20 4.49012 19.6169 3.5652 18.9349 2.88325C18.253 2.2013 17.3281 1.81818 16.3636 1.81818ZM5.45455 7.27273C6.17786 7.27273 6.87156 6.98539 7.38302 6.47393C7.89448 5.96247 8.18182 5.26877 8.18182 4.54545C8.18182 3.82214 7.89448 3.12844 7.38302 2.61698C6.87156 2.10552 6.17786 1.81818 5.45455 1.81818C4.73123 1.81818 4.03754 2.10552 3.52607 2.61698C3.01461 3.12844 2.72727 3.82214 2.72727 4.54545C2.72727 5.26877 3.01461 5.96247 3.52607 6.47393C4.03754 6.98539 4.73123 7.27273 5.45455 7.27273Z" fill="#274D55"/>
                                    </svg>
                                </span>
                                <span class="capacity-text"><?php echo intval($property['capacity']['beds']); ?> beds</span>
                            </div>
                        <?php endif; ?>
                        <?php if ($show_capacity_bathrooms && ($property['capacity']['bathrooms'] ?? '')): ?>
                            <div class="capacity-item">
                                <span class="icon-svg" aria-hidden="true">
                                    <svg width="19" height="19" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1.15624 13.8751C1.15723 14.3605 1.26074 14.8402 1.46 15.2829C1.65925 15.7255 1.94975 16.1211 2.31247 16.4437V17.9219C2.31247 18.0752 2.37338 18.2223 2.4818 18.3307C2.59022 18.4391 2.73727 18.5 2.89059 18.5H4.04683C4.20016 18.5 4.3472 18.4391 4.45562 18.3307C4.56404 18.2223 4.62495 18.0752 4.62495 17.9219V17.3438H13.8748V17.9219C13.8748 18.0752 13.9358 18.2223 14.0442 18.3307C14.1526 18.4391 14.2996 18.5 14.453 18.5H15.6092C15.7625 18.5 15.9096 18.4391 16.018 18.3307C16.1264 18.2223 16.1873 18.0752 16.1873 17.9219V16.4437C16.55 16.1211 16.8405 15.7255 17.0398 15.2829C17.239 14.8402 17.3426 14.3605 17.3436 13.8751V12.1407H1.15624V13.8751ZM17.9217 9.2501H2.89059V2.50238C2.89092 2.35065 2.93618 2.20241 3.02065 2.07637C3.10513 1.95033 3.22504 1.85212 3.36526 1.79415C3.50548 1.73618 3.65973 1.72103 3.80855 1.75061C3.95737 1.7802 4.09409 1.85319 4.20148 1.96039L4.89775 2.6563C4.42333 3.73594 4.62278 4.79209 5.20921 5.53714L5.20307 5.54328C5.09506 5.65164 5.03441 5.7984 5.03441 5.9514C5.03441 6.10439 5.09506 6.25115 5.20307 6.35951L5.61172 6.76817C5.66541 6.82187 5.72915 6.86446 5.7993 6.89352C5.86944 6.92258 5.94463 6.93754 6.02056 6.93754C6.09649 6.93754 6.17168 6.92258 6.24183 6.89352C6.31198 6.86446 6.37572 6.82187 6.4294 6.76817L10.2367 2.9609C10.2904 2.90721 10.333 2.84347 10.362 2.77333C10.3911 2.70318 10.406 2.62799 10.406 2.55206C10.406 2.47613 10.3911 2.40094 10.362 2.33079C10.333 2.26064 10.2904 2.19691 10.2367 2.14322L9.82801 1.73456C9.71961 1.62623 9.57262 1.56537 9.41936 1.56537C9.2661 1.56537 9.11911 1.62623 9.0107 1.73456L9.00456 1.74071C8.25951 1.15428 7.20408 0.954826 6.12372 1.42924L5.42781 0.732973C5.07787 0.382996 4.63201 0.144655 4.14661 0.0480909C3.66121 -0.0484729 3.15808 0.00107871 2.70084 0.190479C2.2436 0.379879 1.8528 0.70062 1.57786 1.11214C1.30292 1.52366 1.1562 2.00746 1.15624 2.50238V9.2501H0.578119C0.424792 9.2501 0.277745 9.31101 0.169327 9.41943C0.0609087 9.52785 0 9.6749 0 9.82822L0 10.4063C0 10.5597 0.0609087 10.7067 0.169327 10.8151C0.277745 10.9236 0.424792 10.9845 0.578119 10.9845H17.9217C18.075 10.9845 18.222 10.9236 18.3305 10.8151C18.4389 10.7067 18.4998 10.5597 18.4998 10.4063V9.82822C18.4998 9.6749 18.4389 9.52785 18.3305 9.41943C18.222 9.31101 18.075 9.2501 17.9217 9.2501Z" fill="#274D55"/>
                                    </svg>
                                </span>
                                <span class="capacity-text"><?php echo intval($property['capacity']['bathrooms']); ?> baths</span>
                            </div>
                        <?php endif; ?>
    				</div>
                <?php endif; ?>
			</div>
		</a>
		<?php
		return ob_get_clean();
	}
}
