<?php

// === Register Settings ===
add_action('admin_init', function () {
    register_setting('digimanagement_settings_group', 'digimanagement_api_key');
    register_setting('digimanagement_settings_group', 'digimanagement_api_url');

    // === Main Config Section
    add_settings_section(
        'digimanagement_api_section',
        __('API Configuration', 'digim-integration'),
        function () {
            echo '<p>' . esc_html__('Configure your Hospitable API connection settings.', 'digim-integration') . '</p>';
        },
        'digimanagement-settings'
    );

    add_settings_field(
        'digimanagement_api_key',
        __('Personal Access Token', 'digim-integration'),
        'digim_render_api_key_field',
        'digimanagement-settings',
        'digimanagement_api_section'
    );

    add_settings_field(
        'digimanagement_api_url',
        __('API Endpoint', 'digim-integration'),
        'digim_render_api_url_field',
        'digimanagement-settings',
        'digimanagement_api_section'
    );
});

// === Render API Key Field ===
function digim_render_api_key_field()
{
    $value = esc_attr(get_option('digimanagement_api_key', ''));
    echo '<input type="password" name="digimanagement_api_key" value="' . $value . '" style="width: 100%;">';
    echo '<p class="description">' . esc_html__('Enter your Hospitable Personal Access Token.', 'digim-integration') . '</p>';
}

// === Render API URL Field ===
function digim_render_api_url_field()
{
    $value = esc_attr(get_option('digimanagement_api_url', ''));
    echo '<input type="text" name="digimanagement_api_url" value="' . $value . '" style="width: 100%;">';
    echo '<p class="description">' . esc_html__('The Hospitable API endpoint URL.', 'digim-integration') . '</p>';
}

// === Render Full Settings Page ===
function digimanagement_render_settings_page()
{
    echo '<div class="wrap">';
    echo '<h1>' . esc_html__('DigiManagement Settings', 'DigiM') . '</h1>';
    echo '<p>' . esc_html__('Configure your Hospitable integration settings below. You will need a Personal Access Token from your Hospitable account.', 'DigiM') . '</p>';

    echo '<form method="post" action="options.php">';
    settings_fields('digimanagement_settings_group');
    do_settings_sections('digimanagement-settings');
    submit_button();
    echo '</form>';

    // If Test API button clicked
    if (isset($_POST['digim_test_api'])) {
        digimanagement_run_api_test();
    }

    // Show Test API form
    echo '<form method="post" style="margin-top: 30px;">';
    echo '<input type="hidden" name="digim_test_api" value="1">';
    submit_button('🔌 Test API Connection', 'secondary', '', false);
    echo '</form>';

    echo '</div>';
}

// === Handle Test API Button Logic ===
function digimanagement_run_api_test()
{
    $api_token = get_option('digimanagement_api_key', '');
    $api_url = rtrim(get_option('digimanagement_api_url', ''), '/');

    if (!$api_token || !$api_url) {
        echo '<div class="notice notice-error"><p><strong>Missing API Key or URL.</strong></p></div>';
        return;
    }

    $response = wp_remote_get($api_url . '/me', [
        'headers' => [
            'Authorization' => 'Bearer ' . $api_token,
            'Accept'        => 'application/json',
        ],
        'timeout' => 10,
    ]);

    if (is_wp_error($response)) {
        echo '<div class="notice notice-error"><p><strong>API Test Failed:</strong> ' . esc_html($response->get_error_message()) . '</p></div>';
        return;
    }

    $code = wp_remote_retrieve_response_code($response);
    $body = json_decode(wp_remote_retrieve_body($response), true);

    if ($code === 200 && isset($body['email'])) {
        echo '<div class="notice notice-success"><p><strong>Success!</strong> Connected as <code>' . esc_html($body['email']) . '</code> ✅</p></div>';
    } else {
        echo '<div class="notice notice-warning"><p><strong>API Response:</strong> HTTP ' . esc_html($code) . '</p></div>';
    }
}
