<div class="digim-main">
    <!-- Search Form -->
    <div class="bg-white">
        <form class="digimanagement-search" method="get">

            <div class="search-grid">
                <!-- WHERE -->
                <div class="search-group">
                    <label>Where</label>
                    <select name="property_search" class="city-select">
                        <option value="">Search destinations</option>
                        <?php foreach ($destination_names as $city): ?>
                            <option value="<?php echo esc_attr($city); ?>" <?php selected($search, $city); ?>>
                                <?php echo esc_html($city); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- CHECKIN / CHECKOUT -->
                <div class="search-group datecal">
                    <label>Check in / Check out</label>
                    <input type="text" name="date_range" class="flatpickr-range" placeholder="Add dates">
                    <input type="hidden" name="checkin" class="checkin-hidden" value="<?php echo esc_attr($checkin); ?>">
                    <input type="hidden" name="checkout" class="checkout-hidden" value="<?php echo esc_attr($checkout); ?>">
                </div>


                <!-- WHO -->
                <div class="search-group">
                    <label>Who</label>
                    <div class="guest-dropdown-wrapper">
                        <button type="button" class="guest-toggle">Add guests</button>
                        <div class="guest-dropdown">
                            <?php
                            $guest_types = [
                                'adults' => ['label' => 'Adults', 'desc' => 'Ages 13 or above'],
                                'children' => ['label' => 'Children', 'desc' => 'Ages 2–12'],
                                'infants' => ['label' => 'Infants', 'desc' => 'Under 2'],
                                'pets' => ['label' => 'Pets', 'desc' => '<a href="#">Bringing a service animal?</a>'],
                            ];
                            foreach ($guest_types as $type => $meta):
                                $val = intval($_GET[$type] ?? 0);
                            ?>
                                <div class="guest-row">
                                    <div class="guest-labels">
                                        <span><?= $meta['label'] ?></span>
                                        <span><?= $meta['desc'] ?></span>
                                    </div>
                                    <div class="guest-controls">
                                        <button type="button" class="minus">−</button>
                                        <span class="guest-count"><?= $val ?></span>
                                        <button type="button" class="plus">+</button>
                                        <input type="hidden" name="<?= $type ?>" value="<?= $val ?>" id="<?= $type ?>-input">
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <input type="hidden" name="guests" value="<?php echo esc_attr($guest_count); ?>" id="total-guests">
                    </div>
                </div>

                <!-- BUTTONS -->
                <div class="search-buttons">
                    <button type="button" class="reset-button" title="Reset"><i class="fas fa-undo"></i></button>
                    <button type="submit" class="search-button" title="Search"><i class="fas fa-search"></i></button>
                </div>
            </div>

        </form>

        <script>
            document.addEventListener("DOMContentLoaded", function() {
                const wrapper = document.querySelector(".guest-dropdown-wrapper");
                const toggleBtn = wrapper.querySelector(".guest-toggle");
                const guestRows = wrapper.querySelectorAll(".guest-row");
                const totalGuestsInput = wrapper.querySelector('input[name="guests"]');

                const updateGuestSummary = () => {
                    let guests = 0;
                    let infants = 0;
                    let pets = 0;

                    guestRows.forEach(row => {
                        const input = row.querySelector('input[type="hidden"]');
                        const count = parseInt(input.value) || 0;
                        const type = input.name;

                        if (type === "adults" || type === "children") guests += count;
                        else if (type === "infants") infants = count;
                        else if (type === "pets") pets = count;

                        row.querySelector(".guest-count").textContent = count;
                    });

                    let text = guests > 0 ? `${guests} guest${guests > 1 ? 's' : ''}` : "Add guests";
                    if (infants > 0) text += `, ${infants} infant${infants > 1 ? 's' : ''}`;
                    if (pets > 0) text += `, ${pets} pet${pets > 1 ? 's' : ''}`;

                    toggleBtn.textContent = text;
                    totalGuestsInput.value = guests;
                };

                // Apply increment/decrement events
                guestRows.forEach(row => {
                    const input = row.querySelector('input[type="hidden"]');
                    const minus = row.querySelector(".minus");
                    const plus = row.querySelector(".plus");

                    minus.addEventListener("click", () => {
                        let val = parseInt(input.value) || 0;
                        input.value = Math.max(0, val - 1);
                        updateGuestSummary();
                    });

                    plus.addEventListener("click", () => {
                        let val = parseInt(input.value) || 0;
                        input.value = val + 1;
                        updateGuestSummary();
                    });
                });

                // Toggle dropdown
                toggleBtn.addEventListener("click", () => {
                    wrapper.querySelector(".guest-dropdown").classList.toggle("active");
                });

                document.addEventListener("click", e => {
                    if (!wrapper.contains(e.target)) {
                        wrapper.querySelector(".guest-dropdown").classList.remove("active");
                    }
                });

                // Reset form
                document.querySelector('.reset-button').addEventListener("click", () => {
                    window.location.href = window.location.pathname;
                });

                updateGuestSummary();
            });
        </script>

        <?php
        $grid_class = $layout_style === 'list' ? 'digimanagement-list' : "digimanagement-grid grid-cols-$grid_columns";
        ?>
        <div class="dm-grid <?php echo $show_map ? 'map-listing' : ''; ?>">
            <div class="dm-property">
                <div class="<?php echo esc_attr($grid_class); ?>">

                    <?php if (empty($properties_to_show)): ?>
                        <p class="no-results" style="margin-top: 1rem;">No listings match your filters. Try changing date, location, or guest count.</p>
                    <?php else: ?>
                        <?php foreach ($properties_to_show as $property):
                            $original_picture = $property['picture'] ?? '';
                            $high_res_picture = preg_replace('/\?.*/', '', $original_picture);
                            $uuid = $property['uuid'] ?? $property['id'] ?? '';
                            $query_params = $_GET;
                            $query_string = http_build_query($query_params);
                            $property_url = site_url('/property/' . esc_attr($uuid) . '/') . ($query_string ? '?' . $query_string : ''); ?>
                            <a href="<?php echo esc_url($property_url); ?>" class="digimanagement-card <?php echo esc_attr($card_style); ?>">
                                <?php if (!empty($high_res_picture)): ?>
                                    <div class="digim-card-img">
                                        <img src="<?php echo esc_url($high_res_picture); ?>" alt="<?php echo esc_attr($property['name']); ?>" />
                                    </div>
                                <?php endif; ?>
                                <div class="digim-card-content">
                                    <h3 class="digim-title"><?php echo esc_html($property['name'] ?? 'Untitled'); ?></h3>
                                    <?php if (!empty($property['address']['display'])): ?>
                                        <p class="digim-address"><?php echo esc_html($property['address']['display']); ?></p>
                                    <?php endif; ?>

                                    <p class="digim-capacity">
                                        <?php if ($property['capacity']['max'] ?? ''): ?>
                                            <span><i class="fas fa-user-group"></i> <?= esc_html($property['capacity']['max']) ?> guests</span>
                                        <?php endif; ?>
                                        <?php if ($property['capacity']['bedrooms'] ?? ''): ?>
                                            <span><i class="fas fa-door-open"></i> <?= esc_html($property['capacity']['bedrooms']) ?> bedrooms</span>
                                        <?php endif; ?>
                                        <?php if ($property['capacity']['beds'] ?? ''): ?>
                                            <span><i class="fas fa-bed"></i> <?= esc_html($property['capacity']['beds']) ?> beds</span>
                                        <?php endif; ?>
                                        <?php if ($property['capacity']['bathrooms'] ?? ''): ?>
                                            <span><i class="fas fa-bath"></i> <?= esc_html($property['capacity']['bathrooms']) ?> baths</span>
                                        <?php endif; ?>
                                    </p>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <?php if ($total_pages > 1): ?>
                    <div class="digimanagement-pagination">
                        <?php
                        $q = $_GET;
                        $show = 3;
                        $dot = false;
                        for ($i = 1; $i <= $total_pages; $i++) {
                            if ($i <= $show || $i > $total_pages - $show) {
                                $q['property_page'] = $i;
                                $url = '?' . esc_attr(http_build_query($q));
                                echo '<a href="' . $url . '" class="' . ($i == $current_page ? 'active' : '') . '">' . $i . '</a>';
                                $dot = true;
                            } elseif ($dot) {
                                echo '<span class="dots">…</span>';
                                $dot = false;
                            }
                        }
                        ?>
                    </div>
                <?php endif; ?>
            </div>

            <?php if ($show_map): ?>
                <div class="digimanagement-map">
                    <?php if (is_admin() && isset($_GET['page']) && $_GET['page'] === 'DigiM-style'): ?>
                        <img src="<?php echo plugin_dir_url(__FILE__) . '../assets/mappreview.png'; ?>" alt="Map Preview" style="width: 100%; border-radius: 10px;" />
                    <?php else: ?>
                        <div id="digim-map" style="width: 100%; height: 400px; border-radius: 10px;"></div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <style>
        .search-button,
        .digimanagement-pagination a.active {
            background: <?php echo $primary_color; ?> !important;
        }

        .digimanagement-pagination a.active {
            border-color: <?php echo $primary_color; ?> !important;
        }

        .digimanagement-card.highlight {
            outline: 2px solid <?php echo $primary_color; ?> !important;
            box-shadow: 0 0 5px <?php echo $primary_color; ?> !important;
        }
    </style>
</div>