document.addEventListener("DOMContentLoaded", function () {
    const selects = document.querySelectorAll("#digim_layout_style, #digim_grid_columns");
  
    selects.forEach((select) => {
      select.addEventListener("change", () => {
        const layout = document.getElementById("digim_layout_style").value;
        const columns = document.getElementById("digim_grid_columns").value;
  
        const previewContainer = document.getElementById("digim-preview");
  
        const xhr = new XMLHttpRequest();
        xhr.open("POST", ajaxurl, true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onload = function () {
          if (xhr.status === 200) {
            previewContainer.innerHTML = xhr.responseText;
          }
        };
  
        xhr.send(
          `action=digim_preview_shortcode&layout=${layout}&columns=${columns}`
        );
      });
    });
  });
  