<?php
add_action('wp_enqueue_scripts', function () {
    global $post;
    
    // Check if we should load the styles and scripts
    $should_load = false;
    
    // Check if shortcode exists in post content
    if (is_singular() && has_shortcode(get_post()->post_content, 'digimanagement_listings')) {
        $should_load = true;
    }
    
    // Check if we're on a page that might contain listings (like /listings/)
    if (is_page() && (strpos($_SERVER['REQUEST_URI'], '/listings') !== false || 
                     strpos($_SERVER['REQUEST_URI'], 'listings') !== false)) {
        $should_load = true;
    }
    
    // Check if we're on a property single page
    if (get_query_var('dm_property_uuid')) {
        $should_load = true;
    }
    
    // Check if the current page template or content contains digim classes
    if (isset($post) && (strpos($post->post_content, 'digim-main') !== false || 
                        strpos($post->post_content, 'digimanagement') !== false)) {
        $should_load = true;
    }
    
    // Fallback: Check if we're on any page that might need the plugin styles
    // This can be customized based on your specific needs
    $force_load_pages = ['listings', 'properties', 'search'];
    foreach ($force_load_pages as $page_slug) {
        if (is_page($page_slug) || strpos($_SERVER['REQUEST_URI'], $page_slug) !== false) {
            $should_load = true;
            break;
        }
    }
    
    if (!$should_load) return;
    
    wp_enqueue_style('leaflet', 'https://unpkg.com/leaflet/dist/leaflet.css');
    wp_enqueue_style('leaflet-cluster', 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.css');
    wp_enqueue_style('leaflet-cluster-default', 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css');
    wp_enqueue_style('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css');
    wp_enqueue_style('flatpickr-css', 'https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css');
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css');

    wp_enqueue_script('leaflet', 'https://unpkg.com/leaflet/dist/leaflet.js', [], null, true);
    wp_enqueue_script('leaflet-cluster', 'https://unpkg.com/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js', ['leaflet'], null, true);
    wp_enqueue_script('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js', ['jquery'], null, true);
    wp_enqueue_script('flatpickr-js', 'https://cdn.jsdelivr.net/npm/flatpickr', [], null, true);

    $map_init_path = plugin_dir_path(__FILE__) . '../assets/js/map-init.js';
    if (file_exists($map_init_path)) {
        wp_enqueue_script('digim-map-init', plugin_dir_url(__FILE__) . '../assets/js/map-init.js', ['leaflet', 'leaflet-cluster'], filemtime($map_init_path), true);
    }

    // Inline Select2 init
    add_action('wp_footer', function () {
?>
        <script>
            jQuery(document).ready(function($) {
                $('select[name="property_search"]').select2({
                    placeholder: "Search destination",
                    allowClear: true,
                    width: '100%'
                });
            });
        </script>
<?php
    }, 100);
});

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('digim-fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css', [], '6.5.2');
}, 5);

add_shortcode('digimanagement_listings', 'digimanagement_hospitable_listings_shortcode');

// ✅ Load all properties (with pagination + caching)
function digim_get_all_properties()
{
    $cache_key = 'digim_all_properties';
    $all_properties = get_transient($cache_key);

    if (!$all_properties) {
        $all_properties = [];
        $page = 1;

        do {
            $response = wp_remote_get(digimanagement_get_api_url() . "/properties?page=$page", [
                'headers' => [
                    'Authorization' => digimanagement_get_api_token(),
                    'Accept' => 'application/json',
                ],
                'timeout' => 15,
            ]);

            if (is_wp_error($response)) break;

            $data = json_decode(wp_remote_retrieve_body($response), true);
            if (!isset($data['data'])) break;

            $all_properties = array_merge($all_properties, $data['data']);
            $has_more = isset($data['links']['next']) && $data['links']['next'];
            $page++;
        } while ($has_more);

        set_transient($cache_key, $all_properties, 60 * 10); // cache for 10 mins
    }

    return $all_properties;
}

// ✅ Main shortcode logic
function digimanagement_hospitable_listings_shortcode()
{
    $layout_style = get_option('digim_layout_style', 'grid');
    $per_page = intval(get_option('digim_cards_per_page', 12));
    $grid_columns = intval(get_option('digim_grid_columns', 3));
    $card_style = get_option('digim_card_style', 'classic');
    $primary_color = get_option('digim_primary_color', '#0073aa');
    error_log("Primary color from database: " . $primary_color);
    $show_map = get_option('digim_show_map', false);

    $search = sanitize_text_field($_GET['property_search'] ?? '');
    $checkin = sanitize_text_field($_GET['checkin'] ?? '');
    $checkout = sanitize_text_field($_GET['checkout'] ?? '');
    $current_page = max(1, intval($_GET['property_page'] ?? 1));

    // 🔄 Fetch all properties
    $all_properties = digim_get_all_properties();

    // 🔎 Filter: City
    if ($search) {
        $all_properties = array_filter(
            $all_properties,
            fn($p) =>
            stripos($p['address']['city'] ?? '', $search) !== false
        );
    }

    // 👥 Guests (adults + children + infants)
    $adults = intval($_GET['adults'] ?? 0);
    $children = intval($_GET['children'] ?? 0);
    $infants = intval($_GET['infants'] ?? 0);
    $total_guests = $adults + $children + $infants;

    if ($total_guests > 0) {
        $all_properties = array_filter(
            $all_properties,
            fn($p) => ($p['capacity']['max'] ?? 0) >= $total_guests
        );
    }

    // 📅 Availability (calendar check)
    if ($checkin && $checkout) {
        $uuids = array_map(fn($p) => $p['uuid'] ?? $p['id'], $all_properties);
        $available_uuids = digimanagement_parallel_calendar_check($uuids, $checkin, $checkout);
        $all_properties = array_filter(
            $all_properties,
            fn($p) =>
            in_array($p['uuid'] ?? $p['id'], $available_uuids)
        );
    }

    // 📦 Pagination
    $total = count($all_properties);
    $total_pages = ceil($total / $per_page);
    $properties_to_show = array_slice($all_properties, ($current_page - 1) * $per_page, $per_page);

    // 🧭 Dropdown values
    $destination_names = array_unique(array_filter(array_map(
        fn($p) =>
        $p['address']['city'] ?? '',
        $all_properties
    )));
    sort($destination_names);

    // 🗺️ Map markers
    $marker_data = array_map(function ($p) {
        $property_slug = digimanagement_create_property_slug(
            $p['name'] ?? '', 
            $p['address']['city'] ?? ''
        );
        return [
            'lat' => $p['address']['coordinates']['latitude'] ?? $p['address']['latitude'] ?? null,
            'lng' => $p['address']['coordinates']['longitude'] ?? $p['address']['longitude'] ?? null,
            'name' => $p['name'] ?? 'No Name',
            'address' => $p['address']['display'] ?? '',
            'img' => $p['picture'] ?? '',
            'url' => site_url('/property/' . $property_slug . '/'),
        ];
    }, array_filter(
        $properties_to_show,
        fn($p) =>
        !empty($p['address']['coordinates']['latitude'] ?? $p['address']['latitude'] ?? null)
    ));

    if ($show_map) {
        wp_localize_script('digim-map-init', 'digimMapData', ['markers' => $marker_data]);
    }

    // 🔄 Render listings
    ob_start();
    include plugin_dir_path(__FILE__) . '/listings-template.php';
    return ob_get_clean();
}

// === SEARCH-ONLY SHORTCODE: [digim_search_form] ==============================

// Enqueue only what the form needs when the shortcode is present (no map libs)
add_action('wp_enqueue_scripts', function () {
    global $post;
    
    // Check if we should load the styles and scripts
    $should_load = false;
    
    // Check if shortcode exists in post content
    if (is_singular() && has_shortcode(get_post()->post_content, 'digim_search_form')) {
        $should_load = true;
    }
    
    // Check if we're on a page that might contain listings (like /listings/)
    if (is_page() && (strpos($_SERVER['REQUEST_URI'], '/listings') !== false || 
                     strpos($_SERVER['REQUEST_URI'], 'listings') !== false)) {
        $should_load = true;
    }
    
    // Check if we're on a property single page
    if (get_query_var('dm_property_uuid')) {
        $should_load = true;
    }
    
    // Check if the current page template or content contains digim classes
    if (isset($post) && (strpos($post->post_content, 'digim-main') !== false || 
                        strpos($post->post_content, 'digimanagement') !== false)) {
        $should_load = true;
    }
    
    // Fallback: Check if we're on any page that might need the plugin styles
    // This can be customized based on your specific needs
    $force_load_pages = ['listings', 'properties', 'search'];
    foreach ($force_load_pages as $page_slug) {
        if (is_page($page_slug) || strpos($_SERVER['REQUEST_URI'], $page_slug) !== false) {
            $should_load = true;
            break;
        }
    }
    
    if (!$should_load) return;

    // Styles
    wp_enqueue_style('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css', [], null);
    wp_enqueue_style('flatpickr-css', 'https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css', [], null);
    wp_enqueue_style('digim-fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css', [], '6.5.2');

    // From inside a file under /plugins/DigiM/templates/...
    $plugin_dir = plugin_dir_path(dirname(__FILE__)); // -> /wp-content/plugins/DigiM/
    $plugin_url = plugin_dir_url(dirname(__FILE__));  // -> https://.../wp-content/plugins/DigiM/
    $rel        = 'assets/css/style.css';
    $style_path = $plugin_dir . $rel;
    $style_url  = $plugin_url . $rel;
    if (file_exists($style_path)) {
        wp_enqueue_style('digim-style', $style_url, [], filemtime($style_path));
    }

    // Scripts
    wp_enqueue_script('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js', ['jquery'], null, true);
    wp_enqueue_script('flatpickr-js', 'https://cdn.jsdelivr.net/npm/flatpickr', [], null, true);
}, 5);

// [digim_search_form listingsurl="/listings"]
add_shortcode('digim_search_form', function ($atts = []) {
    // Accept optional redirection target
    $atts = shortcode_atts([
        'listingsurl' => '', // e.g. "/listings" (relative) or full URL
    ], $atts, 'digim_search_form');

    $listings_url = trim($atts['listingsurl']);
    // Allow relative paths; esc_url handles both
    $form_action = $listings_url ? esc_url($listings_url) : '';

    // Current filters from URL
    $search   = sanitize_text_field($_GET['property_search'] ?? '');
    $checkin  = sanitize_text_field($_GET['checkin'] ?? '');
    $checkout = sanitize_text_field($_GET['checkout'] ?? '');

    $adults   = intval($_GET['adults'] ?? 0);
    $children = intval($_GET['children'] ?? 0);
    $infants  = intval($_GET['infants'] ?? 0);
    $pets     = intval($_GET['pets'] ?? 0);
    $guest_count = max(0, $adults + $children + $infants); // matches listings calc

    // Build destination dropdown values from cached properties
    if (!function_exists('digim_get_all_properties')) {
        return '<p style="color:#c00">digim_get_all_properties() not found.</p>';
    }
    $all_properties = digim_get_all_properties();
    $destination_names = array_unique(array_filter(array_map(
        fn($p) => $p['address']['city'] ?? '',
        $all_properties
    )));
    sort($destination_names);

    ob_start();
    ?>
    <div class="digim-main onlysearch">
        <form class="digimanagement-search" method="get" action="<?php echo $form_action; ?>" data-listings-url="<?php echo esc_attr($listings_url); ?>">
            <div class="search-grid">
                <!-- WHERE -->
                <div class="search-group">
                    <label>Where</label>
                    <select name="property_search" class="city-select">
                        <option value="">Search destinations</option>
                        <?php foreach ($destination_names as $city): ?>
                            <option value="<?php echo esc_attr($city); ?>" <?php selected($search, $city); ?>>
                                <?php echo esc_html($city); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- CHECKIN / CHECKOUT -->
                <div class="search-group datecal">
                    <label>Check in / Check out</label>
                    <input
                        type="text"
                        name="date_range"
                        class="flatpickr-range"
                        placeholder="Add dates"
                        value="<?php
                                echo ($checkin && $checkout)
                                    ? esc_attr(date('M j, Y', strtotime($checkin)) . ' to ' . date('M j, Y', strtotime($checkout)))
                                    : '';
                                ?>">
                    <input type="hidden" name="checkin" class="checkin-hidden" value="<?php echo esc_attr($checkin); ?>">
                    <input type="hidden" name="checkout" class="checkout-hidden" value="<?php echo esc_attr($checkout); ?>">
                </div>

                <!-- WHO -->
                <div class="search-group">
                    <label>Who</label>
                    <div class="guest-dropdown-wrapper">
                        <button type="button" class="guest-toggle">
                            <?php
                            $btn = 'Add guests';
                            $g   = $adults + $children;
                            if ($g > 0) {
                                $btn = $g . ' guest' . ($g > 1 ? 's' : '');
                                if ($infants > 0) $btn .= ", $infants infant" . ($infants > 1 ? 's' : '');
                                if ($pets    > 0) $btn .= ", $pets pet" . ($pets > 1 ? 's' : '');
                            }
                            echo esc_html($btn);
                            ?>
                        </button>
                        <div class="guest-dropdown">
                            <?php
                            $guest_types = [
                                'adults'   => ['label' => 'Adults',   'desc' => 'Ages 13 or above',         'val' => $adults],
                                'children' => ['label' => 'Children', 'desc' => 'Ages 2–12',                'val' => $children],
                                'infants'  => ['label' => 'Infants',  'desc' => 'Under 2',                 'val' => $infants],
                                'pets'     => ['label' => 'Pets',     'desc' => '<a href="#">Bringing a service animal?</a>', 'val' => $pets],
                            ];
                            foreach ($guest_types as $type => $meta): ?>
                                <div class="guest-row">
                                    <div class="guest-labels">
                                        <span><?php echo esc_html($meta['label']); ?></span>
                                        <span><?php echo $meta['desc']; // may contain link 
                                                ?></span>
                                    </div>
                                    <div class="guest-controls">
                                        <button type="button" class="minus" aria-label="Decrease <?php echo esc_attr($type); ?>">−</button>
                                        <span class="guest-count"><?php echo intval($meta['val']); ?></span>
                                        <button type="button" class="plus" aria-label="Increase <?php echo esc_attr($type); ?>">+</button>
                                        <input type="hidden" name="<?php echo esc_attr($type); ?>" value="<?php echo intval($meta['val']); ?>">
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <input type="hidden" name="guests" value="<?php echo esc_attr($guest_count); ?>">
                    </div>
                </div>

                <!-- BUTTONS -->
                <div class="search-buttons">
                    <button type="button" class="reset-button" title="Reset"><i class="fas fa-undo"></i></button>
                    <button type="submit" class="search-button" title="Search"><i class="fas fa-search"></i></button>
                </div>
            </div>
        </form>

        <script>
            document.addEventListener("DOMContentLoaded", function() {
                // Select2 for city
                if (window.jQuery) {
                    jQuery(function($) {
                        $('select[name="property_search"]').select2({
                            placeholder: "Search destination",
                            allowClear: true,
                            width: '100%'
                        });
                    });
                }

                // Flatpickr range -> hidden fields
                (function() {
                    var rangeInput = document.querySelector('.digimanagement-search .flatpickr-range');
                    if (!rangeInput || !window.flatpickr) return;

                    var checkinHidden = document.querySelector('.digimanagement-search .checkin-hidden');
                    var checkoutHidden = document.querySelector('.digimanagement-search .checkout-hidden');

                    flatpickr(rangeInput, {
                        mode: "range",
                        dateFormat: "Y-m-d",
                        altInput: true,
                        altFormat: "M j, Y",
                        allowInput: true,
                        defaultDate: (function() {
                            var ci = checkinHidden && checkinHidden.value ? checkinHidden.value : null;
                            var co = checkoutHidden && checkoutHidden.value ? checkoutHidden.value : null;
                            return (ci && co) ? [ci, co] : [];
                        })(),
                        onChange: function(selectedDates, _dateStr, instance) {
                            if (selectedDates.length === 2) {
                                if (checkinHidden) checkinHidden.value = instance.formatDate(selectedDates[0], "Y-m-d");
                                if (checkoutHidden) checkoutHidden.value = instance.formatDate(selectedDates[1], "Y-m-d");
                            } else if (selectedDates.length === 1) {
                                if (checkinHidden) checkinHidden.value = instance.formatDate(selectedDates[0], "Y-m-d");
                                if (checkoutHidden) checkoutHidden.value = "";
                            } else {
                                if (checkinHidden) checkinHidden.value = "";
                                if (checkoutHidden) checkoutHidden.value = "";
                            }
                        }
                    });
                })();

                // Guests dropdown + summary
                (function() {
                    var wrapper = document.querySelector(".digimanagement-search .guest-dropdown-wrapper");
                    if (!wrapper) return;

                    var toggleBtn = wrapper.querySelector(".guest-toggle");
                    var dropdown = wrapper.querySelector(".guest-dropdown");
                    var guestRows = wrapper.querySelectorAll(".guest-row");
                    var totalGuestsInput = wrapper.querySelector('input[name="guests"]');

                    function updateGuestSummary() {
                        var guests = 0,
                            infants = 0,
                            pets = 0;

                        guestRows.forEach(function(row) {
                            var input = row.querySelector('input[type="hidden"]');
                            var count = parseInt(input.value) || 0;
                            var type = input.name;

                            if (type === "adults" || type === "children") guests += count;
                            else if (type === "infants") infants = count;
                            else if (type === "pets") pets = count;

                            var label = row.querySelector(".guest-count");
                            if (label) label.textContent = count;
                        });

                        var text = guests > 0 ? (guests + " guest" + (guests > 1 ? "s" : "")) : "Add guests";
                        if (infants > 0) text += ", " + infants + " infant" + (infants > 1 ? "s" : "");
                        if (pets > 0) text += ", " + pets + " pet" + (pets > 1 ? "s" : "");

                        toggleBtn.textContent = text;
                        if (totalGuestsInput) totalGuestsInput.value = Math.max(0, guests + infants); // keep parity with server
                    }

                    guestRows.forEach(function(row) {
                        var input = row.querySelector('input[type="hidden"]');
                        var minus = row.querySelector(".minus");
                        var plus = row.querySelector(".plus");

                        minus.addEventListener("click", function() {
                            input.value = Math.max(0, (parseInt(input.value) || 0) - 1);
                            updateGuestSummary();
                        });
                        plus.addEventListener("click", function() {
                            input.value = (parseInt(input.value) || 0) + 1;
                            updateGuestSummary();
                        });
                    });

                    toggleBtn.addEventListener("click", function() {
                        dropdown.classList.toggle("active");
                    });

                    document.addEventListener("click", function(e) {
                        if (!wrapper.contains(e.target)) dropdown.classList.remove("active");
                    });

                    // Reset behavior: if the shortcode had listingsurl, reset to that; else, to current path.
                    var formEl = document.querySelector('.digimanagement-search');
                    var resetBtn = document.querySelector('.digimanagement-search .reset-button');
                    if (resetBtn && formEl) {
                        var target = formEl.getAttribute('data-listings-url') || window.location.pathname;
                        resetBtn.addEventListener("click", function() {
                            window.location.href = target;
                        });
                    }

                    updateGuestSummary();
                })();
            });
        </script>
        <?php 
        // Helper function to darken hex color
        function digim_darken_color($hex, $percent = 20) {
            $hex = str_replace('#', '', $hex);
            $r = hexdec(substr($hex, 0, 2));
            $g = hexdec(substr($hex, 2, 2));
            $b = hexdec(substr($hex, 4, 2));
            
            $r = max(0, min(255, $r - ($r * $percent / 100)));
            $g = max(0, min(255, $g - ($g * $percent / 100)));
            $b = max(0, min(255, $b - ($b * $percent / 100)));
            
            return '#' . str_pad(dechex($r), 2, '0', STR_PAD_LEFT) . str_pad(dechex($g), 2, '0', STR_PAD_LEFT) . str_pad(dechex($b), 2, '0', STR_PAD_LEFT);
        }
        
        $primary_color_hover = digim_darken_color($primary_color, 10);
        $primary_color_active = digim_darken_color($primary_color, 20);
        ?>

        <style>
            :root {
                --digim-primary-color: <?php echo $primary_color; ?>;
                --digim-primary-color-dark: <?php echo $primary_color; ?>dd;
                --digim-primary-color-darker: <?php echo $primary_color; ?>cc;
            }
            
            .digim-main .digimanagement-search .search-buttons button.search-button {
                background: <?php echo $primary_color; ?> !important;
                background-color: <?php echo $primary_color; ?> !important;
                color: #fff !important;
            }
            
            .digim-main .digimanagement-search .search-buttons button.search-button:hover,
            .digim-main .digimanagement-search .search-buttons button.search-button:focus {
                background: <?php echo $primary_color_hover; ?> !important;
                background-color: <?php echo $primary_color_hover; ?> !important;
                color: #fff !important;
            }
            
            .digim-main .digimanagement-search .search-buttons button.search-button:active {
                background: <?php echo $primary_color_active; ?> !important;
                background-color: <?php echo $primary_color_active; ?> !important;
                color: #fff !important;
            }
            
            .digim-main .digimanagement-pagination a.active {
                background: <?php echo $primary_color; ?> !important;
                border-color: <?php echo $primary_color; ?> !important;
            }

            .digimanagement-card.highlight {
                outline: 2px solid <?php echo $primary_color; ?> !important;
                box-shadow: 0 0 5px <?php echo $primary_color; ?> !important;
            }

            /* Minimal safety styles; keeps your structure intact */
            .guest-dropdown-wrapper {
                position: relative;
            }

            .guest-toggle {
                display: inline-flex;
                align-items: center;
                gap: .5rem;
                padding: .5rem .75rem;
                border: 1px solid #ddd;
                border-radius: 8px;
                background: #fff;
                cursor: pointer;
            }

            .guest-dropdown {
                position: absolute;
                top: 100%;
                left: 0;
                z-index: 50;
                width: 320px;
                max-width: 90vw;
                background: #fff;
                border: 1px solid #e5e7eb;
                border-radius: 12px;
                padding: .75rem;
                margin-top: .5rem;
                box-shadow: 0 10px 20px rgba(0, 0, 0, .08);
                display: none;
            }

            .guest-dropdown.active {
                display: block;
            }

            .guest-row {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 1rem;
                padding: .5rem 0;
            }

            .guest-labels {
                display: flex;
                flex-direction: column;
                gap: .15rem;
            }

            .guest-labels span:first-child {
                font-weight: 600;
            }

            .guest-labels span:last-child {
                font-size: .85rem;
                color: #6b7280;
            }

            .guest-controls {
                display: flex;
                align-items: center;
                gap: .75rem;
            }

            .guest-controls .minus,
            .guest-controls .plus {
                width: 32px;
                height: 32px;
                border-radius: 50%;
                border: 1px solid #ddd;
                background: #fff;
                line-height: 30px;
                text-align: center;
                font-size: 18px;
                cursor: pointer;
            }

            .search-grid {
                display: grid;
                grid-template-columns: repeat(4, minmax(0, 1fr));
                gap: 12px;
            }

            @media (max-width:768px) {
                .search-grid {
                    grid-template-columns: 1fr;
                }
            }

            .search-buttons {
                display: flex;
                align-items: center;
                gap: .5rem;
                justify-content: flex-end;
            }

            .search-button {
                padding: .6rem .9rem;
                border-radius: 10px;
                color: #fff;
                border: 1px solid transparent;
            }

            .reset-button {
                padding: .6rem .9rem;
                border-radius: 10px;
                border: 1px solid #ddd;
                background: #fff;
            }
        </style>
    </div>
<?php
    return ob_get_clean();
});
